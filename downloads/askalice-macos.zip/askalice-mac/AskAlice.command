#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
if [ "$(uname -m)" = "arm64" ]; then NODE="$DIR/node-arm64"; else NODE="$DIR/node-x64"; fi
exec "$NODE" "$DIR/askalice.mjs" ui
