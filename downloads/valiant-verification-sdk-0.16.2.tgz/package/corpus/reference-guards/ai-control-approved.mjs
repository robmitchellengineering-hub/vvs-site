#!/usr/bin/env node
// ai-control-approved.mjs — reference guard (AI control standard).
//
// PRINCIPLE (Aza Raskin): "what gets measured gets optimized" — the industry measures AI
// capability, not control. This guard measures control: every action an AI agent takes must
// carry an EXPLICIT human approval. A mutation that strips the approval must go red — a guard
// that never failed proves nothing.
//
// CONVENTION. A controlled agent appends to `ai-actions.jsonl` in the repo, one NDJSON line
// per action:  {"action":"...","approved":true,"source":"...","restated":"..."}
// Exit 0 = every action approved (or nothing recorded) · 1 = an unapproved action exists.
import { readFileSync, existsSync } from "node:fs";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

const LEDGER = "ai-actions.jsonl";

export function check(dir) {
  const p = join(resolve(dir), LEDGER);
  if (!existsSync(p)) return { ok: true, detail: "no action ledger — nothing recorded" };
  const lines = readFileSync(p, "utf8").split("\n").filter((l) => l.trim());
  const bad = [];
  lines.forEach((l, i) => {
    let a;
    try { a = JSON.parse(l); } catch { bad.push(`line ${i + 1}: not JSON`); return; }
    const what = String(a.action ?? "").slice(0, 40);
    if (a.approved === true) return;                                        // the human said yes
    if (a.approved === false) bad.push(`line ${i + 1}: "${what}" was REJECTED — the human said no`);   // a control break
    else bad.push(`line ${i + 1}: "${what}" is PENDING — awaiting the human's yes`);                    // not yet under control
  });
  return { ok: bad.length === 0, detail: bad.length ? bad.join(" · ") : `${lines.length} action(s), all approved` };
}

const IS_MAIN = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;
if (IS_MAIN) {
  if (process.argv.includes("--self-test")) {
    const { mkdtempSync, writeFileSync, rmSync } = await import("node:fs");
    const { tmpdir } = await import("node:os");
    let fail = 0;
    const good = mkdtempSync(join(tmpdir(), "aac-")); writeFileSync(join(good, LEDGER), '{"action":"write a","approved":true}\n');
    if (!check(good).ok) { console.error("FAIL: a fully-approved ledger should pass"); fail++; }
    const bad = mkdtempSync(join(tmpdir(), "aac-")); writeFileSync(join(bad, LEDGER), '{"action":"write a","approved":false}\n');
    if (check(bad).ok) { console.error("FAIL: an unapproved action must go red"); fail++; }
    rmSync(good, { recursive: true, force: true }); rmSync(bad, { recursive: true, force: true });
    console.log(`ai-control-approved: ${fail === 0 ? "PASS" : "FAIL"} self-test`);
    process.exit(fail ? 1 : 0);
  }
  const r = check(process.argv[2] || ".");
  if (r.ok) process.exit(0);
  console.error(`ai-control-approved: ${r.detail}`);
  process.exit(1);
}
