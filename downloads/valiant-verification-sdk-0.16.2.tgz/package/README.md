# Valiant Verification SDK

The standalone runner for **Valiant Verification** — the discipline that makes "done"
mean "verified". The open specification is `robmitchellengineering-hub/valiant-verification`;
this repository is the licensed **SDK** that implements it as an installable tool.

> **Repo:** https://github.com/robmitchellengineering-hub/valiant-verification-sdk (private — it is the licensed SDK layer; the spec is the public Apache-2.0 repo).

A repo adopts the SDK by adding one `valiant.json` that *references its existing checks*.
The SDK never edits them — it runs a throwaway copy.

## Install

**Not on the public npm registry** (still 404 — `npm view valiant-verification-sdk version`). The self-hosted registry does serve it:
`https://api.morpheus.nz/api/functions/getPackage?name=valiant-verification-sdk&version=<version>` returns the tarball. Or install from the
tarball this repo produces:

```sh
node tools/release.mjs                     # writes dist/valiant-verification-sdk-0.2.0.tgz and its .sha256
npm install -g dist/valiant-verification-sdk-0.2.0.tgz
valiant licence --status                   # says whether a licence is installed
```

Requires **Node >= 18** (the same floor as `package.json`).

You should see the gate, guard and ledger counts for the repo you are in. From a checkout without
installing, run `node bin/valiant.mjs status` instead.

## Commands

| command | what it enforces |
|---|---|
| `valiant verify` | runs every gate **by name**; missing / cannot-check (exit 2) / exit-0-with-no-output = fail |
| `valiant mutate` | injects each guard's seeded fault into a throwaway copy and requires the guard to go red; `survived` / `stale` = fail |
| `valiant ledger` | validates the incident ledger — every entry must name a RULE and a GUARD |
| `valiant status` | prints gate / guard / ledger counts |

## The config (`valiant.json`)

```json
{
  "gates": [
    { "name": "lint", "cmd": ["npm", "run", "lint"] }
  ],
  "guards": [
    {
      "name": "lint",
      "file": "src/app.js",
      "find": "const ok = true",
      "replace": "const ok = false",
      "check": ["npm", "run", "lint"]
    }
  ],
  "ledger": "KNOWN-HAZARDS.md"
}
```

A gate is a named command that must exit 0 *and* produce evidence. A guard declares the
file to sabotage, the exact `find`/`replace` (must match exactly once), and the command
that must go red — `check` for the subject flavour (sabotage the guarded file, the guard
goes red) or `fixture` for the guard-logic flavour (sabotage the guard's own logic, a
synthetic exerciser goes red). A guard may carry `"kind": "claim"` to mark a reality-guard — a
guard whose subject is a published claim and whose `check` asserts it against the live system
(the "docs say N, reality has M" class). The incident ledger is validated for RULE + GUARD on every entry.

## Proof is the adoptions — and this repo's own gate is a development aid

The SDK is proven by driving real repos: the recipes in `examples/` and the adopted `valiant.json` files in harness-mesh,
pacland and morpheus. Each guard in `corpus/` is proven against one of those repos, never against a toy fixture shipped
here. **That is the gate of record**; running the tool on itself proves nothing about other repos, because a verifier
that verifies itself is circular.

This repository does run `valiant gate` over its own 38 gates and 4 guards — as a **development aid** that catches its
own regressions, not as evidence the product works. `tools/selftest-box.mjs` is the exception worth knowing about: it
takes the four sentences on the box and runs the attack that would falsify each one.

## Install into a repo (recipes in `examples/`)

A repo is adopted by adding a `valiant.json` (or running `valiant --config <file>`) that
*references its existing checks* — nothing in the target repo is edited. Each recipe is a
ready-to-use config pointing at a repo's real verification entry points:

| recipe | target | status |
|---|---|---|
| `examples/harness-mesh.json` | `~/harness-mesh` | ⚠️ verify **5/6** (measured 2026-11-02) — `hooks-census` is red: 7 nodes have no published verdict; ledger 21 hazards, chained |
| `examples/pacland.json` | `pacland` | ✅ verify 1/1 (114 tests) — proven; ⚠️ no ledger |
| `examples/morpheus.json` | `morpheus-self-hosted` | ✅ driven — SDK ran the real ~130-guard `verify.mjs`; the shared checkout was on another session's `dsh/aggregate-guards` branch, so a clean-`main` result needs a worktree |
| `examples/airmatrix.json` | `airmatrix` | recipe written — full run needs a clean worktree (checkout was mid `rob-core`→`amt-core` rename) and must not run on the CI-shared Mac (cargo build = unattributable measurement) |
| `examples/morpheos.json` | `MorpheOS` | recipe written — `check.sh` refuses on macOS (H16, Linux-only compositor tests); run on the `studio-linux` VM |

Run one — **`--repo .` is not optional**; without it the subject is the config's directory and every gate fails:

```sh
valiant verify --config ./examples/harness-mesh.json --repo .
```

Run from the repo being verified, with `--config` pointing at the recipe (adjust the path to wherever the SDK lives). You
should see `verify: 6/6 gates passed`.

That exact break was live for two days (2026-10-27 → 10-29): a review fix made `--config` decide the subject, the recipes
live inside the SDK, and `tools/selftest-claims.mjs` now exercises this flow so it cannot happen silently again.

**Notes from the first two installs.** A gate that passes with empty stdout (e.g. Python's
`unittest`, which writes its summary to stderr) must declare `"expectStderr": true`, or it is
rightly flagged suspect — a pass must produce evidence. A ledger whose non-hazard `## ` sections
(e.g. "Still open") are held to the RULE+GUARD contract only when they carry a hazard id.

**Licensing, from the payment to a working install:** [docs/LICENSING.md](docs/LICENSING.md) — the monthly subscription,
what is minted, what you install, how renewal works, and exactly what stops when payment does.

**Install and use, start to finish:** [docs/INSTALL.md](docs/INSTALL.md) — include it in the tarball, so it is on the
machine that needs it.

## First run — one command

```sh
valiant setup --licence ./acme.licence    # config + a guard it has already proved can fail + the verdict
```

You should see four numbered steps, ending in `gate: every contract holds`.

`setup` writes `valiant.json` — the only file it adds — chooses a guard against a module your own tests import, runs it
through the real mutation engine, and **writes it only after watching it go red**. If nothing can be proved it says so
and stops with exit 2 rather than handing you a config that verifies nothing.

Then put the gate in front of a push, so a red gate cannot reach a branch:

```sh
valiant hooks --install     # runs the fast check on every push and records that it ran
```

You should see `hooks: installed …/.git/hooks/pre-push` and `hooks: declared "pre-push:gate"`.

What a first run costs, measured: `verify` 0.3 s · `mutate` 1.7 s for four guards · `gate` 2.3–2.9 s, on a repository
whose check is a 90 ms command. The same repository using `npm run test` instead of the command it wraps takes 6.3–7.0 s,
because npm's startup is paid five times — the proof runs your check five times per guard, and cannot be cheaper.
