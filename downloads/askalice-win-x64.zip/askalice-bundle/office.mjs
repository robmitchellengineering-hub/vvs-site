#!/usr/bin/env node
// office.mjs — Word and Excel, because "point it at anything a researcher has" includes the two formats every
// researcher actually has and nobody's tooling reads.
//
// WHY THIS IS NOT A LIBRARY DEPENDENCY. A .docx and an .xlsx are both a zip of XML. Node ships zlib, and the XML
// inside a document is small and regular, so the whole adapter is a zip reader plus two element walks. No package,
// no install, no supply chain — the same rule as every other file here.
//
// THE SPANS MATTER AS MUCH AS THE TEXT:
//   Word   — a paragraph is the unit, so a span is a paragraph index and a character offset inside it.
//   Excel  — a cell is the unit, so a span is sheet!A1, which is what a person checks against a spreadsheet.
// A quote from a spreadsheet that says only "characters 1200-1260" is useless; "Sheet1!B7" is a place.
import { inflateRawSync } from 'node:zlib';

/** zipEntries — the files inside a zip, inflated. No external library, no central-directory trust issues. */
export function zipEntries(buf) {
  const out = new Map();
  const b = Buffer.isBuffer(buf) ? buf : Buffer.from(buf);
  let i = 0;
  while (i < b.length - 4) {
    // local file header signature 0x04034b50
    if (!(b[i] === 0x50 && b[i + 1] === 0x4b && b[i + 2] === 0x03 && b[i + 3] === 0x04)) { i++; continue; }
    const method = b.readUInt16LE(i + 8);
    const compSize = b.readUInt32LE(i + 18);
    const nameLen = b.readUInt16LE(i + 26);
    const extraLen = b.readUInt16LE(i + 28);
    const name = b.subarray(i + 30, i + 30 + nameLen).toString('utf8');
    const dataStart = i + 30 + nameLen + extraLen;
    // A streamed entry has compSize 0 and a data descriptor; those are rare in Office files, so refuse cleanly.
    if (compSize === 0) { i = dataStart; continue; }
    const data = b.subarray(dataStart, dataStart + compSize);
    try {
      out.set(name, method === 0 ? data : inflateRawSync(data));
    } catch { /* a corrupt entry is skipped; the rest of the document still reads */ }
    i = dataStart + compSize;
  }
  return out;
}

const xmlText = (s) => String(s)
  .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
  .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'")
  .replace(/&amp;/g, '&');

/** docxParagraphs — Word: one string per paragraph, in document order. */
export function docxParagraphs(buf) {
  const entries = zipEntries(buf);
  const doc = entries.get('word/document.xml');
  if (!doc) return { paragraphs: [], reason: 'no word/document.xml — not a Word document, or a .doc renamed to .docx' };
  const xml = doc.toString('utf8');
  const paragraphs = [];
  for (const p of xml.matchAll(/<w:p\b[\s\S]*?<\/w:p>/g)) {
    const runs = [...p[0].matchAll(/<w:t\b[^>]*>([\s\S]*?)<\/w:t>/g)].map((m) => xmlText(m[1]));
    // a tab inside a paragraph is a cell boundary in a table, and a space anywhere else
    const text = runs.join('').replace(/\s+/g, ' ').trim();
    if (text) paragraphs.push(text);
  }
  return { paragraphs, reason: paragraphs.length ? null : 'the document has no text runs this build can read' };
}

/** colToNum — "AB" -> 28, so a cell reference can be turned back into a name. */
function colToNum(col) {
  let n = 0;
  for (const ch of col.toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n;
}

/** xlsxSheets — Excel: one array of {cell, value} per sheet, with the cell reference kept. */
export function xlsxSheets(buf) {
  const entries = zipEntries(buf);
  const shared = entries.get('xl/sharedStrings.xml');
  const strings = shared
    ? [...shared.toString('utf8').matchAll(/<si>([\s\S]*?)<\/si>/g)].map((m) =>
        [...m[1].matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map((t) => xmlText(t[1])).join(''))
    : [];
  const wb = entries.get('xl/workbook.xml');
  const names = wb
    ? [...wb.toString('utf8').matchAll(/<sheet\b[^>]*name="([^"]+)"/g)].map((m) => xmlText(m[1]))
    : [];
  const sheets = [];
  const sheetFiles = [...entries.keys()].filter((k) => /^xl\/worksheets\/sheet\d+\.xml$/.test(k)).sort();
  sheetFiles.forEach((file, idx) => {
    const xml = entries.get(file).toString('utf8');
    const cells = [];
    for (const c of xml.matchAll(/<c\b([^>]*)>([\s\S]*?)<\/c>/g)) {
      const attrs = c[1];
      const ref = (attrs.match(/r="([A-Z]+\d+)"/) || [])[1];
      if (!ref) continue;
      const type = (attrs.match(/t="([^"]+)"/) || [])[1];
      const raw = (c[2].match(/<v>([\s\S]*?)<\/v>/) || [])[1];
      if (raw === undefined) continue;
      const value = type === 's' ? (strings[Number(raw)] ?? '') : xmlText(raw);
      if (String(value).trim()) cells.push({ cell: ref, value: String(value).trim() });
    }
    sheets.push({ name: names[idx] || `Sheet${idx + 1}`, cells });
  });
  return { sheets, reason: sheets.length ? null : 'no worksheets found — not an Excel file, or a .xls renamed to .xlsx' };
}

/** officeText — one flat text for searching, with the cell/paragraph noted inline so a span can point back. */
export function officeText(buf) {
  if (isZip(buf)) {
    const docx = docxParagraphs(buf);
    if (docx.paragraphs.length) return { kind: 'docx', text: docx.paragraphs.join('\n'), paragraphs: docx.paragraphs, reason: docx.reason };
    const xlsx = xlsxSheets(buf);
    if (xlsx.sheets.length) {
      const text = xlsx.sheets.map((s) => s.cells.map((c) => `${c.cell}: ${c.value}`).join('\n')).join('\n');
      return { kind: 'xlsx', text, sheets: xlsx.sheets, reason: xlsx.reason };
    }
  }
  return { kind: null, text: '', reason: 'not a zip container — not Word or Excel' };
}

export function isZip(buf) {
  const b = Buffer.isBuffer(buf) ? buf : Buffer.from(buf || '');
  return b.length > 4 && b[0] === 0x50 && b[1] === 0x4b;
}

export function isOffice(buf, name = '') {
  return isZip(buf) && /\.(docx|xlsx)$/i.test(name);
}

// ---------------------------------------------------------------------------
// fixtures — a zip built in code, so the test needs no file and no library
// ---------------------------------------------------------------------------
function makeZip(files) {
  const chunks = [];
  const central = [];
  let offset = 0;
  for (const [name, content] of Object.entries(files)) {
    const nameBuf = Buffer.from(name, 'utf8');
    const data = Buffer.from(content, 'utf8');
    const comp = require('node:zlib').deflateRawSync(data);
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0, 6);
    local.writeUInt16LE(8, 8);          // deflate
    local.writeUInt32LE(0, 10);
    local.writeUInt32LE(0, 14);
    local.writeUInt32LE(comp.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    local.writeUInt16LE(0, 28);
    chunks.push(local, nameBuf, comp);
    const cd = Buffer.alloc(46);
    cd.writeUInt32LE(0x02014b50, 0);
    cd.writeUInt16LE(20, 4);
    cd.writeUInt16LE(20, 6);
    cd.writeUInt16LE(8, 10);
    cd.writeUInt32LE(comp.length, 20);
    cd.writeUInt32LE(data.length, 24);
    cd.writeUInt16LE(nameBuf.length, 28);
    cd.writeUInt32LE(offset, 42);
    central.push(cd, nameBuf);
    offset += local.length + nameBuf.length + comp.length;
  }
  const centralBuf = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(Object.keys(files).length, 8);
  end.writeUInt16LE(Object.keys(files).length, 10);
  end.writeUInt32LE(centralBuf.length, 12);
  end.writeUInt32LE(offset, 16);
  return Buffer.concat([...chunks, centralBuf, end]);
}
void makeZip;

if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href && process.argv.includes('--self-test')) {
  const { deflateRawSync } = await import('node:zlib');
  const zipOf = (files) => {
    const parts = [];
    const cd = [];
    let off = 0;
    const count = Object.keys(files).length;
    for (const [name, content] of Object.entries(files)) {
      const nb = Buffer.from(name);
      const data = Buffer.from(content, 'utf8');
      const comp = deflateRawSync(data);
      const lh = Buffer.alloc(30);
      lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(8, 8);
      lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(nb.length, 26);
      parts.push(lh, nb, comp);
      const c = Buffer.alloc(46);
      c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(8, 10);
      c.writeUInt32LE(comp.length, 20); c.writeUInt32LE(data.length, 24);
      c.writeUInt16LE(nb.length, 28); c.writeUInt32LE(off, 42);
      cd.push(c, nb);
      off += lh.length + nb.length + comp.length;
    }
    const cb = Buffer.concat(cd);
    const end = Buffer.alloc(22);
    end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(count, 8); end.writeUInt16LE(count, 10);
    end.writeUInt32LE(cb.length, 12); end.writeUInt32LE(off, 16);
    return Buffer.concat([...parts, cb, end]);
  };

  const DOCX = zipOf({
    'word/document.xml': '<w:document><w:body><w:p><w:r><w:t>The bridge opened in </w:t></w:r><w:r><w:t>1937.</w:t></w:r></w:p><w:p><w:r><w:t>It carries traffic.</w:t></w:r></w:p></w:body></w:document>'
  });
  const XLSX = zipOf({
    'xl/sharedStrings.xml': '<sst><si><t>Bridge</t></si><si><t>Opening year</t></si></sst>',
    'xl/workbook.xml': '<workbook><sheets><sheet name="Figures"/></sheets></workbook>',
    'xl/worksheets/sheet1.xml': '<worksheet><sheetData><row r="6"><c r="A7" t="s"><v>0</v></c><c r="B7"><v>1937</v></c></row></sheetData></worksheet>'
  });

  const tests = [
    { name: 'a docx yields one string per paragraph', run: () => {
        const r = docxParagraphs(DOCX);
        return r.paragraphs.length === 2 && r.paragraphs[0] === 'The bridge opened in 1937.'; } },
    { name: 'RED: a docx with no document.xml says so instead of returning nothing', run: () => {
        const r = docxParagraphs(zipOf({ 'other.xml': '<x/>' }));
        return r.paragraphs.length === 0 && /not a Word document/.test(r.reason); } },
    { name: 'an xlsx keeps the cell reference, because that is the place a person checks', run: () => {
        const r = xlsxSheets(XLSX);
        const cell = r.sheets[0].cells.find((c) => c.cell === 'B7');
        return r.sheets[0].name === 'Figures' && cell && cell.value === '1937'; } },
    { name: 'an xlsx resolves a shared string', run: () => {
        const r = xlsxSheets(XLSX);
        const a7 = r.sheets[0].cells.find((c) => c.cell === 'A7');
        return a7 && a7.value === 'Bridge'; } },
    { name: 'RED: a zip that is neither Word nor Excel is refused by name', run: () => {
        const r = officeText(zipOf({ 'x.txt': 'hello' }));
        return r.kind === null && /not Word or Excel/.test(r.reason); } },
    { name: 'officeText flattens a spreadsheet with its cell references inline', run: () => {
        const r = officeText(XLSX);
        return r.kind === 'xlsx' && /B7: 1937/.test(r.text); } },
    { name: 'isOffice is false for a plain zip and for a pdf', run: () => isOffice(zipOf({ 'a.txt': 'x' }), 'a.zip') === false }
  ];
  let bad = 0;
  for (const t of tests) {
    let ok = false, err = '';
    try { ok = t.run() === true; } catch (e) { err = e.message; }
    if (ok) console.log(`  ok    ${t.name}`);
    else { bad++; console.error(`  FAIL  ${t.name}${err ? ' — ' + err : ''}`); }
  }
  console.log(`\noffice: ${tests.length - bad}/${tests.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
