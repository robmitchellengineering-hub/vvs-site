#!/usr/bin/env node
// cite.mjs — a claim record becomes a Wikipedia citation that renders when pasted.
//
// THE ACCEPTANCE TEST FOR THIS FILE IS NOT "it looks right", it is: paste the {{cite …}} block into Wikipedia's
// own parser and it renders a real <cite>. That was run on 2026-11-05 through action=parse and produced
// «"Example Domain". example.com. Retrieved 2026-11-05.»
//
// A CORRECTION TO MY OWN FIRST COMMENT, because the control disproved it: I wrote that a missing |title= renders
// a red maintenance error, and it does NOT — a titleless {{cite web}} renders quietly, just badly. So a field we
// do not know is left out and named in `missing` for the real reason: an untitled citation is a poor citation,
// and a tool that invents one is worse than the poor citation. Inventing a value is the thing a verification tool
// must never do.
//
// WHY THE TYPES ARE CHOSEN, NOT GUESSED:
//   {{cite journal}} — a DOI is present: journals are identified by one, and |page= is meaningful.
//   {{cite report}}  — a PDF with a page and a URL: a report is a document with pages you can point at.
//   {{cite web}}     — everything else: a page with a URL fetch date.
// {{cite book}} is not chosen automatically: a book usually has no URL, and we almost never have an ISBN, so
// calling something a book from the web is a guess that renders badly.
import { createHash } from 'node:crypto';
import { extractText } from './extract.mjs';
import { isPdf, pdfPages } from './pdf.mjs';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

/** today-ish date from an ISO timestamp, as Wikipedia wants it: access-date=YYYY-MM-DD */
export function accessDate(iso) {
  const d = iso ? new Date(iso) : new Date();
  if (Number.isNaN(d.getTime())) return new Date().toISOString().slice(0, 10);
  return d.toISOString().slice(0, 10);
}

/** A template parameter value must never contain a raw pipe or a closing brace: both end the parameter. */
export function param(v) {
  // ORDER MATTERS, and getting it wrong is what the pipe fixture caught: escaping the pipe first inserts "}}"
  // (from {{!}}), and a later brace-escape then eats one of its own braces, producing "{{!} B". Braces are
  // neutralised as HTML entities FIRST, then the pipe becomes {{!}} and stays intact.
  return String(v ?? '')
    .replace(/\s+/g, ' ')
    .replace(/\{\{/g, '&#123;&#123;')
    .replace(/\}\}/g, '&#125;&#125;')
    .replace(/\|/g, '{{!}}')
    .trim();
}

/** titleOf — the document's own title, or nothing. Never a guess, never the URL. */
export function titleOf(body, uri) {
  if (!body) return null;
  if (isPdf(body)) {
    const pages = pdfPages(body).pages;
    const first = (pages[0] || '').split(/(?<=[.!?])\s/)[0] || '';
    // a PDF's first line is often the title, but only take it when it reads like one: no sentence-ending verb soup
    const line = first.replace(/\s+/g, ' ').trim();
    return line.length >= 8 && line.length <= 160 ? line.replace(/[.,;:]$/, '') : null;
  }
  const s = String(body);
  const m = s.match(/<title[^>]*>([\s\S]{1,300}?)<\/title>/i);
  if (m) {
    const t = m[1].replace(/\s+/g, ' ').trim();
    // Many pages are "Page name | Site name"; the page name is the part a citation wants.
    const first = t.split(/\s+[|–—]\s+/)[0].trim();
    return (first || t) || null;
  }
  return null;
}

/** websiteOf — the host, which {{cite web}} wants and which is not a guess. */
export function websiteOf(uri) {
  try { return new URL(uri).hostname.replace(/^www\./, ''); } catch { return null; }
}

export function doiOf(uri) {
  const m = String(uri || '').match(/\b(10\.\d{4,9}\/[^\s?#&]+)/);
  return m ? m[1] : null;
}

/**
 * citeFor — the template, the type chosen, and exactly what a human still has to supply.
 * record: a claim record; meta: { body, uri } for the source the quote came from.
 */
export function citeFor(record, meta = {}) {
  const e = record?.evidence || {};
  const uri = e.uri || meta.uri || '';
  const body = meta.body ?? null;
  const title = meta.title ?? titleOf(body, uri);
  const doi = doiOf(uri);
  const page = e.span?.page ?? null;
  const access = accessDate(e.fetchedAt);
  const site = websiteOf(uri);

  const missing = [];
  if (!title) missing.push('title');
  missing.push('author');
  missing.push(doi ? 'journal' : (page ? 'publisher' : 'website name'));

  let kind, params;
  if (doi) {
    kind = 'journal';
    params = [['title', title], ['journal', null], ['doi', doi], ['page', page], ['access-date', access]];
  } else if (page) {
    kind = 'report';
    params = [['title', title], ['url', uri], ['page', page], ['access-date', access]];
  } else {
    kind = 'web';
    params = [['title', title], ['url', uri], ['website', site], ['access-date', access]];
  }

  const filled = params.filter(([, v]) => v !== null && v !== undefined && String(v).length);
  const template = `{{cite ${kind}\n` + filled.map(([k, v]) => ` |${k}=${param(v)}`).join('\n') + '\n}}';

  return {
    kind,
    title: title || null,
    template,
    missing: missing.filter((m) => !(m === 'website name' && site)),
    uri,
    page,
    accessDate: access,
    // the hash makes a citation stable: the same source cited twice yields the same key, so a reference list
    // built from this cannot silently contain the same work under two names.
    key: 'ref_' + createHash('sha256').update(uri + (page ?? '')).digest('hex').slice(0, 8),
    website: site
  };
}

const MON = MONTHS.map((m) => m.slice(0, 3));

/**
 * stylesFor — the citation in the styles a journal actually asks for.
 *
 * Wikitext is what Wikipedia needs; APA, MLA and Chicago are what a draft needs. They are built from the SAME
 * extracted fields as the template, and a field that was never extracted is OMITTED rather than invented — an
 * APA reference with a made-up author is worse than one with the author missing and the gap listed.
 */
export function stylesFor(cite, { author = null, published = null } = {}) {
  if (!cite) return null;
  const title = cite.title || null;
  const site = cite.website || websiteOf(cite.uri) || null;
  const url = cite.uri || '';
  const accessed = cite.accessDate || null;           // ISO date
  // APA's year is the PUBLICATION year. Falling back to the access year made every undated page look like it was
  // published the day it was read — "(2026)" for a page with no date, which is a fabricated fact in the citation.
  const y = (published || '').match(/\d{4}/)?.[0] || null;
  const md = (published || '').match(/^\d{4}-(\d{2})-(\d{2})/);
  const ad = (accessed || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
  const a = author ? author.replace(/\s+/g, ' ') : null;

  // APA 7: Author. (Year, Month Day). Title. Site. URL
  const apaDate = md ? `(${y}, ${MONTHS[Number(md[1]) - 1]} ${Number(md[2])})` : y ? `(${y})` : '(n.d.)';
  const apa = [a ? `${a}.` : null, apaDate + '.', title ? `*${title}*.` : null, site ? `${site}.` : null, url].filter(Boolean).join(' ');

  // MLA 9: Author. "Title." Site, Date, URL. Accessed 5 Nov. 2026.
  const mlaDate = md ? `${Number(md[2])} ${MON[Number(md[1]) - 1]}. ${y}` : y || null;
  const accessedMla = ad ? `${Number(ad[3])} ${MON[Number(ad[2]) - 1]}. ${ad[1]}` : null;
  const mla = [a ? `${a}.` : null, title ? `"${title}."` : null, site ? `${site},` : null, mlaDate ? `${mlaDate},` : null,
    url ? `${url}.` : null, accessedMla ? `Accessed ${accessedMla}.` : null].filter(Boolean).join(' ');

  // Chicago 17 (notes–bibliography): Author. "Title." Site. Accessed November 5, 2026. URL.
  const accessedChi = ad ? `${MONTHS[Number(ad[2]) - 1]} ${Number(ad[3])}, ${ad[1]}` : null;
  const chi = [a ? `${a}.` : null, title ? `"${title}."` : null, site ? `${site}.` : null,
    accessedChi ? `Accessed ${accessedChi}.` : null, url].filter(Boolean).join(' ');

  return {
    apa, mla, chicago: chi,
    // which fields these styles wanted and did not get — the same rule as the template's "to fill" list
    missing: [!a ? 'author' : null, !published ? 'publication date' : null].filter(Boolean)
  };
}

/** talkPageRequest — what a conflicted or paid editor is allowed to leave behind: the ask, not the prose. */
export function talkPageRequest({ article = 'ARTICLE', sentence = '<the sentence you intend to write>', record, cite }) {
  const e = record?.evidence || {};
  const span = e.span || {};
  const where = [span.page ? `p. ${span.page}` : null,
    Number.isInteger(span.start) ? `chars ${span.start}–${span.end}` : null].filter(Boolean).join(', ');
  const lines = [
    `== Proposed addition: sourced sentence ==`,
    ``,
    `{{edit request}}`,
    ``,
    `I would like to add the following sentence to [[${article}]], with the source below:`,
    ``,
    `> ${sentence}`,
    ``,
    `Source: ${cite.template}`,
    ``,
    span.quote ? `The source says, at ${where || 'the point cited'}:` : null,
    span.quote ? `> ${span.quote.split('\n').join('\n> ')}` : null,
    ``,
    `Verdict: ${record?.verdict ?? 'unknown'} — ${record?.reason ?? ''}`,
    record?.falsifier ? `Would be wrong if: ${record.falsifier}` : null,
    ``,
    `~~~~`
  ];
  // Blank lines are structure in wikitext: filtering every empty line glued {{edit request}} to the sentence and
  // lost the paragraph breaks. Only the conditional placeholders are dropped.
  return lines.filter((l) => l !== null && l !== undefined && l !== '').join('\n');
}

// ---------------------------------------------------------------------------
// fixtures — the acceptance test is "renders when pasted", so every case here is a rendering failure waiting
// to happen: a missing title, a pipe in a value, a page number, a DOI, a quote with a newline.
// ---------------------------------------------------------------------------
const rec = (over = {}) => ({
  claim: { subject: 'the bridge', predicate: 'opened in', value: '1937' },
  verdict: 'supported-in-span',
  reason: 'containment only: 2 claim words present',
  falsifier: 'a source stating another year',
  evidence: {
    uri: 'https://example.org/bridge', fetchedAt: '2026-11-05T04:12:07Z', httpStatus: 200,
    span: { quote: 'The bridge opened in 1937.', start: 10, end: 37, extractor: { name: 'dom-text', version: '1.0.0' } },
    contentHash: 'sha256:' + 'a'.repeat(64)
  },
  ...over
});

const TESTS = [
  { name: 'a web citation takes the page title, not the url', run: () => {
      const c = citeFor(rec(), { body: '<html><head><title>Golden Gate Bridge | Transport</title></head></html>' });
      return c.kind === 'web' && c.template.includes('|title=Golden Gate Bridge') && c.template.includes('|url=https://example.org/bridge'); } },
  { name: 'access-date is the wiki format', run: () => citeFor(rec(), {}).template.includes('|access-date=2026-11-05') },
  { name: 'a pipe in a title is escaped, not allowed to break the template', run: () => {
      const c = citeFor(rec(), { title: 'A | B' });
      return c.template.includes('A {{!}} B') && !/\|title=A \| B/.test(c.template); } },
  { name: 'a closing brace in a value cannot end the template early', run: () => citeFor(rec(), { title: 'x }} y' }).template.split('}}').length === 2 },
  { name: 'a DOI makes it a journal citation', run: () => {
      const c = citeFor(rec({ evidence: { ...rec().evidence, uri: 'https://doi.org/10.1038/nature12373' } }), {});
      return c.kind === 'journal' && c.template.includes('|doi=10.1038/nature12373'); } },
  { name: 'a PDF page makes it a report with page=', run: () => {
      const c = citeFor(rec({ evidence: { ...rec().evidence, span: { ...rec().evidence.span, page: 4 } } }), { title: 'Annual report' });
      return c.kind === 'report' && c.template.includes('|page=4'); } },
  { name: 'RED: no title is named as missing, never invented', run: () => {
      const c = citeFor(rec(), { body: '<html></html>' });
      return c.missing.includes('title') && !c.template.includes('|title='); } },
  { name: 'the citation key is stable for the same source and page', run: () => {
      const a = citeFor(rec(), { title: 'T' }).key, b = citeFor(rec(), { title: 'T' }).key;
      const c = citeFor(rec({ evidence: { ...rec().evidence, span: { ...rec().evidence.span, page: 9 } } }), { title: 'T' }).key;
      return a === b && a !== c; } },
  { name: 'the talk request carries the citation and the quote, and no article prose', run: () => {
      // NB: the first version of this fixture built the citation from one record and the request from another
      // (rec() again, without the page), so it failed on a defect that did not exist. Same record both times.
      const r = rec({ evidence: { ...rec().evidence, span: { ...rec().evidence.span, page: 4 } } });
      const c = citeFor(r, { title: 'Report' });
      const t = talkPageRequest({ article: 'Golden Gate Bridge', record: r, cite: c });
      return t.includes('{{edit request}}') && t.includes('{{cite report') && t.includes('The bridge opened in 1937.') && t.includes('p. 4'); } },
  { name: 'APA names the site, dates the access, and omits what it was not given', run: () => {
      const c = citeFor(rec(), { body: '<html><head><title>Golden Gate Bridge</title></head></html>' });
      const st = stylesFor(c);
      return st.apa.includes('Golden Gate Bridge') && st.apa.includes('(n.d.)') && st.missing.includes('author')
        && !/undefined/.test(st.apa); } },
  { name: 'MLA quotes the title and ends with the access date', run: () => {
      const c = citeFor(rec(), { body: '<html><head><title>Golden Gate Bridge</title></head></html>' });
      return /Accessed 5 Nov\. 2026/.test(stylesFor(c).mla) && stylesFor(c).mla.includes('"Golden Gate Bridge."'); } },
  { name: 'Chicago spells the access date out', run: () => {
      const c = citeFor(rec(), { body: '<html><head><title>Golden Gate Bridge</title></head></html>' });
      return /Accessed November 5, 2026/.test(stylesFor(c).chicago); } },
  { name: 'RED: no style invents a date it does not have', run: () => {
      const bare = rec(); bare.evidence = { ...bare.evidence, fetchedAt: null };
      const st = stylesFor(citeFor(bare, { body: '<html><head><title>T</title></head></html>' }));
      return st.apa.includes('(n.d.)') && !/\b20\d\d\b/.test(st.apa) && st.missing.includes('publication date'); } },
  { name: 'RED: a style never prints the string undefined', run: () => {
      const bare = rec(); bare.evidence = { ...bare.evidence, uri: '', fetchedAt: null };
      const st = stylesFor(citeFor(bare, { title: 'Only a title' }));
      return st && [st.apa, st.mla, st.chicago].every((x) => !/undefined|null|NaN/.test(x)); } }

];

if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href && process.argv.includes('--self-test')) {
  let bad = 0;
  for (const t of TESTS) {
    let ok = false, err = '';
    try { ok = t.run() === true; } catch (e) { err = e.message; }
    if (ok) console.log(`  ok    ${t.name}`);
    else { bad++; console.error(`  FAIL  ${t.name}${err ? ' — ' + err : ''}`); }
  }
  console.log(`\ncite: ${TESTS.length - bad}/${TESTS.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
void MONTHS; void extractText;
