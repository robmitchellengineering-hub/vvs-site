#!/usr/bin/env node
// citations.mjs — the references you are writing FROM, kept in one place.
//
// This is the working set of citations a Wikipedia edit or a journal article is built from. It is SEPARATE from
// the library on purpose: the library files every claim ever checked, while this holds the sources the reader has
// deliberately chosen to cite in THIS piece. You add a source from a research finding, and here it sits until the
// article is written — one list, copyable as wikitext or as a plain reference list.
//
// A JSON file, not a database table: it is a short, hand-editable, human-readable list, and a person who wants to
// see exactly what will go into their References section can open the file and read it. Mode 0600 like the token.
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';

export function refsPath(home) {
  return join(home, 'collected-refs.json');
}

export function loadRefs(home) {
  const p = refsPath(home);
  if (!existsSync(p)) return [];
  try { const a = JSON.parse(readFileSync(p, 'utf8')); return Array.isArray(a) ? a : []; }
  catch { return []; }
}

export function saveRefs(home, refs) {
  const p = refsPath(home);
  mkdirSync(dirname(p), { recursive: true });
  writeFileSync(p, JSON.stringify(refs, null, 2), { mode: 0o600 });
}

/** addRef — idempotent by the citation's stable key: the same source cited twice is one reference. */
export function addRef(home, cite) {
  const refs = loadRefs(home);
  if (refs.some((r) => r.key === cite.key)) return false;
  refs.push(cite);
  saveRefs(home, refs);
  return true;
}

export function removeRef(home, key) {
  const refs = loadRefs(home).filter((r) => r.key !== key);
  saveRefs(home, refs);
  return refs.length;
}

// fixtures
if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href && process.argv.includes('--self-test')) {
  const { mkdtempSync } = await import('node:fs');
  const { tmpdir } = await import('node:os');
  const { join: j } = await import('node:path');
  const home = mkdtempSync(j(tmpdir(), 'refs-'));
  const cite = { key: 'ref_abc', title: 'T', uri: 'https://e/x', template: '{{cite web}}' };
  const tests = [
    { name: 'a citation files once, by key', run: () => addRef(home, cite) === true && addRef(home, cite) === false && loadRefs(home).length === 1 },
    { name: 'removing a key removes exactly that one', run: () => { removeRef(home, 'ref_abc'); return loadRefs(home).length === 0; } },
    { name: 'a corrupt file reads as empty, never throws', run: () => {
        writeFileSync(refsPath(home), 'not json'); return loadRefs(home).length === 0; } },
  ];
  let bad = 0;
  for (const t of tests) { let ok = false; try { ok = t.run() === true; } catch {} if (ok) console.log(`  ok    ${t.name}`); else { bad++; console.error(`  FAIL  ${t.name}`); } }
  console.log(`\ncitations: ${tests.length - bad}/${tests.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
