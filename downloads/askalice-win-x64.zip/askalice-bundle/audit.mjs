#!/usr/bin/env node
// audit.mjs — the feature an editor comes back for: their own draft, sentence by sentence, checked against the
// sources THEY cited.
//
// ROB: "this is a tool that people will be able to use alongside their wiki creation and edits … the draft audit
// is the reason people will come back."
//
// WHY THIS IS ALLOWED WHEN WRITING PROSE IS NOT: Alice does not write a word of it. The sentences are the
// editor's; Alice only answers "does the source you attached actually say this". That is verification, and it is
// the one job a human cannot do at speed across 800 words.
//
// THE THREE ANSWERS, and the middle one is the valuable one:
//   supported          — every content word of the sentence is in the source's span
//   partly supported   — most of it is, and the missing words are NAMED. This is the sentence that reads fine and
//                        is quietly wrong: the source says the bridge carried traffic, the draft says it carried
//                        "40,000 vehicles a day", and only the number is missing.
//   unsourced          — no reference attached, or the reference could not be read
//
// A partly-supported sentence is never reported as a failure. It is reported as a DIFFERENCE, with the words the
// source does not carry, because the fix is usually to quote the source or drop the detail — and the editor
// decides, not the tool.
import { createHash } from 'node:crypto';
import { extractText, contentWords } from './extract.mjs';
import { isPdf, pdfPages } from './pdf.mjs';
import { documentsWithText } from './library.mjs';
import { archivedCopy } from './research.mjs';

const SPLIT = /(?<=[.!?])\s+/;

/** splitDraft — sentences, each with the reference markers that were attached to it. */
export function splitDraft(text) {
  const out = [];
  // A marker usually sits AFTER the full stop: "…in 1937.[1] It carries…". Left there it belongs to the NEXT
  // sentence after splitting, which is how the first run of this file merged three sentences into one, attached
  // the marker to the wrong text, and reported a single row. Move it inside the sentence first: "…in 1937[1].".
  const normalised = String(text ?? '').replace(/([.!?])((?:\[\d{1,3}\])+)/g, '$2$1');
  for (const raw of normalised.split(/\n{2,}/)) {
    for (const chunk of raw.split(SPLIT)) {
      const s = chunk.trim();
      if (s.length < 12) continue;
      const refs = [];
      // [1], [2][3], <ref>…</ref>, <ref name="x">, and a bare url at the end
      for (const m of s.matchAll(/\[(\d{1,3})\]/g)) refs.push({ kind: 'n', id: m[1] });
      for (const m of s.matchAll(/<ref[^>]*>([\s\S]*?)<\/ref>/gi)) refs.push({ kind: 'url', id: (m[1].match(/https?:\/\/[^\s|}<]+/) || [])[0] || null });
      for (const m of s.matchAll(/<ref[^>]*name=["']([^"']+)["'][^>]*\/?>/gi)) refs.push({ kind: 'name', id: m[1] });
      const bare = s.match(/https?:\/\/\S+$/);
      if (bare && !refs.length) refs.push({ kind: 'url', id: bare[0] });
      out.push({ text: s.replace(/\s*\[\d{1,3}\]\s*/g, ' ').replace(/\s{2,}/g, ' ').trim().replace(/\s+([.,;:])/g, '$1').replace(/<ref[\s\S]*?<\/ref>/gi, '').replace(/https?:\/\/\S+$/g, '').trim(), refs });
    }
  }
  return out;
}

/** verdictFor — the three answers, plus the difference that makes the middle one useful. */
export function verdictFor(sentence, sourceText) {
  const want = contentWords(sentence);
  if (!want.length) return { verdict: 'unknown', reason: 'no checkable words', missing: [], found: [] };
  const hay = String(sourceText || '').toLowerCase();
  const found = want.filter((w) => hay.includes(w));
  const missing = want.filter((w) => !hay.includes(w));
  if (!found.length) return { verdict: 'contradicted-by-absence', reason: 'the source does not contain any of this sentence', missing, found };
  // a NUMBER is not a word: if the sentence states one and the source does not, the sentence is not supported even
  // if every word matches. That was the lesson from the first desk run, applied here.
  const numbers = (String(sentence).match(/\b\d[\d,.]*\b/g) || []);
  const missingNumbers = numbers.filter((n) => !hay.includes(n));
  if (!missing.length && !missingNumbers.length) return { verdict: 'supported', reason: 'every content word of the sentence is in the source', missing: [], found };
  const ratio = found.length / want.length;
  return {
    verdict: ratio >= 0.5 || missingNumbers.length ? 'partly-supported' : 'not-supported',
    reason: missingNumbers.length ? `the source does not carry the number(s): ${missingNumbers.join(', ')}`
      : `the source does not carry: ${missing.slice(0, 6).join(', ')}`,
    missing: [...missing, ...missingNumbers],
    found
  };
}

/**
 * passageFor — what the source actually SAYS near this sentence.
 *
 * Without this the verdict is a claim about a claim: "the source does not carry 40,000" is only usable if the
 * editor can see the sentence that carries everything else. The best-scoring source sentence is returned, with the
 * words it shares, so the difference is visible rather than asserted.
 */
export function passageFor(sentence, sourceText, pages = null) {
  const want = contentWords(sentence);
  if (!want.length) return null;
  const sentences = String(sourceText || '').split(/(?<=[.!?])\s+/).map((x) => x.trim()).filter((x) => x.length > 12);
  let best = null, bestScore = 0;
  for (const cand of sentences) {
    const low = cand.toLowerCase();
    const score = want.filter((w) => low.includes(w)).length;
    if (score > bestScore) { bestScore = score; best = cand; }
  }
  if (!best || bestScore < 2) return null;
  // A page number is what makes a PDF quote checkable: "p. 4, characters 1210–1340" is a place, a bare quote is not.
  let page = null, start = null;
  if (Array.isArray(pages)) {
    for (let i = 0; i < pages.length; i++) {
      const at = (pages[i] || '').indexOf(best.slice(0, 60));
      if (at !== -1) { page = i + 1; start = at; break; }
    }
  }
  return { quote: best.slice(0, 400), shared: bestScore, of: want.length, page, start };
}

/**
 * audit — check a draft against the sources it cites.
 * refs: { '1': 'https://…' } from a reference list, or discovered inline.
 */
/**
 * auditAgainstLibrary — is every sentence of the draft backed by a document ALREADY IN THE LIBRARY?
 *
 * The reader did the research first; this answers "will this survive a Wiki publishing review" without refetching
 * anything: each sentence is checked against the extracted text of every filed document. A sentence is supported
 * when one document carries all its content words AND its numbers; otherwise it is unsourced, with the nearest
 * document named so the reader knows what is missing.
 */
export function auditAgainstLibrary(draft, lib) {
  const sentences = splitDraft(draft);
  const docs = documentsWithText(lib);
  const rows = sentences.map((s) => {
    let best = null;
    for (const d of docs) {
      const v = verdictFor(s.text, d.text);
      if (v.verdict === 'supported') {
        best = { docId: d.id, uri: d.uri, title: d.title, kind: d.kind, verdict: 'supported', reason: v.reason, passage: passageFor(s.text, d.text) };
        break;
      }
      if (!best && v.verdict !== 'contradicted-by-absence') {
        // a near miss is better than nothing: keep the document that shared the most words
        if (!best || (v.found?.length || 0) > (best.shared || 0)) {
          best = { docId: d.id, uri: d.uri, title: d.title, kind: d.kind, verdict: 'unsourced', reason: v.reason, shared: v.found?.length || 0, passage: passageFor(s.text, d.text) };
        }
      }
    }
    if (!best) best = { verdict: 'unsourced', reason: docs.length ? 'no document in the library carries this sentence' : 'the library is empty — run some research first' };
    return { text: s.text, ...best, sourceQuote: best.passage?.quote ?? null, page: best.passage?.page ?? null };
  });
  const supported = rows.filter((r) => r.verdict === 'supported').length;
  return {
    sentences: rows,
    summary: { sentences: rows.length, supported, unsourced: rows.length - supported, documents: docs.length },
    // the conformance answer a Wiki editor actually needs: every sentence sourced, or name what is not
    conforms: rows.every((r) => r.verdict === 'supported')
  };
}

export async function audit(draft, { refs = {}, fetchImpl = globalThis.fetch, maxFetch = 12 } = {}) {
  const sentences = splitDraft(draft);
  const cache = new Map();

  const urlFor = (ref) => {
    if (!ref) return null;
    if (ref.kind === 'url') return ref.id;
    if (ref.kind === 'n') return refs[ref.id] || null;
    if (ref.kind === 'name') return refs[ref.id] || null;
    return null;
  };

  const fetchOnce = async (url) => {
    if (cache.has(url)) return cache.get(url);
    let r = await fetchImpl(url, { headers: { 'user-agent': 'askalice/0.1 (audit)' }, redirect: 'follow' }).catch(() => null);
    let archived = null;
    // A dead link is not a dead end: the Wayback copy is the same work, and the row says which one was read.
    if (!r || !r.ok) {
      const a = await archivedCopy(url, { fetchImpl });
      if (a?.archived) {
        const ar = await fetchImpl(a.archived, { headers: { 'user-agent': 'askalice/0.1 (audit)' }, redirect: 'follow' }).catch(() => null);
        if (ar && ar.ok) { r = ar; archived = a.archived; }
      }
    }
    const buf = r && r.ok ? Buffer.from(await r.arrayBuffer()) : null;
    const pages = buf && isPdf(buf) ? pdfPages(buf).pages : null;
    const text = buf ? (pages ? pages.join(' ') : extractText(buf.toString('utf8'))) : '';
    const val = { ok: Boolean(r && r.ok), status: r?.status ?? 0, text, pages, archived, hash: buf ? 'sha256:' + createHash('sha256').update(buf).digest('hex') : null };
    cache.set(url, val);
    return val;
  };

  const rows = [];
  let fetched = 0;
  for (const s of sentences) {
    const ref = s.refs[0] || null;
    const url = urlFor(ref);
    if (!ref) { rows.push({ ...s, verdict: 'unsourced', reason: 'no reference attached', url: null }); continue; }
    if (!url) { rows.push({ ...s, verdict: 'unsourced', reason: `reference [${ref.id}] is not in the reference list`, url: null }); continue; }
    if (fetched >= maxFetch) { rows.push({ ...s, verdict: 'unknown', reason: `not fetched — the run stopped after ${maxFetch} sources`, url }); continue; }
    fetched++;
    const src = await fetchOnce(url);
    if (!src.ok) { rows.push({ ...s, verdict: 'unknown', reason: `the source answered HTTP ${src.status}`, url }); continue; }
    const v = verdictFor(s.text, src.text);
    // what the source says, so the verdict can be judged rather than trusted
    const passage = passageFor(s.text, src.text, src.pages);
    // RECONCILIATION, not arithmetic: when the sentence states a number the source does not carry, show the
    // numbers the source does carry nearby. The reader does the comparison; the tool never asserts that 40,000 is
    // wrong because 3,892,063 over a year works out to something else. That would be a calculation, not a source.
    const srcNumbers = [...new Set((passage?.quote || src.text.slice(0, 2000)).match(/\b\d[\d,.]{1,}\b/g) || [])].slice(0, 4);
    rows.push({ ...s, ...v, url, sourceHash: src.hash, archived: src.archived || null,
      sourceQuote: passage?.quote ?? null, page: passage?.page ?? null, sourceNumbers: srcNumbers, sharedWords: passage?.shared ?? 0 });
  }

  const count = (k) => rows.filter((r) => r.verdict === k).length;
  return {
    sentences: rows,
    summary: {
      sentences: rows.length,
      supported: count('supported'),
      partly: count('partly-supported'),
      unsupported: count('not-supported') + count('contradicted-by-absence'),
      unsourced: count('unsourced'),
      unknown: count('unknown'),
      sources: cache.size
    }
  };
}

// ---------------------------------------------------------------------------
// fixtures — offline; every one is a sentence a real editor would write
// ---------------------------------------------------------------------------
if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href && process.argv.includes('--self-test')) {
  const page = (t) => async () => ({ ok: true, status: 200, arrayBuffer: async () => Buffer.from(`<html><body><p>${t}</p></body></html>`) });
  const tests = [
    { name: 'a sentence the source carries is supported', run: async () => {
        const r = await audit('The bridge opened in 1932.[1]', { refs: { 1: 'https://e/1' }, fetchImpl: page('The bridge opened in 1932 after four years.') });
        return r.sentences[0].verdict === 'supported' && r.summary.supported === 1; } },
    { name: 'RED: a sentence whose NUMBER the source lacks is partly supported, and the number is named', run: async () => {
        const r = await audit('The bridge carried 40000 vehicles a day.[1]', { refs: { 1: 'https://e/1' }, fetchImpl: page('The bridge carried vehicles a day.') });
        const s = r.sentences[0];
        return s.verdict === 'partly-supported' && s.missing.includes('40000'); } },
    { name: 'RED: a sentence with no reference is unsourced, not "fine"', run: async () => {
        const r = await audit('The bridge is widely regarded as beautiful and important.', { fetchImpl: page('x') });
        return r.sentences[0].verdict === 'unsourced' && r.summary.unsourced === 1; } },
    { name: 'RED: a dead reference is unknown, never unsourced and never supported', run: async () => {
        const r = await audit('The bridge opened in 1932.[1]', { refs: { 1: 'https://e/1' }, fetchImpl: async () => ({ ok: false, status: 404 }) });
        return r.sentences[0].verdict === 'unknown' && /404/.test(r.sentences[0].reason); } },
    { name: 'the same source cited twice is fetched once', run: async () => {
        let calls = 0;
        const f = async () => { calls++; return { ok: true, status: 200, arrayBuffer: async () => Buffer.from('<p>The bridge opened in 1932.</p>') }; };
        const r = await audit('The bridge opened in 1932.[1] The bridge opened in 1932 again.[1]', { refs: { 1: 'https://e/1' }, fetchImpl: f });
        return calls === 1 && r.summary.sources === 1; } },
    { name: 'a reference marker that is not in the list is named, not ignored', run: async () => {
        const r = await audit('A claim with a missing reference.[7]', { refs: {}, fetchImpl: page('x') });
        return r.sentences[0].verdict === 'unsourced' && /\[7\]/.test(r.sentences[0].reason); } },
    { name: 'an inline <ref>url</ref> is used directly', run: async () => {
        const r = await audit('The bridge opened in 1932.<ref>https://e/inline</ref>', { fetchImpl: page('The bridge opened in 1932.') });
        return r.sentences[0].verdict === 'supported' && r.sentences[0].url === 'https://e/inline'; } },
    { name: 'a verdict carries the source passage, so it can be judged rather than trusted', run: async () => {
        const r = await audit('The bridge carried 40000 vehicles a day.[1]', { refs: { 1: 'https://e/1' },
          fetchImpl: page('The bridge carries traffic between the two cities. It carries vehicles every day of the year.') });
        return r.sentences[0].verdict === 'partly-supported' && typeof r.sentences[0].sourceQuote === 'string' && r.sentences[0].sourceQuote.includes('vehicles'); } },
    { name: 'a dead source falls back to the archive, and the row says which copy was read', run: async () => {
        const f = async (u) => {
          if (String(u).includes('wayback/available')) return { ok: true, json: async () => ({ archived_snapshots: { closest: { available: true, url: 'https://web.archive.org/web/2019/x', timestamp: '2019' } } }) };
          if (String(u).startsWith('https://web.archive.org')) return { ok: true, status: 200, arrayBuffer: async () => Buffer.from('<p>The bridge opened in 1932.</p>') };
          return { ok: false, status: 404 };
        };
        const r = await audit('The bridge opened in 1932.[1]', { refs: { 1: 'https://gone/x' }, fetchImpl: f });
        return r.sentences[0].verdict === 'supported' && r.sentences[0].archived === 'https://web.archive.org/web/2019/x'; } },
    { name: 'a PDF source reports the page the passage is on', run: async () => {
        const { makePdf } = await import('./pdf.mjs');
        const f = async () => ({ ok: true, status: 200, arrayBuffer: async () => makePdf({ text: 'The bridge opened to traffic in 1937 after four years.' }) });
        const r = await audit('The bridge opened to traffic in 1937.[1]', { refs: { 1: 'https://e/x.pdf' }, fetchImpl: f });
        return r.sentences[0].verdict === 'supported' && r.sentences[0].page === 1; } },
    { name: 'a draft is conformant when every sentence is backed by a library document', run: async () => {
        const { openLibrary, fileDocument } = await import('./library.mjs');
        const { mkdtempSync } = await import('node:fs');
        const { tmpdir } = await import('node:os');
        const { join } = await import('node:path');
        const lib = openLibrary(join(mkdtempSync(join(tmpdir(), 'ala-')), 'x.db'));
        fileDocument(lib, { bytes: Buffer.from('a'), uri: 'https://e/x', kind: 'html', title: 'X', text: 'The bridge opened to traffic in 1937 after four years.' });
        const r = auditAgainstLibrary('The bridge opened in 1937. It carried forty thousand cars.', lib);
        return r.conforms === false && r.summary.supported === 1 && r.summary.unsourced === 1; } },
    { name: 'RED: an empty library reports empty, not conformant', run: async () => {
        const { openLibrary } = await import('./library.mjs');
        const { mkdtempSync } = await import('node:fs');
        const { tmpdir } = await import('node:os');
        const { join } = await import('node:path');
        const lib = openLibrary(join(mkdtempSync(join(tmpdir(), 'alb-')), 'x.db'));
        const r = auditAgainstLibrary('The bridge opened in 1937.', lib);
        return r.conforms === false && /empty/.test(r.sentences[0].reason); } },
    { name: 'the summary adds up to the sentence count', run: async () => {
        const r = await audit('One supported sentence here about the bridge.[1] Another one with nothing at all.', { refs: { 1: 'https://e/1' }, fetchImpl: page('One supported sentence about the bridge.') });
        const s = r.summary;
        return s.supported + s.partly + s.unsupported + s.unsourced + s.unknown === s.sentences; } }
  ];
  let bad = 0;
  for (const t of tests) {
    let ok = false, err = '';
    try { ok = (await t.run()) === true; } catch (e) { err = e.message; }
    if (ok) console.log(`  ok    ${t.name}`);
    else { bad++; console.error(`  FAIL  ${t.name}${err ? ' — ' + err : ''}`); }
  }
  console.log(`\naudit: ${tests.length - bad}/${tests.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
