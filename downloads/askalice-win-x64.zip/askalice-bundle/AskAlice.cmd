@echo off
"%~dp0node.exe" "%~dp0askalice.mjs" ui
