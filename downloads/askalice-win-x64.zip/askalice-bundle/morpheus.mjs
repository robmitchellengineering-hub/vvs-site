#!/usr/bin/env node
// morpheus.mjs — the only file that knows how Ask Alice talks to a Morpheus account.
//
// WHY THE DEVICE FLOW AND NOT A TOKEN FIELD. Morpheus has a device flow built for exactly this shape of client
// (server/src/lib/deviceToken.js): the app asks for a short code, the reader approves it in their own browser
// while logged into their own account, and the app receives a `dvc_` token that resolves server-side to that
// person — so every AI call bills THEIR credits through the same invokeAI path as everything else. No password,
// no JWT pasted into a config file, nothing a reader can leak by sharing a screenshot.
//
// Measured against the live API on 2026-11-05:
//   POST /api/auth/device/start {"client_label":"askalice desk","scopes":["ai_action"]}
//   -> 200 {user_code:"48FC-97JC", verification_uri:"https://morpheus.nz/connect",
//           verification_uri_complete:"...?code=48FC-97JC", interval:5, expires_in:600, device_code:"<opaque>"}
import { readFileSync, writeFileSync, mkdirSync, existsSync, chmodSync } from 'node:fs';
import { homedir, platform } from 'node:os';
import { join } from 'node:path';

export const DEFAULT_API = 'https://api.morpheus.nz';
export const CLIENT_LABEL = 'askalice desk';
export const SCOPES = ['ai_action'];

export function apiBase() {
  return (process.env.ASKALICE_API || DEFAULT_API).replace(/\/+$/, '');
}

/** home — where the token lives. Windows uses USERPROFILE; nothing else is guessed. */
export function home() {
  if (process.env.ASKALICE_HOME) return process.env.ASKALICE_HOME;
  return join(process.env.USERPROFILE || homedir(), '.askalice');
}

export function tokenPath() {
  return join(home(), 'token');
}

export function readToken(path = tokenPath()) {
  try {
    const t = readFileSync(path, 'utf8').trim();
    return t.startsWith('dvc_') || t.length > 20 ? t : null;
  } catch { return null; }
}

/** writeToken — 0600, and it returns nothing that could be printed by accident. */
export function writeToken(token, path = tokenPath()) {
  mkdirSync(home(), { recursive: true });
  writeFileSync(path, token.trim() + '\n', { mode: 0o600 });
  try { chmodSync(path, 0o600); } catch { /* windows ignores this; the file is under USERPROFILE */ }
  return { path, length: token.trim().length };
}

export function redact(token) {
  if (!token) return '(none)';
  const t = String(token);
  return t.slice(0, 4) + '…' + t.slice(-2);
}

async function post(path, body, { fetchImpl, token } = {}) {
  const f = fetchImpl ?? globalThis.fetch;
  const headers = { 'content-type': 'application/json', 'user-agent': 'askalice/0.1' };
  if (token) headers.authorization = `Bearer ${token}`;
  const res = await f(apiBase() + path, { method: 'POST', headers, body: JSON.stringify(body ?? {}) });
  let json = null;
  try { json = await res.json(); } catch { /* an empty or html body is not a crash */ }
  return { status: res.status, ok: res.ok, json };
}

export async function deviceStart({ fetchImpl } = {}) {
  const r = await post('/api/auth/device/start', { client_label: CLIENT_LABEL, scopes: SCOPES }, { fetchImpl });
  if (!r.ok || !r.json?.user_code) {
    return { ok: false, status: r.status, reason: r.status === 404 ? 'this Morpheus deployment has no device flow' : `start answered HTTP ${r.status}` };
  }
  return { ok: true, ...r.json };
}

export async function devicePoll(deviceCode, { fetchImpl } = {}) {
  const r = await post('/api/auth/device/poll', { device_code: deviceCode }, { fetchImpl });
  const j = r.json ?? {};
  const status = j.status || (r.ok ? 'pending' : 'error');
  return { ok: r.ok, status, token: j.token || j.device_token || null, user: j.user || null, reason: j.error || j.message || null, http: r.status };
}

/**
 * login — the whole flow, with the waiting injected so it can be tested without sleeping.
 * onShow({verification_uri, user_code, verification_uri_complete}) is where the CLI prints the URL.
 */
export async function login({ fetchImpl, onShow, sleep = (ms) => new Promise((r) => setTimeout(r, ms)), maxWaitMs = 600000 } = {}) {
  const start = await deviceStart({ fetchImpl });
  if (!start.ok) return { ok: false, reason: start.reason };
  // The show callback gets a SANITISED view: device_code is the secret half of the pair and has no business in
  // anything a terminal prints or a screenshot captures. The fixture caught this passing `start` through.
  if (onShow) {
    onShow({
      user_code: start.user_code,
      verification_uri: start.verification_uri,
      verification_uri_complete: start.verification_uri_complete,
      expires_in: start.expires_in,
      interval: start.interval
    });
  }
  const interval = Math.max(1, Number(start.interval) || 5) * 1000;
  const deadline = Date.now() + Math.min(maxWaitMs, (Number(start.expires_in) || 600) * 1000);
  while (Date.now() < deadline) {
    const p = await devicePoll(start.device_code, { fetchImpl });
    if (p.token) return { ok: true, token: p.token, user: p.user };
    if (p.status === 'denied') return { ok: false, reason: 'the request was denied in the browser' };
    if (p.status === 'expired') return { ok: false, reason: 'the code expired before it was approved' };
    if (p.status === 'error') return { ok: false, reason: p.reason || 'the poll failed' };
    await sleep(interval);
  }
  return { ok: false, reason: 'timed out waiting for approval' };
}

/**
 * recordUsage — what the last AI call actually consumed, kept on this machine.
 *
 * The response already carries the metered block (`usage`), so the number a buyer asks for — "what did that
 * check cost" — needs no new endpoint: it is the usage of the call that just ran. The ACCOUNT BALANCE does need
 * one (no read-only balance function is exposed on the device scope yet), and that gap is named in the plan
 * rather than papered over with an estimate.
 */
export function recordUsage(json, { at = new Date().toISOString() } = {}) {
  const u = json?.usage;
  if (!u) return null;
  const row = { at, model: json.model ?? null, provider: json.provider ?? null, ...u };
  try {
    mkdirSync(home(), { recursive: true });
    writeFileSync(join(home(), 'usage.json'), JSON.stringify(row) + '\n', { mode: 0o600 });
  } catch { /* a machine that cannot write still gets the number back */ }
  return row;
}

export function lastUsage(path = join(home(), 'usage.json')) {
  try { return JSON.parse(readFileSync(path, 'utf8')); } catch { return null; }
}

/** callFunction — any function the token is scoped for. Read-only callers use this, not aiCall. */
export async function callFunction(name, payload = {}, { fetchImpl, token } = {}) {
  const t = token ?? readToken();
  if (!t) return { ok: false, status: 0, reason: 'no-token' };
  const r = await post(`/api/functions/${name}`, payload, { fetchImpl, token: t });
  if (r.status === 401 || r.status === 403) return { ok: false, status: r.status, reason: 'token-rejected' };
  return { ok: r.ok, status: r.status, json: r.json };
}

/** balance — what is left on the account this machine is signed in as. Read-only. */
export async function balance(opts = {}) {
  const r = await callFunction('getUsage', {}, opts);
  if (!r.ok) return r;
  return { ok: true, credit_balance: r.json?.credit_balance ?? null, recent: r.json?.recent_usage ?? [], purchases: r.json?.recent_purchases ?? [] };
}

/** aiCall — the scoped AI function a device token may call (DEVICE_SCOPE_FUNCTIONS.ai_action). */
export async function aiCall(payload, { fetchImpl, token } = {}) {
  const t = token ?? readToken();
  if (!t) return { ok: false, status: 0, reason: 'no-token' };
  const r = await post('/api/functions/runAiAction', payload, { fetchImpl, token: t });
  if (r.status === 401 || r.status === 403) return { ok: false, status: r.status, reason: 'token-rejected' };
  const usage = r.ok ? recordUsage(r.json) : null;
  return { ok: r.ok, status: r.status, json: r.json, usage };
}

// ---------------------------------------------------------------------------
// fixtures — offline, injected fetch, and one that is about not leaking
// ---------------------------------------------------------------------------
const START = { user_code: '48FC-97JC', device_code: 'dc_secret_value', verification_uri: 'https://morpheus.nz/connect', verification_uri_complete: 'https://morpheus.nz/connect?code=48FC-97JC', interval: 1, expires_in: 60 };

const fake = (script) => {
  let i = 0;
  return async (url, opts) => {
    const step = script[Math.min(i++, script.length - 1)];
    const body = typeof step === 'function' ? step(url, opts) : step;
    return { ok: (body.status ?? 200) < 400, status: body.status ?? 200, json: async () => body };
  };
};

const tests = [
  { name: 'start returns a code and a url', run: async () => {
      const r = await deviceStart({ fetchImpl: fake([START]) });
      return r.ok && r.user_code === '48FC-97JC' && r.verification_uri_complete.includes('48FC-97JC'); } },
  { name: 'poll then approve yields a token', run: async () => {
      const r = await login({ fetchImpl: fake([START, { status: 'pending' }, { status: 'approved', token: 'dvc_abc123' }]), sleep: async () => {} });
      return r.ok && r.token === 'dvc_abc123'; } },
  { name: 'RED: a denied request is reported, not retried forever', run: async () => {
      const r = await login({ fetchImpl: fake([START, { status: 'denied' }]), sleep: async () => {} });
      return r.ok === false && /denied/.test(r.reason); } },
  { name: 'RED: the device_code is never shown to the user', run: async () => {
      let shown = '';
      await login({ fetchImpl: fake([START, { status: 'approved', token: 'dvc_x' }]), sleep: async () => {}, onShow: (s) => { shown = JSON.stringify(s); } });
      return shown.includes('48FC-97JC') && !shown.includes('dc_secret_value'); } },
  { name: 'RED: a rejected token is named, not a crash', run: async () => {
      const r = await aiCall({}, { fetchImpl: fake([{ status: 401 }]), token: 'dvc_bad' });
      return r.ok === false && r.reason === 'token-rejected'; } },
  { name: 'RED: a missing token is a reason, not an exception', run: async () => {
      const r = await aiCall({}, { fetchImpl: fake([{ status: 200 }]), token: null, env: true });
      return r.ok === false && r.reason === 'no-token'; } },
  { name: 'the token path follows USERPROFILE on windows', run: () => {
      const old = process.env.USERPROFILE; const oldH = process.env.ASKALICE_HOME;
      process.env.USERPROFILE = 'C:\\Users\\rob'; delete process.env.ASKALICE_HOME;
      const p = tokenPath();
      process.env.USERPROFILE = old; if (oldH !== undefined) process.env.ASKALICE_HOME = oldH;
      return p.includes('.askalice') && (platform() !== 'win32' || p.startsWith('C:\\Users\\rob'));
    } },
  { name: 'a usage block is recorded, and costs nothing to read back', run: () => {
      const row = recordUsage({ model: 'deepseek-v4-pro', provider: 'platform', usage: { prompt_tokens: 975, completion_tokens: 141, total_tokens: 1116 } }, { at: '2026-11-05T00:00:00Z' });
      const back = lastUsage();
      return row && row.total_tokens === 1116 && back && back.total_tokens === 1116; } },
  { name: 'RED: a response with no usage records nothing', run: () => recordUsage({ approved: true }) === null },
  { name: 'redact never returns the full token', run: () => !redact('dvc_0123456789abcdef').includes('0123456789abcdef') }
];

if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href && process.argv.includes('--self-test')) {
  let bad = 0;
  for (const t of tests) {
    let ok = false, err = '';
    try { ok = (await t.run()) === true; } catch (e) { err = e.message; }
    if (ok) console.log(`  ok    ${t.name}`);
    else { bad++; console.error(`  FAIL  ${t.name}${err ? ' — ' + err : ''}`); }
  }
  console.log(`\nmorpheus client: ${tests.length - bad}/${tests.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
