#!/usr/bin/env node
// pdf.mjs — the adapter that decides whether any of this works for academics, because most of their sources are
// PDFs and a PDF has no <a href> to follow.
//
// WHY THIS FILE EXISTS. The descent can read a wiki's edit source and a page's links. A PDF is a different
// animal: it is a page description language, not a document. Text lives inside compressed content streams, in
// show-text operators, in an encoding that owes nothing to Unicode. So "read the PDF" is a real piece of work
// and not a fetch with a different header.
//
// WHAT IT HONESTLY DOES, v1.0.0:
//   - finds page objects and their content streams (walking /Contents references, not guessing);
//   - inflates FlateDecode streams and reads uncompressed ones;
//   - extracts text from the show operators (Tj, TJ, ', ") and turns text-positioning into spaces;
//   - returns ONE STRING PER PAGE, whitespace-normalised, so a span can say "page 4, characters 1210-1340".
//
// WHAT IT DOES NOT DO, and will say so rather than return half a page:
//   - a PDF with /Encrypt is refused outright: an encrypted stream decodes to noise, and noise scored as text is
//     the worst possible outcome for a verification tool;
//   - Type3/embedded font encodings that map glyphs to non-text are not guessed at — an unmappable stream
//     yields no text and is reported as such;
//   - layout (columns, tables, reading order) is not reconstructed. A span is a quote on a page, and a reader
//     checks it against the page, which is what a PDF page is for.
import { inflateSync, inflateRawSync, deflateSync } from 'node:zlib';
import { pathToFileURL } from 'node:url';
// A module that runs its fixtures on IMPORT exits the importing process: it silently truncated another suite's
// output the first time this was wired together. Main-module check, once, at the top.
const IS_MAIN = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;

export const PDF_EXTRACTOR = { name: 'pdf-text', version: '1.0.0' };

export function isPdf(buf) {
  const head = Buffer.isBuffer(buf) ? buf.subarray(0, 5).toString('latin1') : String(buf ?? '').slice(0, 5);
  return head === '%PDF-';
}

/** streamAt — the decoded bytes of the stream whose 'stream' keyword begins at `at`. */
function streamAt(buf, latin, at) {
  let dataStart = at + 6;                       // 'stream'
  if (latin.startsWith('\r\n', dataStart)) dataStart += 2;
  else if (latin.startsWith('\n', dataStart) || latin.startsWith('\r', dataStart)) dataStart += 1;
  const end = latin.indexOf('endstream', dataStart);
  if (end === -1) return null;
  let data = buf.subarray(dataStart, end);
  // the trailing EOL before 'endstream' is not part of the data
  if (data.length && data[data.length - 1] === 0x0a) data = data.subarray(0, data.length - 1);
  if (data.length && data[data.length - 1] === 0x0d) data = data.subarray(0, data.length - 1);
  const dict = latin.slice(Math.max(0, at - 400), at);
  const flate = /\/FlateDecode/.test(dict);
  if (flate) {
    try { return inflateSync(data); } catch { try { return inflateRawSync(data); } catch { return null; } }
  }
  return data;
}

/** decodeLiteral — a PDF string body: escapes, octal, and parentheses that are content. */
function decodeLiteral(body) {
  let out = '';
  for (let i = 0; i < body.length; i++) {
    const c = body[i];
    if (c !== '\\') { out += c; continue; }
    const n = body[i + 1];
    if (n === undefined) break;
    if (n === 'n') { out += ' '; i++; }
    else if (n === 'r') { out += ' '; i++; }
    else if (n === 't') { out += ' '; i++; }
    else if (n === 'b' || n === 'f') { i++; }
    else if (n === '(' || n === ')' || n === '\\') { out += n; i++; }
    else if (/[0-7]/.test(n)) {
      let oct = '';
      let j = i + 1;
      while (j < body.length && oct.length < 3 && /[0-7]/.test(body[j])) oct += body[j++];
      out += String.fromCharCode(parseInt(oct, 8));
      i = j - 1;
    } else { out += n; i++; }
  }
  return out;
}

/**
 * textFromContent — the words a content stream paints, in order.
 *
 * THE KERNING RULE, bought 2026-11-05 on a real paper. A PDF often sets a word by painting several strings with
 * a small horizontal adjustment between them, so a naive "join every string with a space" turns "attribution"
 * into "attrib ution". That is not cosmetic: containment then fails on a word that IS on the page. So inside a
 * TJ array a space is inserted only when the adjustment is a real word gap (<= -200 units), not for kerning.
 */
export function textFromContent(stream) {
  const s = Buffer.isBuffer(stream) ? stream.toString('latin1') : String(stream ?? '');
  let out = '';
  let i = 0;

  const readString = (at) => {              // at '(' -> { text, next }
    let depth = 1, j = at + 1;
    while (j < s.length && depth > 0) {
      if (s[j] === '\\') { j += 2; continue; }
      if (s[j] === '(') depth++;
      else if (s[j] === ')') depth--;
      j++;
    }
    return { text: decodeLiteral(s.slice(at + 1, depth === 0 ? j - 1 : j)), next: j };
  };

  while (i < s.length) {
    const c = s[i];

    // a TJ array: strings and numbers, and the numbers are kerning
    if (c === '[') {
      let j = i + 1, depth = 1;
      const items = [];
      while (j < s.length && depth > 0) {
        const ch = s[j];
        if (ch === '[') { depth++; j++; continue; }
        if (ch === ']') { depth--; j++; if (depth === 0) break; continue; }
        if (ch === '(') { const r = readString(j); items.push({ t: 's', v: r.text }); j = r.next; continue; }
        if (ch === '<') {
          const close = s.indexOf('>', j);
          const hex = s.slice(j + 1, close).replace(/\s+/g, '');
          let t = '';
          for (let k = 0; k + 1 < hex.length; k += 2) {
            const code = parseInt(hex.substr(k, 2), 16);
            if (code >= 32 && code < 127) t += String.fromCharCode(code);
          }
          items.push({ t: 's', v: t });
          j = close + 1;
          continue;
        }
        const num = /^-?\d+(\.\d+)?/.exec(s.slice(j, j + 12));
        if (num) { items.push({ t: 'n', v: Number(num[0]) }); j += num[0].length; continue; }
        j++;
      }
      const after = s.slice(j, j + 8);
      if (/^\s*TJ/.test(after)) {
        for (const it of items) {
          if (it.t === 's') out += it.v;
          else if (it.v <= -200) out += ' ';     // a real word gap
        }
        out += ' ';
      } else {
        for (const it of items) if (it.t === 's') out += it.v + ' ';
      }
      i = j;
      continue;
    }

    if (c === '(') { const r = readString(i); out += r.text + ' '; i = r.next; continue; }

    if (c === '<' && /[0-9A-Fa-f\s]/.test(s[i + 1] ?? '')) {
      const close = s.indexOf('>', i);
      if (close > i) {
        const hex = s.slice(i + 1, close).replace(/\s+/g, '');
        if (hex.length % 2 === 0 && /^[0-9A-Fa-f]*$/.test(hex)) {
          let t = '';
          for (let k = 0; k < hex.length; k += 2) {
            const code = parseInt(hex.substr(k, 2), 16);
            if (code >= 32 && code < 127) t += String.fromCharCode(code);
            else if (code === 32) t += ' ';
          }
          out += t + ' ';
        }
        i = close + 1;
        continue;
      }
    }

    if (s.startsWith('Td', i) || s.startsWith('TD', i) || s.startsWith('T*', i) || s.startsWith('ET', i)) {
      out += ' ';
      i += 2;
      continue;
    }
    i++;
  }
  return out.replace(/\s+/g, ' ').trim();
}

/** pageRefs — the /Contents stream numbers of each page object, in document order. */
function pageRefs(latin) {
  const pages = [];
  const re = /(\d+)\s+0\s+obj\b([\s\S]{0,600}?)\bendobj/g;
  let m;
  while ((m = re.exec(latin))) {
    const body = m[2];
    if (!/\/Type\s*\/Page\b(?!s)/.test(body)) continue;
    const single = body.match(/\/Contents\s+(\d+)\s+0\s+R/);
    const many = body.match(/\/Contents\s*\[([^\]]*)\]/);
    const refs = [];
    if (single) refs.push(Number(single[1]));
    else if (many) {
      const rr = /(\d+)\s+0\s+R/g;
      let x;
      while ((x = rr.exec(many[1]))) refs.push(Number(x[1]));
    }
    pages.push({ obj: Number(m[1]), refs });
  }
  return pages;
}

function objectStream(buf, latin, num) {
  const re = new RegExp(`(?:^|[\\r\\n])\\s*${num}\\s+0\\s+obj\\b`, 'g');
  const m = re.exec(latin);
  if (!m) return null;
  const at = latin.indexOf('stream', m.index);
  if (at === -1) return null;
  return streamAt(buf, latin, at);
}

/**
 * pdfPages — one normalised string per page, plus an honest reason when there is no text.
 * This is the function every other part of the system uses; it never throws.
 */
export function pdfPages(input) {
  const buf = Buffer.isBuffer(input) ? input : Buffer.from(String(input ?? ''), 'latin1');
  if (!isPdf(buf)) return { pages: [], reason: 'not a PDF: the file does not begin %PDF-', encrypted: false };
  const latin = buf.toString('latin1');
  if (/\/Encrypt\b/.test(latin)) {
    return { pages: [], reason: 'the PDF is encrypted — an encrypted stream decodes to noise, and noise scored as text is worse than no text', encrypted: true };
  }
  const refs = pageRefs(latin);
  const pages = [];
  if (refs.length) {
    for (const p of refs) {
      let text = '';
      if (!p.refs.length) { pages.push(''); continue; }
      for (const num of p.refs) {
        const st = objectStream(buf, latin, num);
        if (st) text += ' ' + textFromContent(st);
      }
      pages.push(text.replace(/\s+/g, ' ').trim());
    }
  } else {
    // No page tree this build can walk: read every content-like stream in document order and report one page.
    const re = /stream\r?\n/g;
    let m, all = '';
    while ((m = re.exec(latin))) {
      const st = streamAt(buf, latin, m.index - 0);
      if (!st) continue;
      const t = textFromContent(st);
      if (t) all += ' ' + t;
    }
    pages.push(all.replace(/\s+/g, ' ').trim());
    if (!pages[0]) return { pages, reason: 'no page tree and no readable content streams', encrypted: false };
    return { pages, reason: 'no page tree could be walked; the text is the whole document as page 1', encrypted: false };
  }
  const any = pages.some((p) => p.length > 0);
  return { pages, reason: any ? null : 'the document has pages but no text this build can read (a scan, or an unmappable encoding)', encrypted: false };
}

/** pdfText — the whole document, pages joined by a form-feed, so offsets stay per page. */
export function pdfText(input) {
  const { pages, reason } = pdfPages(input);
  return { text: pages.join('\f'), pages, reason };
}

// ---------------------------------------------------------------------------
// fixtures — tiny PDFs built in code, so the test needs no file and no library
// ---------------------------------------------------------------------------
export function makePdf({ text = 'The bridge opened in 1932.', flate = false, encrypt = false, imageOnly = false } = {}) {
  const content = imageOnly
    ? 'q 200 0 0 100 0 0 cm /Im1 Do Q'
    : `BT /F1 12 Tf 72 720 Td (${text.replace(/[()\\]/g, (c) => '\\' + c)}) Tj ET`;
  const body = Buffer.from(content, 'latin1');
  const data = flate ? deflateSync(body) : body;
  const head = Buffer.from(
    '%PDF-1.4\n' +
    '1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n' +
    '2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n' +
    '3 0 obj << /Type /Page /Parent 2 0 R /Contents 4 0 R >> endobj\n' +
    `4 0 obj << /Length ${data.length}${flate ? ' /Filter /FlateDecode' : ''} >>\nstream\n`, 'latin1');
  const tail = Buffer.from('\nendstream endobj\n' + (encrypt ? '5 0 obj << /Encrypt true >> endobj\n' : '') + 'trailer << /Root 1 0 R >>\n%%EOF\n', 'latin1');
  return Buffer.concat([head, data, tail]);
}

const FIXTURES = [
  { name: 'text is read from an uncompressed page', run: () => pdfPages(makePdf()).pages[0].includes('bridge opened in 1932') },
  { name: 'text is read from a FlateDecode page', run: () => pdfPages(makePdf({ flate: true })).pages[0].includes('bridge opened in 1932') },
  { name: 'one entry per page', run: () => pdfPages(makePdf()).pages.length === 1 },
  { name: 'parentheses inside the text survive', run: () => pdfPages(makePdf({ text: 'The bridge (1937) is long.' })).pages[0].includes('(1937)') },
  { name: 'RED: an encrypted PDF is refused, not decoded to noise', run: () => {
      const r = pdfPages(makePdf({ encrypt: true })); return r.encrypted === true && r.pages.length === 0 && /encrypted/.test(r.reason); } },
  { name: 'RED: a page with only an image yields no text and says why', run: () => {
      const r = pdfPages(makePdf({ imageOnly: true }));
      return r.pages[0] === '' && /no text this build can read/.test(r.reason || ''); } },
  { name: 'RED: a non-PDF is refused by its header', run: () => {
      const r = pdfPages(Buffer.from('<html>not a pdf</html>')); return r.pages.length === 0 && /not a PDF/.test(r.reason); } }
];

if (IS_MAIN && process.argv.includes('--self-test')) {
  let bad = 0;
  for (const f of FIXTURES) {
    let ok = false, err = '';
    try { ok = f.run() === true; } catch (e) { err = e.message; }
    if (ok) console.log(`  ok    ${f.name}`);
    else { bad++; console.error(`  FAIL  ${f.name}${err ? ' — ' + err : ''}`); }
  }
  console.log(`\npdf: ${FIXTURES.length - bad}/${FIXTURES.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
