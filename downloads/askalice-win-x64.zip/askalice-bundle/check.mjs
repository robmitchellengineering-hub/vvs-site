#!/usr/bin/env node
// check.mjs — the reference checks for VDS Extension 1, and the proof that each one fails when it should.
//
// WHY THIS FILE EXISTS. The spec says a conforming system must show each verdict going red on a fixture
// (CLAIM-RECORD.md §8). Without that table an implementer ships a checker that has never been wrong, which is
// indistinguishable from a checker that does nothing. This is the reference: three checks, nine fixtures, and
// `--self-test` exits non-zero unless every one of them behaves.
//
// WHAT IT HONESTLY IS. These are not readers of meaning. `span-containment` v1.0.0 answers exactly one
// question — are the claim's content words present in this span — and records that it answered that. It does
// not detect entailment, sarcasm, or a quotation under discussion. Two consequences are built in rather than
// papered over:
//
//   1. A NEGATIVE claim cannot be established by containment. "245 is not mandatory" is supported by the
//      absence of a mandatory flag, and absence cannot be found in a span. Such a claim returns
//      `unknown/ambiguous` unless the span carries an explicit negation. Writing the checker is what found
//      this; the spec now carries the rule.
//   2. A refusal to fetch is not a fact. 403, 404, 429, 5xx, timeouts and paywalls are five different
//      UNKNOWNs; 404 is still not a contradiction, and 403 is not a missing source.
//
// Dependency-free, deterministic, offline by default: the fetch is injected, so the 403 and 404 fixtures are
// exact rather than incidental.
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
// A module that runs its fixtures on IMPORT exits the importing process: it silently truncated another suite's
// output the first time this was wired together. Main-module check, once, at the top.
const IS_MAIN = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;

const CHECK = { name: 'span-containment', version: '1.0.0' };
const TRIAGE = { name: 'triage-heuristic', version: '1.0.0' };
const LAYERS = ['bytes', 'coded-values', 'authority', 'content'];

// The tokeniser lives in extract.mjs and is imported, not copied: two copies of "what a word is" is how a
// containment check and a span finder come to disagree about the same page.
import { EXTRACTOR, extractText, findSpan, hashBytes, refind, contentWords, words as tokens } from './extract.mjs';
import { isPdf, pdfPages, PDF_EXTRACTOR, makePdf } from './pdf.mjs';

const NEGATION = new Set(['not', 'no', 'never', 'none', 'without', 'denies', 'denied', 'refuses', 'refuted',
  'false', 'incorrect', 'untrue', 'unfounded', 'fails', 'isnt', 'doesnt', 'wasnt', 'cannot', "n't"]);
const EVALUATIVE = new Set(['disgrace', 'shameful', 'appalling', 'brilliant', 'terrible', 'wonderful',
  'disgusting', 'ridiculous', 'outrageous', 'fantastic', 'awful', 'great', 'best', 'worst']);

// ---------------------------------------------------------------------------
// triage — is this string a checkable claim at all?
// A HEURISTIC, and it says so. It refuses to call something `not-a-claim` when it can see a subject and a
// value; that direction is deliberate, because filing a checkable claim as opinion is the failure that hides
// work, while filing an opinion as a claim only costs a check.
// ---------------------------------------------------------------------------
export function triage(text) {
  const t = String(text ?? '').trim();
  if (!t) return { verdict: 'not-a-claim', reason: 'empty string' };
  if (/\?$/.test(t)) return { verdict: 'not-a-claim', reason: 'a question asserts nothing' };
  const words = tokens(t);
  const evals = words.filter((w) => EVALUATIVE.has(w));
  const nums = words.filter((w) => /\d/.test(w));
  const hasVerb = words.some((w) => /(ed|ing)$/.test(w) || ['is', 'was', 'are', 'were', 'has', 'have', 'had', 'opened', 'founded', 'won', 'cost', 'reached'].includes(w));
  if (evals.length && !nums.length && contentWords(t).length <= 6) {
    return { verdict: 'not-a-claim', reason: `evaluative language (${evals[0]}) with no checkable quantity` };
  }
  if (!hasVerb) return { verdict: 'not-a-claim', reason: 'no finite verb — nothing is asserted' };
  if (contentWords(t).length < 2) return { verdict: 'not-a-claim', reason: 'too little content to be a claim' };
  return { verdict: 'claim', reason: 'has a subject, a verb and a value' };
}

// ---------------------------------------------------------------------------
// containment — the only mechanical question this check asks
// ---------------------------------------------------------------------------
export function containment(claim, spanText) {
  const spanTokens = new Set(tokens(spanText));
  const subject = contentWords(claim.subject);
  const value = contentWords(claim.value);
  // The predicate carries the relation word, which a span states in its own way ("is" / "was" / "-").
  // So it is reported, not required: requiring it would fail every claim written in the active voice.
  const predicate = contentWords(claim.predicate);
  const missing = [...subject, ...value].filter((w) => !spanTokens.has(w));
  const matched = [...subject, ...value].filter((w) => spanTokens.has(w));
  const supportsNegation = [...NEGATION].some((n) => spanTokens.has(n));
  // A NUMBER IS NOT A WORD. "the bridge opened on May 27" was reported supported by a navigation menu that
  // contained "Bridge" and "May" — containment was satisfied and the claim was not. If the value carries a
  // digit, the span must carry that digit; found by the first desk run on a live page, 2026-11-05.
  const number = (String(claim.value ?? '').match(/\d[\d,.–-]*/) || [])[0];
  const numberFound = number ? spanText.includes(number) : true;
  return { supported: missing.length === 0 && matched.length > 0 && numberFound, missing, matched, predicate, supportsNegation, number, numberFound };
}

// A claim whose value is a negation cannot be established by finding words in a span.
function isNegativeClaim(claim) {
  const v = String(claim?.value ?? '').toLowerCase();
  if (['false', 'no', 'not', 'never', 'none', 'incorrect', 'untrue'].includes(v.trim())) return true;
  return tokens(v).some((w) => NEGATION.has(w));
}


/**
 * checkFetched — build a record from a claim and an already-fetched source.
 * `fetched` = { uri, httpStatus, body, fetchedAt?, contentHash? }
 */
export function checkFetched(claim, fetched, scope) {
  const rec = (over) => ({
    id: over.id ?? 'cr_' + createHash('sha256').update(JSON.stringify([claim, fetched?.uri, over.verdict, over.reason])).digest('hex').slice(0, 12),
    claim: { subject: claim.subject, predicate: claim.predicate, value: claim.value },
    evidence: null,
    check: CHECK,
    verifier: { kind: 'machine', id: 'valiant/reference-check' },
    verdict: over.verdict,
    reason: over.reason,
    falsifier: over.falsifier ?? 'a source that states the claim, or an explicit denial in this one',
    scope: { layer: scope?.layer ?? 'content', item: scope?.item ?? (fetched?.uri ?? 'unknown') },
    ...(over.evidence !== undefined ? { evidence: over.evidence } : {}),
    ...(over.checked !== undefined ? { checked: over.checked } : {})
  });

  const status = fetched?.httpStatus;
  // ---- the five unknowns. 403 is NOT 404 and 404 is NOT a contradiction.
  if (status === 403) return rec({ verdict: 'unknown', reason: 'http-403' });
  if (status === 404) return rec({ verdict: 'unknown', reason: 'http-404' });
  if (status === 429) return rec({ verdict: 'unknown', reason: 'http-429' });
  if (typeof status === 'number' && status >= 500) return rec({ verdict: 'unknown', reason: 'http-5xx' });
  if (typeof status !== 'number' || status < 200 || status >= 300) {
    return rec({ verdict: 'unknown', reason: 'check-not-run' });
  }

  const body = String(fetched.body ?? '');
  // A PDF is read page by page: a span carries the page it is on, because "page 4, characters 1210-1340" is what
  // a reader can check and "characters 41000-41200" is not.
  const isPdfBody = isPdf(fetched.body);
  const contentHash = fetched.contentHash ?? hashBytes(isPdfBody ? Buffer.from(fetched.body).toString('latin1') : body);
  if (isPdfBody) {
    const { pages, reason } = pdfPages(fetched.body);
    if (!pages.length || !pages.some((p) => p.length)) {
      return rec({ verdict: 'unknown', reason: 'no-span', falsifier: reason || 'a text layer in this document' });
    }
    const wanted = contentWords(`${claim.subject} ${claim.value}`);
    let bestPage = 0, bestScore = -1;
    pages.forEach((pg, i) => {
      const score = wanted.filter((w) => pg.toLowerCase().includes(w)).length;
      if (score > bestScore && pg.length) { bestScore = score; bestPage = i; }
    });
    const pageText = pages[bestPage];
    const missing = wanted.filter((w) => !pageText.toLowerCase().includes(w));
    if (missing.length) {
      return rec({ verdict: 'unknown', reason: 'no-span', falsifier: "the words of the claim appearing on a page of this document", evidence: null });
    }
    const sp = findSpan(pageText, claim);
    return rec({
      verdict: 'supported-in-span',
      reason: `containment on page ${bestPage + 1}: ${wanted.length - missing.length}/${wanted.length} claim words present, page ${pages.length} of the document`,
      evidence: {
        uri: fetched.uri,
        fetchedAt: fetched.fetchedAt ?? new Date().toISOString(),
        httpStatus: status,
        span: { quote: sp.quote, start: sp.start, end: sp.end, page: bestPage + 1, extractor: PDF_EXTRACTOR },
        contentHash
      }
    });
  }
  // Offsets are taken into the EXTRACTED TEXT, never the bytes: on an HTML page the bytes put them in markup.
  const text = extractText(body);

  // A negative claim: containment cannot support absence.
  if (isNegativeClaim(claim)) {
    const spanText = text; // the searched region, in text space
    if (!/\b(not|no|never|false|without|absent|none)\b/i.test(spanText)) {
      return rec({
        verdict: 'unknown',
        reason: 'ambiguous',
        falsifier: 'a statement in the same source that the claim is false, or a rule that makes it required',
        evidence: undefined,
        reason_note: 'a negative claim is supported by an ABSENCE, and an absence is not findable in a span'
      });
    }
  }

  const spanText = text;
  const c = containment(claim, spanText);
  if (!c.supported) {
    return rec({
      verdict: 'unknown',
      reason: 'no-span',
      falsifier: 'the claim\'s words appearing in this source, or a better source',
      evidence: null,
      // an UNKNOWN that looked somewhere must say where: "I fetched this and did not find it" is the most useful
      // sentence a verification tool prints, and it is not the same as "I did not look".
      checked: { uri: fetched.uri, httpStatus: status }
    });
  }
  const { start, end, quote } = findSpan(text, claim);
  return rec({
    verdict: 'supported-in-span',
    reason: `containment only: ${c.matched.length} claim words present${c.number ? `, the number ${c.number} found in the span` : ''}; predicate words reported not required`,
    evidence: {
      uri: fetched.uri,
      fetchedAt: fetched.fetchedAt ?? new Date().toISOString(),
      httpStatus: status,
      span: { quote, start, end, extractor: EXTRACTOR },
      contentHash
    }
  });
}

/** assertUnbacked — the record builder must refuse `unbacked` when a source exists. */
export function canBeUnbacked(evidence) {
  return evidence === null || evidence === undefined;
}

// ---------------------------------------------------------------------------
// fixtures — every one of these must behave, or the self-test fails
// ---------------------------------------------------------------------------
const claim = { subject: 'the bridge', predicate: 'opened in', value: '1932' };
const page = 'The bridge opened in 1932 after four years of construction. It carries 40,000 vehicles a day.';

const HTML_PAGE = '<html><head><style>body{color:red}</style><script>var claim="the bridge opened in 1932";</script></head>' +
  '<body><p>The bridge opened in <b>1932</b> after four years of construction.</p>' +
  '<p>It carries 40,000 vehicles a day.</p></body></html>';

const FIXTURES = [
  // ---- the three checks working
  { name: 'containment: claim present in span', run: () => checkFetched(claim, { uri: 'https://e/x', httpStatus: 200, body: page }).verdict === 'supported-in-span' },
  { name: 'containment: span offsets locate the quote', run: () => {
      const r = checkFetched(claim, { uri: 'https://e/x', httpStatus: 200, body: page });
      const e = r.evidence; return e && e.span.start >= 0 && e.span.end > e.span.start && e.contentHash.startsWith('sha256:');
    } },
  { name: 'triage: a real assertion is a claim', run: () => triage('The bridge opened in 1932.').verdict === 'claim' },
  { name: 'triage: an opinion is not a claim', run: () => triage('That bridge is a disgrace.').verdict === 'not-a-claim' },

  // ---- the six mutation fixtures: each must produce the RIGHT refusal
  { name: 'RED: claim absent from the span is not supported', run: () => checkFetched({ subject: 'the tunnel', predicate: 'opened in', value: '1999' }, { uri: 'https://e/x', httpStatus: 200, body: page }).verdict !== 'supported-in-span' },
  { name: 'RED: 403 is http-403, never http-404', run: () => { const r = checkFetched(claim, { uri: 'https://e/x', httpStatus: 403, body: '' }); return r.verdict === 'unknown' && r.reason === 'http-403'; } },
  { name: 'RED: 404 is http-404, never contradicted', run: () => { const r = checkFetched(claim, { uri: 'https://e/x', httpStatus: 404, body: '' }); return r.verdict === 'unknown' && r.reason === 'http-404'; } },
  { name: 'RED: a negative claim is not "supported" by absence', run: () => { const r = checkFetched({ subject: 'MARC 245', predicate: 'is mandatory', value: 'false' }, { uri: 'https://e/x', httpStatus: 200, body: '245 - Title Statement (NR)' }); return r.verdict === 'unknown'; } },
  { name: 'RED: unbacked is refused when evidence exists', run: () => canBeUnbacked({ uri: 'https://e/x' }) === false },
  { name: 'RED: a sentence with a real triple is not filed as not-a-claim', run: () => triage('The bridge opened in 1932.').verdict !== 'not-a-claim' },

  // ---- PDFs: the source class that decides whether this works for academics
  { name: 'pdf: a claim on a page gets a page-numbered span', run: () => {
      const rec = checkFetched({ subject: 'the bridge', predicate: 'opened in', value: '1932' },
        { uri: 'https://e/x.pdf', httpStatus: 200, body: makePdf() });
      return rec.verdict === 'supported-in-span' && rec.evidence.span.page === 1 && rec.evidence.span.extractor.name === 'pdf-text';
    } },
  { name: 'pdf: the span re-finds on its page', run: () => {
      const buf = makePdf();
      const rec = checkFetched({ subject: 'the bridge', predicate: 'opened in', value: '1932' }, { uri: 'u', httpStatus: 200, body: buf });
      return refind(rec, buf).state === 'unchanged';
    } },
  { name: 'RED: an encrypted PDF is unknown, never supported', run: () => {
      const rec = checkFetched({ subject: 'the bridge', predicate: 'opened in', value: '1932' },
        { uri: 'u', httpStatus: 200, body: makePdf({ encrypt: true }) });
      return rec.verdict === 'unknown';
    } },
  { name: 'RED: a claim absent from the PDF is not supported by page 1', run: () => {
      const rec = checkFetched({ subject: 'the tunnel', predicate: 'opened in', value: '1999' },
        { uri: 'u', httpStatus: 200, body: makePdf() });
      return rec.verdict !== 'supported-in-span';
    } },

  // ---- extraction and the round trip: a span is only evidence if it can be walked back
  { name: 'extract: script and style are not page text', run: () => {
      const t = extractText(HTML_PAGE);
      return t.includes('bridge opened in 1932') && !t.includes('var claim') && !t.includes('color:red');
    } },
  { name: 'extract: entities decode before offsets are taken', run: () => extractText('<p>R&amp;D spending &mdash; up</p>') === 'R&D spending — up' },
  { name: 'span: offsets land in text, never in markup', run: () => {
      const text = extractText(HTML_PAGE);
      const sp = findSpan(text, claim);
      return !sp.quote.includes('<') && sp.quote.includes('opened in');
    } },
  { name: 'refind: unchanged round trip', run: () => {
      const rec = checkFetched(claim, { uri: 'https://e/x', httpStatus: 200, body: HTML_PAGE });
      return refind(rec, HTML_PAGE).state === 'unchanged';
    } },
  { name: 'refind: a script added above the text does not move the span', run: () => {
      const rec = checkFetched(claim, { uri: 'https://e/x', httpStatus: 200, body: HTML_PAGE });
      return refind(rec, '<script>console.log(1)</script>' + HTML_PAGE).state === 'unchanged';
    } },
  { name: 'refind: an edited sentence reports gone, not unchanged', run: () => {
      const rec = checkFetched(claim, { uri: 'https://e/x', httpStatus: 200, body: HTML_PAGE });
      // NB: the first version of this fixture replaced '1932', which occurs FIRST inside the <script>. The
      // extracted text was therefore unchanged and the check correctly said 'unchanged' — the fixture was
      // wrong, not the code. It now edits the visible sentence.
      return refind(rec, HTML_PAGE.replace('after four years', 'after five years')).state === 'gone';
    } },
  { name: 'refind: a record naming no extractor is unknown', run: () => {
      const rec = checkFetched(claim, { uri: 'https://e/x', httpStatus: 200, body: HTML_PAGE });
      const broken = { ...rec, evidence: { ...rec.evidence, span: { ...rec.evidence.span, extractor: undefined } } };
      return refind(broken, HTML_PAGE).state === 'unknown';
    } }
];

if (IS_MAIN && process.argv.includes('--self-test')) {
  let bad = 0;
  for (const f of FIXTURES) {
    let ok = false, err = '';
    try { ok = f.run() === true; } catch (e) { err = e.message; }
    const mutation = f.name.startsWith('RED:');
    if (ok) console.log(`  ok    ${f.name}`);
    else { bad++; console.error(`  FAIL  ${f.name}${err ? ' — ' + err : ''}`); }
    void mutation;
  }
  console.log(`\nclaim-record checks: ${FIXTURES.length - bad}/${FIXTURES.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}

// ---- a one-record run, so the CLI does something useful ---------------------
// Only when executed, never on import: a module that runs a CLI on import cannot be unit-tested, and this
// file is imported by the fixtures above.
const RUN_AS_CLI = IS_MAIN;
if (!RUN_AS_CLI) { /* imported: export only */ } else {
const [uri, subj, pred, val] = process.argv.slice(2);
if (!uri) {
  console.error('usage: node check.mjs <url> "<subject>" "<predicate>" "<value>" | --self-test');
  process.exit(2);
}
const res = await fetch(uri, { redirect: 'follow' }).catch((e) => ({ status: 0, err: e }));
const body = res.status && res.body ? await res.text() : '';
const record = checkFetched({ subject: subj ?? '', predicate: pred ?? '', value: val ?? '' },
  { uri, httpStatus: res.status ?? 0, body, fetchedAt: new Date().toISOString() });
console.log(JSON.stringify(record, null, 2));
process.exit(record.verdict === 'unknown' ? 2 : 0);
}
void LAYERS; void TRIAGE;
