#!/usr/bin/env node
// keys.mjs — the reader's own credentials for the sources that need them (Trove, and any others later).
//
// WHY THIS EXISTS. The Trove pill links to the API application page, but a link does not CONNECT anything — the
// reader still has no place to put the key they were just issued. This is that place. A key lives in a JSON file
// in the reader's own home, mode 0600, and is NEVER echoed back — the same rule as the device token.
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';

export function keysPath(home) {
  return join(home, 'sources.json');
}

export function loadKeys(home) {
  const p = keysPath(home);
  if (!existsSync(p)) return {};
  try { const o = JSON.parse(readFileSync(p, 'utf8')); return o && typeof o === 'object' ? o : {}; }
  catch { return {}; }
}

/** saveKey — store one key, and return the whole set without the secret so a caller can say "connected" without
 *  ever reading the value back. */
export function saveKey(home, name, value) {
  const keys = loadKeys(home);
  keys[name] = String(value || '').trim();
  const p = keysPath(home);
  mkdirSync(dirname(p), { recursive: true });
  writeFileSync(p, JSON.stringify(keys, null, 2), { mode: 0o600 });
  return Object.keys(keys);
}

export function deleteKey(home, name) {
  const keys = loadKeys(home);
  delete keys[name];
  const p = keysPath(home);
  mkdirSync(dirname(p), { recursive: true });
  writeFileSync(p, JSON.stringify(keys, null, 2), { mode: 0o600 });
  return Object.keys(keys);
}

// fixtures
if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href && process.argv.includes('--self-test')) {
  const { mkdtempSync } = await import('node:fs');
  const { tmpdir } = await import('node:os');
  const { join: j } = await import('node:path');
  const home = mkdtempSync(j(tmpdir(), 'keys-'));
  const tests = [
    { name: 'a key is stored and the value is not returned', run: () => {
        const names = saveKey(home, 'TROVE_API_KEY', 'secret-123');
        return names.includes('TROVE_API_KEY') && loadKeys(home).TROVE_API_KEY === 'secret-123'; } },
    { name: 'a key can be removed', run: () => { deleteKey(home, 'TROVE_API_KEY'); return !('TROVE_API_KEY' in loadKeys(home)); } },
    { name: 'RED: a corrupt file reads as empty, never throws', run: () => {
        writeFileSync(keysPath(home), 'not json'); return Object.keys(loadKeys(home)).length === 0; } },
  ];
  let bad = 0;
  for (const t of tests) { let ok = false; try { ok = t.run() === true; } catch {} if (ok) console.log(`  ok    ${t.name}`); else { bad++; console.error(`  FAIL  ${t.name}`); } }
  console.log(`\nkeys: ${tests.length - bad}/${tests.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
