#!/usr/bin/env node
// extract.mjs — turn a fetched resource into the text a span is measured against, and re-find a span later.
//
// WHY THIS EXISTS. The first version of check.mjs took offsets into the RAW BYTES. On an HTML page those land
// in markup: a live run against example.com produced a quote that began inside the doctype. A span whose
// offsets cannot be walked back to the same words is not evidence — it is a screenshot with a timestamp.
//
// THE CONTRACT THIS FILE MAKES, and the reason it is versioned:
//
//   1. `extractText(raw)` is deterministic. Same bytes in, same text out, forever, for a given version.
//   2. A span's offsets are offsets INTO THAT TEXT, never into the bytes.
//   3. A third party can re-run the extractor on the same resource and slice the same words back out with no
//      access to us, our service, or the original fetch.
//   4. The extractor's name and version travel INSIDE the record. If the normalisation ever changes, records
//      under the old version stay verifiable under it — otherwise every past verdict silently becomes a lie.
//
// Version 1.1.0 adds ONE thing: a heading is a boundary, not a word gap. Before it, "Example Domain This domain
// is for use in documentation examples" was one run of text, so a span that started at the page's <h1> quoted the
// title as if it were the sentence. Blocks now end with a newline, and findSpan starts at a line or sentence
// boundary. Old records keep extractor 1.0.0 and stay verifiable; new ones say 1.1.0.
//
// Version 1.0.0 did four things and no more: drop elements that carry no readable text, turn block boundaries
// into a space, decode character entities, and collapse whitespace. It does NOT fix hyphenation, de-duplicate
// running headers, strip cookie banners, or reconstruct a table's meaning. Each of those would change offsets,
// and each therefore needs its own version.
import { createHash } from 'node:crypto';
import { pdfPages } from './pdf.mjs';

export const EXTRACTOR = { name: 'dom-text', version: '1.1.0' };

const NAMED = {
  amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ',
  mdash: '—', ndash: '–', hellip: '…', middot: '·', bull: '•',
  lsquo: '\u2018', rsquo: '\u2019', ldquo: '\u201c', rdquo: '\u201d',
  copy: '©', reg: '®', trade: '™', deg: '°', pound: '£', euro: '€'
};

export function decodeEntities(s) {
  return String(s)
    .replace(/&#(\d+);/g, (_, d) => {
      const n = Number(d);
      return Number.isFinite(n) && n > 0 && n < 0x110000 ? String.fromCodePoint(n) : '';
    })
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => {
      const n = parseInt(h, 16);
      return Number.isFinite(n) && n > 0 && n < 0x110000 ? String.fromCodePoint(n) : '';
    })
    .replace(/&([a-z]+);/gi, (m, name) => (name.toLowerCase() in NAMED ? NAMED[name.toLowerCase()] : m));
}

/** extractText — the only function that decides what "the text of a page" means. */
export function extractText(raw) {
  let s = String(raw ?? '');
  // elements whose contents are machinery, not prose
  s = s.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<template\b[^>]*>[\s\S]*?<\/template>/gi, ' ')
    .replace(/<svg\b[^>]*>[\s\S]*?<\/svg>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ');
  // block boundaries must not weld two words together ("</p><p>" -> " "), inline tags must not either
  // A BLOCK ENDS A LINE. It is the difference between a heading and the sentence under it.
  s = s.replace(/<\/?(?:p|div|br|hr|li|ul|ol|dl|dt|dd|tr|td|th|table|thead|tbody|h[1-6]|section|article|header|footer|main|nav|aside|blockquote|pre|figure|figcaption|form|fieldset)\b[^>]*>/gi, '\n');
  s = s.replace(/<\/?(?:label|option|select|textarea|button|a|span|em|strong|b|i|u|small|code|sup|sub)\b[^>]*>/gi, ' ');
  s = s.replace(/<[^>]+>/g, ' ');
  s = decodeEntities(s);
  // every flavour of space a page can contain, plus the ones entities decode into
  s = s.replace(/[\u00a0\u1680\u2000-\u200b\u202f\u205f\u3000\ufeff]/g, ' ');
  s = s.split('\n').map((line) => line.replace(/[ \t]+/g, ' ').trim()).filter(Boolean).join('\n');
  return s;
}

export function hashBytes(raw) {
  return 'sha256:' + createHash('sha256').update(String(raw ?? ''), 'utf8').digest('hex');
}

/** contentWords — the words a claim is actually about, used by containment and by span finding. */
const STOP = new Set(('a an the is are was were be been being of in on at to for from by with and or not no ' +
  'this that these those it its as if then than into over under has have had does do did').split(' '));
const tokens = (s) => String(s ?? '').toLowerCase().replace(/[’']/g, '')
  .replace(/[^a-z0-9.%-]+/g, ' ').split(/\s+/).filter(Boolean)
  .map((t) => t.replace(/^[.%-]+|[.%-]+$/g, '')).filter(Boolean);
export const contentWords = (s) => tokens(s).filter((t) => t.length >= 2 && !STOP.has(t));
export const words = tokens;

/**
 * findSpan — the sentence that contains the claim, in TEXT space.
 *
 * A span must be pointable-at: "the whole page" is honest about what was searched and useless as evidence.
 * It must also be the RIGHT sentence: "domain" occurs in the heading before it occurs in the sentence that
 * supports the claim, so the first textual match is not the answer. Each candidate is expanded to its
 * sentence, and the first one that contains ALL of the claim's content words wins. The first match is the
 * fallback, so a page with no containing sentence still yields a span to look at.
 */
export function findSpan(text, claim) {
  const wanted = [...contentWords(claim.subject), ...contentWords(claim.value)];
  const all = contentWords(`${claim.subject} ${claim.value}`);
  const lower = text.toLowerCase();

  const candidateIndexes = [];
  for (const w of wanted) {
    let at = lower.indexOf(w);
    while (at !== -1 && candidateIndexes.length < 60) { candidateIndexes.push(at); at = lower.indexOf(w, at + 1); }
  }
  candidateIndexes.sort((x, y) => x - y);

  const expand = (idx) => {
    const lineStart = text.lastIndexOf('\n', Math.max(0, idx - 1));
    const sentStart = text.lastIndexOf('. ', Math.max(0, idx - 2));
    let start;
    if (lineStart > sentStart) start = lineStart + 1;
    else if (sentStart !== -1) start = sentStart + 2;
    else start = 0;

    const nextLine = text.indexOf('\n', idx);
    let end = text.indexOf('. ', idx);
    if (nextLine !== -1 && (end === -1 || nextLine < end)) end = nextLine;
    else if (end !== -1) end += 2;
    else end = Math.min(text.length, idx + 200);
    if (end - start > 600) end = start + 600;
    return { start, end, quote: text.slice(start, end) };
  };

  let fallback = null;
  for (const idx of candidateIndexes) {
    const sp = expand(idx);
    const has = all.every((w) => sp.quote.toLowerCase().includes(w));
    if (!fallback) fallback = { ...sp, matchedWord: lower.slice(idx).split(/\s/)[0] };
    if (has) return { ...sp, matchedWord: lower.slice(idx).split(/\s/)[0] };
  }
  if (fallback) return fallback;
  return { start: 0, end: Math.min(text.length, 300), quote: text.slice(0, 300), matchedWord: null };
}

/**
 * refind — walk a recorded span back out of a resource, without trusting the recorder.
 * Three answers, and they are different: unchanged / moved / gone. A "gone" that was reported as "unchanged"
 * is how a stale verdict survives the page it was about.
 */
export function refind(record, rawNow) {
  const sp = record?.evidence?.span;
  if (!sp || !Number.isInteger(sp.start) || !Number.isInteger(sp.end)) {
    return { state: 'no-span', reason: 'the record carries no span offsets to re-find' };
  }
  if (!record?.evidence?.span?.extractor) {
    return { state: 'unknown', reason: 'the record names no extractor, so the text cannot be reproduced' };
  }
  const isPdfSpan = sp.extractor?.name === 'pdf-text';
  if (isPdfSpan) {
    if (!Number.isInteger(sp.page) || sp.page < 1) return { state: 'no-span', reason: 'a pdf span must name its page' };
    const { pages, reason } = pdfPages(rawNow);
    const pageText = pages[sp.page - 1];
    if (pageText === undefined) return { state: 'gone', reason: reason || 'the document has fewer pages than the record names' };
    const onPage = pageText.slice(sp.start, sp.end);
    if (onPage === sp.quote) return { state: 'unchanged', page: sp.page };
    const movedOnPage = pageText.indexOf(sp.quote);
    if (movedOnPage >= 0) return { state: 'moved', from: sp.start, to: movedOnPage, page: sp.page };
    return { state: 'gone', page: sp.page, got: onPage.slice(0, 120) };
  }
  const text = extractText(rawNow);
  const at = text.slice(sp.start, sp.end);
  if (at === sp.quote) return { state: 'unchanged', textLength: text.length };
  const moved = text.indexOf(sp.quote);
  if (moved >= 0) return { state: 'moved', from: sp.start, to: moved, textLength: text.length };
  return { state: 'gone', textLength: text.length, got: at.slice(0, 120) };
}

// ---------------------------------------------------------------------------
// fixtures — the extractor is versioned because these offsets are the thing everything else trusts
// ---------------------------------------------------------------------------
const HEADED = '<h1>Example Domain</h1><p>This domain is for use in documentation examples.</p><p>Avoid use in operations.</p>';

const EXTRACT_TESTS = [
  { name: 'a heading is a line, not the start of the sentence', run: () => {
      const text = extractText(HEADED);
      const sp = findSpan(text, { subject: 'the domain', predicate: 'is for use in', value: 'documentation examples' });
      return sp.quote.startsWith('This domain') && !sp.quote.includes('Example Domain'); } },
  { name: 'a span does not run across a line break', run: () => {
      const text = extractText(HEADED);
      const sp = findSpan(text, { subject: 'the domain', predicate: 'x', value: 'documentation examples' });
      return !sp.quote.includes('Avoid use'); } },
  { name: 'script and style are still not text', run: () => {
      const t = extractText('<script>var x=1</script><style>a{}</style><p>Real words here.</p>');
      return t === 'Real words here.'; } },
  { name: 'entities still decode', run: () => extractText('<p>R&amp;D &mdash; up</p>') === 'R&D — up' },
  { name: 'refind still walks a recorded span back out', run: () => {
      const claim = { subject: 'the domain', predicate: 'is for use in', value: 'documentation examples' };
      const text = extractText(HEADED);
      const sp = findSpan(text, claim);
      const rec = { evidence: { span: { quote: sp.quote, start: sp.start, end: sp.end, extractor: EXTRACTOR } } };
      return refind(rec, HEADED).state === 'unchanged'; } }
];

if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href && process.argv.includes('--self-test')) {
  let bad = 0;
  for (const t of EXTRACT_TESTS) {
    let ok = false, err = '';
    try { ok = t.run() === true; } catch (e) { err = e.message; }
    if (ok) console.log(`  ok    ${t.name}`);
    else { bad++; console.error(`  FAIL  ${t.name}${err ? ' — ' + err : ''}`); }
  }
  console.log(`\nextract (${EXTRACTOR.name} ${EXTRACTOR.version}): ${EXTRACT_TESTS.length - bad}/${EXTRACT_TESTS.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
