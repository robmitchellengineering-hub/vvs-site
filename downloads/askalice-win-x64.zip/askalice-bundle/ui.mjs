#!/usr/bin/env node
// ui.mjs — `askalice ui`: serve one page that runs the same checks the CLI runs.
//
// The page is a file (ui.html), not a string in here: the client's own templating collided with the server's,
// and a page a person edits should be a page, not a literal buried in a server.
import { createServer } from 'node:http';
import { readFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { extractText } from './extract.mjs';
import { isPdf, pdfPages } from './pdf.mjs';
import { checkFetched } from './check.mjs';
import { lineageOf, sourceKind } from './lineage.mjs';
import { loadRefs, addRef, removeRef } from './citations.mjs';
import { exportLibrary, importLibrary } from './backup.mjs';
import { loadKeys, saveKey, deleteKey } from './keys.mjs';
import { citeFor, stylesFor, talkPageRequest } from './cite.mjs';
import { openLibrary, fileDocument, fileClaim, stats, query, documentText, createScene, listScenes, currentSceneId, setCurrentScene } from './library.mjs';
import { audit, auditAgainstLibrary } from './audit.mjs';
import { isOffice, officeText } from './office.mjs';
import { archivedCopy, bestOpenCopy } from './research.mjs';
import { remediationFor } from './remediation.mjs';
import { whatTheLibrarySays } from './synthesis.mjs';
import { research, gatedSources } from './research.mjs';
import { balance, readToken, aiCall } from './morpheus.mjs';
import { home } from './morpheus.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const UA = { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
  'accept': 'text/html,application/xhtml+xml,application/pdf;q=0.9,*/*;q=0.8', 'accept-language': 'en-AU,en;q=0.9' };
const PAGE = () => readFileSync(join(HERE, 'ui.html'), 'utf8');

/** readSource — fetch a URL and reduce it to text. Read and Summarise must agree on the SAME text, so both call
 *  this; the title is the page title when one exists, else the URL's host. */
/** resolveDoi — what a DOI actually points at, from the services that index it: title, abstract, and the best
 *  open full text. The publisher landing page 403s a machine; the metadata does not. */
async function resolveDoi(doi) {
  let title = null, abstract = null, oaUrl = null;
  try {
    const r = await fetch(`https://api.crossref.org/works/${encodeURIComponent(doi)}`, { headers: { accept: 'application/json', 'user-agent': 'AskAlice/0.2 (mailto:info@valiantmusic.com.au)' } });
    if (r.ok) {
      const j = await r.json();
      const m = j.message || {};
      title = (m.title || [])[0] || null;
      abstract = typeof m.abstract === 'string' ? m.abstract.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() : null;
    }
  } catch { /* a failed metadata lookup must not block the fallbacks */ }
  const oa = await bestOpenCopy(doi);
  if (oa?.oaUrl) oaUrl = oa.oaUrl;
  return { title, abstract, oaUrl };
}

/** citeForFinding — a research finding becomes a citation. A TERTIARY source (Wikipedia, Britannica) is a
 *  pointer, not a source: citing it would be a circular citation, so this returns { tertiary: true } and the
 *  caller must descend instead. Everything else gets a real {{cite web|journal}} plus the three styles. */
function citeForFinding(f) {
  const uri = f.url || (f.doi ? `https://doi.org/${f.doi}` : '');
  if (!uri) return { ok: false, reason: 'this finding has no address to cite' };
  if (sourceKind(uri) === 'tertiary') return { ok: true, tertiary: true, reason: 'this is a pointer — descend to what it cites, then cite that' };
  const rec = { claim: { subject: '', predicate: '', value: '' }, verdict: 'unknown',
    evidence: { uri, fetchedAt: new Date().toISOString() } };
  try {
    const c = citeFor(rec, { title: f.title || null, uri });
    const st = stylesFor(c, {});
    return { ok: true, cite: { key: c.key, title: f.title, uri, year: f.year, source: f.source, template: c.template,
      apa: st?.apa, mla: st?.mla, chicago: st?.chicago, added_at: new Date().toISOString() } };
  } catch (e) { return { ok: false, reason: e.message }; }
}

async function readSource(source) {
  const doi = (String(source).match(/10\.\d{4,9}\/[^\s?#]+/) || [])[0];
  let src = await loadSource(source);
  let via = null;
  if (src.kind === 'unreachable' || src.kind === 'missing') {
    if (doi) {
      const meta = await resolveDoi(doi);
      if (meta.oaUrl) {
        const alt = await loadSource(meta.oaUrl);
        if (alt.kind !== 'unreachable' && alt.kind !== 'missing') { src = alt; via = 'the open copy'; }
      }
      if (!via && meta.abstract) {
        // the full text is paywalled, but the abstract is not: read/summarise that, and say so
        return { ok: true, uri: source, title: meta.title, text: meta.abstract, via: 'the abstract — the full text is paywalled', abstract: true };
      }
    }
    if (!via) {
      const arch = await archivedCopy(source);
      if (arch?.archived) {
        const alt = await loadSource(arch.archived);
        if (alt.kind !== 'unreachable' && alt.kind !== 'missing') { src = alt; via = `the archived copy (${arch.timestamp})`; }
      }
    }
    if (!via) {
      const why = src.reason === 'HTTP 403' ? 'the host refused this machine (paywalled, or it blocks automated reads)'
        : src.reason === 'HTTP 404' ? 'the address is gone'
        : src.reason || 'cannot read';
      return { ok: false, reason: `${why} — and no open or archived copy exists, so it cannot be read here` };
    }
  }
  let text, title = null;
  if (src.kind === 'pdf') {
    const pages = pdfPages(src.body).pages;
    text = pages.join('\n\n');
  } else {
    const html = src.body.toString('utf8');
    title = (html.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1]?.trim() || null;
    text = extractText(html);
  }
  return { ok: true, uri: source, title, text, via };
}

async function loadSource(source) {
  if (/^https?:\/\//i.test(source)) {
    const r = await fetch(source, { headers: UA, redirect: 'follow' }).catch(() => null);
    if (!r || !r.ok) return { uri: source, httpStatus: r?.status ?? 0, kind: 'unreachable', reason: r?.status ? `HTTP ${r.status}` : 'no response' };
    const buf = Buffer.from(await r.arrayBuffer());
    if (isPdf(buf)) return { uri: source, httpStatus: r.status, body: buf, kind: 'pdf' };
    return { uri: source, httpStatus: r.status, body: buf.toString('utf8'), kind: 'html' };
  }
  if (!existsSync(source)) return { uri: source, httpStatus: 0, kind: 'missing', reason: 'no such file on this machine' };
  const buf = readFileSync(source);
  if (isPdf(buf)) return { uri: source, httpStatus: 200, body: buf, kind: 'pdf' };
  return { uri: source, httpStatus: 200, body: buf.toString('utf8'), kind: 'html' };
}

async function runOne(claim, src) {
  if (sourceKind(src.uri) === 'tertiary') {
    const walked = await lineageOf(claim, src.uri);
    if (!walked.deepest) {
      return { claim, verdict: 'unknown', reason: walked.reason === 'unsourced' ? 'no-span' : 'check-not-run',
        lineage: walked.chain, evidence: null, checked: null,
        falsifier: 'a real source the page cites, or an explicit denial in one' };
    }
    const r = await fetch(walked.deepest, { headers: UA, redirect: 'follow' }).catch(() => null);
    const buf = r && r.ok ? Buffer.from(await r.arrayBuffer()) : null;
    const body = buf && isPdf(buf) ? buf : (buf ? buf.toString('utf8') : '');
    return { ...checkFetched(claim, { uri: walked.deepest, httpStatus: r?.status ?? 0, body }), lineage: walked.chain };
  }
  return checkFetched(claim, { uri: src.uri, httpStatus: src.httpStatus, body: src.body });
}

const server = createServer(async (req, res) => {
  if (req.method === 'GET' && (req.url === '/' || req.url.startsWith('/?'))) {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    return res.end(PAGE());
  }
  if (req.method === 'GET' && req.url.startsWith('/api/query')) {
    // the library, asked a question — the same numbers a person would get from `askalice library`
    try {
      const u = new URL(req.url, 'http://x');
      const lib = openLibrary(join(home(), 'library.db'));
      const rows = query(lib, {
        phrase: u.searchParams.get('q') || undefined,
        from: u.searchParams.get('from') ? Number(u.searchParams.get('from')) : undefined,
        to: u.searchParams.get('to') ? Number(u.searchParams.get('to')) : undefined,
        verdict: u.searchParams.get('verdict') || undefined
      });
      lib.db.close();
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ rows }));
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'GET' && req.url.startsWith('/api/library')) {
    try {
      const u = new URL(req.url, 'http://x');
      const lib = openLibrary(join(home(), 'library.db'));
      const rows = u.searchParams.get('q') || u.searchParams.get('from') || u.searchParams.get('to')
        ? query(lib, {
            phrase: u.searchParams.get('q') || undefined,
            from: u.searchParams.get('from') ? Number(u.searchParams.get('from')) : undefined,
            to: u.searchParams.get('to') ? Number(u.searchParams.get('to')) : undefined,
            scene: u.searchParams.get('scene') ? Number(u.searchParams.get('scene')) : undefined
          })
        : query(lib, { limit: 50 });
      const s0 = stats(lib);
      lib.db.close();
      // Every row must be able to become an ARTIFACT: a citation you can paste, and a quote you can cite.
      // A library you cannot act on is a log. Duplicated rows (the same claim filed twice) collapse to one.
      const seen = new Set();
      const enriched = [];
      for (const r of rows) {
        const key = `${r.subject}|${r.value}|${r.quote}|${r.uri}`;
        if (seen.has(key)) continue;
        seen.add(key);
        let citation = null;
        try {
          citation = citeFor({
            claim: { subject: r.subject, predicate: r.predicate, value: r.value },
            verdict: r.verdict, reason: r.reason, falsifier: r.falsifier,
            evidence: { uri: r.uri, fetchedAt: r.filed_at, httpStatus: 200,
              span: { quote: r.quote || '', start: r.start ?? 0, end: r.end ?? 0, page: r.page ?? undefined } }
          }, {}).template;
        } catch { /* a row that cannot be cited is still a row */ }
        enriched.push({ ...r, citation });
      }
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ rows: enriched, stats: s0 }));
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/research') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { query: q } = JSON.parse(body || '{}');
      if (!q || !String(q).trim()) throw new Error('say what to look for');
      const run = await research(String(q), { keys: { ...process.env, ...loadKeys(home()) } });
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify(run));
    } catch (e) {
      res.writeHead(422, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'GET' && req.url === '/api/synthesis') {
    try {
      const lib = openLibrary(join(home(), 'library.db'));
      const out = whatTheLibrarySays(lib);
      lib.db.close();
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify(out));
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'GET' && req.url === '/api/scenes') {
    try {
      const lib = openLibrary(join(home(), 'library.db'));
      const scenes = listScenes(lib);
      const cur = currentSceneId(lib);
      lib.db.close();
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ scenes, current: cur }));
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/scene') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { name } = JSON.parse(body || '{}');
      if (!name || !String(name).trim()) throw new Error('a scene name is required');
      const lib = openLibrary(join(home(), 'library.db'));
      const sc = createScene(lib, name);
      setCurrentScene(lib, sc.id);
      const scenes = listScenes(lib);
      lib.db.close();
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ scenes, current: sc.id, name: sc.name }));
    } catch (e) {
      res.writeHead(422, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'GET' && req.url === '/api/backup') {
    try {
      const lib = openLibrary(join(home(), 'library.db'));
      const data = exportLibrary(lib);
      lib.db.close();
      const body = JSON.stringify(data, null, 2);
      res.writeHead(200, { 'content-type': 'application/json', 'content-disposition': `attachment; filename="askalice-research-${new Date().toISOString().slice(0, 10)}.json"` });
      return res.end(body);
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/restore') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const data = JSON.parse(body || '{}');
      const lib = openLibrary(join(home(), 'library.db'));
      const r = importLibrary(lib, data);
      lib.db.close();
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ imported: r }));
    } catch (e) {
      res.writeHead(422, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'GET' && req.url === '/api/sources') {
    try {
      const have = loadKeys(home());
      const list = gatedSources().map((g) => ({ id: g.id, needs: g.needs, connect: g.connect, connected: Boolean(have[g.needs]) }));
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ sources: list }));
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/connect') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { name, key, remove } = JSON.parse(body || '{}');
      const known = new Set(gatedSources().map((g) => g.needs));
      if (!known.has(name)) throw new Error('unknown source');
      const names = remove ? deleteKey(home(), name) : (key ? saveKey(home(), name, key) : loadKeys(home()));
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ connected: Array.isArray(names) ? names : Object.keys(names) }));
    } catch (e) {
      res.writeHead(422, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'GET' && req.url === '/api/account') {
    try {
      const signedIn = Boolean(readToken());
      const bal = signedIn ? await balance() : { ok: false, reason: 'no-token' };
      const lib = openLibrary(join(home(), 'library.db'));
      const s0 = stats(lib);
      lib.db.close();
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ signedIn, balance: bal, library: s0 }));
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'GET' && req.url.startsWith('/api/document-text')) {
    try {
      const u = new URL(req.url, 'http://x');
      const id = Number(u.searchParams.get('id'));
      if (!Number.isInteger(id)) throw new Error('a document id is required');
      const lib = openLibrary(join(home(), 'library.db'));
      const d = documentText(lib, id);
      lib.db.close();
      if (!d) { res.writeHead(404, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ error: 'no such document' })); }
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ id: d.id, uri: d.uri, title: d.title, kind: d.kind, text: d.text }));
    } catch (e) {
      res.writeHead(422, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/read') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { url } = JSON.parse(body || '{}');
      if (!/^https?:\/\//i.test(url || '')) throw new Error('a link is required');
      const r = await readSource(url);
      if (!r.ok) { res.writeHead(422, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ error: r.reason })); }
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ title: r.title, text: r.text, chars: r.text.length, via: r.via }));
    } catch (e) {
      res.writeHead(422, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/wiki-output') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { draft, refs } = JSON.parse(body || '{}');
      if (!draft || !String(draft).trim()) throw new Error('a draft is required');
      let refmap = {};
      try { refmap = JSON.parse(refs || '{}'); } catch { refmap = {}; }
      const cites = {};      // n -> { key, template, name }
      const notes = [];
      for (const [n, url] of Object.entries(refmap)) {
        if (!/^https?:\/\//i.test(String(url))) { notes.push(`[${n}] is not a link — left as a marker`); continue; }
        if (sourceKind(String(url)) === 'tertiary') { notes.push(`[${n}] is a pointer (${String(url)}) — descend to the real source, then re-run`); continue; }
        try {
          const src = await readSource(String(url));
          if (!src.ok) { notes.push(`[${n}] could not be read (${src.reason}) — left as a marker`); continue; }
          const c = citeFor({ claim: { subject: '', predicate: '', value: '' }, verdict: 'unknown', evidence: { uri: String(url), fetchedAt: new Date().toISOString() } }, { title: src.title || null, uri: String(url) });
          cites[n] = { key: c.key, template: c.template.replace(/\n/g, ' ') };
        } catch (e) { notes.push(`[${n}] could not be cited (${e.message})`); }
      }
      // replace each [n] with a named ref — full citation the first time, the bare name afterwards
      const used = new Set();
      let wikitext = String(draft);
      for (const [n, c] of Object.entries(cites)) {
        const re = new RegExp(`\\[${n}\\]`, 'g');
        let first = true;
        wikitext = wikitext.replace(re, () => {
          const out = first ? `<ref name="${c.key}">${c.template}</ref>` : `<ref name="${c.key}" />`;
          first = false; return out;
        });
      }
      const references = '== References ==\n{{reflist}}\n';
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ wikitext, references, cites: Object.values(cites).map((c) => c.key), notes }));
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/verify-meaning') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { sentence, url } = JSON.parse(body || '{}');
      if (!sentence || !String(sentence).trim()) throw new Error('a sentence is required');
      if (!/^https?:\/\//i.test(url || '')) throw new Error('the cited source link is required');
      if (!readToken()) { res.writeHead(401, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ error: 'sign in to verify meaning (askalice login)' })); }
      const r = await readSource(url);
      if (!r.ok) { res.writeHead(422, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ error: r.reason })); }
      const call = await aiCall({ task: 'verify_paraphrase', sentence: String(sentence), source: r.text.slice(0, 12000) });
      if (!call.ok) {
        const msg = call.json?.error || call.reason || (call.status === 400 ? 'the verify action is not on this Morpheus yet' : `HTTP ${call.status}`);
        res.writeHead(502, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ error: msg }));
      }
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ verdict: call.json?.verdict, reason: call.json?.reason, options: call.json?.options || [], usage: call.usage }));
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/summarise') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { url } = JSON.parse(body || '{}');
      if (!/^https?:\/\//i.test(url || '')) throw new Error('a link is required');
      if (!readToken()) { res.writeHead(401, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ error: 'sign in to summarise (askalice login)' })); }
      const r = await readSource(url);
      if (!r.ok) { res.writeHead(422, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ error: r.reason })); }
      const call = await aiCall({ task: 'summarize', title: r.title || null, text: r.text.slice(0, 20000) });
      if (!call.ok) {
        const msg = call.json?.error || call.reason || (call.status === 400 ? 'the summarize action is not on this Morpheus yet' : `HTTP ${call.status}`);
        res.writeHead(502, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ error: msg }));
      }
      const bullets = Array.isArray(call.json?.bullets) ? call.json.bullets : [];
      if (!bullets.length && call.json?.error) { res.writeHead(400, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ error: call.json.error })); }
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ title: r.title, bullets, usage: call.usage, via: r.via }));
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/audit-library') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { draft } = JSON.parse(body || '{}');
      if (!draft || !String(draft).trim()) throw new Error('a draft is required');
      const lib = openLibrary(join(home(), 'library.db'));
      const r = auditAgainstLibrary(String(draft), lib);
      lib.db.close();
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify(r));
    } catch (e) {
      res.writeHead(422, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/cite') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { finding } = JSON.parse(body || '{}');
      if (!finding) throw new Error('a finding is required');
      const built = citeForFinding(finding);
      if (!built.ok) { res.writeHead(422, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ error: built.reason })); }
      if (built.tertiary) { res.writeHead(200, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ tertiary: true, reason: built.reason })); }
      const added = addRef(home(), built.cite);
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ added, count: loadRefs(home()).length, cite: built.cite }));
    } catch (e) {
      res.writeHead(422, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/reference-remove') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { key } = JSON.parse(body || '{}');
      const n = removeRef(home(), key);
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ removed: n < loadRefs(home()).length ? 1 : 0, count: loadRefs(home()).length }));
    } catch (e) {
      res.writeHead(422, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'GET' && req.url === '/api/references') {
    // every reference the reader is writing FROM, once, non-circular, ready to paste into the article
    try {
      const collected = loadRefs(home());
      const lib = openLibrary(join(home(), 'library.db'));
      const rows = query(lib, { limit: 200 });
      lib.db.close();
      const seen = new Set();
      const cites = [];
      const add = (c) => {
        if (!c || seen.has(c.key)) return;
        if (c.uri && sourceKind(c.uri) === 'tertiary') return;   // a pointer is never a reference
        seen.add(c.key); cites.push(c);
      };
      for (const r of rows) {
        if (!r.quote) continue;
        const rec = { claim: { subject: r.subject, predicate: r.predicate, value: r.value }, verdict: r.verdict,
          evidence: { uri: r.uri, fetchedAt: r.filed_at, span: { quote: r.quote, page: r.page ?? undefined, start: r.start ?? 0, end: r.end ?? 0 } } };
        let c = null;
        try { c = citeFor(rec, {}); } catch { continue; }
        add({ key: c.key, uri: r.uri, template: c.template });
      }
      for (const c of collected) add(c);
      const wikitext = cites.map((c) => `<ref name="${c.key}">${c.template.replace(/\n/g, ' ')}</ref>`).join('\n');
      const plain = cites.map((c, i) => `${i + 1}. ${c.title ? c.title + ' — ' : ''}${c.template.replace(/\n/g, ' ')}`).join('\n');
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ count: cites.length, collected: collected.length, wikitext, plain, cites }));
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/audit') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { draft, refs } = JSON.parse(body || '{}');
      if (!draft || !String(draft).trim()) throw new Error('paste a draft first');
      let parsed = {};
      if (typeof refs === 'string' && refs.trim()) {
        try { parsed = JSON.parse(refs); } catch { throw new Error('the reference list is not valid JSON — it should look like {"1":"https://…"}'); }
      } else if (refs && typeof refs === 'object') parsed = refs;
      const result = await audit(String(draft), { refs: parsed });
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify(result));
    } catch (e) {
      res.writeHead(422, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/check') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { source, claim, file } = JSON.parse(body || '{}');
      // A FILE THE READER ALREADY HAS. The page sends the bytes, because a browser cannot hand the server a local
      // path — and a path typed by hand is a path that does not exist on this machine, which is exactly what the
      // first "PDF" example did.
      if (file && file.data) {
        const bytes = Buffer.from(String(file.data).split(',').pop(), 'base64');
        const name = String(file.name || 'document');
        let kind = /\.pdf$/i.test(name) ? 'pdf' : /\.(html?|htm)$/i.test(name) ? 'html' : 'text';
        // Word and Excel are zips of XML; a spreadsheet's text carries its cell references, so a quote can say
        // "B7: 1937" — the place a person checks — rather than a character offset into a binary.
        let officeBody = null;
        if (isOffice(bytes, name)) {
          const o = officeText(bytes);
          if (o.kind) { kind = o.kind; officeBody = o.text; }
          else throw new Error(o.reason + ' — save it as .docx or .xlsx first');
        }
        const src = { uri: 'file://' + name, httpStatus: 200,
          body: kind === 'pdf' ? bytes : (officeBody ?? bytes.toString('utf8')), kind };
        const records = [];
        const attach = (rec) => { return rec; };
        if (claim) {
          const [subject, predicate, value] = claim.split('|').map((x) => (x ?? '').trim());
          records.push(attach(await runOne({ subject: subject || 'the claim', predicate: predicate || 'states', value: value || '' }, src)));
        } else {
          const { candidateClaims } = await import('./desk.mjs');
          const text = kind === 'pdf' ? pdfPages(bytes).pages.join(' ') : (officeBody ?? extractText(src.body));
          for (const c of candidateClaims(text).slice(0, 6)) records.push(attach(await runOne(c, src)));
        }
        try {
          const lib = openLibrary(join(home(), 'library.db'));
          const text = kind === 'pdf' ? pdfPages(bytes).pages.join(' ') : (officeBody ?? extractText(src.body));
          const doc = fileDocument(lib, { bytes, uri: src.uri, kind, title: name, text, sceneId: currentSceneId(lib) });
          for (const r of records) fileClaim(lib, r, { docId: doc.id, page: r.evidence?.span?.page ?? null });
          lib.db.close();
        } catch { /* filing is best-effort here too */ }
        res.writeHead(200, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ records }));
      }
      if (!source) throw new Error('a source is required');
      const src = await loadSource(source);
      if (src.kind === 'unreachable' || src.kind === 'missing') {
        res.writeHead(422, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ error: `Cannot read ${source} — ${src.reason}` }));
      }
      const records = [];
      const attach = (rec) => {
        // The citation is built here, from the record and the bytes that produced it, so the page never has to
        // know how a {{cite}} is assembled — and never has to invent a title.
        // an UNKNOWN is a task, not a wall: attach what would settle it, and how to reach it
        rec.remediation = remediationFor(rec, { claim: rec.claim, sourceUri: src.uri });
        if (rec.evidence?.span?.quote) {
          try {
            const c = citeFor(rec, { body: src.body });
            rec.citation = c;
            // the same fields, in the styles a journal asks for — APA, MLA, Chicago
            rec.styles = stylesFor(c, { author: c?.author || null, published: c?.published || null });
            rec.talk = talkPageRequest({ article: '<the article you are editing>', record: rec, cite: c });
          } catch { /* a citation we cannot build must not lose the record */ }
        }
        return rec;
      };
      if (claim) {
        const [subject, predicate, value] = claim.split('|').map((x) => (x ?? '').trim());
        records.push(attach(await runOne({ subject: subject || 'the claim', predicate: predicate || 'states', value: value || '' }, src)));
      } else {
        const { candidateClaims } = await import('./desk.mjs');
        const text = src.kind === 'pdf' ? pdfPages(src.body).pages.join(' ') : extractText(src.body);
        for (const c of candidateClaims(text).slice(0, 6)) records.push(attach(await runOne(c, src)));
      }
      // FILE IT. A check that is only shown is a check that is lost; the library is the point of the product.
      let filed = null;
      try {
        const lib = openLibrary(join(home(), 'library.db'));
        const text = src.kind === 'pdf' ? pdfPages(src.body).pages.join(' ') : extractText(src.body);
        const doc = fileDocument(lib, { bytes: src.body, uri: src.uri, kind: src.kind, title: null, text, sceneId: currentSceneId(lib) });
        for (const r of records) fileClaim(lib, r, { docId: doc.id, page: r.evidence?.span?.page ?? null });
        filed = { documentId: doc.id, existing: doc.existing, ...stats(lib) };
        lib.db.close();
      } catch (e) { filed = { error: e.message }; }

      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ records, filed }));
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }
  res.writeHead(404, { 'content-type': 'text/plain' });
  res.end('not found');
});

const port = Number(process.env.PORT || 4173);
// 127.0.0.1 by default: the product runs on one machine (D32). ASKALICE_UI_HOST is opt-in, so the default is
// never an open port — a shared-account tester sets it, and nobody else has to know it exists.
const host = process.env.ASKALICE_UI_HOST || '127.0.0.1';
server.listen(port, host, () => {
  const url = `http://${host === '0.0.0.0' ? 'localhost' : host}:${port}/`;
  console.log(`askalice ui → ${url}`);
  if (process.argv.includes('--open')) {
    const cmd = process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]]
      : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
    import('node:child_process').then(({ spawn }) => { try { spawn(cmd[0], cmd[1], { detached: true, stdio: 'ignore' }).unref(); } catch { } });
  }
});
