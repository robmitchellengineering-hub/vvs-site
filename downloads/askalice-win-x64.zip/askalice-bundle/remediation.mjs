#!/usr/bin/env node
// remediation.mjs — a claim that could not be checked is not a dead end. It is a task with a list.
//
// ROB: "pointing and suggestions on what needs to happen to make the data verified is perfect if Ask Alice cant
// find the sources itself without paid services like Trove."
//
// So every UNKNOWN carries four things: what is missing, the ROUTES that would get it (each a real, pre-filled
// search a person can open), where to put the file when they have it, and what would then be provable. The tool
// never says "unverified" and stops; it says which document would settle it and how to reach one.
//
// THE ROUTES ARE BUILT FROM THE CLAIM'S OWN WORDS, not from a template with blanks in it: a Trove search for the
// claim's subjects and dates is a search a historian can use; "search Trove" is not.
import { contentWords } from './extract.mjs';

const enc = (s) => encodeURIComponent(String(s || '').trim());

/** queryFor — the words a search engine needs, in the order that finds a source rather than a mention. */
export function queryFor(claim) {
  const words = contentWords(`${claim?.subject || ''} ${claim?.value || ''}`);
  return words.slice(0, 8).join(' ');
}

/** doiOf — a DOI anywhere in a URI or a value, so an Open Access copy can be looked for. */
export function doiIn(...parts) {
  for (const p of parts) {
    const m = String(p || '').match(/\b(10\.\d{4,9}\/[^\s?#&]+)/);
    if (m) return m[1];
  }
  return null;
}

/**
 * remediationFor — the four things every unverified claim should come with.
 * Returns null when the claim WAS verified: a supported claim needs no instruction.
 */
export function remediationFor(record, { claim, sourceUri } = {}) {
  const v = record?.verdict;
  if (!v || v === 'supported-in-span' || v === 'contradicted') return null;

  const c = claim || record?.claim || {};
  const q = queryFor(c);
  const doi = doiIn(sourceUri, record?.evidence?.uri, record?.checked?.uri, c.value);
  const year = (String(c.value || '').match(/\b(1[5-9]\d{2}|20\d{2})\b/) || [])[1] || null;
  const reason = record?.reason || 'unknown';
  const what = reason === 'http-403' ? 'a source this machine is not allowed to read (the host refused)'
    : reason === 'http-404' ? 'the source at that address is gone'
    : reason === 'paywall' ? 'a source behind a subscription'
    : reason === 'no-span' ? 'the words of the claim, in a source that was actually read'
    : 'the check could not run';

  const routes = [];
  if (doi) routes.push({ label: 'the open copy, if one exists', url: `https://api.unpaywall.org/v2/${enc(doi)}?email=info@valiantmusic.com.au`, why: 'Unpaywall answers with a legal open access copy of the same DOI when there is one' });
  routes.push({ label: 'Trove — Australian newspapers, journals, pictures, archives', url: `https://trove.nla.gov.au/search?keyword=${enc(q)}`, why: 'free to search; an API key makes it checkable in bulk' });
  routes.push({ label: 'OpenAlex — the work itself', url: `https://api.openalex.org/works?search=${enc(q)}`, why: 'finds the paper even when the page you have is a summary' });
  routes.push({ label: 'Internet Archive — scans and old editions', url: `https://archive.org/search?query=${enc(q)}`, why: 'a book that predates the web is usually here' });
  if (year) {
    // Trove takes a decade as l-decade=193 for the 1930s. Named properly, because a person reads this line.
    const decade = Math.floor(Number(year) / 10) * 10;
    routes.push({ label: `period sources for the ${decade}s`, url: `https://trove.nla.gov.au/search?keyword=${enc(q)}&l-decade=${decade / 10}`, why: 'a dated claim is usually settled by a source from that decade' });
  }

  return {
    missing: what,
    query: q,
    doi,
    year,
    routes,
    drop: 'Drop the PDF or a scan on this claim — it is checked against this exact sentence, on this machine.',
    thenWhat: `If that source says ${c.value ? `“${c.value}”` : 'this'}, the claim becomes supported with the page and character offset; if it says something else, it becomes contradicted — and you will have the line that says it.`,
    // the one thing a tool must not do here: dress a suggestion up as a result
    note: 'Nothing above has been read. These are the routes to the document that would settle it, not evidence.'
  };
}

// ---------------------------------------------------------------------------
// fixtures
// ---------------------------------------------------------------------------
if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href && process.argv.includes('--self-test')) {
  const claim = { subject: 'the Golden Gate Bridge', predicate: 'carried', value: '40000 vehicles in 1937' };
  const tests = [
    { name: 'a supported claim needs no instruction', run: () => remediationFor({ verdict: 'supported-in-span' }, { claim }) === null },
    { name: 'an unknown claim says WHAT is missing, in words a person reads', run: () => {
        const r = remediationFor({ verdict: 'unknown', reason: 'paywall' }, { claim });
        return r && /subscription/.test(r.missing); } },
    { name: 'the Trove route is pre-filled with the claim\'s own words', run: () => {
        const r = remediationFor({ verdict: 'unknown', reason: 'no-span' }, { claim });
        const trove = r.routes.find((x) => x.url.includes('trove.nla.gov.au'));
        return trove && trove.url.includes(encodeURIComponent('golden')) && trove.url.includes('1937'); } },
    { name: 'a DOI in the source adds the open-copy route first', run: () => {
        const r = remediationFor({ verdict: 'unknown', reason: 'paywall' }, { claim, sourceUri: 'https://doi.org/10.1038/nature12373' });
        return r.doi === '10.1038/nature12373' && r.routes[0].url.includes('unpaywall.org/v2/10.1038%2Fnature12373'); } },
    { name: 'a dated claim gets a period-source route', run: () => {
        const r = remediationFor({ verdict: 'unknown', reason: 'no-span' }, { claim });
        const route = r.routes.find((x) => /l-decade=/.test(x.url));
        return route && route.url.includes('l-decade=193') && /1930s/.test(route.label); } },
    { name: 'RED: the instruction never claims the routes were read', run: () => {
        const r = remediationFor({ verdict: 'unknown', reason: 'no-span' }, { claim });
        return /not evidence/.test(r.note) && !/verified/i.test(r.note); } },
    { name: 'a 403 and a 404 say different things, because they are different problems', run: () => {
        const a = remediationFor({ verdict: 'unknown', reason: 'http-403' }, { claim }).missing;
        const b = remediationFor({ verdict: 'unknown', reason: 'http-404' }, { claim }).missing;
        return a !== b && /refused/.test(a) && /gone/.test(b); } }
  ];
  let bad = 0;
  for (const t of tests) {
    let ok = false, err = '';
    try { ok = t.run() === true; } catch (e) { err = e.message; }
    if (ok) console.log(`  ok    ${t.name}`);
    else { bad++; console.error(`  FAIL  ${t.name}${err ? ' — ' + err : ''}`); }
  }
  console.log(`\nremediation: ${tests.length - bad}/${tests.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
