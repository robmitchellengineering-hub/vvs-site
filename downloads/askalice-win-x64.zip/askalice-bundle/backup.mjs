#!/usr/bin/env node
// backup.mjs — the research is portable: export it as one file, import it anywhere, share it.
//
// WHY A JSON EXPORT, NOT A COPY OF THE SQLITE FILE. Two libraries on two machines have their own row ids; copying a
// .db across machines cannot be merged, only replaced. A JSON export is re-filed through the normal fileDocument /
// fileClaim path, so the SAME document dedupes by its content hash — importing a friend's research into yours
// merges it instead of clobbering it, and the same backup restores after a move. One format does both.
import { createScene, fileDocument, fileClaim, listScenes } from './library.mjs';

const KIND = 'askalice-research';

/** exportLibrary — everything the library holds, as a shareable object. */
export function exportLibrary(lib) {
  const scenes = listScenes(lib);
  const documents = lib.db.prepare('SELECT id, hash, uri, kind, title, text, scene_id FROM documents').all();
  const claims = lib.db.prepare(`
    SELECT c.doc_id, c.subject, c.predicate, c.value, c.verdict, c.reason, c.falsifier, c.layer,
           s.page, s.start, s.end, s.quote, s.extractor
    FROM claims c LEFT JOIN spans s ON s.id = c.span_id`).all();
  return {
    kind: KIND, version: 1, exported_at: new Date().toISOString(),
    scenes, documents,
    claims: claims.map((c) => ({ ...c, extractor: c.extractor || null })),
  };
}

function parseExtractor(s) {
  const [name, version] = String(s || 'unknown@0').split('@');
  return { name: name || 'unknown', version: version || '0' };
}

/** importLibrary — re-file every document and claim. The content hash dedupes, so this MERGES, not replaces. */
export function importLibrary(lib, data) {
  if (!data || data.kind !== KIND) throw new Error('not an Ask Alice research backup');
  const sceneMap = {};
  for (const sc of data.scenes || []) sceneMap[sc.id] = createScene(lib, sc.name).id;
  const docMap = {};
  const uriByDoc = {};
  for (const d of data.documents || []) {
    const doc = fileDocument(lib, {
      bytes: Buffer.from(d.text || ''), hash: d.hash, uri: d.uri, kind: d.kind || 'text',
      title: d.title, text: d.text, sceneId: sceneMap[d.scene_id] || null
    });
    docMap[d.id] = doc.id;
    uriByDoc[d.id] = d.uri;
  }
  let claims = 0;
  for (const c of data.claims || []) {
    const docId = docMap[c.doc_id];
    if (!docId) continue;
    try {
      fileClaim(lib, {
        claim: { subject: c.subject, predicate: c.predicate, value: c.value },
        verdict: c.verdict, reason: c.reason, falsifier: c.falsifier, scope: { layer: c.layer || undefined },
        evidence: { uri: uriByDoc[c.doc_id], span: c.quote ? { quote: c.quote, page: c.page ?? undefined, start: c.start ?? 0, end: c.end ?? (c.quote || '').length, extractor: parseExtractor(c.extractor) } : null }
      }, { docId });
      claims++;
    } catch { /* a claim that cannot be refiled must not lose the rest */ }
  }
  return { documents: Object.keys(docMap).length, claims };
}

// fixtures
if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href && process.argv.includes('--self-test')) {
  const { mkdtempSync } = await import('node:fs');
  const { tmpdir } = await import('node:os');
  const { join } = await import('node:path');
  const { openLibrary } = await import('./library.mjs');
  const mk = () => openLibrary(join(mkdtempSync(join(tmpdir(), 'bk-')), 'x.db'));

  const tests = [
    { name: 'an export round-trips: import into a fresh library restores documents and claims', run: () => {
        const a = mk(); const sc = createScene(a, 'Grace'); const d = fileDocument(a, { bytes: Buffer.from('The bridge opened in 1937.'), uri: 'https://e/x', kind: 'html', title: 'X', text: 'The bridge opened in 1937.', sceneId: sc.id });
        fileClaim(a, { claim: { subject: 'the bridge', predicate: 'opened in', value: '1937' }, verdict: 'supported-in-span', evidence: { span: { quote: 'The bridge opened in 1937.', start: 0, end: 26, extractor: { name: 'dom-text', version: '1.1.0' } } } }, { docId: d.id });
        const data = exportLibrary(a);
        const b = mk(); const r = importLibrary(b, data);
        return r.documents === 1 && r.claims === 1 && listScenes(b).length === 1; } },
    { name: 'importing the SAME research twice merges, it does not duplicate', run: () => {
        const a = mk(); const d = fileDocument(a, { bytes: Buffer.from('x'), uri: 'u', kind: 'text', text: 'x' });
        const data = exportLibrary(a);
        const b = mk(); importLibrary(b, data); importLibrary(b, data);
        const c = b.db.prepare('SELECT COUNT(*) n FROM documents').get();
        return c.n === 1; } },
    { name: 'RED: a non-backup file is refused, not guessed at', run: () => {
        try { importLibrary(mk(), { hello: 'world' }); return false; } catch (e) { return /not an Ask Alice/.test(e.message); } } },
  ];
  let bad = 0;
  for (const t of tests) { let ok = false; try { ok = t.run() === true; } catch (e) { console.error('  err', e.message); } if (ok) console.log(`  ok    ${t.name}`); else { bad++; console.error(`  FAIL  ${t.name}`); } }
  console.log(`\nbackup: ${tests.length - bad}/${tests.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
