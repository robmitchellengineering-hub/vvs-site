#!/usr/bin/env node
// askalice — the command a person actually types.
//
// Rob, 2026-11-05: "there will need to be an account creation path for morpheus.nz from within ask alice".
// So signup is a first-class verb, not a link to a web page: a reader with no Morpheus account types
// `askalice signup` and is done — no web form to find, no token to paste.
//
// Four verbs, and each one either works or says exactly what is missing:
//   signup   create a morpheus.nz account, then hold the token it returns
//   login    approve a device code in the browser, then hold a revocable `dvc_` token
//   status   which account this machine is, and where the token lives (never the token itself)
//   check    run the desk over a source, mechanically — no AI, no credits
//   doctor   say what is wrong, in the order a user would hit it
import { existsSync, rmSync, readSync, readFileSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { spawnSync } from 'node:child_process';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readToken, writeToken, redact, tokenPath, home, apiBase, login, deviceStart, lastUsage, balance } from './morpheus.mjs';
// library.mjs is imported lazily: it pulls node:sqlite, which prints an experimental warning on Node 22, and
// a research run that is not filing anything should not pay for that.
const libMod = () => import('./library.mjs');
import { research, SOURCES } from './research.mjs';
import { audit } from './audit.mjs';
import { checkFetched } from './check.mjs';
import { isPdf, pdfPages } from './pdf.mjs';
import { citeFor } from './cite.mjs';
import { createHash } from 'node:crypto';

const HERE = dirname(fileURLToPath(import.meta.url));

export async function register({ email, password, full_name, fetchImpl } = {}) {
  if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return { ok: false, reason: 'a valid email is required' };
  if (!password || password.length < 8) return { ok: false, reason: 'the password must be at least 8 characters' };
  const f = fetchImpl ?? globalThis.fetch;
  let res;
  try {
    res = await f(apiBase() + '/api/auth/register', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'user-agent': 'askalice/0.1' },
      body: JSON.stringify({ email, password, full_name })
    });
  } catch (e) { return { ok: false, reason: `could not reach ${apiBase()}: ${e.message}` }; }
  let j = null;
  try { j = await res.json(); } catch { /* empty body is not a crash */ }
  if (res.status === 409) return { ok: false, status: 409, reason: 'an account with this email already exists — run `askalice login`' };
  if (res.status === 400) return { ok: false, status: 400, reason: j?.error || 'the account details were refused' };
  if (!res.ok) return { ok: false, status: res.status, reason: j?.error || `registration answered HTTP ${res.status}` };
  if (!j?.token) return { ok: false, status: res.status, reason: 'registered but no token came back' };
  return { ok: true, token: j.token, user: j.user };
}

function ask(prompt) {
  // A prompt that works in cmd.exe, PowerShell and a posix shell without a dependency.
  process.stdout.write(prompt);
  const buf = Buffer.alloc(1024);
  try {
    const n = readSync(0, buf, 0, buf.length, null);
    return buf.subarray(0, n).toString('utf8').split('\n')[0].trim();
  } catch { return ''; }
}

/**
 * openBrowser — the step that removes "copy this URL anywhere". A person double-clicking an installer should see
 * a browser, not a console instruction. Never awaited: a missing browser must not stop the login.
 */
export function openBrowser(url) {
  const cmd = process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]]
    : process.platform === 'darwin' ? ['open', [url]]
    : ['xdg-open', [url]];
  try { const p = spawn(cmd[0], cmd[1], { detached: true, stdio: 'ignore' }); p.unref(); return true; } catch { return false; }
}

function banner() {
  console.log('\n  askalice — a claim, its source, and the line in it.\n');
}

async function main() {
  const [verb, ...rest] = process.argv.slice(2);
  const flag = (n) => { const i = rest.indexOf(n); return i >= 0 ? rest[i + 1] : undefined; };
  const has = (n) => rest.includes(n);

  if (!verb || verb === '--help' || has('--help') || verb === 'help') {
    banner();
    console.log('  askalice signup            create a morpheus.nz account from here');
    console.log('  askalice login             approve a code in the browser (no password in the terminal)');
    console.log('  askalice status            which account this machine holds');
    console.log('  askalice check <src> [--claim "a | b | c"]');
    console.log('  askalice library ["phrase"] [--from 1900] [--to 1950] [--verdict supported-in-span]');
    console.log('  askalice research "<what to find>" [--claim "a | b | c"] [--check 3]');
    console.log('  askalice audit <draft.md> [--refs refs.json]     check your own sentences against your sources');
    console.log('  askalice ui                                      open the page');
    console.log('  askalice doctor            check the install, in the order things break\n');
    console.log(`  api     ${apiBase()}`);
    console.log(`  token   ${tokenPath()}\n`);
    return 0;
  }

  if (verb === 'signup') {
    banner();
    const email = flag('--email') || ask('  email     ');
    const password = flag('--password') || ask('  password  ');
    const name = flag('--name');
    const r = await register({ email, password, full_name: name });
    if (!r.ok) { console.error(`\n  ${r.reason}\n`); return 2; }
    const stored = writeToken(r.token);
    console.log(`\n  account created${r.user?.email ? ` for ${r.user.email}` : ''}`);
    console.log(`  check your email for a verification code (it expires in 15 minutes)`);
    console.log(`  token stored at ${stored.path} (${stored.length} characters, never printed)\n`);
    console.log('  next: askalice check <url> --claim "subject | predicate | value"\n');
    return 0;
  }

  if (verb === 'login') {
    banner();
    const r = await login({
      onShow: (s) => {
        console.log('  1. open this page — it creates an account too, if you do not have one:\n');
        const url = s.verification_uri_complete || s.verification_uri;
        openBrowser(url);
        console.log(`       ${url}\n   (opened in your browser — if nothing appeared, put that address in one)\n`);
        console.log(`  2. confirm the code shown is  ${s.user_code}\n`);
        console.log('  waiting for approval…');
      }
    });
    if (!r.ok) { console.error(`\n  ${r.reason}\n`); return 2; }
    const stored = writeToken(r.token);
    console.log(`\n  logged in${r.user?.email ? ` as ${r.user.email}` : ''}`);
    console.log(`  token stored at ${stored.path} — this token bills your own credits, and it can be revoked\n`);
    return 0;
  }

  if (verb === 'status') {
    const t = readToken();
    banner();
    console.log(`  account   ${t ? 'a token is held' : 'not logged in'}`);
    console.log(`  token     ${redact(t)}`);
    console.log(`  api       ${apiBase()}`);
    console.log(`  file      ${tokenPath()} ${existsSync(tokenPath()) ? '' : '(missing)'}`);
    const u = lastUsage();
    console.log(`  last AI   ${u ? `${u.total_tokens} tokens (${u.prompt_tokens} in, ${u.completion_tokens} out) on ${u.model} at ${u.at}` : 'none — mechanical checks spend nothing'}`);
    const bal = t ? await balance() : { ok: false, reason: 'no-token' };
    console.log(`  balance   ${bal.ok && bal.credit_balance !== null ? bal.credit_balance + ' credits' + (bal.recent?.length ? ` · last: ${bal.recent[0].action} (${bal.recent[0].credits})` : '') : bal.status === 404 ? 'the balance function is not deployed yet' : bal.reason === 'token-rejected' ? 'the token was refused — run askalice login again' : 'unavailable (' + (bal.reason || bal.status) + ')'}\n`);
    return t ? 0 : 1;
  }

  if (verb === 'logout') {
    if (existsSync(tokenPath())) { rmSync(tokenPath()); console.log('\n  token removed from this machine\n'); return 0; }
    console.log('\n  there was no token on this machine\n');
    return 0;
  }

  if (verb === 'doctor') {
    banner();
    const checks = [];
    checks.push(['node', `v${process.versions.node}`, Number(process.versions.node.split('.')[0]) >= 18]);
    const t = readToken();
    checks.push(['token', t ? `held (${redact(t)})` : 'none — run `askalice login`', Boolean(t)]);
    let reach = false;
    try {
      const r = await deviceStart();
      reach = r.ok;
      checks.push(['api', reach ? `reachable — ${apiBase()}` : `${apiBase()} — ${r.reason}`, reach]);
    } catch (e) { checks.push(['api', `unreachable — ${e.message}`, false]); }
    checks.push(['desk', existsSync(join(HERE, 'desk.mjs')) ? 'present' : 'missing', existsSync(join(HERE, 'desk.mjs'))]);
    checks.push(['platform', `${process.platform}${process.platform === 'win32' ? ' — PowerShell 5.1, .cmd shim expected' : ''}`, true]);
    for (const [name, state, ok] of checks) console.log(`  ${ok ? 'ok  ' : 'FAIL'}  ${name.padEnd(9)} ${state}`);
    console.log('');
    return checks.every((c) => c[2]) ? 0 : 1;
  }

  if (verb === 'audit') {
    const file = rest.find((a) => !a.startsWith('--') && a !== flag('--refs'));
    if (!file) { console.error('  usage: askalice audit <draft.md|draft.txt> [--refs refs.json]\n'); return 2; }
    let draft;
    try { draft = readFileSync(file, 'utf8'); } catch (e) { console.error(`  cannot read ${file} — ${e.message}\n`); return 2; }
    let refs = {};
    const refsFile = flag('--refs');
    if (refsFile) { try { refs = JSON.parse(readFileSync(refsFile, 'utf8')); } catch (e) { console.error(`  cannot read ${refsFile} — ${e.message}\n`); return 2; } }
    banner();
    console.log(`  auditing ${file}\n`);
    const r = await audit(draft, { refs });
    const mark = { supported: 'ok  ', 'partly-supported': 'PART', 'not-supported': 'NO  ', 'contradicted-by-absence': 'CON ', unsourced: '----', unknown: '??  ' };
    for (const s of r.sentences) {
      const m = mark[s.verdict] || '?   ';
      console.log(`  ${m} ${String(s.text).slice(0, 96)}`);
      if (s.verdict !== 'supported') console.log(`        ${s.reason}${s.url ? '\n        ' + s.url : ''}`);
    }
    const x = r.summary;
    console.log(`\n  ${x.sentences} sentence(s) · ${x.supported} supported · ${x.partly} partly · ${x.unsupported} unsupported · ${x.unsourced} unsourced · ${x.unknown} unknown · ${x.sources} source(s) read\n`);
    return x.partly + x.unsupported + x.unsourced ? 1 : 0;
  }

  if (verb === 'research') {
    const q = rest.filter((a) => !a.startsWith('--') && a !== flag('--claim')).join(' ').trim();
    const claimArg = flag('--claim');
    if (!q) { console.error('  usage: askalice research "<what to find>" [--claim "a | b | c"] [--check N]\n'); return 2; }
    banner();
    console.log(`  asking ${SOURCES.length} sources for: ${q}\n`);
    const run = await research(q);
    for (const p of run.perSource) {
      const mark = { ok: 'ok  ', empty: '----', gated: 'key ', 'rate-limited': '429 ', refused: 'x   ', error: '!!  ' }[p.status] || '?   ';
      console.log(`  ${mark} ${p.id.padEnd(11)} ${String(p.count || '').padStart(2)}  ${p.reason || p.status}`);
    }
    console.log(`\n  ${run.findings.length} distinct source(s) after dedupe\n`);
    for (const f of run.findings.slice(0, 10)) {
      console.log(`   ${f.year || '----'}  ${String(f.title || '(no title)').slice(0, 72)}`);
      console.log(`          ${f.source}  ${f.url || f.doi || ''}`);
    }

    // --check: fetch and test each finding against the claim, then file what survives
    if (claimArg) {
      const [subject, predicate, value] = claimArg.split('|').map((x) => (x || '').trim());
      const claim = { subject: subject || 'the claim', predicate: predicate || 'states', value: value || '' };
      const n = Math.min(Number(flag('--check') || 3), run.findings.length);
      console.log(`\n  checking the first ${n} against: ${claim.subject} ${claim.predicate} ${claim.value}\n`);
      const { openLibrary, fileDocument, fileClaim } = await libMod();
      const lib = openLibrary(join(home(), 'library.db'));
      for (const f of run.findings.slice(0, n)) {
        const url = f.url || (f.doi ? `https://doi.org/${f.doi}` : null);
        if (!url || !/^https?:/.test(url)) { console.log(`   skipped  ${f.title?.slice(0, 60)} — no fetchable url`); continue; }
        const res = await fetch(url, { headers: { 'user-agent': 'askalice/0.1 (research)' }, redirect: 'follow' }).catch(() => null);
        const buf = res && res.ok ? Buffer.from(await res.arrayBuffer()) : null;
        const body = buf && isPdf(buf) ? buf : (buf ? buf.toString('utf8') : '');
        const rec = checkFetched(claim, { uri: url, httpStatus: res?.status ?? 0, body });
        const doc = fileDocument(lib, { bytes: buf || Buffer.from(''), uri: url, kind: buf && isPdf(buf) ? 'pdf' : 'html', title: f.title || null });
        fileClaim(lib, rec, { docId: doc.id, page: rec.evidence?.span?.page ?? null });
        console.log(`   ${rec.verdict.padEnd(17)} ${String(f.title || url).slice(0, 58)}`);
        if (rec.evidence?.span?.quote) {
          console.log(`      "${String(rec.evidence.span.quote).replace(/\s+/g, ' ').slice(0, 90)}"`);
          const c = citeFor(rec, { body: buf, title: f.title || null });
          console.log(`      ${c.template.split('\n')[0]} … (askalice library for the full citation)`);
        }
      }
      lib.db.close();
    }
    console.log('');
    return 0;
  }

  if (verb === 'library') {
    const phrase = rest.filter((a) => !a.startsWith('--')).join(' ') || undefined;
    const from = flag('--from') ? Number(flag('--from')) : undefined;
    const to = flag('--to') ? Number(flag('--to')) : undefined;
    banner();
    try {
      const { openLibrary, query, stats } = await libMod();
      const lib = openLibrary(join(home(), 'library.db'));
      const s0 = stats(lib);
      const rows = query(lib, { phrase, from, to, verdict: flag('--verdict'), limit: 20 });
      console.log(`  ${s0.documents} document(s) · ${s0.claims} claim(s) · ${s0.spans} span(s)\n`);
      if (!rows.length) { console.log('  nothing matches. Run a check first: askalice check <source> --claim "a | b | c"\n'); return 0; }
      for (const r of rows) {
        const where = r.page ? `p.${r.page} ` : '';
        console.log(`  ${r.verdict.padEnd(17)} ${where}${r.subject} — ${r.predicate} ${r.value || ''}`);
        if (r.quote) console.log(`      "${String(r.quote).replace(/\s+/g, ' ').slice(0, 100)}"`);
        console.log(`      ${r.uri}\n`);
      }
      lib.db.close();
      return 0;
    } catch (e) { console.error(`  ${e.message}\n`); return 2; }
  }

  if (verb === 'ui') {
    const ui = join(HERE, 'ui.mjs');
    if (!existsSync(ui)) { console.error('  askalice: the page is missing from this install\n'); return 2; }
    const port = flag('--port') || '4173';
    const child = spawn(process.execPath, [ui], { detached: true, stdio: 'ignore', env: { ...process.env, PORT: port } });
    child.unref();
    const url = `http://127.0.0.1:${port}/`;
    const tryFetch = async (n) => {
      for (let i = 0; i < n; i++) {
        try { const r = await fetch(url); if (r.ok) return true; } catch { /* not up yet */ }
        await new Promise((r) => setTimeout(r, 300));
      }
      return false;
    };
    const up = await tryFetch(20);
    banner();
    console.log('  ' + (up ? 'the page is open:' : 'starting… the page will be at:') + '\n');
    console.log(`    ${url}\n`);
    console.log('  copy anything you see — the quote, the citation, the report.\n');
    openBrowser(url);
    return up ? 0 : 2;
  }

  if (verb === 'check') {
    const desk = join(HERE, 'desk.mjs');
    if (!existsSync(desk)) { console.error('  askalice: the desk is missing from this install'); return 2; }
    const args = rest.length ? rest : [];
    const r = spawnSync(process.execPath, [desk, ...args], { stdio: 'inherit' });
    return r.status ?? 2;
  }

  console.error(`  askalice: unknown command "${verb}" — try askalice --help`);
  return 2;
}

const SELF_TESTS = [
  { name: 'RED: signup refuses a bad email before calling the api', run: async () => {
      let called = false;
      const r = await register({ email: 'nope', password: '12345678', fetchImpl: async () => { called = true; return { ok: true, status: 201, json: async () => ({ token: 'x' }) }; } });
      return r.ok === false && called === false && /valid email/.test(r.reason); } },
  { name: 'RED: signup refuses a short password', run: async () => {
      const r = await register({ email: 'a@b.co', password: 'short' });
      return r.ok === false && /8 characters/.test(r.reason); } },
  { name: 'RED: an existing account points at login, not at a stack trace', run: async () => {
      const r = await register({ email: 'a@b.co', password: '12345678', fetchImpl: async () => ({ ok: false, status: 409, json: async () => ({ error: 'exists' }) }) });
      return r.ok === false && r.status === 409 && /askalice login/.test(r.reason); } },
  { name: 'a successful signup yields a token', run: async () => {
      const r = await register({ email: 'a@b.co', password: '12345678', fetchImpl: async () => ({ ok: true, status: 201, json: async () => ({ token: 'jwt_x', user: { email: 'a@b.co' } }) }) });
      return r.ok && r.token === 'jwt_x'; } }
];

if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href && process.argv.includes('--self-test')) {
  let bad = 0;
  for (const t of SELF_TESTS) {
    let ok = false, err = '';
    try { ok = (await t.run()) === true; } catch (e) { err = e.message; }
    if (ok) console.log(`  ok    ${t.name}`);
    else { bad++; console.error(`  FAIL  ${t.name}${err ? ' — ' + err : ''}`); }
  }
  console.log(`\naskalice: ${SELF_TESTS.length - bad}/${SELF_TESTS.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}

if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href) {
  main().then((c) => process.exit(c)).catch((e) => { console.error(`  askalice: ${e.message}`); process.exit(2); });
}
