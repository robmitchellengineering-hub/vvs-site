#!/usr/bin/env node
// desk.mjs — the one surface. Paste a source, get the claims it makes and what backs each one.
//
// WHY THIS FILE IS THE POINT OF THE OTHER FOUR. extract.mjs, pdf.mjs, check.mjs and lineage.mjs are separate
// mechanisms; a person does not want four commands. The desk is the thing that answers "is what I am reading
// true, and what is behind it" in one run.
//
// TWO MODES, and the difference matters:
//
//   1. `--claim "subject | predicate | value" <source>`   — I have a claim and a source. Check the claim
//      against that source, and if the source is tertiary, descend it first (D28).
//
//   2. `<source>` with no claim                            — I have a page and want its references checked.
//      The desk pairs each citation with the sentence it supports and checks that sentence against the cited
//      source. Checking a page against itself always passes, which is why this mode never does that.
//
// WHAT IT WILL NOT DO: decide that a claim is true. Every line it prints is a verdict from a named check, with
// the quote that produced it and the observation that would overturn it.
import { readFileSync, existsSync } from 'node:fs';
import { extname } from 'node:path';
import { extractText, contentWords } from './extract.mjs';
import { isPdf, pdfPages } from './pdf.mjs';
import { checkFetched } from './check.mjs';
import { lineageOf, sourceKind, wikipediaPage } from './lineage.mjs';

const UA = { 'user-agent': 'ask-alice/0.1 (desk)' };

// ---------------------------------------------------------------------------
// loading
// ---------------------------------------------------------------------------
async function load(source) {
  if (/^https?:\/\//i.test(source)) {
    const r = await fetch(source, { headers: UA, redirect: 'follow' }).catch((e) => ({ status: 0, err: e }));
    if (!r || !r.ok) return { uri: source, httpStatus: r?.status ?? 0, body: '', kind: 'unreachable', reason: r?.status ? `HTTP ${r.status}` : 'no response' };
    const buf = Buffer.from(await r.arrayBuffer());
    if (isPdf(buf)) return { uri: source, httpStatus: r.status, body: buf, kind: 'pdf' };
    const html = buf.toString('utf8');
    return { uri: source, httpStatus: r.status, body: html, kind: 'html', text: extractText(html) };
  }
  if (!existsSync(source)) return { uri: source, httpStatus: 0, body: '', kind: 'missing', reason: 'no such file' };
  const buf = readFileSync(source);
  if (isPdf(buf)) return { uri: source, httpStatus: 200, body: buf, kind: 'pdf' };
  const raw = buf.toString('utf8');
  const ext = extname(source).toLowerCase();
  const html = ext === '.html' || ext === '.htm' || /<html|<!doctype/i.test(raw.slice(0, 400));
  return { uri: source, httpStatus: 200, body: raw, kind: html ? 'html' : 'text', text: html ? extractText(raw) : raw };
}

function textOf(src) {
  if (src.kind === 'pdf') return pdfPages(src.body).pages.join(' ');
  return src.text ?? extractText(src.body);
}

// ---------------------------------------------------------------------------
// claiming: a sentence becomes a checkable triple, honestly and crudely
// ---------------------------------------------------------------------------
const SPLIT = /(?<=[.!?])\s+/;

/** candidateClaims — sentences that carry something checkable, as subject/predicate/value. */
export function candidateClaims(text) {
  const out = [];
  for (const raw of String(text ?? '').split(SPLIT)) {
    const s = raw.trim();
    if (s.length < 24 || s.length > 400) continue;
    if (/\?$/.test(s)) continue;
    if (/^(see|main article|further information|references)/i.test(s)) continue;
    const words = s.replace(/[[\]]/g, '').split(/\s+/);
    // the value is the number, date or proper phrase a tool can actually look for
    const num = s.match(/\b(\d[\d,.–-]*\s?(?:%|bn|billion|million|thousand)?|\d{4}|\d{1,2}\s+\w+\s+\d{4})\b/);
    const value = num ? num[0].trim() : '';
    const subject = words.slice(0, Math.min(5, words.length)).join(' ').replace(/[.,;:]$/, '');
    const predicate = words.slice(5, 9).join(' ') || 'states';
    if (!contentWords(subject).length) continue;
    out.push({ subject, predicate, value: value || '', sentence: s });
    if (out.length >= 40) break;
  }
  return out;
}

/** pairs — for a wiki page, each citation with the sentence immediately before it. */
export function pairsFromWikitext(wikitext) {
  const text = String(wikitext ?? '');
  const pairs = [];
  const re = /<ref\b[^>]*>([\s\S]*?)<\/ref>/gi;
  let m, lastEnd = 0;
  while ((m = re.exec(text))) {
    const before = text.slice(lastEnd, m.index);
    const url = (m[1].match(/https?:\/\/[^\s|}\]<]+/) || [])[0] || null;
    const doi = (m[1].match(/\b(10\.\d{4,9}\/[^\s|}\]<]+)/) || [])[1] || null;
    const target = url || (doi ? `https://doi.org/${doi}` : null);
    // Strip templates and tables before looking for a sentence: the wikitext before a <ref> is usually an
    // infobox row, and the first desk run turned "| material = Steel" into a claim. A sentence with a pipe or a
    // brace in it is markup, not prose.
    const prose = before.replace(/\{\{[^{}]*\}\}/g, ' ').replace(/\|[^\n]*/g, ' ').replace(/<[^>]+>/g, ' ');
    const sentences = prose.split(SPLIT).map((x) => x.trim()).filter(Boolean);
    const claimText = sentences.length ? sentences[sentences.length - 1] : '';
    if (claimText && claimText.length > 20 && !/[|{}]/.test(claimText)) pairs.push({ sentence: claimText.replace(/<[^>]+>/g, ''), target, ref: m[1].replace(/\s+/g, ' ').trim().slice(0, 160) });
    lastEnd = m.index + m[0].length;
  }
  return pairs;
}

// ---------------------------------------------------------------------------
// the desk's two runs
// ---------------------------------------------------------------------------
async function checkOne(claim, src) {
  const kind = sourceKind(src.uri);
  if (kind === 'tertiary') {
    const walked = await lineageOf(claim, src.uri);
    const deepest = walked.deepest;
    const chainLine = walked.chain.map((c) => `${c.kind}${c.refs ? ` (${c.refs} cites)` : ''} — ${c.reason}`).join(' → ');
    if (!deepest) {
      return { verdict: 'unknown', reason: walked.reason === 'unsourced' ? 'no-span' : 'check-not-run', chain: chainLine, uri: null, claim, note: 'the descent ran out; a tertiary page is not a source' };
    }
    const r = await fetch(deepest, { headers: UA, redirect: 'follow' }).catch(() => null);
    const buf = r && r.ok ? Buffer.from(await r.arrayBuffer()) : null;
    const body = buf && isPdf(buf) ? buf : (buf ? buf.toString('utf8') : '');
    const rec = checkFetched(claim, { uri: deepest, httpStatus: r?.status ?? 0, body });
    return { ...rec, chain: chainLine };
  }
  const rec = checkFetched(claim, { uri: src.uri, httpStatus: src.httpStatus, body: src.body });
  return { ...rec, chain: 'this source is the evidence (no descent needed)' };
}

function line(rec, i) {
  const v = rec.verdict.toUpperCase().padEnd(17);
  const out = [];
  out.push(`  ${String(i).padStart(2)}  ${v} ${rec.claim.subject} — ${rec.claim.predicate}${rec.claim.value ? ` ${rec.claim.value}` : ''}`);
  if (rec.evidence) {
    const sp = rec.evidence.span || {};
    const where = rec.evidence.uri + (sp.page ? `  page ${sp.page}` : '') + (Number.isInteger(sp.start) ? `  chars ${sp.start}-${sp.end}` : '');
    out.push(`      source   ${where}`);
    if (sp.quote) out.push(`      quote    "${sp.quote.slice(0, 150)}${sp.quote.length > 150 ? '…' : ''}"`);
  }
  if (!rec.evidence && rec.checked) out.push(`      looked   ${rec.checked.uri}  (HTTP ${rec.checked.httpStatus}) — fetched, claim not in it`);
  out.push(`      why      ${rec.reason}`);
  if (rec.falsifier) out.push(`      dies if  ${rec.falsifier}`);
  if (rec.chain) out.push(`      chain    ${rec.chain}`);
  return out.join('\n');
}

async function main() {
  const args = process.argv.slice(2);
  if (!args.length) {
    console.log('usage: node desk.mjs <url|file.pdf|file.html> [--claim "subject | predicate | value"]');
    console.log('       with no --claim, every citation on the page is paired with the sentence it supports');
    process.exit(2);
  }
  const ci = args.indexOf('--claim');
  const claimArg = ci >= 0 ? args[ci + 1] : null;
  const source = args.find((a, i) => a !== '--claim' && i !== ci + 1) ?? args[0];

  const src = await load(source);
  if (src.kind === 'unreachable' || src.kind === 'missing') {
    console.error(`desk: cannot read ${source} — ${src.reason}`);
    process.exit(2);
  }

  if (claimArg) {
    const [subject, predicate, value] = claimArg.split('|').map((x) => (x ?? '').trim());
    const claim = { subject: subject || 'the claim', predicate: predicate || 'states', value: value || '' };
    const rec = await checkOne(claim, src);
    console.log(`\n  DESK · one claim against one source\n`);
    console.log(line(rec, 1));
    console.log('');
    process.exit(rec.verdict === 'unknown' ? 1 : 0);
  }

  // no claim: the page's own references, each paired with its sentence
  let pairs = [];
  if (src.kind === 'html' && /wikipedia\.org/.test(src.uri)) {
    const api = `https://${wikipediaPage(src.uri).lang}.wikipedia.org/w/api.php?action=parse&page=` +
      `${encodeURIComponent(wikipediaPage(src.uri).title)}&prop=wikitext&format=json&formatversion=2&redirects=1`;
    const r = await fetch(api, { headers: UA }).catch(() => null);
    const j = r && r.ok ? await r.json().catch(() => null) : null;
    if (j?.parse?.wikitext) pairs = pairsFromWikitext(j.parse.wikitext);
  }
  if (!pairs.length) {
    console.error('desk: no citations could be paired on this source. Use --claim "subject | predicate | value".');
    process.exit(2);
  }

  console.log(`\n  DESK · ${pairs.length} citation(s) paired with the sentence each one supports\n`);
  const results = [];
  let n = 0;
  for (const p of pairs.slice(0, 8)) {
    const claim = candidateClaims(p.sentence)[0] ?? { subject: p.sentence.slice(0, 60), predicate: 'states', value: 'event' };
    let rec;
    if (!p.target) {
      rec = { verdict: 'unknown', reason: 'no-span', falsifier: 'a citation naming a source', claim, chain: 'the reference carries no url or doi — unsourced at the source' };
    } else {
      const r = await fetch(p.target, { headers: UA, redirect: 'follow' }).catch(() => null);
      const buf = r && r.ok ? Buffer.from(await r.arrayBuffer()) : null;
      const body = buf && isPdf(buf) ? buf : (buf ? buf.toString('utf8') : '');
      rec = checkFetched(claim, { uri: p.target, httpStatus: r?.status ?? 0, body });
      rec.chain = `cited by the page → ${p.target.slice(0, 70)}`;
    }
    results.push(rec);
    console.log(line(rec, ++n));
    console.log('');
  }
  const checkable = results.filter((r) => r.verdict !== 'unknown').length;
  const supported = results.filter((r) => r.verdict === 'supported-in-span').length;
  console.log(`  ${supported} of ${checkable} checkable claim(s) supported · ${results.length - checkable} could not be checked`);
  console.log(`  coverage ${checkable}/${results.length} · survival ${checkable ? supported + '/' + checkable : 'n/a'}\n`);
}

if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href) {
  main().catch((e) => { console.error(`desk: ${e.message}`); process.exit(2); });
}
