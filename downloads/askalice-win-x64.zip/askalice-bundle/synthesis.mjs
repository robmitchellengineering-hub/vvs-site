#!/usr/bin/env node
// synthesis.mjs — what a library is FOR: two documents that disagree, and two things that keep appearing together.
//
// ROB: "synthesise with other verified research to find things and correlations that would otherwise take years to
// do by hand … create new historical theories and consensus from verified data."
//
// TWO ANSWERS, and neither is a score.
//
// CONTRADICTION — two claims about the same subject in the same year, carrying different values, each with its own
// document and quote. That is checkable by a human in a minute, and it is the thing that takes a year by hand.
//
// CORRELATION — two entities appearing in the same documents. The honest part is the ORIGIN COUNT: five documents
// that all trace to one press release are ONE source, not five. The count of independent origins is reported
// beside the co-occurrence, and a pair seen only in one origin is reported as exactly that.
//
// EVERY RESULT IS ITSELF A CLAIM: it carries its evidence (the documents and the quotes), its verdict, and the
// falsifier that would undo it — because a synthesis that cannot be argued with is the thing this project exists to
// stop.
import { openLibrary } from './library.mjs';

const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();

/** originOf — the thing an independence count is made of. A host is a router, not an origin: two pages on one host
 *  are normally one publisher, so the host is the honest unit available without fetching every page. */
export function originOf(uri) {
  try { return new URL(uri).hostname.replace(/^www\./, '').toLowerCase(); } catch { return String(uri || '').toLowerCase(); }
}

/** contradictions — same subject, same year, different value, different document. */
export function contradictions(lib, { limit = 20 } = {}) {
  const rows = lib.db.prepare(`
    SELECT c.id, c.subject, c.predicate, c.value, c.verdict, c.filed_at,
           d.uri, d.title, s.quote, s.page
    FROM claims c
    JOIN documents d ON d.id = c.doc_id
    LEFT JOIN spans s ON s.id = c.span_id
    WHERE c.value IS NOT NULL AND c.value <> ''
    ORDER BY c.id
  `).all();

  const byKey = new Map();
  for (const r of rows) {
    // The YEAR IS THE THING THAT DIFFERS, so it cannot be part of the key: "opened in 1937" and "opened in 1938"
    // are the same subject and predicate with a different value, which is exactly a contradiction. Grouping by
    // subject+predicate found zero of them in the first run of this file.
    const key = `${norm(r.subject)}|${norm(r.predicate)}`;
    if (!byKey.has(key)) byKey.set(key, []);
    byKey.get(key).push(r);
  }

  const found = [];
  for (const [key, group] of byKey) {
    if (group.length < 2) continue;
    for (let i = 0; i < group.length; i++) {
      for (let j = i + 1; j < group.length; j++) {
        const a = group[i], b = group[j];
        if (a.uri === b.uri) continue;                       // one document cannot contradict itself here
        if (norm(a.value) === norm(b.value)) continue;        // agreement is not a finding
        found.push({
          kind: 'contradiction',
          claim: { subject: a.subject, predicate: a.predicate, value: `${a.value} vs ${b.value}` },
          verdict: 'contradicted',
          reason: `two documents give different values for the same subject and predicate`,
          evidence: {
            a: { uri: a.uri, quote: a.quote, page: a.page },
            b: { uri: b.uri, quote: b.quote, page: b.page }
          },
          falsifier: `a source that shows one of these is a different subject, a different year, or not what the document says`
        });
        if (found.length >= limit) return found;
      }
    }
  }
  return found;
}

/** correlations — two names that keep appearing together, counted by INDEPENDENT origin. */
export function correlations(lib, { minDocuments = 2, limit = 20 } = {}) {
  const rows = lib.db.prepare(`
    SELECT e.name, c.id AS claim_id, d.uri
    FROM entities e
    JOIN claims c ON c.id = e.claim_id
    JOIN documents d ON d.id = c.doc_id
  `).all();

  // name -> set of documents, and name -> set of origins
  const docs = new Map(), origins = new Map();
  for (const r of rows) {
    if (!docs.has(r.name)) { docs.set(r.name, new Set()); origins.set(r.name, new Set()); }
    docs.get(r.name).add(r.uri);
    origins.get(r.name).add(originOf(r.uri));
  }

  const names = [...docs.keys()];
  const out = [];
  for (let i = 0; i < names.length; i++) {
    for (let j = i + 1; j < names.length; j++) {
      const a = names[i], b = names[j];
      const together = [...docs.get(a)].filter((u) => docs.get(b).has(u));
      if (together.length < minDocuments) continue;
      const independentOrigins = [...new Set(together.map(originOf))];
      out.push({
        kind: 'correlation',
        claim: { subject: a, predicate: 'co-occurs with', value: b },
        verdict: independentOrigins.length >= 2 ? 'supported-in-span' : 'unknown',
        reason: independentOrigins.length >= 2
          ? `found together in ${together.length} document(s) from ${independentOrigins.length} independent origins`
          : `found together in ${together.length} document(s) but only ONE origin (${independentOrigins[0]}) — one source, not agreement`,
        evidence: { documents: together, origins: independentOrigins },
        falsifier: independentOrigins.length >= 2
          ? 'a document showing one of the two is never discussed where the other is, or that their pairing traces to one origin'
          : 'a second, independent origin that mentions both — until then this is one source repeated',
        independentOrigins: independentOrigins.length,
        coOccurrences: together.length
      });
      if (out.length >= limit) return out;
    }
  }
  return out;
}

/** whatTheLibrarySays — one call for the UI. Never throws: an empty library is an answer. */
export function whatTheLibrarySays(lib) {
  return { contradictions: contradictions(lib), correlations: correlations(lib) };
}

// ---------------------------------------------------------------------------
// fixtures — a library built in code, because a synthesis over nothing is a demo
// ---------------------------------------------------------------------------
if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href && process.argv.includes('--self-test')) {
  const { mkdtempSync } = await import('node:fs');
  const { tmpdir } = await import('node:os');
  const { join } = await import('node:path');
  const { fileDocument, fileClaim } = await import('./library.mjs');

  const mk = (name) => openLibrary(join(mkdtempSync(join(tmpdir(), 'synth-')), name));
  const add = (lib, uri, title, claims) => {
    const doc = fileDocument(lib, { bytes: Buffer.from(uri), uri, kind: 'html', title });
    for (const c of claims) fileClaim(lib, c, { docId: doc.id });
    return doc;
  };
  const claim = (subject, pred, value, quote) => ({
    claim: { subject, predicate: pred, value }, verdict: 'supported-in-span', reason: 'containment',
    falsifier: 'a different value', evidence: { uri: 'x', span: { quote, start: 0, end: quote.length, extractor: { name: 'dom-text', version: '1.1.0' } } }
  });

  const tests = [
    { name: 'two documents with different values for one subject are a contradiction', run: () => {
        const lib = mk('a.db');
        add(lib, 'https://a.example/x', 'A', [claim('the bridge', 'opened in', '1937', 'opened in 1937')]);
        add(lib, 'https://b.example/y', 'B', [claim('the bridge', 'opened in', '1938', 'opened in 1938')]);
        const c = contradictions(lib);
        return c.length === 1 && c[0].kind === 'contradiction' && c[0].evidence.a.uri !== c[0].evidence.b.uri; } },
    { name: 'two documents that agree are not a finding', run: () => {
        const lib = mk('b.db');
        add(lib, 'https://a.example/x', 'A', [claim('the bridge', 'opened in', '1937', 'q')]);
        add(lib, 'https://b.example/y', 'B', [claim('the bridge', 'opened in', '1937', 'q')]);
        return contradictions(lib).length === 0; } },
    { name: 'RED: one document cannot contradict itself', run: () => {
        const lib = mk('c.db');
        add(lib, 'https://a.example/x', 'A', [claim('the bridge', 'opened in', '1937', 'q1'), claim('the bridge', 'opened in', '1938', 'q2')]);
        return contradictions(lib).length === 0; } },
    { name: 'a correlation across two origins counts two', run: () => {
        const lib = mk('d.db');
        add(lib, 'https://a.example/x', 'A', [claim('bridge steamers', 'were used by', 'ferry companies', 'q')]);
        add(lib, 'https://b.example/y', 'B', [claim('bridge traffic', 'carried by', 'ferry companies', 'q')]);
        const c = correlations(lib, { minDocuments: 2 }).find((x) => x.kind === 'correlation');
        return c && c.independentOrigins === 2 && c.verdict === 'supported-in-span'; } },
    { name: 'RED: five documents from ONE origin are one source, and say so', run: () => {
        const lib = mk('e.db');
        for (const p of ['x', 'y', 'z']) add(lib, `https://one.example/${p}`, p.toUpperCase(), [claim('bridge traffic', 'carried by', 'ferry companies', 'q')]);
        const c = correlations(lib, { minDocuments: 2 }).find((x) => x.kind === 'correlation');
        return c && c.independentOrigins === 1 && c.verdict === 'unknown' && /ONE origin/.test(c.reason); } },
    { name: 'every synthesis result carries a falsifier', run: () => {
        const lib = mk('f.db');
        add(lib, 'https://a.example/x', 'A', [claim('the bridge', 'opened in', '1937', 'q'), claim('bridge traffic', 'carried by', 'ferry companies', 'q')]);
        add(lib, 'https://b.example/y', 'B', [claim('the bridge', 'opened in', '1938', 'q'), claim('bridge tolls', 'paid to', 'ferry companies', 'q')]);
        const all = [...contradictions(lib), ...correlations(lib, { minDocuments: 2 })];
        return all.length > 0 && all.every((x) => typeof x.falsifier === 'string' && x.falsifier.length > 10); } }
  ];
  let bad = 0;
  for (const t of tests) {
    let ok = false, err = '';
    try { ok = t.run() === true; } catch (e) { err = e.message; }
    if (ok) console.log(`  ok    ${t.name}`);
    else { bad++; console.error(`  FAIL  ${t.name}${err ? ' — ' + err : ''}`); }
  }
  console.log(`\nsynthesis: ${tests.length - bad}/${tests.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
