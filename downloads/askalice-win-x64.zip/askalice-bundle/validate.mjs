#!/usr/bin/env node
// validate.mjs — the claim-record validator, and the proof that it can reject.
//
// WHY THIS FILE EXISTS. VDS Extension 1 defines one small object that every published claim carries. A schema
// nobody runs is a paragraph; this runs the schema's actual rules against a record and refuses the ones that
// break them. The rules it enforces are the ones with a failure that matters:
//
//   - a verdict that needs a span and has none            -> rejected
//   - `unknown` with a reason outside the closed set      -> rejected (that is how "could not check" rots into "fine")
//   - `unbacked` carrying evidence                        -> rejected (absence and a source cannot both be true)
//   - a 403 recorded as 404                               -> rejected (the id.loc.gov trap, measured 2026-11-05)
//
// `--self-test` runs fixtures of each: it exits 0 ONLY if every invalid record is refused for the right rule and
// every valid one is accepted. A self-test that cannot fail is not a test, so the fixtures are built to fail.
//
// No dependencies, by design: this ships inside a zero-dependency SDK and must run on a machine that has node
// and nothing else.
import { readFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const VERDICTS = ['supported-in-span', 'contradicted', 'unknown', 'unbacked', 'not-a-claim'];
const LAYERS = ['bytes', 'coded-values', 'authority', 'content'];
const TERTIARY_HOST = /(^|\.)(wikipedia|wikidata|dbpedia|wikiwand|britannica|encyclopedia|fandom)\.(org|com)$/i;
const UNKNOWN_REASONS = ['http-403', 'http-404', 'http-429', 'http-5xx', 'timeout', 'paywall', 'no-span', 'check-not-run', 'ambiguous'];

// validate(record) -> string[] of violations. Empty means the record conforms.
export function validate(r) {
  const bad = [];
  if (!r || typeof r !== 'object' || Array.isArray(r)) return ['the record is not an object'];

  for (const k of ['id', 'claim', 'evidence', 'check', 'verifier', 'verdict', 'reason', 'falsifier', 'scope']) {
    if (!(k in r)) bad.push(`missing required field: ${k}`);
  }
  if (bad.length) return bad;

  if (typeof r.id !== 'string' || !r.id) bad.push('id must be a non-empty string');

  const c = r.claim;
  if (!c || typeof c !== 'object') bad.push('claim must be an object');
  else for (const k of ['subject', 'predicate', 'value']) {
    if (typeof c[k] !== 'string' || !c[k].trim()) bad.push(`claim.${k} must be a non-empty string`);
  }

  if (!VERDICTS.includes(r.verdict)) bad.push(`verdict must be one of: ${VERDICTS.join(', ')}`);
  if (typeof r.reason !== 'string' || !r.reason.trim()) bad.push('reason must be a non-empty string');
  if (typeof r.falsifier !== 'string' || !r.falsifier.trim()) bad.push('falsifier must be a non-empty string');

  const ck = r.check;
  if (!ck || typeof ck !== 'object') bad.push('check must be an object');
  else {
    if (typeof ck.name !== 'string' || !ck.name) bad.push('check.name must be a non-empty string');
    if (typeof ck.version !== 'string' || !/^\d+\.\d+\.\d+$/.test(ck.version)) bad.push('check.version must be semver, e.g. 1.0.0');
  }

  const v = r.verifier;
  if (!v || typeof v !== 'object') bad.push('verifier must be an object');
  else {
    if (!['machine', 'human'].includes(v.kind)) bad.push('verifier.kind must be machine or human');
    if (typeof v.id !== 'string' || !v.id) bad.push('verifier.id must be a non-empty string');
  }

  const sc = r.scope;
  if (!sc || typeof sc !== 'object') bad.push('scope must be an object');
  else {
    if (!LAYERS.includes(sc.layer)) bad.push(`scope.layer must be one of: ${LAYERS.join(', ')}`);
    if (typeof sc.item !== 'string' || !sc.item) bad.push('scope.item must be a non-empty string');
  }

  // ---- evidence, and the verdict rules that depend on it --------------------
  const e = r.evidence;
  const hasEvidence = e && typeof e === 'object';
  if (e !== null && !hasEvidence) bad.push('evidence must be an object or null');

  if (hasEvidence) {
    if (typeof e.uri !== 'string' || !/^https?:\/\//.test(e.uri)) bad.push('evidence.uri must be an http(s) URL');
    if (typeof e.fetchedAt !== 'string' || Number.isNaN(Date.parse(e.fetchedAt))) bad.push('evidence.fetchedAt must be an RFC 3339 timestamp');
    if (!Number.isInteger(e.httpStatus) || e.httpStatus < 100 || e.httpStatus > 599) bad.push('evidence.httpStatus must be an integer 100-599');
    if (typeof e.contentHash !== 'string' || !/^sha256:[0-9a-f]{64}$/.test(e.contentHash)) bad.push('evidence.contentHash must be sha256:<64 hex> — a verdict is about bytes that cannot silently change');
    const sp = e.span;
    if (!sp || typeof sp !== 'object') bad.push('evidence.span is required: a quote without offsets cannot be re-checked');
    else {
      if (typeof sp.quote !== 'string' || !sp.quote) bad.push('evidence.span.quote must be a non-empty string');
      if (!Number.isInteger(sp.start) || sp.start < 0) bad.push('evidence.span.start must be a non-negative integer');
      if (!Number.isInteger(sp.end) || sp.end <= (sp.start ?? -1)) bad.push('evidence.span.end must be an integer greater than start');
      if ('page' in sp && (!Number.isInteger(sp.page) || sp.page < 1)) bad.push('evidence.span.page must be a page number (integer >= 1)');
      const ex = sp.extractor;
      if (!ex || typeof ex !== 'object') bad.push('evidence.span.extractor is required: offsets into bytes cannot be walked back to words');
      else {
        if (typeof ex.name !== 'string' || !ex.name) bad.push('evidence.span.extractor.name must be a non-empty string');
        if (typeof ex.version !== 'string' || !/^\d+\.\d+\.\d+$/.test(ex.version)) bad.push('evidence.span.extractor.version must be semver, so a normalisation change cannot silently re-point old spans');
        if (ex.name === 'pdf-text' && !Number.isInteger(sp.page)) bad.push('a pdf-text span must name its page — "characters 41000-41200" is not a place a reader can check');
      }
    }
  }

  if (['supported-in-span', 'contradicted'].includes(r.verdict) && !hasEvidence) {
    bad.push(`verdict ${r.verdict} requires evidence with a span — a contradiction without the text that contradicts is an accusation`);
  }
  if (['unbacked', 'not-a-claim'].includes(r.verdict) && hasEvidence) {
    bad.push(`verdict ${r.verdict} requires evidence to be null — absence of evidence and a source cannot both be true`);
  }
  if (r.verdict === 'unknown') {
    if (!UNKNOWN_REASONS.includes(r.reason)) {
      bad.push(`unknown must use a closed reason (${UNKNOWN_REASONS.join(', ')}) — got "${r.reason}"`);
    }
    // The measured trap: a 403 is not a 404, and a 404 is not a contradiction.
    if (hasEvidence && e.httpStatus === 403 && r.reason !== 'http-403') {
      bad.push('a 403 must be recorded as http-403 — a host behind a challenge page is not a missing source');
    }
    if (hasEvidence && e.httpStatus === 404 && r.reason !== 'http-404') {
      bad.push('a 404 must be recorded as http-404 — a dead link is absent evidence, not a contradiction');
    }
    if (hasEvidence && e.httpStatus >= 200 && e.httpStatus < 300 && r.reason === 'http-404') {
      bad.push('a 2xx fetch cannot be recorded as http-404');
    }
  }
  // D28: a tertiary host is a pointer. It may be where a claim was FOUND, never what SUPPORTS it.
  if (hasEvidence && ['supported-in-span', 'contradicted'].includes(r.verdict)) {
    let host = '';
    try { host = new URL(e.uri).hostname.replace(/^www\./, ''); } catch { /* uri already checked above */ }
    if (TERTIARY_HOST.test(host)) {
      bad.push(`evidence.uri is ${host}, a tertiary source — descend to what it cites; a pointer is not a source (D28)`);
    }
  }
  if ('lineage' in r) {
    if (!Array.isArray(r.lineage)) bad.push('lineage must be an array when present');
    else r.lineage.forEach((h, i) => {
      if (!h || typeof h !== 'object') return bad.push(`lineage[${i}] is not an object`);
      if (!Number.isInteger(h.hop)) bad.push(`lineage[${i}].hop must be an integer`);
      if (!['tertiary', 'web', 'none'].includes(h.kind)) bad.push(`lineage[${i}].kind must be tertiary, web or none`);
      if (typeof h.reason !== 'string' || !h.reason) bad.push(`lineage[${i}].reason must be a non-empty string`);
    });
  }
  if (['supported-in-span', 'contradicted'].includes(r.verdict) && hasEvidence && e.httpStatus !== 200) {
    bad.push(`a ${r.verdict} verdict needs a successful fetch, not HTTP ${e.httpStatus}`);
  }
  return bad;
}

// ---- fixtures: each invalid one names the rule it must trip ------------------
const ok = (over = {}) => ({
  id: 'cr_fixture',
  claim: { subject: 'the MARC 245 field', predicate: 'is mandatory', value: 'false' },
  evidence: {
    uri: 'https://www.loc.gov/marc/bibliographic/bd245.html',
    fetchedAt: '2026-11-05T04:12:07Z',
    httpStatus: 200,
    span: { quote: '245 - Title Statement (NR)', start: 1841, end: 1866, extractor: { name: 'dom-text', version: '1.0.0' } },
    contentHash: 'sha256:' + 'a'.repeat(64)
  },
  check: { name: 'span-containment', version: '1.0.0' },
  verifier: { kind: 'machine', id: 'valiant/0.16.1' },
  verdict: 'supported-in-span',
  reason: 'the named field is present in the span with its stated repeatability',
  falsifier: 'a row in the same table declaring 245 mandatory',
  scope: { layer: 'coded-values', item: 'record/example/1' },
  ...over
});

const FIXTURES = [
  { name: 'valid: supported-in-span', expect: true, record: ok() },
  { name: 'valid: unknown with a closed reason', expect: true, record: ok({ verdict: 'unknown', reason: 'check-not-run', evidence: null }) },
  { name: 'valid: a 403 recorded as a 403', expect: true, record: ok({ verdict: 'unknown', reason: 'http-403', evidence: { ...ok().evidence, httpStatus: 403 } }) },
  { name: 'valid: unbacked with null evidence', expect: true, record: ok({ verdict: 'unbacked', reason: 'no source was named', evidence: null }) },
  {
    name: 'invalid: supported-in-span with no evidence',
    expect: false, match: /requires evidence with a span/,
    record: ok({ evidence: null })
  },
  {
    name: 'invalid: unknown with a free-text reason',
    expect: false, match: /closed reason/,
    record: ok({ verdict: 'unknown', reason: 'could not check, looks fine though', evidence: null })
  },
  {
    name: 'invalid: 403 recorded as 404',
    expect: false, match: /403 must be recorded as http-403/,
    record: ok({ verdict: 'unknown', reason: 'http-404', evidence: { ...ok().evidence, httpStatus: 403 } })
  },
  {
    name: 'invalid: span without offsets',
    expect: false, match: /cannot be re-checked|span.start/,
    record: ok({ evidence: { ...ok().evidence, span: { quote: '245 - Title Statement (NR)' } } })
  },
  {
    name: 'invalid: unbacked carrying evidence',
    expect: false, match: /be null/,
    record: ok({ verdict: 'unbacked', reason: 'no source' })
  },
  {
    name: 'invalid: a wikipedia url offered as supporting evidence',
    expect: false, match: /tertiary source/,
    record: ok({ evidence: { ...ok().evidence, uri: 'https://en.wikipedia.org/wiki/Golden_Gate_Bridge' } })
  },
  {
    name: 'valid: a lineage hop is accepted',
    expect: true,
    record: ok({ lineage: [{ hop: 0, uri: 'https://en.wikipedia.org/wiki/X', kind: 'tertiary', refs: 191, reason: '191 citations on the page' }] })
  },
  {
    name: 'invalid: a pdf span with no page',
    expect: false, match: /must name its page/,
    record: ok({ evidence: { ...ok().evidence, span: { ...ok().evidence.span, extractor: { name: 'pdf-text', version: '1.0.0' } } } })
  },
  {
    name: 'valid: a pdf span with a page',
    expect: true,
    record: ok({ evidence: { ...ok().evidence, span: { ...ok().evidence.span, page: 4, extractor: { name: 'pdf-text', version: '1.0.0' } } } })
  },
  {
    name: 'invalid: a span naming no extractor',
    expect: false, match: /extractor/,
    record: ok({ evidence: { ...ok().evidence, span: { ...ok().evidence.span, extractor: undefined } } })
  },
  {
    name: 'invalid: no falsifier',
    expect: false, match: /falsifier/,
    record: ok({ falsifier: '   ' })
  },
  {
    name: 'invalid: verdict not in the enum',
    expect: false, match: /verdict must be one of/,
    record: ok({ verdict: 'mostly-true' })
  }
];

if (process.argv.includes('--self-test')) {
  let failures = 0;
  for (const f of FIXTURES) {
    const got = validate(f.record);
    const accepted = got.length === 0;
    const pass = accepted === f.expect && (f.expect || (f.match ? got.some((m) => f.match.test(m)) : true));
    if (!pass) {
      failures++;
      console.error(`  FAIL  ${f.name}`);
      console.error(`        expected ${f.expect ? 'accept' : 'reject'}${f.match ? ' matching ' + f.match : ''}, got ${accepted ? 'accept' : 'reject: ' + got.join('; ')}`);
    } else {
      console.log(`  ok    ${f.name}  (${f.expect ? 'accepted' : 'rejected: ' + got[0].slice(0, 70) + '…'})`);
    }
  }
  console.log(`\nclaim-record self-test: ${FIXTURES.length - failures}/${FIXTURES.length} fixtures behaved`);
  process.exit(failures ? 1 : 0);
}

const file = process.argv[2];
if (!file) {
  console.error('usage: node validate.mjs <record.json> | --self-test');
  process.exit(2);
}
if (!existsSync(file)) { console.error(`validate: ${file} does not exist`); process.exit(2); }
let rec;
try { rec = JSON.parse(readFileSync(file, 'utf8')); } catch (e) { console.error(`validate: ${file} is not JSON (${e.message})`); process.exit(2); }
const bad = validate(rec);
if (bad.length) { for (const b of bad) console.error(`  FAIL  ${b}`); process.exit(1); }
console.log(`validate: ${file} conforms to VDS Extension 1 (verdict: ${rec.verdict})`);
void join; void HERE;
