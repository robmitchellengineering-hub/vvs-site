#!/usr/bin/env node
// lineage.mjs — a tertiary source is a POINTER, not a source. Descend it.
//
// ROB, 2026-11-05: "if it references wiki for data it needs to dig down for all the real references rather than
// referencing wiki itself."
//
// That is not a preference, it is the rule Wikipedia applies to itself: an encyclopedia article is not a
// reliable source for a claim, the thing it cites is (WP:RS/WP:V). Citing Wikipedia in an article is a circular
// citation, and a checked verdict resting on a Wikipedia page is a verdict resting on whoever edited it last.
//
// So this module walks the chain down. Given a claim and a tertiary URI:
//
//   1. fetch the page's own edit source (the wikitext, not the rendered page — the rendered page hides which
//      sentence was sourced to what);
//   2. pull the citations out of it: <ref> blocks, then the first URL and any DOI/ISBN inside each;
//   3. fetch the deepest citation and run the containment check THERE;
//   4. record every hop, so the verdict names the real source and the chain that reached it;
//   5. when the descent runs out — an unsourced sentence, a dead link, a citation with no URL — the answer is
//      UNKNOWN with the chain attached. It is never "Wikipedia says so".
//
// The chain is the product. A reference manager that tells you "this sentence traces to a 2019 transport
// authority report, here is the line" is the powerhouse; one that says "Wikipedia" is a citation generator.
import { extractText, findSpan, hashBytes, contentWords } from './extract.mjs';
import { pathToFileURL } from 'node:url';
// A module that runs its fixtures on IMPORT exits the importing process: it silently truncated another suite's
// output the first time this was wired together. Main-module check, once, at the top.
const IS_MAIN = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;

export const LINEAGE_VERSION = '1.0.0';
const MAX_DEPTH = 3;

// Hosts that are pointers rather than sources. Deliberately a list, not a judgement: it is things whose own
// content is a summary of other things.
const TERTIARY = [
  /(^|\.)wikipedia\.org$/i, /(^|\.)wikidata\.org$/i, /(^|\.)dbpedia\.org$/i,
  /(^|\.)wikiwand\.com$/i, /(^|\.)britannica\.com$/i, /(^|\.)encyclopedia\.com$/i,
  /(^|\.)fandom\.com$/i, /(^|\.)everything2\.com$/i
];

export function hostOf(uri) {
  try { return new URL(uri).hostname.replace(/^www\./, ''); } catch { return ''; }
}

export function sourceKind(uri) {
  const h = hostOf(uri);
  return TERTIARY.some((re) => re.test(h)) ? 'tertiary' : 'web';
}

/** wikipediaPage — the API URL for a page's wikitext, from any wikipedia.org article URL. */
export function wikipediaPage(uri) {
  let u;
  try { u = new URL(uri); } catch { return null; }
  if (!/(^|\.)wikipedia\.org$/i.test(u.hostname.replace(/^www\./, ''))) return null;
  const m = u.pathname.match(/^\/wiki\/(.+)$/);
  if (!m) return null;
  const lang = u.hostname.split('.')[0];
  return { lang, title: decodeURIComponent(m[1]).replace(/_/g, ' ') };
}

export function wikitextApiUrl(uri) {
  const p = wikipediaPage(uri);
  if (!p) return null;
  return `https://${p.lang}.wikipedia.org/w/api.php?action=parse&page=${encodeURIComponent(p.title)}` +
    `&prop=wikitext&format=json&formatversion=2&redirects=1`;
}

const SKIP_HOSTS = /(^|\.)(facebook|twitter|x|instagram|youtube|tiktok|linkedin|pinterest|reddit)\.com$/i;

/**
 * extractLinks — the general adapter: when a tertiary source is not a wiki, its citations are its outbound
 * links. This is a HEURISTIC and it is labelled as one: a link can mean "cited by", "see also" or "advert",
 * and nothing in the HTML says which. It is still the right descent for an encyclopedia entry, because the
 * alternative is treating the entry itself as the source.
 */
export function extractLinks(html, baseUri) {
  const base = (() => { try { return new URL(baseUri).hostname.replace(/^www\./, ''); } catch { return ''; } })();
  const out = [];
  const re = /<a\b[^>]*href=["']([^"'#]+)["'][^>]*>([\s\S]{0,200}?)<\/a>/gi;
  let m;
  while ((m = re.exec(String(html ?? '')))) {
    let abs;
    try { abs = new URL(m[1], baseUri).href; } catch { continue; }
    if (!/^https?:/i.test(abs)) continue;
    const host = hostOf(abs);
    if (!host || host === base || SKIP_HOSTS.test(host)) continue;
    const label = String(m[2]).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    out.push({ url: abs, label: label.slice(0, 200), raw: label.slice(0, 200), doi: null, isbn: null, target: abs });
  }
  // one entry per target: a page can link the same source twice
  const seen = new Set();
  return out.filter((r) => (seen.has(r.target) ? false : (seen.add(r.target), true)));
}

/**
 * extractReferences — pull the citations out of a page's edit source.
 * Every <ref> block is one reference; the first http(s) URL is its target, and a DOI or ISBN is recorded when
 * the citation carries one instead of (or as well as) a link.
 */
export function extractReferences(wikitext) {
  const text = String(wikitext ?? '');
  const out = [];
  const re = /<ref\b[^>]*>([\s\S]*?)<\/ref>/gi;
  let m;
  while ((m = re.exec(text))) {
    const body = m[1];
    const url = (body.match(/https?:\/\/[^\s|}\]<]+/) || [])[0] || null;
    const doi = (body.match(/\b(10\.\d{4,9}\/[^\s|}\]<]+)/) || [])[1] || null;
    const isbn = (body.match(/\b(97[89][\d-]{10,}|[0-9]{9}[\dXx])\b/) || [])[1] || null;
    out.push({ raw: body.replace(/\s+/g, ' ').trim().slice(0, 300), url: url ? url.replace(/[.,;]$/, '') : null, doi, isbn, target: url || (doi ? `https://doi.org/${doi}` : null) });
  }
  return out;
}

/**
 * descend — one hop down from a tertiary URI to its citations.
 * Returns { kind, refs, reason } and never throws: a fetch that fails is an UNKNOWN hop, not a crash.
 */
export async function descend(uri, { fetchImpl } = {}) {
  const f = fetchImpl ?? globalThis.fetch;
  const kind = sourceKind(uri);
  if (kind !== 'tertiary') return { kind, refs: [], reason: 'already a primary source' };

  const page = wikipediaPage(uri);
  if (!page) {
    // Not a wiki: fall back to the general adapter — the page's outbound links.
    let r;
    try { r = await f(uri, { headers: { 'user-agent': 'ask-alice/0.1 (lineage)' } }); }
    catch (e) { return { kind, refs: [], reason: `the fetch failed: ${e.message}` }; }
    if (!r || !r.ok) return { kind, refs: [], reason: `HTTP ${r?.status ?? 'no response'}` };
    const html = await r.text();
    const refs = extractLinks(html, uri);
    return { kind, refs, reason: refs.length ? `${refs.length} outbound link(s), read as citations` : 'no outbound links to descend' };
  }

  const api = wikitextApiUrl(uri);
  let res;
  try { res = await f(api, { headers: { 'user-agent': 'ask-alice/0.1 (lineage)' } }); }
  catch (e) { return { kind, refs: [], reason: `the wiki fetch failed: ${e.message}` }; }
  if (!res || !res.ok) return { kind, refs: [], reason: `the wiki api answered HTTP ${res?.status ?? 'no response'}` };

  let json;
  try { json = await res.json(); } catch { return { kind, refs: [], reason: 'the wiki api returned something that is not json' }; }
  const wikitext = json?.parse?.wikitext;
  if (typeof wikitext !== 'string') return { kind, refs: [], reason: 'the wiki api returned no wikitext' };

  const refs = extractReferences(wikitext);
  return { kind, refs, reason: refs.length ? `${refs.length} citation(s) on the page` : 'the page carries no citations at all' };
}

/**
 * lineageOf — walk down from a claim's evidence to the first real source, and record every hop.
 * `checkFetched` is injected so this file does not import the checker and the checker can import this one.
 */
export async function lineageOf(claim, uri, { fetchImpl, checkFetched, maxDepth = MAX_DEPTH } = {}) {
  const f = fetchImpl ?? globalThis.fetch;
  const chain = [];
  const seen = new Set([uri]);
  let current = uri;
  let depth = 0;

  while (depth < maxDepth) {
    const hop = await descend(current, { fetchImpl: f });
    chain.push({ hop: depth, uri: current, kind: hop.kind, refs: hop.refs.length, reason: hop.reason });
    if (hop.kind !== 'tertiary') break;

    // choose the citation whose words best match the claim: the page cites many things, and the right one is
    // the one about this claim, not the first <ref> alphabetically.
    const wanted = contentWords(`${claim.subject} ${claim.value}`).slice(0, 4);
    let best = null, bestScore = -1;
    for (const r of hop.refs) {
      const t = String(r.target ?? '');
      if (!t) continue;
      const score = wanted.filter((w) => (r.raw || '').toLowerCase().includes(w) || t.toLowerCase().includes(w)).length;
      if (score > bestScore) { bestScore = score; best = r; }
    }
    if (!best || !best.target) {
      chain.push({ hop: depth + 1, uri: null, kind: 'none', refs: 0, reason: 'the citation that could support this carries no url or doi — unsourced at the source' });
      return { chain, verdict: 'unknown', reason: 'unsourced', deepest: null };
    }
    if (seen.has(best.target)) {
      chain.push({ hop: depth + 1, uri: best.target, kind: 'none', refs: 0, reason: 'circular: this source is already in the chain' });
      return { chain, verdict: 'unknown', reason: 'circular', deepest: null };
    }
    seen.add(best.target);
    current = best.target;
    depth++;
  }

  return { chain, deepest: current, verdict: null, reason: null, depth };
}

/** The verdict a lineage produces: the hop's own record, with the chain attached. Never the wiki page. */
export async function checkWithLineage(claim, uri, deps = {}) {
  const { fetchImpl } = deps;
  const f = fetchImpl ?? globalThis.fetch;
  const walked = await lineageOf(claim, uri, { ...deps, fetchImpl: f });
  if (!walked.deepest) {
    return {
      ...deps.record(null, claim, 'unknown', walked.reason === 'unsourced' ? 'no-span' : 'check-not-run'),
      lineage: walked.chain
    };
  }
  let res;
  try { res = await f(walked.deepest); } catch (e) { res = null; }
  const body = res && res.ok ? await res.text() : '';
  const rec = deps.record({ uri: walked.deepest, httpStatus: res?.status ?? 0, body }, claim);
  return { ...rec, lineage: walked.chain };
}

// ---------------------------------------------------------------------------
// fixtures
// ---------------------------------------------------------------------------
const WIKITEXT = `
'''Golden Gate Bridge''' is a suspension bridge. It opened in 1937.<ref name="opened">{{cite news
|url=https://example.org/transport/1937-opening |title=Bridge opens to traffic |date=1937-05-28}}</ref>
The bridge is {{convert|1.7|mi|km}} long.<ref name="len">{{cite book |title=Spanning the Gate |isbn=978-0-8118-0546-7}}</ref>
It is widely regarded as beautiful.<ref>Cited to nothing at all.</ref>
`;

const FIXTURES = [
  { name: 'wikipedia is tertiary', run: () => sourceKind('https://en.wikipedia.org/wiki/Golden_Gate_Bridge') === 'tertiary' },
  { name: 'a journal article is not', run: () => sourceKind('https://www.nature.com/articles/x') === 'web' },
  { name: 'the api url carries the page title', run: () => wikitextApiUrl('https://en.wikipedia.org/wiki/Golden_Gate_Bridge').includes('Golden%20Gate%20Bridge') },
  { name: 'every <ref> becomes a reference', run: () => extractReferences(WIKITEXT).length === 3 },
  { name: 'a url citation yields its url', run: () => extractReferences(WIKITEXT)[0].target === 'https://example.org/transport/1937-opening' },
  { name: 'a citation with only an isbn does not pretend to have a url', run: () => {
      const r = extractReferences(WIKITEXT)[1]; return r.url === null && r.isbn && r.target === null; } },
  { name: 'an unsourced ref is visible as unsourced', run: () => {
      const r = extractReferences(WIKITEXT)[2]; return r.url === null && r.doi === null && r.isbn === null; } },
  { name: 'RED: descent picks the citation about the claim, not the first one', run: async () => {
      const TWO = "X.<ref>{{cite news|url=https://a.example/opening}}</ref>" +
        "<ref>{{cite book|url=https://b.example/length|title=The length of the bridge}}</ref>";
      const wiki = { parse: { wikitext: TWO } };
      const fakeFetch = async () => ({ ok: true, status: 200, json: async () => wiki, text: async () => '' });
      const w = await lineageOf({ subject: 'the bridge', predicate: 'is', value: 'length' },
        'https://en.wikipedia.org/wiki/X', { fetchImpl: fakeFetch });
      // the first <ref> is about the opening; the claim is about length, so the second one must win
      return w.deepest === 'https://b.example/length';
    } },
  { name: 'RED: a page with no citations ends UNKNOWN, never "wikipedia says so"', run: async () => {
      const wiki = { parse: { wikitext: 'No refs here at all.' } };
      const fakeFetch = async () => ({ ok: true, status: 200, json: async () => wiki });
      const w = await lineageOf({ subject: 'x', predicate: 'is', value: 'y' }, 'https://en.wikipedia.org/wiki/Nothing', { fetchImpl: fakeFetch });
      return w.deepest === null && w.verdict === 'unknown';
    } },
  { name: 'RED: a wiki api that 404s is a failed hop, not a crash', run: async () => {
      const fakeFetch = async () => ({ ok: false, status: 404 });
      const w = await lineageOf({ subject: 'x', predicate: 'is', value: 'y' }, 'https://en.wikipedia.org/wiki/Missing', { fetchImpl: fakeFetch });
      return w.deepest === null && w.chain[0].reason.includes('404');
    } },
  { name: 'general adapter: a non-wiki page descends to its outbound links', run: async () => {
      const html = '<p>See <a href="https://study.example/paper">the study</a> and ' +
        '<a href="https://twitter.com/x">a tweet</a>.</p>';
      const fakeFetch = async () => ({ ok: true, status: 200, text: async () => html });
      const hop = await descend('https://www.britannica.com/place/Golden-Gate-Bridge', { fetchImpl: fakeFetch });
      return hop.refs.length === 1 && hop.refs[0].target === 'https://study.example/paper';
    } },
  { name: 'general adapter: same-host and social links are not citations', run: () => {
      const html = '<a href="/other">internal</a><a href="https://www.youtube.com/watch?v=1">video</a>' +
        '<a href="https://jstor.example/stable/1">article</a>';
      const refs = extractLinks(html, 'https://encyclopedia.example/x');
      return refs.length === 1 && refs[0].target === 'https://jstor.example/stable/1';
    } },
  { name: 'RED: a circular citation ends UNKNOWN, never a clean chain', run: async () => {
      const wiki = { parse: { wikitext: 'Claim.<ref>{{cite web|url=https://en.wikipedia.org/wiki/X}}</ref>' } };
      const fakeFetch = async () => ({ ok: true, status: 200, json: async () => wiki });
      const w = await lineageOf({ subject: 'claim', predicate: 'is', value: 'true' }, 'https://en.wikipedia.org/wiki/X', { fetchImpl: fakeFetch });
      return w.verdict === 'unknown' && w.reason === 'circular';
    } },
  { name: 'RED: a page whose only citation is unsourced ends UNKNOWN', run: async () => {
      const wiki = { parse: { wikitext: 'Claim.<ref>Unsourced.</ref>' } };
      const fakeFetch = async (u) => ({ ok: true, status: 200, json: async () => wiki, text: async () => '' });
      const w = await lineageOf({ subject: 'claim', predicate: 'is', value: 'true' }, 'https://en.wikipedia.org/wiki/X', { fetchImpl: fakeFetch });
      return w.deepest === null && w.verdict === 'unknown';
    } }
];

if (IS_MAIN && process.argv.includes('--self-test')) {
  let bad = 0;
  for (const f of FIXTURES) {
    let ok = false, err = '';
    try { ok = (await f.run()) === true; } catch (e) { err = e.message; }
    if (ok) console.log(`  ok    ${f.name}`);
    else { bad++; console.error(`  FAIL  ${f.name}${err ? ' — ' + err : ''}`); }
  }
  console.log(`\nlineage: ${FIXTURES.length - bad}/${FIXTURES.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
