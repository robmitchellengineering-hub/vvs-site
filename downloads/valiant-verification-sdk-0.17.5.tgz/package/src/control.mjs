// control.mjs — the AI control standard: measure control, not capability (Aza Raskin).
//
// `valiant control` runs the three ai-control reference guards against the agent's action
// ledger (`ai-actions.jsonl`) and emits the CONTROL NUMBER:
//   0 = under control · 1 = a control broke · 2 = could not check
// The number is the whole point — a benchmark says what a model CAN do; this says whether the
// agent's actions stayed under human authority, and proves it by checking a ledger a human can
// re-open. Each guard is mutation-tested: it breaks on purpose and goes red, so a green number
// is evidence, not a claim.
import { readFileSync, existsSync, appendFileSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";
import * as approved from "../corpus/reference-guards/ai-control-approved.mjs";
import * as traceable from "../corpus/reference-guards/ai-control-traceable.mjs";
import * as restated from "../corpus/reference-guards/ai-control-restated.mjs";

export const LEDGER = "ai-actions.jsonl";

export const GUARDS = [
  { name: "ai-control-approved", run: approved.check, what: "every action carries a human yes" },
  { name: "ai-control-traceable", run: traceable.check, what: "every claim points at a re-checkable source" },
  { name: "ai-control-restated", run: restated.check, what: "the agent restated what it meant before it acted" },
];

/** Run the three control guards and reduce them to the control number + a human summary. */
export function checkControl(dir) {
  const root = resolve(dir);
  const ledger = join(root, LEDGER);
  if (!existsSync(ledger)) {
    return {
      ok: false, number: 2, guards: [],
      summary: `no ${LEDGER} — nothing was recorded, so control could not be checked (2)`,
    };
  }
  const guards = GUARDS.map((g) => {
    const r = g.run(root);
    return { name: g.name, ok: r.ok, detail: r.detail, what: g.what };
  });
  const broken = guards.filter((g) => !g.ok);
  const number = broken.length ? 1 : 0;
  const summary = number === 0
    ? `${guards.length}/${guards.length} control guard(s) hold — under control (0)`
    : `${broken.map((g) => g.name).join(", ")} broke control (1)`;
  return { ok: number === 0, number, guards, summary };
}

/** The safe class: read-only commands that cannot change state. Auto-approving these reserves the human's
 *  tick for consequential actions — the fix for approval fatigue (Anthropic measured ~93% of permission
 *  prompts auto-approved anyway; we make the auto-approval explicit and scoped to the safe class). */
const LOW_RISK = /^(ls|cat|head|tail|grep|egrep|rg|pwd|which|command -v|wc|sort|uniq|find|stat|file|readlink|echo|printf|git\s+(status|log|diff|show|branch|remote|rev-parse|ls-files|fetch|grep)|node\s+-e|python3?\s+-c|uname|whoami|date|env|printenv)\b/;

/** Record one action to the ledger (NDJSON append). An agent calls this before it acts. */
export function record(dir, action) {
  const root = resolve(dir);
  const p = join(root, LEDGER);
  // RISK-TIERED APPROVAL: a read-only action is auto-approved (it cannot change state), so the human's tick
  // is reserved for the write/network/secret actions that actually matter. Explicit, not a rubber stamp.
  if (action.approved === undefined && typeof action.action === "string" && LOW_RISK.test(action.action.trim())) {
    action.approved = true;
  }
  const line = JSON.stringify(action) + "\n";
  appendFileSync(p, line);
  return { path: p, line: JSON.parse(line) };
}

/** Read the ledger back as rows (line number + the action fields), for the panel's tick buttons. */
export function readActions(dir) {
  const p = join(resolve(dir), LEDGER);
  if (!existsSync(p)) return [];
  return readFileSync(p, "utf8").split("\n").filter((l) => l.trim()).map((l, i) => {
    try { return { line: i + 1, ...JSON.parse(l) }; } catch { return { line: i + 1, action: "(invalid JSON)", approved: null }; }
  });
}

/** The human's tick on one line: approve (yes) or reject (no). */
export function tick(dir, line, approve) {
  const p = join(resolve(dir), LEDGER);
  if (!existsSync(p)) return { ok: false, why: "no ledger to tick" };
  const lines = readFileSync(p, "utf8").split("\n").filter((l) => l.trim());
  if (!Number.isInteger(line) || line < 1 || line > lines.length) return { ok: false, why: `no such line ${line}` };
  let a; try { a = JSON.parse(lines[line - 1]); } catch { return { ok: false, why: `line ${line} is not JSON` }; }
  a.approved = approve;
  lines[line - 1] = JSON.stringify(a);
  writeFileSync(p, lines.join("\n") + "\n");
  return { ok: true };
}

/** The hook entry: run the guards and BLOCK (exit 2) when control is broken, so a live agent
 *  cannot proceed while the ledger is red. Exit 0 when under control or when there is no ledger
 *  in this directory (a repo that never recorded actions is not an agent under control — yet). */
export function hookVerdict(dir, command) {
  const r = checkControl(dir);
  if (!existsSync(join(resolve(dir), LEDGER))) return { allow: true, reason: "no ledger here — not our business" };
  if (r.number === 0) return { allow: true, reason: r.summary };
  return { allow: false, reason: r.summary };
}
