// review-gate.mjs — the model judge for VVS rules 33 (understand) + 11 (review behaviour).
//
// A mechanical grep cannot tell "advised without understanding" from "advised correctly", nor a
// removed-rationale diff from a tidy-up. So this judge has TWO modes:
//
//   MOCK (default, no cost): a deterministic heuristic — a reply that references a file not present in
//     the investigation trace is "advising without evidencing understanding". This proves the PIPELINE
//     (hook -> subcommand -> judgment -> block), not the semantic judgment.
//   REAL (REVIEW_GATE=1, metered): sends the reply to the model (aiCall, task "review-judgment"), which
//     does the actual prose judgment. Billed per call; OFF by default.
//
// The honesty is in the return: the detail always says WHICH mode decided, so a mock pass is never
// reported as a model pass.
import { readFileSync } from "node:fs";

const TRACE = "/Users/mac/.dsh/trace/read-trace.log";

export function mockJudge(reply, trace) {
  const refs = [...new Set((String(reply).match(/[A-Za-z0-9_./-]+\.(lean|py|mjs|js|ts|rs|md|sh|json|toml|yaml|yml)/g) || []))];
  const unread = refs.filter((r) => !trace.includes(r));
  if (unread.length) {
    return { ok: false, mode: "mock", detail: `references file(s) not read this session: ${unread.join(", ")} (rule 33/11 — advised without evidencing understanding)` };
  }
  return { ok: true, mode: "mock", detail: "no unread file reference (mock heuristic; model judge not run)" };
}

export async function realJudge(reply, aiCall, opts) {
  const r = await aiCall({ task: "review_judgment", reply }, opts);
  if (!r.ok) return { ok: false, mode: "real", detail: `model call failed: ${r.reason}`, callFailed: true };
  const verdict = r.json?.verdict ?? "pass";
  const detail = r.json?.detail ?? "";
  return { ok: /^pass$/i.test(verdict), mode: "real", detail };
}

/** judgeReply — decide whether a reply passes 33/11. Mock by default; real when REVIEW_GATE=1.
 *  On an infrastructure failure (no token, network, rejected), fall back to the MOCK rather than
 *  block — a broken gate must never read as "everything is a violation". */
export async function judgeReply(reply, { real = false, aiCall = null, opts = {} } = {}) {
  let trace = "";
  try { trace = readFileSync(TRACE, "utf8"); } catch { /* no trace yet */ }
  if (real && aiCall) {
    const r = await realJudge(reply, aiCall, opts);
    if (r.callFailed) return mockJudge(reply, trace);
    return r;
  }
  return mockJudge(reply, trace);
}
