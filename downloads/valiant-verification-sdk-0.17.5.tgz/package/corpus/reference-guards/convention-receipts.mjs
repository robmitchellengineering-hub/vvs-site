#!/usr/bin/env node
// Reference guard — invariants 5, 6, 16: sync/verify receipts + named machines.
//
// Rule 5: "sync against the live source of truth" — the declared sync-receipt must record a commit hash
// (the remote HEAD it synced against) and a timestamp, so "synced" is evidenced, not assumed.
// Rule 6: "verify before depending" — the declared verify-receipt must record a request/response.
// Rule 16: "name the machines" — each declared machines module must name a target architecture.
// A declared file that is missing or un-evidenced is a fail; an undeclared convention is named as
// unchecked (never a silent pass).
import { readFileSync, existsSync } from "node:fs";
import { join, resolve } from "node:path";
import { readConventions, CONVENTIONS, unenforced } from "../../src/conventions.mjs";

const root = resolve(process.argv[2] || ".");
const cfgPath = join(root, "valiant.json");
if (!existsSync(cfgPath)) { console.log("  ok   no valiant.json: nothing is adopted here"); process.exit(0); }
const cfg = JSON.parse(readFileSync(cfgPath, "utf8"));
const { declared, problems } = readConventions(cfg, root);
const KEYS = ["sync-receipt", "verify-receipt", "machines"];
const mine = problems.filter((p) => KEYS.includes(p.key));
if (mine.length) { console.error(`  ${mine.map((m) => m.why).join("; ")}`); process.exit(1); }

const bad = [];
if (declared["sync-receipt"] === undefined) {
  console.log("  " + unenforced(CONVENTIONS.find((c) => c.key === "sync-receipt")));
} else {
  const f = join(root, declared["sync-receipt"]);
  if (!existsSync(f)) bad.push(`sync-receipt: ${declared["sync-receipt"]} declared but missing`);
  else {
    const src = readFileSync(f, "utf8");
    if (!/[0-9a-f]{7,40}/.test(src)) bad.push(`sync-receipt: no commit hash (the remote HEAD it synced against)`);
    if (!/(\d{4}-\d{2}-\d{2}|timestamp|ISO|Z\b)/i.test(src)) bad.push(`sync-receipt: no timestamp`);
  }
}
if (declared["verify-receipt"] === undefined) {
  console.log("  " + unenforced(CONVENTIONS.find((c) => c.key === "verify-receipt")));
} else {
  const f = join(root, declared["verify-receipt"]);
  if (!existsSync(f)) bad.push(`verify-receipt: ${declared["verify-receipt"]} declared but missing`);
  else {
    const src = readFileSync(f, "utf8");
    if (!/(request|response|GET |POST |status|HTTP|200|body)/i.test(src)) bad.push(`verify-receipt: no request/response recorded`);
  }
}
if (declared["machines"] === undefined) {
  console.log("  " + unenforced(CONVENTIONS.find((c) => c.key === "machines")));
} else {
  for (const rel of declared["machines"]) {
    const f = join(root, rel);
    if (!existsSync(f)) { bad.push(`machines: ${rel} declared but missing`); continue; }
    const src = readFileSync(f, "utf8");
    if (!/(aarch64|x86_64|amd64|arm64|darwin|linux|windows)/i.test(src)) bad.push(`machines: ${rel} does not name a target architecture`);
  }
}
if (bad.length) { console.error("  receipt/declaration problems:"); for (const b of bad) console.error(`    ${b}`); process.exit(1); }
console.log("  ok   sync/verify receipts + machines are evidenced where declared");
process.exit(0);
