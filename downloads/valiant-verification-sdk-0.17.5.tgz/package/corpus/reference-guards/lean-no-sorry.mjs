#!/usr/bin/env node
// Reference guard — invariant 48: "a formal proof is never a placeholder."
// Refuses the three things a half-finished Lean proof hides behind: `sorry`, `admit`, and an `axiom` where a
// theorem was claimed (the `_find_once` fact VVS says it proves by reflection). `opaque rejects_sabotage` is the
// ONE allowed assumption — it is the honest black-box conformance, named as observed-not-proved, not a hole.
// Usage: node lean-no-sorry.mjs [dir]   (exit 0 = clean, 1 = a placeholder exists)
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, resolve } from "node:path";

const root = resolve(process.argv[2] || ".");
const SKIP = new Set(["node_modules", ".git", ".lake", "dist", "build"]);

const problems = [];
function walk(dir) {
  let entries = [];
  try { entries = readdirSync(dir); } catch { return; }
  for (const name of entries) {
    if (SKIP.has(name)) continue;
    const p = join(dir, name);
    let st; try { st = statSync(p); } catch { continue; }
    if (st.isDirectory()) { walk(p); continue; }
    if (!name.endsWith(".lean")) continue;
    const text = readFileSync(p, "utf8");
    const lines = text.split("\n");
    lines.forEach((line, i) => {
      const t = line.trim();
      if (/\bsorry\b/.test(t)) problems.push(`${p}:${i + 1}: \`sorry\` — an unfinished proof left as a placeholder`);
      if (/\badmit\b/.test(t)) problems.push(`${p}:${i + 1}: \`admit\` — an unproved statement admitted`);
      // A `_find_once` axiom is a placeholder only when it is CLAIMED to be reflected (its own doc says
      // "reflected"/"native_decide"/"proved by") yet declared an axiom — the green lie. An honestly-marked
      // axiom ("computed by the JS structural kernel, not claimed as a reflected proof") is the documented fallback.
      if (/^axiom\b.*_find_once/.test(t) && /reflection|native_decide|reflected|proved by/.test(t)) problems.push(`${p}:${i + 1}: \`axiom …_find_once\` claimed as a reflected proof but declared an assumption`);
    });
  }
}
walk(root);

if (problems.length) {
  console.error("formal proofs that are placeholders:\n  " + problems.join("\n  "));
  process.exit(1);
}
console.log(`no sorry/admit/find_once-axiom in ${problems.length === 0 ? "the Lean proofs" : ""}`);

// --self-test: the fault, seeded.

// --self-test: the fault, seeded. (dynamic import — this is an ES module, not CommonJS)
if (process.argv[2] === "--self-test") {
  const { mkdtempSync, writeFileSync, rmSync } = await import("node:fs");
  const { join } = await import("node:path");
  const { tmpdir } = await import("node:os");
  const { spawnSync } = await import("node:child_process");
  let fail = 0;
  const good = mkdtempSync(join(tmpdir(), "lns-")); writeFileSync(join(good, "clean.lean"), "theorem t : True := by trivial\n");
  if (spawnSync(process.execPath, [process.argv[1], good]).status !== 0) { console.error("FAIL: a clean proof must pass"); fail++; }
  const bad = mkdtempSync(join(tmpdir(), "lns-")); writeFileSync(join(bad, "bad.lean"), "theorem t : True := by sorry\n");
  if (spawnSync(process.execPath, [process.argv[1], bad]).status !== 1) { console.error("FAIL: a sorry must be refused"); fail++; }
  const ax = mkdtempSync(join(tmpdir(), "lns-")); writeFileSync(join(ax, "ax.lean"), "axiom guard_x_find_once : True\n");
  if (spawnSync(process.execPath, [process.argv[1], ax]).status !== 1) { console.error("FAIL: a find_once axiom must be refused"); fail++; }
  rmSync(good, { recursive: true, force: true }); rmSync(bad, { recursive: true, force: true }); rmSync(ax, { recursive: true, force: true });
  console.log(`lean-no-sorry: ${fail === 0 ? "PASS" : "FAIL"} self-test`);
  process.exit(fail ? 1 : 0);
}
