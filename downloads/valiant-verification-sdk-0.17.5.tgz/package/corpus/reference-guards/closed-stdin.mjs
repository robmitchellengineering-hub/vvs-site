#!/usr/bin/env node
// Reference guard — invariant 20: "close stdin on spawned subprocesses."
// Flags spawn/exec calls that re-inherit stdin, so a child that prompts hangs the loop instead of EOF.
// Usage: node closed-stdin.mjs [dir]   (exit 0 = clean, 1 = inherited stdin found)
import { readFileSync, readdirSync, statSync, writeFileSync, mkdtempSync, rmSync } from "node:fs";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";

const SKIP = new Set(['node_modules', '.git', 'dist', 'build', '.vv']);
// A TEST THAT ASSERTS THIS RULE MUST CONTAIN THE FAULT, and so must the guard's own source. Without these exemptions the guard
// convicts its own fixture — the same self-reference that made `no-swallowed-build` cry wolf.
const SKIP_PATHS = [/reference-guards[\\/]/, /selftest-|\.test\.|__fixtures__/, /\.md$/];
const LOOK = ['.mjs', '.js', '.cjs', '.ts'];

function scan(root) {
  const problems = [];
  function walk(dir) {
    for (const name of readdirSync(dir)) {
      if (SKIP.has(name)) continue;
      const p = join(dir, name);
      if (SKIP_PATHS.some((re) => re.test(p))) continue;
      const s = statSync(p);
      if (s.isDirectory()) { walk(p); continue; }
      if (!LOOK.some((e) => name.endsWith(e))) continue;
      const text = readFileSync(p, 'utf8');
      const lines = text.split('\n');
      lines.forEach((line, i) => {
        if (/stdio:\s*['"]inherit['"]|stdio:\s*\[\s*['"]inherit['"]/.test(line)) {
          problems.push(`${p}:${i + 1}: ${line.trim()}`);
        }
      });
    }
  }
  walk(root);
  return problems;
}

if (process.argv[2] === "--self-test") {
  // The fault, seeded: a fixture with `stdio: inherit`, which the guard must catch (exit 1).
  let fail = 0;
  const d = mkdtempSync(join(tmpdir(), "csi-"));
  try {
    writeFileSync(join(d, "clean.mjs"), "spawnSync('x', [], { stdio: 'pipe' });\n");
    if (scan(d).length !== 0) { console.error("FAIL: a clean fixture must pass"); fail++; }
    const bad = mkdtempSync(join(tmpdir(), "csi-"));
    writeFileSync(join(bad, "bad.mjs"), "spawnSync('x', [], { stdio: 'inherit' });\n");
    if (scan(bad).length === 0) { console.error("FAIL: an inherited-stdin fixture must be caught"); fail++; }
    rmSync(bad, { recursive: true, force: true });
  } finally {
    rmSync(d, { recursive: true, force: true });
  }
  console.log(`closed-stdin: ${fail === 0 ? "PASS" : "FAIL"} self-test`);
  process.exit(fail ? 1 : 0);
}

const root = resolve(process.argv[2] || '.');
const problems = scan(root);
if (problems.length) {
  console.error('spawns that inherit stdin:\n  ' + problems.join('\n  '));
  process.exit(1);
}
console.log('no subprocess inherits stdin');
