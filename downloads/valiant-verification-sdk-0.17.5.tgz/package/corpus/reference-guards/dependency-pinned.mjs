#!/usr/bin/env node
// dependency-pinned.mjs — reference guard (supply chain).
//
// Slopsquatting (a hallucinated or typosquatted package name) is a top agentic-coding risk, and an
// unpinned version range (`^1.2.3`) means today's build is not yesterday's. This guard requires, for
// every declared dependency: an exact pinned version in package.json AND a lockfile that records the
// resolved tree. It does not call the registry (offline); a name that is pinned locally still needs a
// human/registry check, but a name that is NOT pinned fails here.
//
// Convention: a repo with package.json. Exit 0 = every dependency pinned + a lockfile exists · 1 = not.
import { readFileSync, existsSync } from "node:fs";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

const LOCKFILES = ["package-lock.json", "yarn.lock", "pnpm-lock.yaml", "npm-shrinkwrap.json"];
const RANGE = /[\^\~*x]|\b(gte|lte|gt|lt|latest|next)\b/;

export function check(dir) {
  const root = resolve(dir);
  const pkgPath = join(root, "package.json");
  if (!existsSync(pkgPath)) return { ok: true, detail: "no package.json — nothing to pin" };
  let pkg;
  try { pkg = JSON.parse(readFileSync(pkgPath, "utf8")); } catch { return { ok: false, detail: "package.json is not valid JSON" }; }
  const deps = { ...(pkg.dependencies ?? {}), ...(pkg.devDependencies ?? {}) };
  const names = Object.keys(deps);
  if (names.length === 0) return { ok: true, detail: "no dependencies declared" };
  const unpinned = names.filter((n) => RANGE.test(String(deps[n])));
  const lock = LOCKFILES.find((f) => existsSync(join(root, f)));
  const bad = [];
  if (!lock) bad.push("no lockfile (package-lock.json / yarn.lock / pnpm-lock.yaml) — the resolved tree is not recorded");
  if (unpinned.length) bad.push(`unpinned version(s): ${unpinned.map((n) => `${n}@${deps[n]}`).join(", ")}`);
  return { ok: bad.length === 0, detail: bad.length ? bad.join(" · ") : `${names.length} dependenc(ies) pinned + ${lock}` };
}

const IS_MAIN = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;
if (IS_MAIN) {
  if (process.argv.includes("--self-test")) {
    const { mkdtempSync, writeFileSync, rmSync } = await import("node:fs");
    const { tmpdir } = await import("node:os");
    let fail = 0;
    const good = mkdtempSync(join(tmpdir(), "dpn-")); writeFileSync(join(good, "package.json"), '{"dependencies":{"left-pad":"1.3.0"}}'); writeFileSync(join(good, "package-lock.json"), '{}');
    if (!check(good).ok) { console.error("FAIL: an exact-pinned dep with a lockfile should pass"); fail++; }
    const bad = mkdtempSync(join(tmpdir(), "dpn-")); writeFileSync(join(bad, "package.json"), '{"dependencies":{"left-pad":"^1.3.0"}}');
    if (check(bad).ok) { console.error("FAIL: a range dep without a lockfile must go red"); fail++; }
    rmSync(good, { recursive: true, force: true }); rmSync(bad, { recursive: true, force: true });
    console.log(`dependency-pinned: ${fail === 0 ? "PASS" : "FAIL"} self-test`);
    process.exit(fail ? 1 : 0);
  }
  const r = check(process.argv[2] || ".");
  if (r.ok) process.exit(0);
  console.error(`dependency-pinned: ${r.detail}`);
  process.exit(1);
}
