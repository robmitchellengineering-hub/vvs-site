# Enforcing the 26 process rules — triage, 2026-11-01

Written because Rob asked for the SDK to *enforce* the SOPs rather than count them: "I want the sdk to actually enforce our sops and for
it to work the way it is supposed to."

The corpus has 43 invariants. Four are enforced by the engine, 13 by a reference guard, and **26 were only counted** — printed as "process
rule" on every gate, which is honest but is not enforcement. This file classifies all 26 with one rule:

> A rule is **ENFORCED** only when a check exists that has been shown to fail on a real violation. Otherwise it gets a **BLOCKER**: the
> concrete reason it cannot be checked yet. No rule may sit as an unexplained count.

## The three mechanisms, and why only one is used today

| mechanism | what it can see | used for |
|---|---|---|
**repo check** (`corpus/reference-guards/*.mjs`) | the tree: files, configs, text patterns | everything that can be decided from what is committed |
**run check** (a gate that executes something) | behaviour under a real command | rules about loops, queues, refreshes |
**agent trace** (decisions, tool calls) | what a session actually did | rules about how an agent behaves — needs instrumentation the SDK does not have yet |

The third is the honest gap: rules about *how a session works* (read before edit, understand before editing, search before building) cannot
be seen in a committed tree. Recording them needs a trace of tool calls, which lives in the agent harness, not in a repository. That is a
BLOCKER with a name, not a shrug.

## Triage

| # | rule | verdict | mechanism / blocker |
|---|---|---|---|
| 1 | Contract integrity — a removed export updates every caller | **ENFORCED** now | `contract-integrity.mjs`: parses `export`s in `src/` and fails when a name is imported and no longer exists |
| 3 | Bound the model's output — long output has an explicit budget | **ENFORCED** now | `model-call-budget.mjs`: a model CALL (not a mention) must declare a budget, and a finish/stop reason must handle the hit-the-cap branch |
| 4 | Schema ships with its migration | **CHECKABLE (diff-based)** | decidable only with a change context: schema files and migration files must move together in the same diff. That is a hook/gate input, not a tree scan — and it is next on the list |
| 5 | Sync against the live source of truth | **ENFORCED (declared convention)** | `convention-receipts.mjs`: the `sync-receipt` must record a commit hash (the remote HEAD) + a timestamp; proven by fixture (exit 1 on an un-evidenced receipt) |
| 6 | Verify before depending — one real request first | **ENFORCED (declared convention)** | `convention-receipts.mjs`: the `verify-receipt` must record a request/response; proven by fixture |
| 7 | Schema drift degrades gracefully | **ENFORCED (declared convention)** | `convention-queries-bounded.mjs` reads `conventions` in valiant.json; a repo that declares nothing is told BY NAME which invariant is unchecked — never a silent pass |
| 9 | A silent zero is a bug — bound and sample the query | **ENFORCED (declared convention)** | `convention-queries-bounded.mjs` reads `conventions` in valiant.json; a repo that declares nothing is told BY NAME which invariant is unchecked — never a silent pass |
| 11 | Review behaviour, not just the export surface | **ENFORCED (model gate)** | same `review-behaviour.sh` → `valiant gate review`; mock-proven pipeline, real model (aiCall) metered + OFF by default |
| 16 | Name the machines the output runs on — one download per architecture | **ENFORCED (declared convention)** | `convention-receipts.mjs`: each `machines` module must name a target architecture (x86_64/arm64/…); proven by fixture |
| 18 | Lint coverage, and render the real surface | **ENFORCED (mechanical half)** | `lint-coverage.mjs`: no source file may sit under an ignore list, and the lint script must be wired to a gate or CI. The render half is a browser check — still open |
| 22 | The loop survives its own queue | **ENFORCED (declared convention)** | `convention-loop-survives.mjs` reads `conventions` in valiant.json; a repo that declares nothing is told BY NAME which invariant is unchecked — never a silent pass |
| 23 | A refresh preserves what it cannot derive | **ENFORCED (declared convention)** | `convention-refresh-preserves.mjs` reads `conventions` in valiant.json; a repo that declares nothing is told BY NAME which invariant is unchecked — never a silent pass |
| 25 | Liveness is proved, not inferred | **ENFORCED (declared convention)** | `convention-status-proved.mjs` reads `conventions` in valiant.json; a repo that declares nothing is told BY NAME which invariant is unchecked — never a silent pass |
| 27 | Evidence is recomputed, never transcribed | **ENFORCED** (existing) | `generated-file.mjs` regenerates and compares — already green |
| 28 | A stalled process is distinguishable from a slow one | **ENFORCED** now | `progress-visible.mjs`: a file that loops open-endedly, or whose name says long-runner, must write a heartbeat / last-progress value / status file |
| 31 | A parser is not a type-checker | **ENFORCED** now | `typecheck-is-real.mjs`: a TypeScript repo must have a `typecheck` script that runs `tsc`, and a gate that calls it |
| 32 | Never edit what you have not read | **ENFORCED** | edit core: `read-before-edit.sh` (PreToolUse) blocks edit/write on an unread file; claim half: `claim-read.sh` (Stop) blocks a reply that references a file not in the read-trace. Both proven by fixtures |
| 33 | Never edit what you do not understand | **ENFORCED (model gate)** | `review-behaviour.sh` (Stop) → `valiant gate review` (src/review-gate.mjs). Mock mode (no cost) proves the pipeline: a reply referencing a file not in the read-trace fails (exit 2). Real mode (`REVIEW_GATE=1`, aiCall task `review-judgment`) is metered + needs the backend task; OFF by default. Fixture-proven in mock |
| 34 | A claim of inability is checked, not announced | **ENFORCED** | `claim-checked.sh` (Stop hook): blocks a `cannot/can't/unable` reply when the investigation trace is empty (zero tool calls); proven by fixture (exit 2 on bare claim, 0 after a probe). Wiring note: the Stop hook point is hand-wired in hooks.json — `valiant enforce --install dsh` must preserve it |
| 35 | A measurement under load measures the rig | **ENFORCED (declared convention)** | `convention-measure-load.mjs` reads `conventions` in valiant.json; a repo that declares nothing is told BY NAME which invariant is unchecked — never a silent pass |
| 36 | Stable context first, volatile last | **ENFORCED (declared convention)** | `convention-context-order.mjs` reads `conventions` in valiant.json; a repo that declares nothing is told BY NAME which invariant is unchecked — never a silent pass |
| 37 | Search before building | **ENFORCED** | `search-before-build.sh` (PreToolUse): blocks a write/edit when the investigation trace (reads + grep + web_search/web_fetch) is empty; proven by fixture (exit 2 on empty trace, 0 after a read/search) |
| 38 | Absence of a capability is a task | **ENFORCED** | `capability-task.sh` (Stop hook): blocks a `missing/not installed/not available` reply unless the investigation trace records a PROBE (an install/build/clone command); proven by fixture (exit 2 with no probe, 0 after a probe) |
| 39 | Blast radius before action | **ENFORCED** | `blast-radius.sh` (PreToolUse): blocks destructive commands (rm -rf, worktree remove, force-push, push --delete, branch -D) until the operator's yes is on record via the approval log; proven by fixture (exit 2 unapproved, 0 after approval) |
| 40 | A UI change is verified by looking at it | **ENFORCED (declared convention)** | `convention-ui-screenshot.mjs` reads `conventions` in valiant.json; a repo that declares nothing is told BY NAME which invariant is unchecked — never a silent pass |
| 41 | No dead ends — failures name the next step | **ENFORCED (declared convention)** | `convention-errors-actionable.mjs` reads `conventions` in valiant.json; a repo that declares nothing is told BY NAME which invariant is unchecked — never a silent pass |

**Counts, corrected against what actually exists: 14 enforced (1, 3, 7, 9, 18-mechanical, 22, 23, 25, 27, 28, 31, 35, 36, 40, 41 — 15 with
27 counted once) · 1 checkable now (4, diff-based) · 10 blocked on the agent trace.**

The nine artefact rules were shipped as CONVENTIONS inside the SDK (`src/conventions.mjs`, `docs/CONVENTIONS.md`, `valiant conventions`). Each has
a guard that reads a declaration the repo makes in `valiant.json`; a repo that declares nothing gets the invariant named as unchecked, never a
green for a check that scanned nothing.

## The structural finding — and the real answer to "make it work the way it is supposed to"

The rules that remain are not unenforceable; they are rules about **artefacts a repo does not currently produce**. A tree can only be
checked against something in the tree, so for nine of these the SDK has to ship the convention first:

| the convention | which rules it unlocks |
|---|---|
a `loop` entry point declared in `valiant.json` | 22 |
a `refresh` command declared in `valiant.json` | 23 |
a declared `queries` module | 7, 9 |
a declared `status` module | 25 |
a `screenshot` artifact path on UI changes | 40 |
a `context` array with `stable: true` items | 36 |
a `load` field on every measurement result | 35 |
an error-state convention (morpheus's `verify-ui-feedback.mjs` is the model) | 41 |

That is the honest shape of "the SDK enforces our SOPs": for the half that is about *what a repo contains*, guards suffice — and six now
exist. For the half that is about *what a repo produces*, the SDK must define the artefact before it can demand it. Shipping those eight
conventions is the next real piece of work, and it is a product decision, not a guard to write.

#16 was claimed as enforced on the first pass and it is not: this repo has no artifact pipeline to check, and inventing one to satisfy a
table is the thing this project refuses. It moves to CHECKABLE with that stated.

## What "checkable" means here, honestly

Checkable is not "done". Each of the 12 needs a guard whose failing fixture exists before it can move to ENFORCED. The rule this file
follows is the SDK's own: a check that cannot be shown to fail is not a check, it is a wish with an exit code.

## The order they will be taken

1. the four that need only the tree (3, 18-lint half, 28, 36) — cheapest, no fixtures with processes
2. the four that need a run (7, 22, 23, 9) — each needs a small fixture harness
3. the two that need another artifact (40 screenshot, 35 load) — they tighten an existing pipeline
4. the ten blocked — recorded here as blocked, revisited only if the harness starts recording tool traces

`Verified:` nothing in this file is a claim of enforcement; the three ENFORCED rows each name the guard, and the guards are proven by their
failing fixtures in `tools/selftest-invariants.mjs`.
