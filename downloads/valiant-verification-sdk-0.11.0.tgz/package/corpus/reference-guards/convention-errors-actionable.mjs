#!/usr/bin/env node
// Reference guard — invariant 41: "no dead ends".
//
// An error with nothing to press is a defect, not a message. Every failure and empty state must name the next step and offer it as an action.
//
// WHAT THIS CHECKS. In the directories declared as `conventions.errors`, every JSX/TSX/Vue/Svelte element that renders an error or empty state
// (a class or text containing "error", "failed", "empty", "no results") must contain a link, a button, or a handler — an action, not just words.
//
// WHAT IT DOES NOT DO. It does not decide whether the action is the RIGHT one; it refuses a dead end, which is the failure people hit most.
import { readFileSync, existsSync, readdirSync, statSync } from "node:fs";
import { join, resolve, relative } from "node:path";
import { readConventions, CONVENTIONS, unenforced } from "../../src/conventions.mjs";

const root = resolve(process.argv[2] || ".");
const cfgPath = join(root, "valiant.json");
if (!existsSync(cfgPath)) { console.log("  ok   no valiant.json: nothing is adopted here"); process.exit(0); }
const cfg = JSON.parse(readFileSync(cfgPath, "utf8"));
const c = CONVENTIONS.find((x) => x.key === "errors");
const { declared, problems } = readConventions(cfg, root);
const mine = problems.filter((p) => p.key === "errors");
if (mine.length) { console.error(`  ${mine.map((m) => m.why).join("; ")}`); process.exit(1); }
if (declared.errors === undefined) { console.log("  " + unenforced(c)); process.exit(0); }

const EXT = /\.(jsx|tsx|vue|svelte)$/i;
const files = [];
const walk = (dir) => {
  let entries = []; try { entries = readdirSync(dir); } catch { return; }
  for (const e of entries) {
    if (e === "node_modules" || e === ".git") continue;
    const p = join(dir, e); let s = null; try { s = statSync(p); } catch { continue; }
    if (s.isDirectory()) walk(p); else if (EXT.test(e)) files.push(p);
  }
};
for (const d of declared.errors) walk(join(root, d));

const DEAD = /(class(Name)?\s*=\s*["'{][^"'}]*\b(error|empty|no-results|failed)\b[^"'}]*["'}]|>\s*(No results?|Nothing (here|yet)|Error|Failed)\b)/i;
const ACTION = /(<(a|Link|button|Button|NavLink)\b[^>]*href|onClick\s*=|to\s*=\s*["'{]|onPress\s*=)/;
const bad = [];
for (const f of files) {
  const src = readFileSync(f, "utf8");
  // Scan element-sized chunks: a dead-end is a block that renders an error/empty state and offers nothing.
  const chunks = src.split(/<\/?(?:div|section|main|li|ul|td|tr|p)\b[^>]*>/i);
  for (const chunk of chunks) {
    if (!DEAD.test(chunk)) continue;
    if (ACTION.test(chunk)) continue;
    bad.push(`${relative(root, f)}: renders an error/empty state with no action — ${chunk.replace(/\s+/g, " ").trim().slice(0, 90)}`);
    break;
  }
}
if (bad.length) {
  console.error("  dead ends (a failure the reader cannot act on):");
  for (const b of bad.slice(0, 10)) console.error(`    ${b}`);
  process.exit(1);
}
console.log(`  ok   ${files.length} UI file(s) checked; every error/empty state offers an action`);
process.exit(0);
