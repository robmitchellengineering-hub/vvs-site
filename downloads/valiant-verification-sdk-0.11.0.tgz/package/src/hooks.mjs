// hooks.mjs — put the gate in front of `git push`, and record the decision so a dead hook is caught.
//
// The hole this closes: `valiant gate` was a command nobody was required to run. The SDK repo has no CI (U-07 forbids
// GitHub-hosted minutes and no self-hosted runner exists), so between the work and `main` there was nothing — a PR was
// merged while the gate read "a contract is broken" (V-16, harness-mesh/SOP-VIOLATIONS.md).
//
// The receipts mechanism already existed (`valiant decisions`, hash-chained, UNEXERCISED). It had no hook to record from,
// so it could never fire. This installs the hook AND declares it, because a declared hook that stops firing is caught by
// the UNEXERCISED check — which is the difference between a hook and a hope.
import { readFileSync, writeFileSync, existsSync, mkdirSync, chmodSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";

export const MARKER = "# installed by valiant hooks --install";

/** Where a repo's hooks live, honouring a worktree (the hook must run in the tree it guards, not the shared clone). */
function hooksDir(repoRoot) {
  // A HOOK RUNNING US INHERITS GIT_DIR, GIT_WORK_TREE AND FRIENDS. With them set, `git rev-parse --git-path hooks` answers
  // for the OUTER repository — so `valiant hooks --install` could write into someone else's repo. Strip them and let cwd
  // decide, which is the only thing the caller actually chose.
  const env = { ...process.env };
  for (const k of ["GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_COMMON_DIR", "GIT_PREFIX", "GIT_OBJECT_DIRECTORY"]) delete env[k];
  const r = spawnSync("git", ["rev-parse", "--git-path", "hooks"], { cwd: repoRoot, encoding: "utf8", env });
  if (r.status !== 0) return null;
  const p = (r.stdout ?? "").trim();
  return p ? (p.startsWith("/") ? p : join(repoRoot, p)) : null;
}

/**
 * The pre-push body.
 *
 * FAST BY DEFAULT. A pre-push hook that costs minutes is a hook that gets `--no-verify`'d and then ignored, which is
 * worse than no hook — so this runs `verify` (under a second on a small repo, measured) and blocks on any non-zero.
 * `VALIANT_HOOK_MODE=gate` runs the whole thing, proof included, for anyone who wants that on every push.
 */
function prePushBody(cliPath) {
  const node = process.execPath;
  // A HOOK THAT POINTS AT A MOVED CHECKOUT BLOCKS EVERY PUSH WITH `MODULE_NOT_FOUND`, and says nothing about why. This bit me for
  // real: the SDK was installed from a worktree that was later removed, and every push failed with a stack trace. The hook now
  // prefers `valiant` on PATH (which survives a checkout moving), falls back to the path recorded at install time, and if neither
  // exists it says exactly that — exit 2, "could not check", which blocks and explains rather than blocking and confusing.
  return `#!/bin/sh
${MARKER} — remove this line and the hook stops being managed by valiant
#
# Exit 0 only when every contract holds. 1 = a contract is broken, 2 = a contract could not be checked.
# Both block the push: "we could not look" is not a pass. Bypass with \`git push --no-verify\`, which leaves no record —
# deliberately visible rather than convenient.
#
# THE RECORDED PATH COMES FIRST. Preferring PATH would let a stale \`valiant\` installed months ago silently run instead of the
# checkout this hook belongs to — a check that runs a different version is worse than one that refuses. PATH is the fallback for
# when the checkout has moved; both failing is explained.
VALIANT_BIN=""
if [ -f "${cliPath}" ]; then VALIANT_BIN="${node} ${cliPath}"
elif command -v valiant >/dev/null 2>&1; then VALIANT_BIN="$(command -v valiant)"
fi
if [ -z "$VALIANT_BIN" ]; then
  echo ""
  echo "valiant: the hook cannot find the CLI — neither \`valiant\` on PATH nor ${cliPath}"
  echo "  the checkout it was installed from has moved or been removed."
  echo "  fix: run \`valiant hooks --install\` from the SDK checkout you actually use."
  echo "  (exit 2 = could not check, which is not a pass)"
  exit 2
fi
if [ "\${VALIANT_HOOK_MODE:-verify}" = "gate" ]; then
  $VALIANT_BIN gate
else
  $VALIANT_BIN verify
fi
code=$?
if [ "$code" -eq 0 ]; then
  $VALIANT_BIN decisions --record --hook pre-push:gate --verdict allow --reason "\${VALIANT_HOOK_MODE:-verify} held" >/dev/null 2>&1
else
  $VALIANT_BIN decisions --record --hook pre-push:gate --verdict deny --reason "\${VALIANT_HOOK_MODE:-verify} exit $code" >/dev/null 2>&1
  echo ""
  echo "valiant: the check did not hold (exit $code) — the push is blocked."
  echo "  1 = a contract is broken · 2 = a contract could not be checked"
  echo "  this was: valiant \${VALIANT_HOOK_MODE:-verify}   (VALIANT_HOOK_MODE=gate runs the full proof)"
  exit 1
fi
`;
}

export function install(repoRoot, cliPath) {
  const dir = hooksDir(repoRoot);
  if (!dir) return { ok: false, why: "this is not a git repository, so there is nothing to hook" };
  const file = join(dir, "pre-push");
  let existing = null;
  try { existing = readFileSync(file, "utf8"); } catch { existing = null; }

  if (existing && !existing.includes(MARKER)) {
    return { ok: false, why: `${file} already exists and was not written by valiant — left alone (merge it by hand)` };
  }
  const already = existing !== null;
  try {
    mkdirSync(dir, { recursive: true });
    writeFileSync(file, prePushBody(cliPath));
    chmodSync(file, 0o755);
  } catch (e) {
    return { ok: false, why: `could not write ${file}: ${e.message}` };
  }
  return { ok: true, file, already };
}

export function status(repoRoot) {
  const dir = hooksDir(repoRoot);
  if (!dir) return { ok: false, installed: false, why: "not a git repository" };
  const file = join(dir, "pre-push");
  if (!existsSync(file)) return { ok: true, installed: false, file, why: "no pre-push hook — nothing runs the gate before a push" };
  let body = "";
  try { body = readFileSync(file, "utf8"); } catch { /* unreadable */ }
  const ours = body.includes(MARKER);
  return { ok: ours, installed: true, file, ours, why: ours ? "valiant's pre-push hook is installed" : "a pre-push hook exists but valiant did not write it" };
}

/**
 * EVERY HOOK THIS REPO RELIES ON, and whether each one would actually run.
 *
 * WHY THIS EXISTS. `hooks --install` writes a pre-push hook and the agent hooks; nothing ever checked them again. A hook file that points at a
 * checkout that has moved, or an agent hook removed by an editor, leaves a repo that LOOKS enforced and blocks nothing — and the only thing that
 * noticed was a bespoke gate in one repo (harness-mesh), which is exactly the duplication the SDK should remove.
 *
 * Reported, not assumed: a hook is "live" only if its file exists AND the command it names resolves. The agent hooks are read from the files the
 * agents themselves read (`.claude/settings.json`, `~/.dsh/hooks/hooks.json`), because a hook that is not in those files is not installed.
 */
export function allHooks(repoRoot) {
  const out = [];
  const pre = status(repoRoot);
  if (pre.installed) {
    let live = true;
    let why = pre.ours ? "valiant's pre-push hook is installed" : "a pre-push hook exists but valiant did not write it";
    try {
      const body = readFileSync(pre.file, "utf8");
      // THE RECORDED PATH IS INLINE, in `[ -f "${cliPath}" ]` — not a variable of its own. Reading it wrong made a hook pointing at a deleted
      // checkout report LIVE (measured 2026-11-01): the check was looking for a name the template never writes.
      const m = /\[ -f "([^"]+\.mjs)" \]/.exec(body);
      if (m && !existsSync(m[1])) {
        const onPath = spawnSync("sh", ["-c", "command -v valiant"], { encoding: "utf8" }).stdout?.trim();
        if (!onPath) { live = false; why = `the pre-push hook points at ${m[1]}, which no longer exists, and valiant is not on PATH — every push would fail with a module error`; }
      }
    } catch { live = false; why = "the pre-push hook is unreadable"; }
    out.push({ name: "pre-push", kind: "git", installed: true, live, file: pre.file, why });
  } else {
    out.push({ name: "pre-push", kind: "git", installed: false, live: false, file: pre.file, why: pre.why });
  }

  // the agent hooks: Claude's Stop hook, and DSH's PreToolUse entry
  const claude = join(repoRoot, ".claude", "settings.json");
  if (existsSync(claude)) {
    let live = false;
    let why = "the Claude hook file exists but names no valiant command";
    try {
      const s = JSON.parse(readFileSync(claude, "utf8"));
      const cmds = Object.values(s.hooks ?? {}).flat().flatMap((e) => e.hooks ?? []).map((h) => String(h.command ?? ""));
      const ours = cmds.find((c) => c.includes("valiant"));
      if (ours) {
        const at = /\/[^\s"']*valiant[^\s"']*\.mjs/.exec(ours);
        live = !at || existsSync(at[0]);
        why = live ? "the Claude Stop hook runs valiant" : `the Claude hook points at ${at?.[0]}, which does not exist`;
      }
    } catch (e) { why = `the Claude hook file could not be read (${e.message})`; }
    out.push({ name: "claude", kind: "agent", installed: true, live, file: claude, why });
  }
  const dsh = join(process.env.HOME ?? "", ".dsh", "hooks", "hooks.json");
  if (existsSync(dsh)) {
    let live = false;
    let why = "the DSH hook file exists but names no valiant command";
    try {
      const s = JSON.parse(readFileSync(dsh, "utf8"));
      const cmds = (s.hooks?.PreToolUse ?? []).flatMap((e) => e.hooks ?? []).map((h) => String(h.command ?? ""));
      const ours = cmds.find((c) => c.includes("valiant"));
      if (ours) {
        const at = /\/[^\s"']*valiant[^\s"']*\.mjs/.exec(ours);
        live = !at || existsSync(at[0]);
        why = live ? "the DSH PreToolUse hook runs valiant" : `the DSH hook points at ${at?.[0]}, which does not exist`;
      }
    } catch (e) { why = `the DSH hook file could not be read (${e.message})`; }
    out.push({ name: "dsh", kind: "agent", installed: true, live, file: dsh, why });
  }
  return out;
}
