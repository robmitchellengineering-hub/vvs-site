// gateproof.mjs — a gate must be shown to FAIL, the same way a guard is.
//
// THE GAP THIS CLOSES. Every guard is proved by mutation: sabotage the thing it protects, and the guard must go red. A gate — the command that
// actually decides a verdict — was trusted on its own output. `{"name":"theatre","cmd":["node","-e","console.log('24 checks passed')"]}` passed
// the gate, printing evidence of checks that do not exist (measured 2026-11-01). The SDK already refuses a gate that exits 0 with NO output
// ("suspect: a pass must produce evidence"); it cannot tell a real check from a convincing sentence.
//
// THE SHAPE. A gate may declare what it protects and how to break it, exactly like a guard:
//
//   { "name": "schemas", "cmd": ["node", "scripts/check-schema.mjs"],
//     "subject": "prisma/schema.prisma",
//     "sabotage": { "find": "model User {", "replace": "model UserBroken {" } }
//
// `valiant mutate` applies the sabotage, runs the gate, and requires the gate to go non-zero. A gate that still passes has proved nothing.
//
// WHAT IT DOES NOT DO. It cannot invent a sabotage for a gate that declares none — those are counted as UNPROVEN and ratcheted, which is honest:
// a check nobody has broken is a claim, and the count says how many such claims a repo is carrying.
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";

/** Apply a sabotage, run the gate, restore. Never leaves the tree changed. */
export function proveGate(gate, repoRoot) {
  const s = gate.sabotage ?? {};
  const file = s.file ?? gate.subject;
  const name = gate.name;
  if (!file || typeof s.find !== "string" || s.replace === undefined) {
    return { name, kind: "gate", result: "unproven", detail: "no sabotage declared, so nothing shows it can fail" };
  }
  const abs = join(repoRoot, file);
  let original;
  try {
    original = readFileSync(abs, "utf8");
  } catch (e) {
    return { name, kind: "gate", result: "error", detail: `${file} could not be read (${e.message})` };
  }
  const hits = original.split(s.find).length - 1;
  if (hits !== 1) {
    return { name, kind: "gate", result: "stale", detail: `the sabotage matches ${file} ${hits} time(s), so it proves nothing about the current file` };
  }
  let mutated = original.replace(s.find, s.replace);
  // Keep the file's shape readable when the sabotage is trivial: SQL/JS comments are not needed, but a same-length swap that keeps syntax
  // valid is what makes "the check went red" mean "the check noticed", not "the file stopped parsing".
  try {
    writeFileSync(abs, mutated);
    const r = spawnSync(gate.cmd[0], gate.cmd.slice(1), { cwd: repoRoot, encoding: "utf8", timeout: 600000 });
    const code = r.status ?? 1;
    if (code === 0) {
      return { name, kind: "gate", result: "survived", detail: `the gate still passed with ${file} sabotaged — it does not protect what it names` };
    }
    return { name, kind: "gate", result: "caught", detail: `exit ${code} with ${file} sabotaged`, file, find: s.find, replace: s.replace, check: gate.cmd };
  } catch (e) {
    return { name, kind: "gate", result: "error", detail: e.message };
  } finally {
    try { writeFileSync(abs, original); } catch { /* the caller reports a disrupted tree separately */ }
  }
}

/** Gates with no sabotage at all — counted, never silently accepted. */
export function unprovenGates(cfg) {
  return (cfg?.gates ?? []).filter((g) => !g.sabotage);
}
