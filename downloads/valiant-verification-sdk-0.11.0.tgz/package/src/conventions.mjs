// conventions.mjs — the nine things a repo must DECLARE before the SDK can check the rules that are about artefacts.
//
// WHY THIS EXISTS. Twenty-six corpus invariants were "process rules": counted, never enforced. Six became guards because the rule is
// decidable from the tree. Nine of the rest are not wishes — they are rules about artefacts a repo does not produce yet: a worker's loop, a
// regenerating tool, a query helper, a status reporter, a measurement, a context builder, an error state, a UI screenshot. A tree can only be
// checked against what is IN the tree, so the SDK has to define the shape once and let a repo declare that it has one.
//
// THE CONTRACT. `valiant.json` gains an optional `conventions` object. Every key is optional; a repo that declares nothing is told, by name,
// which rule is therefore unenforced — never silently passed.
//
//   "conventions": {
//     "loop":     { "entry": "scripts/worker.mjs", "progress": "state/heartbeat.json" },
//     "refresh":  { "command": ["node", "scripts/probe.mjs"], "fixture": "fixtures/probe" },
//     "queries":  ["src/queries.mjs"],
//     "status":   ["src/status.mjs"],
//     "context":  "src/context.mjs",
//     "measure":  ["scripts/bench.mjs"],
//     "ui":       { "roots": ["src/pages", "src/components"], "screenshots": "screenshots" },
//     "errors":   ["src/pages"]
//   }
//
// WHAT IT DOES NOT DO. It does not run a repo's code by guessing: `loop` and `refresh` name an entry point explicitly, and a guard that runs
// one says so. Everything here is a declaration the repo owns, checked against itself — no convention is inferred from a filename pattern.
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";

/** The conventions, in the order they unlock rules. `unlocks` names corpus invariants so a report can say what a gap costs. */
export const CONVENTIONS = [
  {
    key: "loop", unlocks: [22], rule: "a loop survives an item that vanishes mid-iteration",
    what: "the entry point of a long-running loop, the directory of items it consumes, and the file it writes progress to",
    shape: { entry: "string (a file, relative to the repo root)", queue: "string (a directory of items)", progress: "string (the file the loop updates)" },
    check: (v) => (typeof v?.entry === "string" && v.entry ? null : '"loop" needs "entry": the file a guard may run'),
  },
  {
    key: "refresh", unlocks: [23], rule: "a refresh preserves what it cannot derive",
    what: "a command that regenerates state, plus a fixture it may run against",
    shape: { command: "array of strings", fixture: "string (a directory)" },
    check: (v) => (Array.isArray(v?.command) && v.command.length ? null : '"refresh" needs "command": the exact argv, never a shell string'),
  },
  {
    key: "queries", unlocks: [7, 9], rule: "a silent zero is a bug; a missing column degrades",
    what: "the module(s) a repo queries its data through",
    shape: "array of file paths",
    check: (v) => (Array.isArray(v) && v.length ? null : '"queries" must be a non-empty array of files'),
  },
  {
    key: "status", unlocks: [25], rule: "liveness is proved, not inferred",
    what: "the module(s) that report a component as up",
    shape: "array of file paths",
    check: (v) => (Array.isArray(v) && v.length ? null : '"status" must be a non-empty array of files'),
  },
  {
    key: "context", unlocks: [36], rule: "stable context first, volatile last",
    what: "the module that assembles ordered context for a model",
    shape: "file path",
    check: (v) => (typeof v === "string" && v ? null : '"context" must be a file path'),
  },
  {
    key: "measure", unlocks: [35], rule: "a measurement under load measures the rig",
    what: "the script(s) that produce a measurement result",
    shape: "array of file paths",
    check: (v) => (Array.isArray(v) && v.length ? null : '"measure" must be a non-empty array of files'),
  },
  {
    key: "ui", unlocks: [40], rule: "a UI change is verified by looking at it",
    what: "the directories that render UI, and where screenshots of a change are kept",
    shape: { roots: "array of directories", screenshots: "a directory" },
    check: (v) => (Array.isArray(v?.roots) && v.roots.length && typeof v?.screenshots === "string" ? null : '"ui" needs "roots" (array) and "screenshots" (a directory)'),
  },
  {
    key: "errors", unlocks: [41], rule: "a failure names the next step",
    what: "the directories whose error and empty states must offer an action",
    shape: "array of directories",
    check: (v) => (Array.isArray(v) && v.length ? null : '"errors" must be a non-empty array of directories'),
  },
];

/**
 * Read and validate `conventions` from a loaded config.
 * @returns {{ declared: object, problems: Array<{key: string, why: string}>, missing: Array<object> }}
 */
export function readConventions(cfg, repoRoot = ".") {
  const declared = cfg?.conventions && typeof cfg.conventions === "object" && !Array.isArray(cfg.conventions) ? cfg.conventions : {};
  const problems = [];
  const missing = [];
  for (const c of CONVENTIONS) {
    if (declared[c.key] === undefined) { missing.push(c); continue; }
    const why = c.check(declared[c.key]);
    if (why) { problems.push({ key: c.key, why }); continue; }
    // A declared path that is not there is worse than an absent convention: the repo says it has the artefact and does not.
    // AN OUTPUT PATH NEED NOT EXIST YET. `progress` is written by the loop and `screenshots` holds what a change produced, so demanding they
    // pre-exist would make a repo unable to declare a convention until after it had already satisfied it — measured 2026-11-01: a correct
    // declaration was reported BROKEN because the screenshots directory had not been created yet.
    const OUTPUT = new Set(["progress", "screenshots"]);
    const paths = [];
    const v = declared[c.key];
    if (typeof v === "string") paths.push(v);
    else if (Array.isArray(v)) paths.push(...v);
    else for (const k of ["entry", "queue", "progress", "fixture", "screenshots", "file"]) {
      if (OUTPUT.has(k)) continue;
      if (typeof v?.[k] === "string") paths.push(v[k]);
    }
    if (Array.isArray(v?.roots)) paths.push(...v.roots);
    if (Array.isArray(v?.command)) paths.push(v.command[0]);
    for (const p of paths) {
      if (p.startsWith("-")) continue;                        // a flag, not a path
      if (!existsSync(join(repoRoot, p))) problems.push({ key: c.key, why: `"${p}" is declared but does not exist in this repo` });
    }
  }
  return { declared, problems, missing };
}

/** One line per convention for `valiant conventions`: declared (and valid), declared-but-broken, or absent. */
export function conventionReport(cfg, repoRoot = ".") {
  const { declared, problems, missing } = readConventions(cfg, repoRoot);
  const broken = new Set(problems.map((p) => p.key));
  return CONVENTIONS.map((c) => ({
    key: c.key,
    unlocks: c.unlocks,
    state: declared[c.key] === undefined ? "absent" : broken.has(c.key) ? "broken" : "declared",
    detail: problems.filter((p) => p.key === c.key).map((p) => p.why).join("; ") || c.what,
  }));
}

/** The sentence a guard prints when its convention is absent — the rule is unenforced, and says so by name. */
export function unenforced(c) {
  return `not checked: invariant ${c.unlocks.join(", ")} needs the "${c.key}" convention (${c.what}) — declare it in valiant.json`;
}
