# Valiant Verification SDK — how to use it (and get the most out of it)

This is the operating manual. Read it, or paste the whole thing into your AI
harness (Claude / Grok / ChatGPT) so the agent knows how to work with Valiant.

## What it is, in one sentence

Valiant turns the checks a repo already has into a **proven, signed verdict** and
**blocks** when that verdict is red — then tells you *why* and gives you the *fix*.

It does not write your tests or your code. It wraps what you already have and
answers one question: **does "done" hold?** — `0` holds · `1` broken · `2` could not check.

## The golden path (install → works)

1. **Install** (one command):

   macOS / Linux:
   ```
   curl -fsSL https://vvs.morpheus.nz/install.sh | sh
   ```

   Windows (PowerShell, after installing Node LTS):
   ```
   npm install -g "https://vvs.morpheus.nz/downloads/valiant-verification-sdk-0.17.0.tgz"
   ```

2. **Licence** — paste your token once:

   ```
   valiant licence <your-token>
   ```

3. **One command wires everything** — run inside your repo:

   ```
   valiant setup
   ```

   That single step does: licence check → writes the config → adopts a guard →
   proves it can fail → installs the **push gate + agent hooks + MCP (Claude/Grok/ChatGPT)**
   → installs the **hourly self-heal** → runs the gate. Nothing else to wire by hand.

## Feed this to your harness (once)

> Before you report work as done, call `valiant_gate` and report its exit code:
> `0` every contract holds · `1` a contract is broken · `2` could not be checked.
> Never describe a gate as passing unless `exitCode` is `0`.
> If it fails, read the `why` and the `fix`, apply the fix, then re-run until `0`.

The MCP server says the same thing in its own `initialize` message, so a client
that reads it does not need this prompt.

## How the loop works (block → why → fix → re-pass)

- A red check **blocks**: the push is refused, the agent is stopped at completion.
- Every failure carries a **why** (the rule/incident) and a **fix** (the exact next step).
- Apply the fix, re-run. Green means it holds.
- `git push --no-verify` and skipping the hook are the escape hatch, **not** the workflow —
  every time you use one you buy back the exact staleness Valiant exists to catch.

## The self-heal

`valiant setup` installs an hourly `valiant doctor --fix` (cron on macOS/Linux,
Task Scheduler on Windows) that regenerates the corpus, re-mounts hooks, and re-checks
the licence, so staleness cannot pile up. Leave it on. Run it by hand anytime:

```
valiant doctor --fix
```

## Getting the most out of it (what actually compounds value)

1. **Feed it real checks.** A repo with a genuine `test`/`lint`/`build` suite gets a real
   verdict; a repo with `test: echo ok` gets a green lie. Valiant proves the *checking*,
   not the quality.
2. **Wire all three surfaces** — push, CI, and the agent. One surface is a door left open.
3. **Keep the guards honest** — re-run `valiant mutate` after big changes so you know the
   checks still fail when they should, not just that they pass.
4. **Write your own guards** for your repo's real failure modes; the shipped baseline is the floor.
5. **Obey the block, read the why, apply the fix.** That loop is the product.

## What it does NOT do (honest limits)

- It cannot read the AI's true intent — the `restated/approved/traceable` record is only as
  good as the agent's honesty plus your review of it.
- It does not write or fix code — the `fix:` line tells *you* (or the agent) what to change.
- It is only as good as the checks underneath it.

## Two speeds: fast every day, exhaustive before shipping

The SDK is tiered so it stays usable and fast in the daily loop, and exhaustive only when it matters.

- **Daily (fast):** `valiant gate` — runs just your declared checks (lint / typecheck / unit tests).
  Keep these fast; this is the "is my change ok" answer in seconds-to-a-minute.
- **Pre-production (full):** `valiant prove` — runs *everything*: verify → mutate → control → audit → report,
  the whole evidence a reviewer, customer or regulator can point at. Run it before a final compile or deploy.

So: iterate on `gate`, ship on `prove`. If `prove` is slow, that is the point — it is the one exhaustive run
you do once before going out, not the loop you run on every keystroke.

## Commands you'll actually use

```
valiant setup              one command: licence, config, guard, proof, hooks, gate
valiant verify             run every gate by name
valiant gate               the whole verdict (0/1/2)
valiant mutate             prove each guard can fail (writes mutations.json)
valiant doctor --fix       heal the chain (regenerate, re-mount, re-verify)
valiant enforce --status   what is enforced where
valiant mcp                serve MCP over stdio (5 tools for your agent)
valiant ui                 the control panel
```
