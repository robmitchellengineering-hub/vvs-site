# Conformance — grading a certificate you did not produce

The artefact a partner needs before piloting the format. Point it at **their** certificate JSON; it tells
them, mechanically, whether the certificate conforms — with no one from this project in the room.

```
node tools/conformance.mjs their-certificate.json          # human summary, exit 0 = conformant
node tools/conformance.mjs their-certificate.json --json   # machine-readable
node tools/conformance-selftest.mjs                        # prove the suite can say NO
```

## What it checks

| # | rule | why it exists |
|---|---|---|
| 1 | every gate carries `name`, `result`, `evidence`, `producer`, `scope`, `watch`, `remedy` | the two fields standards normally omit are the two that matter |
| 2 | `scope` is not a restatement of `result` | a condition cannot be the claim it bounds |
| 3 | `watch` names an **owner** and a **rate** | a signal nobody owns, or nobody checks, is not a watch |
| 4 | `remedy` is present and not a placeholder | a claim nobody would act on is not a claim |
| 5 | the certificate's grade is **no better than its worst gate** | a grade is the worst finding, never the average |
| 6 | a certificate with no gates is refused | a certificate with nothing to check certifies nothing |

## The suite must be able to fail

`tools/conformance-selftest.mjs` runs six broken certificates — a restated falsifier, a placeholder remedy,
an averaged grade, an empty gate list, and the full adversarial fixture (seven findings) — and asserts the
suite catches each. **A conformance suite that only ever says yes is the defect it exists to find.**

## Why v2 replaced the falsifier

v1 required a **falsifier**: "what would make this claim false". That is a physics-shaped requirement. In a
closed system the space of observations is finite and you can name the one that breaks the claim; in a human
system — a lab, a QA function, a model-risk team — the set of defeating events is unbounded, so the field can
only be satisfied by a sentence written to satisfy it.

**Scope + watch is the scalable form.** Scope is finite and enumerable. The watch is what makes it honest:
you cannot be exhaustive in an open system, **you can be timely**. And a claim whose failure modes are not
enumerable is still conformant, provided the watch states a sampling rate.

## What it deliberately does not do

It does not judge whether a claim is **true**. It judges whether a claim is **falsifiable, evidenced,
attributed, and gradable** — the part that can be checked without the domain. Truth is the domain's job;
**gradeability is ours**, and it is the part that had no standard.
