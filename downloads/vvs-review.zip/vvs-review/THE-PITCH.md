# Valiant — one loop, six answers

**The AI says *done*. Valiant makes done mean *proven* — with a human tether and a tamper-evident record of every yes.**

Most tools do one thing. Valiant is the one loop that answers all six questions every team and every
regulator is now asking:

| step | the question it answers | the mechanism |
|---|---|---|
| **verify** | *is it actually done?* | `valiant gate` — a 0/1/2 verdict, not a claim |
| **prove** | *would the checks catch a bug?* | `valiant mutate` — sabotage the code, the check must catch it |
| **block** | *can bad work ship?* | the push hook + the Stop hook refuse red |
| **coach** | *does the AI fix it or just fail?* | every failure carries the why + the fix, re-run until green |
| **record** | *who did what, who said yes?* | the approved/restated/traceable ledger, hash-chained |
| **assure** | *can a third party trust the evidence?* | `valiant pack` — signed, tamper-evident, verifiable offline |

## Two speeds

- **Daily:** `valiant gate` — fast, just your checks.
- **Before shipping:** `valiant prove` — the full run (verify → mutate → control → audit → report).

## It maps to the law, not just to best practice

`valiant report` shows the posture live: human oversight (EU AI Act Art 14), automatic logging of who
verified (Art 12), declared accuracy/robustness (Art 15), NIST Govern/Measure/Manage, ISO 42001
documentation, OWASP's silent-failure — each with the mechanism that satisfies it and the live numbers.

## The honest limits

It verifies the *checking*, not the quality of the code; it cannot read the AI's true intent (that is the
human's job, and the `restated` field is the tether that makes it explicit); and it is only as good as the
checks you feed it.

Install: `curl -fsSL https://vvs.morpheus.nz/install.sh | sh` → `valiant licence <token>` → `valiant setup`.
