#!/usr/bin/env node
import { spawnSync } from "node:child_process";
import os from "node:os";
import crypto, { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
import { dirname } from "node:path";
import { join, resolve, basename } from "node:path";
import { readFileSync, existsSync, writeFileSync, mkdirSync, readdirSync, statSync, mkdtempSync, cpSync, rmSync } from "node:fs";
const r2 = readFileSync;
import { tmpdir } from "node:os";
const fsmod = { readdirSync, statSync };
const mkdirSyncRecursive = (d) => { try { mkdirSync(d, { recursive: true, mode: 0o700 }); } catch { /* exists */ } };
import { loadConfig } from "../src/config.mjs";
import { runAllGates } from "../src/gates.mjs";
import { runAllMutations } from "../src/mutate.mjs";
import { checkLedger } from "../src/ledger.mjs";

// Snapshot the tracked working tree so `mutate` can prove it never touched the
// real repo. Returns null when the target is not a git repo (nothing to check).
/**
 * A CONTENT HASH OF THE WHOLE TREE, gitignored files included. "no-disruption" used to read `git status`, which cannot
 * see a gitignored directory — so a build-shaped check could write the real `dist/` while the run printed "working
 * tree untouched" (independent review #8, C). Every byte of every file is hashed before and after.
 */
function walkGitDir() { /* replaced below by an inline walker */ }

function treeHash(root) {
  // node_modules and .venv ARE hashed (as a name+size manifest, for speed): they are symlinked into the copy, so a
  // check that writes there writes the real repo. `.git` is hashed too for the parts that can RUN — hooks, config,
  // index — because a planted pre-commit hook executes on the next commit (independent reviews #9 F2.1, #10 F2.2).
  const h = createHash("sha256");
  const file = (full, name) => {
    let st = null;
    try { st = statSync(full); } catch { return; }
    if (!st.isFile()) return;
    if (/(^|\/)(node_modules|\.venv)(\/|$)/.test(name)) { try { h.update(`${name}:${st.size}:${st.mtimeMs}`); } catch { /* unreadable */ } return; }
    try { h.update(name); h.update(readFileSync(full)); } catch { /* unreadable */ }
  };
  const walk = (dir, rel) => {
    let entries = [];
    try { entries = readdirSync(dir).sort(); } catch { return; }
    for (const e of entries) {
      const full = join(dir, e);
      const name = rel ? `${rel}/${e}` : e;
      let st = null;
      try { st = statSync(full); } catch { continue; }
      if (st.isDirectory()) {
        if (e === ".git") { for (const keep of ["config", "index", "hooks", "info"]) walkGit(join(full, keep), `.git/${keep}`); continue; }
        walk(full, name);
        continue;
      }
      file(full, name);
    }
  };
  const walkGit = (path2, name) => {
    let st = null;
    try { st = statSync(path2); } catch { return; }
    if (st.isFile()) { file(path2, name); return; }
    let entries = [];
    try { entries = readdirSync(path2).sort(); } catch { return; }
    for (const e of entries) walkGit(join(path2, e), `${name}/${e}`);
  };
  walk(root, "");
  return h.digest("hex");
}

function gitStatus(root) {
  const res = spawnSync("git", ["-C", root, "status", "--short"], { encoding: "utf8" });
  // `git status` in a non-repo exits 128 with empty stdout; treating that as "clean" printed a PASS for a check
  // that never ran (independent review #4, F7).
  if (res.error || res.status !== 0) return null;
  if (res.error) return null;
  return (res.stdout || "").trim();
}

// The repo root is where gate/guard commands resolve (the cwd). The config path is
// independent: `--config /path/to/x.json` drives a repo without touching it.
// With --config, the repo under test is the one the CONFIG lives in. Using the caller's cwd silently ran
// the caller's checks against another repo's config — `valiant gate --config ../other/valiant.json` said
// "every contract holds" while the other repo was broken. Found by an independent review, 2026-10-26.
// THE DEADLINE IS SET ONCE, WHERE THE FLAGS ARE READ, so every path that runs proofs inherits it (the gate's own runner
// and evidence.mjs both reach runAllMutations). `--timeout` is in minutes; VALIANT_TIMEOUT_MINUTES does the same for a CI
// file that cannot change the command line.
{
  const i = process.argv.indexOf("--timeout");
  const mins = Number(i !== -1 ? process.argv[i + 1] : (process.env.VALIANT_TIMEOUT_MINUTES ?? 0));
  if (Number.isFinite(mins) && mins > 0) {
    process.env.VALIANT_DEADLINE_MS = String(Date.now() + mins * 60000);
    // A WATCHDOG PROCESS, NOT A TIMER. The gate spends most of its life inside synchronous child processes, where a JS
    // timer cannot fire at all — measured: --timeout 0.05 still ran for minutes. A detached process can end it: SIGTERM
    // first (so the mutation handlers clean up), then SIGKILL if it has not gone.
    const ms = Math.round(mins * 60000);
    const script = `const t=setTimeout(()=>{try{process.kill(${process.pid},"SIGTERM")}catch{};`
      + `setTimeout(()=>{try{process.kill(${process.pid},"SIGKILL")}catch{};process.exit(0)},15000)},${ms});t.unref()`;
    try {
      const wd = (await import("node:child_process")).spawn(process.execPath, ["-e", script], { detached: true, stdio: "ignore" });
      wd.unref();
      process.once("exit", () => { try { wd.kill("SIGKILL"); } catch { /* already gone */ } });
    } catch { /* no watchdog available: the job-level timeout is still the backstop */ }
  }
}
const repoRoot = (() => {
  // --repo NAMES THE SUBJECT. Without it there is no way to say "verify THAT repo with THIS config", and the documented
  // recipe (`cd <repo> && valiant verify --config <sdk>/examples/x.json`) ran every gate inside the SDK's examples/
  // directory instead — every adoption broke on 2026-10-27 and the docs still claimed they passed.
  const ri = process.argv.indexOf("--repo");
  if (ri !== -1 && process.argv[ri + 1]) return resolve(process.argv[ri + 1]);
  const i = process.argv.indexOf("--config");
  const p = i !== -1 && process.argv[i + 1] ? process.argv[i + 1] : null;
  return p ? dirname(resolve(p)) : process.cwd();
})();
const cfgFlag = process.argv.indexOf("--config");
const configPath = cfgFlag !== -1 && process.argv[cfgFlag + 1]
  ? process.argv[cfgFlag + 1]
  : join(repoRoot, "valiant.json");
const FLAGS_WITH_VALUE = new Set(["--config", "--repo"]);
// IS IT INSTALLED, AND IS IT CURRENT? `--version` answered "this repo has no valiant.json" and exited 2, because the command word
// parser skips anything starting with `--`. A tool that cannot say what it is cannot be confirmed on a machine, and confirming it on
// every machine in the estate is exactly what this rollout needs.
if (process.argv.includes("--version") || process.argv.includes("-v")) {
  const { readFileSync: rv } = await import("node:fs");
  const { fileURLToPath: f2u } = await import("node:url");
  const { dirname: dn, join: jn } = await import("node:path");
  let version = "unknown";
  try { version = JSON.parse(rv(jn(dn(f2u(import.meta.url)), "..", "package.json"), "utf8")).version ?? "unknown"; } catch { /* no package.json */ }
  const me = f2u(import.meta.url);
  let gates = 0; let guards = 0; let where = "not inside an adopted repo";
  try {
    const c = JSON.parse(rv(jn(process.cwd(), "valiant.json"), "utf8"));
    gates = c.gates?.length ?? 0; guards = c.guards?.length ?? 0;
    where = `${gates} gate(s), ${guards} guard(s) in ${process.cwd()}`;
  } catch { /* not adopted here */ }
  console.log(`valiant ${version}`);
  console.log(`  cli      ${me}`);
  console.log(`  node     ${process.version}`);
  console.log(`  repo     ${where}`);
  process.exit(0);
}

// A HOOK'S RECORD MUST NOT DEPEND ON A REPO. `decisions --record` bailed with "this repo has no valiant.json" and exited 0 when run from a
// directory that is not adopted, so a routing hook's blocks were never recorded while the command reported success. The log is
// machine-global; it is written before any config is read. (This handler was lost once in a rebase, which is how the flags above
// silently stopped being honoured — the test that catches it is tools/selftest-decisions.mjs.)
if (process.argv[2] === "review") {
  // PRINCIPLE 3 WITH A MECHANISM. `--record` writes a block naming BOTH models; the check (and the release gate) refuse a record where they match.
  const { checkReview, recordReview } = await import("../src/review.mjs");
  const args = process.argv.slice(3);
  const val = (n) => { const i = args.indexOf(n); return i !== -1 ? args[i + 1] : undefined; };
  if (args.includes("--record")) {
    try {
      const r = recordReview(repoRoot, {
        reviewerModel: val("--reviewer"), authorModel: val("--author"),
        scope: val("--scope"), verdict: val("--verdict") ?? "pass",
        notes: val("--notes") ?? "",
        findings: args.includes("--finding") ? args.filter((a, i) => args[i - 1] === "--finding") : [],
      });
      console.log(`review: recorded — ${r.line}`);
      console.log("  the release gate reads this block; a review by the author's own model is refused.");
      process.exit(0);
    } catch (e) { console.error(`review: ${e.message}`); process.exit(2); }
  }
  const r = checkReview(repoRoot);
  console.log(`  [${r.ok ? "PASS" : "FAIL"}] review — ${r.detail}`);
  process.exit(r.ok ? 0 : 1);
}

if (process.argv[2] === "decisions" && process.argv.includes("--record")) {
  const { recordDecision } = await import("./../src/receipts.mjs");
  const a = process.argv.slice(3);
  const f = (n) => { const i = a.indexOf(n); return i >= 0 ? a[i + 1] : undefined; };
  const r = recordDecision({ hook: f("--hook"), tool: f("--tool"), command: f("--command"),
    verdict: f("--verdict") ?? "allow", reason: f("--reason") ?? process.env.VALIANT_DECISION_REASON ?? "" });
  if (!r.ok) console.error(`valiant decisions: the record could not be written (${r.why}) — the hook's verdict still stands`);
  process.exit(0);
}

const cmd = (() => {
  // Find the first argument that is not a flag and not a flag's value.
  let skip = false;
  for (const a of process.argv.slice(2)) {
    if (skip) { skip = false; continue; }
    if (FLAGS_WITH_VALUE.has(a)) { skip = true; continue; }
    if (a.startsWith("--")) continue;
    return a;
  }
  return "status";
})();

if (cmd === "help" || process.argv.includes("--help") || process.argv.includes("-h") || (!process.argv[2] && !process.argv.includes("--config"))) {
  // A tool a stranger installs must answer `--help`. It used to fall through to `status` and die on a missing config.
  const lines = [
    "valiant — make \"done\" mean \"verified\"",
    "",
    "  valiant init                  write valiant.json from the checks this repo has (the SOP baseline ships in the SDK)",
    "  valiant gate                  the whole verdict: gates, ledger, guards proved, SOP baseline",
    "  valiant prove                 the FULL pre-production run (verify + mutate + control + audit + report) — run before a final compile",
    "  valiant verify                run every gate by name",
    "  valiant mutate [--strict]     prove each guard can fail; writes mutations.json",
    "  valiant ledger                check the hazard ledger (RULE + GUARD on every entry)",
    "  valiant sops init|check|list  the installer-SOP baseline and your own rules",
    "  valiant sample-proofs         re-run every published proof through the SDK itself",
    "  valiant status                counts: gates, guards, ledger",
    "  valiant disambiguate \"text\"   name every dangling it/that/bits — rewrite + tick boxes (--ai, --ai-login)",
    "  valiant control               the AI control number: 0 under control · 1 a control broke · 2 could not check (--record '<json>', --hook)",
    "  valiant audit                 the decision trail — who did what, who said yes, on what evidence (--json, --html)",
    "  valiant report                the compliance posture — each feature mapped to EU AI Act / NIST / ISO",
    "  valiant conformance           the L1–L3 ladder — your level and the statutory controls it satisfies",
    "  valiant licence --status      what licence this machine has",
    "  valiant licence --list|--html every licence this machine knows (table, or a page)",
    "  valiant outcomes              what this machine's verifier has seen, as (diff, verdict) pairs",
    "  valiant decisions             hook decisions, hash-chained (and UNEXERCISED hooks)",
    "  valiant contract <record>     check what a run produced against what it declared",
    "  valiant pack [--out dir]      one bundle of evidence a third party can verify offline",
    "  valiant pack --verify <dir>   check a pack: every hash, every file, and the manifest signature",
    "  valiant ci-init [github|jenkins|gitlab] write the CI step — --self-hosted, --existing <labels>, --mesh <dir>, --fleet <file>, --check",
    "  valiant setup [--licence <path>] one command: licence, config, proved guard, gate",
    "  valiant doctor [--fix]        heal the chain — regenerate corpus, re-mount hooks, verify",
    "  valiant doctor --schedule     install an hourly self-heal (cron / Task Scheduler) — --unschedule to remove",
    "  valiant hooks --install       put the gate in front of git push, and declare it",
    "  valiant enforce --install claude|dsh   make the AGENT run the gate (a hook where it tries to finish)",
    "  valiant enforce --status      what is enforced where: push, CI, Claude, DSH",
    "  valiant mcp                   serve MCP over stdio, so an agent can ask for the verdict (tools: gate, verify, ledger, outcomes, licence)",
    "  valiant ui [--port 8787]      open the control panel (toggle enforcement, run + watch the gate live)",
    "",
    "  exit: 0 every contract holds · 1 a contract is broken · 2 a contract could not be checked",
    "",
    "  First run:  valiant init  →  add one guard  →  valiant mutate  →  valiant gate",
  ];
  process.stdout.write(lines.join("\n") + "\n");
  process.exit(0);
}

// `pack --verify` RUNS BEFORE ANYTHING ELSE. It is the one command an AUDITOR uses, on a machine that has never seen
// this repo — so it must not require a valiant.json, a licence, or a network. Loading the config first made verification
// fail with "this repo has no valiant.json yet" on exactly the machine the pack exists for.
// `valiant mcp` IS NOT GATED AND NOT CONFIG-DEPENDENT. An MCP client starts the server once, in whatever directory it
// happens to be, and asks about repos by path. Loading a config first would make the server fail to start in a repo-less
// directory — the one place an agent is most likely to launch it from.
// `valiant ci-init` RUNS BEFORE THE CONFIG LOAD TOO: a team may want the step in CI before the repo has adopted, and a
// command that refuses because there is no valiant.json yet would be the "install and work" story failing at step one.
if (process.argv[2] === "ci-init") {
  const { runCiInit } = await import("../src/ci-cli.mjs");
  const hereCi = dirname(fileURLToPath(import.meta.url));
  process.exit(runCiInit(process.argv.slice(3), process.cwd(), join(hereCi, "..", "package.json")));
}

// `valiant disambiguate` IS NOT GATED AND NOT CONFIG-DEPENDENT — it is a self-contained
// instruction → { rewrite, bullets[] } tool (D37). It needs no valiant.json, licence or repo,
// so it runs before the config load, beside ci-init and mcp.
if (process.argv[2] === "disambiguate") {
  const { disambiguate, effectiveResolution, detect } = await import("../src/disambiguate.mjs");
  const args = process.argv.slice(3);
  const wantJson = args.includes("--json");
  const bullets = [];
  let text = "";
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--json" || a === "--ai" || a === "--ai-login") continue;
    if (a === "--file") {
      const p = args[++i];
      if (!p) { console.error("valiant disambiguate --file <path>"); process.exit(2); }
      try { text = readFileSync(resolve(p), "utf8"); } catch (e) { console.error(`disambiguate: cannot read ${p}: ${e.message}`); process.exit(2); }
      continue;
    }
    if (a === "--resolve") {
      const kv = args[++i];
      if (!kv) { console.error("valiant disambiguate --resolve <referent>=<replacement>"); process.exit(2); }
      const eq = kv.indexOf("=");
      if (eq <= 0) { console.error("valiant disambiguate --resolve <referent>=<replacement>"); process.exit(2); }
      bullets.push({ referent: kv.slice(0, eq), resolved_to: kv.slice(eq + 1), answer: true });
      continue;
    }
    text += (text ? " " : "") + a;
  }
  // --ai-login: run the device flow once and store the token, so --ai needs no browser afterwards.
  if (args.includes("--ai-login")) {
    const { login, writeToken } = await import("../src/ai.mjs");
    const lr = await login({ onShow: (s) => {
      console.log(`  open  ${s.verification_uri_complete || s.verification_uri}`);
      console.log(`  approve the code  ${s.user_code}`);
      console.log("  waiting for approval…");
    } });
    if (!lr.ok) { console.error(`  ai login: ${lr.reason}`); process.exit(2); }
    const stored = writeToken(lr.token);
    console.log(`  logged in${lr.user?.email ? ` as ${lr.user.email}` : ""}`);
    console.log(`  token stored at ${stored.path} (${stored.length} chars, never printed)`);
    process.exit(0);
  }

  let r;
  if (args.includes("--ai")) {
    const { disambiguateAI, readToken, login, writeToken } = await import("../src/ai.mjs");
    const detected = detect(text);
    let token = readToken();
    if (!token) {
      const lr = await login({ onShow: (s) => {
        console.error(`  ai needs a Morpheus account — open  ${s.verification_uri_complete || s.verification_uri}`);
        console.error(`  approve the code  ${s.user_code}`);
        console.error("  waiting for approval…");
      } });
      if (!lr.ok) { console.error(`  ai login: ${lr.reason}`); process.exit(2); }
      token = lr.token;
      writeToken(token);
    }
    const ar = await disambiguateAI(text, detected.map((d) => ({ referent: d.referent, kind: d.kind })), { token });
    if (ar.ok && ar.json?.rewrite) {
      // The AI GUESSES resolved_to (answer null); a --resolve (answer true) overrides it in the merge.
      const guesses = (ar.json.resolutions ?? []).map((x) => ({ referent: x.referent, resolved_to: x.resolved_to, answer: null }));
      r = disambiguate(text, { bullets: [...guesses, ...bullets], aiRewrite: ar.json.rewrite });
      if (!wantJson && ar.usage) console.log(`  ai: ${ar.usage.total_tokens ?? "?"} tokens on ${ar.json.model || "?"} (${ar.usage.prompt_tokens ?? "?"} in / ${ar.usage.completion_tokens ?? "?"} out)`);
    } else {
      console.error(`  ai: ${ar.reason || `HTTP ${ar.status}`} — using the mechanical rewrite`);
      r = disambiguate(text, { bullets });
    }
  } else {
    r = disambiguate(text, { bullets });
  }

  if (wantJson) {
    console.log(JSON.stringify(r, null, 2));
  } else {
    if (!r.bullets.length) console.log("  nothing ambiguous");
    for (const b of r.bullets) {
      const res = effectiveResolution(b);
      const mark = b.answer === true ? "ok " : b.answer === false ? "no " : "?  ";
      console.log(`  [${b.id}] ${mark} "${b.referent}" (${b.kind})${res ? " \u2192 " + res : ""}`);
      console.log(`        ${b.question}`);
    }
    console.log(`  rewrite: ${r.rewrite}`);
    console.log(`  verdict: ${r.verdict}`);
    if (r.unresolved.length) console.log(`  unresolved: ${r.unresolved.map((u) => u.referent).join(", ")}`);
  }
  process.exit(r.verdict === "unambiguous" ? 0 : r.verdict === "rejected" ? 2 : 1);
}

// `valiant control` — the AI control standard (Aza Raskin: measure control, not capability).
// Runs the three ai-control guards against the action ledger and emits the CONTROL NUMBER:
//   0 = under control · 1 = a control broke · 2 = could not check.
// It is NOT gated and NOT config-dependent — the ledger is a convention the agent opts into.
if (process.argv[2] === "control") {
  const { checkControl, record, GUARDS } = await import("../src/control.mjs");
  const args = process.argv.slice(3);

  if (args.includes("--record")) {
    const i = args.indexOf("--record");
    const json = args[i + 1];
    if (!json) { console.error("control: --record '<json>' — the action to append"); process.exit(2); }
    let a; try { a = JSON.parse(json); } catch { console.error("control: --record takes JSON, got something else"); process.exit(2); }
    if (typeof a.action !== "string" || !a.action) { console.error("control: a recorded action needs an \"action\" string"); process.exit(2); }
    const r = record(process.cwd(), a);
    console.log(`control: recorded "${a.action}" → ${r.path}`);
    process.exit(0);
  }

  if (args.includes("--approve") || args.includes("--reject")) {
    // THE HUMAN'S TICK. --approve marks every PENDING action yes; --reject <n> marks line n no.
    // The approved guard is what makes this matter: pending is red until you tick, and rejected is a break.
    const { readFileSync, writeFileSync, existsSync } = await import("node:fs");
    const { join } = await import("node:path");
    const p = join(process.cwd(), "ai-actions.jsonl");
    if (!existsSync(p)) { console.error("control: no ai-actions.jsonl to approve"); process.exit(2); }
    const lines = readFileSync(p, "utf8").split("\n").filter((l) => l.trim());
    const rejectAt = args.includes("--reject") ? Number(args[args.indexOf("--reject") + 1]) : NaN;
    let changed = 0;
    const out = lines.map((l, i) => {
      let a; try { a = JSON.parse(l); } catch { return l; }
      if (args.includes("--approve") && a.approved !== true) { a.approved = true; changed++; return JSON.stringify(a); }
      if (args.includes("--reject") && !isNaN(rejectAt) && i + 1 === rejectAt && a.approved !== false) { a.approved = false; changed++; return JSON.stringify(a); }
      return l;
    });
    writeFileSync(p, out.join("\n") + "\n");
    console.log(`control: ${args.includes("--approve") ? "approved" : "rejected line " + rejectAt} — ${changed} action(s) updated`);
    process.exit(0);
  }

  if (args.includes("--restate")) {
    // THE AGENT'S RESTATEMENT. --restate <line> '<plain-language intent>' writes the asked-vs-meant gap
    // for that action. This is the flow that closes intent-explicitness: the auto-record writes null, the
    // guard flags it red, and THIS is how the agent fixes it — by saying what it meant, not copying the command.
    const { readFileSync, writeFileSync, existsSync } = await import("node:fs");
    const { join } = await import("node:path");
    const p = join(process.cwd(), "ai-actions.jsonl");
    if (!existsSync(p)) { console.error("control: no ai-actions.jsonl to restate"); process.exit(2); }
    const i = args.indexOf("--restate");
    const line = Number(args[i + 1]);
    const text = args[i + 2];
    if (!Number.isInteger(line) || !text || !text.trim()) { console.error("control: --restate <line> '<text>' — both required"); process.exit(2); }
    const lines = readFileSync(p, "utf8").split("\n").filter((l) => l.trim());
    if (line < 1 || line > lines.length) { console.error(`control: no such line ${line}`); process.exit(2); }
    let a; try { a = JSON.parse(lines[line - 1]); } catch { console.error(`control: line ${line} is not JSON`); process.exit(2); }
    if (text.trim() === String(a.action ?? "").trim()) { console.error("control: that is the command, not the intent — write what you MEANT, not what you ran"); process.exit(1); }
    a.restated = text.trim();
    lines[line - 1] = JSON.stringify(a);
    writeFileSync(p, lines.join("\n") + "\n");
    console.log(`control: restated line ${line} — "${text.trim()}"`);
    process.exit(0);
  }

  if (args.includes("--hook")) {
    // A PreToolUse hook: run the guards and BLOCK a live agent while the ledger is red.
    let raw = "";
    if (!process.stdin.isTTY) { const b = []; process.stdin.setEncoding("utf8"); for await (const c of process.stdin) b.push(c); raw = b.join(""); }
    const cmd = (() => { try { const e = JSON.parse(raw || "{}"); return String(e?.tool_input?.command ?? e?.command ?? ""); } catch { return ""; } })();
    const { hookVerdict } = await import("../src/control.mjs");
    const v = hookVerdict(process.cwd(), cmd);
    if (v.allow) process.exit(0);
    console.error(`blocked (control): ${v.reason}`);
    console.error("  fix the ledger, or record this action with --record, then re-run.");
    process.exit(2);
  }

  if (args.includes("--prove")) {
    // THE STANDARD'S SELF-PROOF, re-runnable by anyone: each guard must be shown to FAIL on its own
    // seeded violation. A guard that never fails proves nothing, so this is what makes the green number
    // evidence rather than a claim — and it is the thing a third party runs to check us.
    const { spawnSync } = await import("node:child_process");
    const { join, dirname } = await import("node:path");
    const { fileURLToPath } = await import("node:url");
    const here = dirname(fileURLToPath(import.meta.url));
    let bad = 0;
    for (const g of GUARDS) {
      const r = spawnSync(process.execPath, [join(here, "..", "corpus", "reference-guards", g.name + ".mjs"), "--self-test"], { encoding: "utf8" });
      const ok = r.status === 0;
      if (!ok) bad++;
      console.log(`  [${ok ? "PASS" : "FAIL"}] ${g.name} self-test${ok ? "" : ` :: ${(r.stderr || r.stdout).split("\n").filter(Boolean).slice(-1)[0] || ""}`}`);
    }
    console.log(`control: ${GUARDS.length - bad}/${GUARDS.length} guard(s) proven to fail on a seeded violation`);
    process.exit(bad ? 1 : 0);
  }

  const r = checkControl(process.cwd());
  console.log(`control: ${r.summary}`);
  for (const g of r.guards) {
    console.log(`  [${g.ok ? "PASS" : "FAIL"}] ${g.name} — ${g.what}${g.ok ? "" : ` :: ${g.detail}`}`);
  }
  process.exit(r.number);
}

// `valiant audit` — the decision trail. "Who did what, who said yes, on what evidence" is the question a
// regulator, a customer or a sceptical colleague asks, and the control ledger answers it — but only if it is
// ONE command, not a JSON file someone has to grok. Reads ai-actions.jsonl and renders the whole trail.
if (process.argv[2] === "audit") {
  const { readFileSync, existsSync } = await import("node:fs");
  const { join } = await import("node:path");
  const p = join(process.cwd(), "ai-actions.jsonl");
  if (!existsSync(p)) { console.error("audit: no ai-actions.jsonl in this directory — nothing was recorded"); process.exit(2); }
  const rows = readFileSync(p, "utf8").split("\n").filter((l) => l.trim()).map((l, i) => {
    try { return { line: i + 1, ...JSON.parse(l) }; } catch { return { line: i + 1, action: "(invalid JSON)", approved: null }; }
  });
  const verdict = (a) => a === true ? "approved" : a === false ? "REJECTED" : "pending";
  const copied = rows.filter((r) => typeof r.restated === "string" && r.restated.trim() === String(r.action ?? "").trim()).length;
  const approved = rows.filter((r) => r.approved === true).length;
  const rejected = rows.filter((r) => r.approved === false).length;
  const pending = rows.length - approved - rejected;
  const number = rejected > 0 ? 1 : 0;

  if (process.argv.includes("--json")) { console.log(JSON.stringify(rows, null, 2)); process.exit(number); }
  if (process.argv.includes("--html")) {
    const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
    const body = rows.map((r) => `<tr><td>#${r.line}</td><td>${esc(verdict(r.approved))}</td><td>${esc((r.at ?? "").slice(0, 19))}</td><td>${esc(r.source?.split("/").pop() ?? "")}</td><td>${esc((r.action ?? "").slice(0, 120))}</td></tr>`).join("\n");
    console.log(`<!doctype html><meta charset="utf-8"><title>valiant audit</title><h1>valiant audit — ${rows.length} action(s), ${approved} approved · ${pending} pending · ${rejected} rejected (control ${number})</h1><table border="1" cellspacing="0" cellpadding="4"><tr><th>#</th><th>verdict</th><th>when</th><th>where</th><th>what</th></tr>${body}</table>`);
    process.exit(number);
  }

  console.log(`audit — ${rows.length} action(s), ${approved} approved · ${pending} pending · ${rejected} rejected · ${copied} copied-not-restated  (control ${number})`);
  for (const r of rows) {
    console.log(`  #${r.line} ${verdict(r.approved).padEnd(9)} ${String(r.at ?? "").slice(0, 19)}  ${String(r.source ?? "").split("/").pop() || "-"}`);
    console.log(`       did:    ${String(r.action ?? "").slice(0, 90)}`);
    if (r.restated && r.restated !== r.action) console.log(`       meant:  ${String(r.restated).slice(0, 90)}`);
    else if (r.restated && r.restated === r.action) console.log(`       intent: NOT restated (copied the command) — the asked-vs-meant gap went unchecked`);
    if (r.traceable) console.log(`       source: ${String(r.traceable).slice(0, 90)}`);
  }
  process.exit(number);
}

// `valiant report` — the compliance posture. Maps what VVS ships to the obligations the world is writing into
// law (EU AI Act, NIST RMF, ISO 42001) with the mechanism named per line, so a customer or regulator can point
// at a feature rather than a promise. The live numbers (control, ledger) are read where the repo has them.
if (process.argv[2] === "report") {
  const { checkControl } = await import("../src/control.mjs");
  const { readFileSync: rfs, existsSync: exs } = await import("node:fs");
  const { join: jn } = await import("node:path");
  const ctl = checkControl(process.cwd());
  // LIVE EVIDENCE — the numbers a reviewer can read, not a promise. Each line below is backed by one of these.
  let gates = 0, caught = 0, total = 0;
  try { const v = JSON.parse(rfs(jn(process.cwd(), "valiant.json"), "utf8")); gates = (v.gates ?? []).length; } catch {}
  try { const m = JSON.parse(rfs(jn(process.cwd(), "mutations.json"), "utf8")); const r = m.proofs ?? []; total = r.length; caught = r.filter((x) => x?.result === "red").length; } catch {}
  const live = [
    `${gates} gate(s) declared`,
    `${caught}/${total} mutation(s) caught`,
    `control ${ctl.number} (${ctl.guards?.filter((g) => g.ok).length ?? 0}/${ctl.guards?.length ?? 0} hold)`,
  ];
  const rows = [
    ["EU AI Act Art 12 — automatic event logging over the lifetime, incl. who verified", "the ai-actions.jsonl control ledger + `valiant audit` (hash-chained, who said yes to what)"],
    ["EU AI Act Art 14 — human oversight + the ability to override, reverse or stop", "the Stop/PreToolUse hook (safe halt) + the approved/restated/traceable tick on every action"],
    ["EU AI Act Art 15 — declared accuracy/robustness, resilience to poisoned inputs", "`valiant gate` exit-code contract (0/1/2) + `valiant mutate` proving each guard can fail"],
    ["NIST AI RMF Govern — named roles + accountability structures", "the control ledger's `source` + `approved` fields (who acted, who ticked)"],
    ["NIST AI RMF Measure — validity, reliability, robustness, independent review", "`valiant verify` + mutation score + the coaching loop's why/fix"],
    ["NIST AI RMF Manage — continuous monitoring and improvement", "`valiant doctor --schedule` — the hourly self-heal that regenerates and re-verifies"],
    ["ISO 42001 §7.5/§9 — documented information, performance evaluation, records", "the signed corpus (46 invariants / 58 hazards / 24 method) + `valiant pack` (tamper-evident evidence)"],
    ["OWASP LLM Top 10 — silent failure, hidden/mis-stated behaviour", "`valiant mutate` (prove the check can fail) + the 'exit 0 with no output — suspect' refusal"],
    ["Anthropic containment — approval fatigue / rubber-stamping", "risk-tiered approval (auto-approve read/lint, gate write/network/secrets)"],
    ["AI control — restate intent before acting (asked-vs-meant)", "the `restated` field, recorded before the action and shown in `valiant audit`"],
  ];
  console.log("# Valiant — verification & control compliance posture\n");
  console.log(`live: ${live.join(" · ")}\n`);
  console.log("| obligation | the mechanism that satisfies it |");
  console.log("|---|---|");
  for (const [k, v] of rows) console.log(`| ${k} | ${v} |`);
  console.log("\nRegenerate with `valiant report`; audit the trail with `valiant audit`. Full evidence: `valiant pack`.");
  process.exit(0);
}

// `valiant conformance` — the graduated ladder (L1–L3) a compliance team can quote. Detects the level from
// what is actually running and ticks each statutory control per level, so a buyer or regulator can check off
// NIST / EU AI Act / ISO obligations automatically instead of mapping them by hand.
if (cmd === "conformance") {
  const { readFileSync, existsSync } = await import("node:fs");
  const { join } = await import("node:path");
  const cwd = process.cwd();
  const read = (p) => { try { return JSON.parse(readFileSync(join(cwd, p), "utf8")); } catch { return null; } };

  const v = read("valiant.json");
  const l1 = (v?.gates ?? []).length > 0;
  let l2 = false, l3 = false, caught = 0, total = 0, ctlNum = null;
  // ORACLE-CLASS (from SEXTANT): grade the guards by evidence class, not just by feature. kernel = Lean-checked,
  // exact = symbolic; the default empirical = mutation-tested.
  const oracles = { empirical: 0, kernel: 0, exact: 0 };
  for (const g of (v?.guards ?? [])) { const o = g.oracle ?? "empirical"; oracles[o] = (oracles[o] ?? 0) + 1; }
  const oracleLine = `oracle: ${oracles.empirical} empirical · ${oracles.kernel} kernel · ${oracles.exact} exact`;
  if (l1) {
    const m = read("mutations.json"); total = (m?.proofs ?? []).length; caught = (m?.proofs ?? []).filter((x) => x?.result === "red").length;
    const { checkControl } = await import("../src/control.mjs");
    const ctl = checkControl(cwd); ctlNum = ctl.number;
    l2 = caught > 0 && ctl.number === 0;
    l3 = l2 && existsSync(join(cwd, "ai-actions.jsonl")) && existsSync(join(cwd, "corpus"));
  }
  const level = l3 ? "L3 — Assured" : l2 ? "L2 — Proven" : l1 ? "L1 — Verified" : "below L1";

  // Each level unlocks a set of statutory controls. L2 and L3 include the levels below them.
  const controls = [
    ["NIST AI RMF Measure — validity, reliability, robustness", 1, "the gate + the 0/1/2 verdict"],
    ["EU AI Act Art 15 — declared accuracy & robustness", 1, "the gate's exit-code contract"],
    ["NIST AI RMF Govern — named roles + accountability", 2, "the control ledger (who said yes)"],
    ["EU AI Act Art 14 — human oversight + stop/override", 2, "the approved/restated ledger + Stop hook"],
    ["EU AI Act Art 12 — automatic event logging incl. who verified", 3, "the tamper-evident pack + audit trail"],
    ["ISO 42001 §7.5/§9 — documented information + records", 3, "the signed corpus + the pack"],
  ];
  const myLevel = l3 ? 3 : l2 ? 2 : l1 ? 1 : 0;

  console.log("# Valiant conformance\n");
  console.log(`level: ${level}`);
  console.log(`evidence: ${(v?.gates ?? []).length} gate(s) · ${caught}/${total} mutation(s) caught · control ${ctlNum ?? "n/a"} · ${oracleLine}\n`);
  console.log("| statutory control | level | status | the mechanism |");
  console.log("|---|---|---|---|");
  for (const [name, need, how] of controls) {
    const ok = myLevel >= need;
    console.log(`| ${name} | L${need} | ${ok ? "satisfied" : `not yet — reach L${need}`} | ${how} |`);
  }
  console.log(`\nTo reach the next level: ${myLevel === 0 ? "run `valiant setup` to wire the gate (L1)." : myLevel === 1 ? "run `valiant mutate` + tick the control ledger (L2)." : myLevel === 2 ? "run `valiant pack` and keep the audit trail (L3)." : "you are at the top level."}`);
  process.exit(0);
}

// `valiant prove` — the FULL pre-production run. The daily loop is `valiant gate` (fast: just the checks);
// before a final compile or deploy you run THIS — everything a reviewer, customer or regulator can point at, in
// one command: verify → mutate → control → audit → report. It is deliberately slower than `gate`; that is the
// trade the two tiers make — fast every day, exhaustive once before shipping.
if (cmd === "prove") {
  const { spawnSync } = await import("node:child_process");
  const me = process.argv[1];
  const steps = [
    ["verify", "the verdict — every gate holds (0)"],
    ["mutate", "the proof — each guard can actually fail"],
    ["control", "the tether — 0 under control"],
    ["audit", "the trail — who did what, who said yes"],
    ["report", "the posture — mapped to EU AI Act / NIST / ISO"],
    ["pack", "the evidence — a signed bundle a third party can verify offline"],
  ];
  let exit = 0;
  for (const [c, what] of steps) {
    console.log(`\n═══ ${c} — ${what} ═══`);
    const r = spawnSync(process.execPath, [me, c], { cwd: repoRoot, encoding: "utf8", stdio: ["ignore", "inherit", "inherit"] });
    if (r.status !== 0 && exit === 0) exit = r.status ?? 2;
  }
  console.log(`\nprove: ${exit === 0 ? "everything holds — ready to ship" : "a step did not hold (see above)"}`);
  process.exit(exit);
}

// SHIPPING EVIDENCE MUST WORK ANYWHERE ON A NODE. `outcomes --export` and `corpus absorb|leads` read the machine's own
// log, not a repository — and a node running a measurement has no valiant.json in front of it. Requiring a config made
// these commands fail on exactly the machines that produce the most evidence.
if ((process.argv[2] === "outcomes" && process.argv.includes("--export")) || (process.argv[2] === "corpus" && ["absorb", "leads", "prove", "promote"].includes(process.argv[3]))) {
  const { buildShard, writeShard, absorb, storeSummary } = await import("../src/ship.mjs");
  const args = process.argv.slice(3);
  if (process.argv[2] === "outcomes") {
    const at = args.indexOf("--export");
    const next = args[at + 1];
    const out = next && !next.startsWith("--") ? next : "valiant-outcomes.json";
    const sinceAt = args.indexOf("--since");
    const since = sinceAt !== -1 ? args[sinceAt + 1] : null;
    const exclude = args.flatMap((a, i2) => (a === "--exclude" && args[i2 + 1] ? [args[i2 + 1]] : []));
    const shard = buildShard({ since, exclude });
    writeShard(out, shard);
    console.log(`outcomes: ${shard.count} distinct recipe(s) from ${shard.rowsRead} record(s) → ${out}`);
    console.log(`  shard hash ${shard.hash.slice(0, 16)} · node ${shard.node} (${shard.platform})`);
    console.log("  every row is a LEAD (proven: false) until the same class is proven here by re-execution");
    process.exit(0);
  }
  if (args[0] === "absorb") {
    const file = args[1];
    if (!file) { console.error("valiant corpus absorb <shard.json>"); process.exit(2); }
    const r = absorb(file);
    if (!r.ok) { console.error(`corpus absorb: ${r.why}`); process.exit(2); }
    const s2 = storeSummary();
    console.log(`corpus absorb: +${r.added} new, ${r.seen} already known, from ${r.host} (${r.node})`);
    console.log(`  store: ${s2.total} recipe(s) from ${s2.nodes} node(s) · ${s2.unproven} still unproven here`);
    console.log(`  by verdict: ${Object.entries(s2.byVerdict).map(([k, v]) => `${k} ${v}`).join(" · ")}`);
    process.exit(0);
  }
  if (args[0] === "prove") {
    // Re-execute one lead HERE, where its file lives. A shard's word is not evidence — that is the difference between a
    // corpus and a rumour.
    const { prove } = await import("../src/ship.mjs");
    const key = args[1];
    if (!key) { console.error("valiant corpus prove <key> --repo <path>"); process.exit(2); }
    const ri = process.argv.indexOf("--repo");
    const repo = ri !== -1 && process.argv[ri + 1] ? resolve(process.argv[ri + 1]) : process.cwd();
    const r = await prove(key, repo);
    if (!r.ok) { console.error(`corpus prove: ${r.why}`); process.exit(2); }
    console.log(`corpus prove: ${r.row.diff.file} — ${r.verdict.result} HERE (the lead said ${r.row.verdict})`);
    console.log(`  ${r.verdict.detail}`);
    console.log(`  provenance kept: first seen on ${r.row.host} (${r.row.node})`);
    process.exit(r.verdict.result === "caught" ? 0 : 1);
  }
  if (args[0] === "promote") {
    const { promote } = await import("../src/ship.mjs");
    const apply = process.argv.includes("--apply");
    const ni = process.argv.indexOf("--min-nodes");
    const minNodes = ni !== -1 ? Number(process.argv[ni + 1]) : 2;
    const r = promote({ minNodes, apply });
    console.log(`corpus promote: ${r.ready.length} ready (proven here AND seen on >= ${minNodes} node(s)) · ${r.single.length} proven but on one node · ${r.leads.length} still a lead`);
    for (const c of r.ready.slice(0, 10)) console.log(`  [${c.proofVerdict}] ${c.diff.file} — ${String(c.diff.find).slice(0, 50)} · ${c.nodes.length} node(s)`);
    if (r.single.length) console.log(`  proven here, one node so far: ${r.single.slice(0, 3).map((u) => u.diff?.file).join(", ")} — absorb another node's shard`);
    if (r.leads.length) console.log(`  not promotable yet: ${r.leads.slice(0, 3).map((u) => `${u.diff?.file} (corpus prove ${u.key})`).join(", ")}`);
    if (!apply) { console.log("  nothing written — re-run with --apply to promote"); process.exit(0); }
    console.log(`  promoted ${r.applied} rule(s) → ${r.file}`);
    process.exit(0);
  }
  const s3 = storeSummary();
  if (!s3.total) { console.log("no absorbed leads yet — run: valiant corpus absorb <shard.json>"); process.exit(0); }
  const interesting = s3.rows.filter((r) => r.verdict === "survived" || r.verdict === "always-red");
  console.log(`  ${s3.total} recipe(s) from ${s3.nodes} node(s) · ${s3.unproven} unproven here`);
  for (const r of interesting.slice(0, 10)) console.log(`  [${r.verdict}] ${r.diff?.file} — ${String(r.diff?.find).slice(0, 50)}`);
  if (interesting.length > 10) console.log(`  … and ${interesting.length - 10} more`);
  process.exit(0);
}

if (process.argv[2] === "mcp") {
  const { serve } = await import("../src/mcp.mjs");
  serve();
  // THE SERVER OWNS THE PROCESS. Falling through to the command dispatcher made `valiant mcp` start the server and then
  // die with "unknown command" — the handshake worked and the client got nothing after it.
  await new Promise(() => { /* exited by serve() on stdin end */ });
} else if (process.argv[2] === "ui") {
  // THE CONTROL PANEL. A local, zero-dependency dashboard that mirrors the agent surface: run the tools, toggle
  // enforcement. It holds the process the same way `mcp` does — the server is the command.
  const { serve } = await import("../src/ui.mjs");
  const portArg = process.argv.indexOf("--port");
  const port = portArg !== -1 && process.argv[portArg + 1] ? Number(process.argv[portArg + 1]) : 8787;
  serve({ port });
  await new Promise(() => { /* server holds the process; Ctrl-C exits */ });
} else if (process.argv[2] === "pack" && process.argv.includes("--verify")) {
  const { verifyPack } = await import("../src/pack.mjs");
  const args2 = process.argv.slice(3);
  const dir = args2.find((a) => !a.startsWith("--")) ?? "valiant-pack";
  const r = verifyPack(dir);
  console.log(`  [${r.ok ? "PASS" : "FAIL"}] pack — ${r.detail}`);
  process.exit(r.ok ? 0 : 1);
}


// ── U-05: the tools that verify a repo need a licence ────────────────────────────────────────────────
//
// WHAT IS GATED: `verify` and `mutate` — the two commands that are the product.
// WHAT IS NEVER GATED: `status`, `licence` and `--revoked`, because you cannot install a licence from a
// tool that refuses to run without one. That ordering mistake would make the tool unbootable.
//
// THE ISSUER IS EXEMPT, and that is a rule rather than a special case: the machine holding the signing key
// can mint a licence at any time, so gating it proves nothing. `VALIANT_ISSUER_KEY` makes that testable —
// point it somewhere with no key and the gate has to fire.
const GATED = new Set(["verify", "mutate", "gate"]);
if (GATED.has(cmd)) {
  const { existsSync: x, readFileSync: r } = await import("node:fs");
  const { join: jj } = await import("node:path");
  const home = process.env.HOME || os.homedir();
  const storedPath = jj(home, ".valiant", "licence");
  const issuerKey = process.env.VALIANT_ISSUER_KEY || jj(home, ".valiant", "issuer-key.pem");
  const revokedPath = jj(home, ".valiant", "revoked.txt");
  // THE ISSUER EXEMPTION MUST BE A REAL KEY. It used to be `existsSync(issuerKey)`, so `touch` on
  // ~/.valiant/issuer-key.pem unlocked verify/mutate/gate: the paid boundary was a filename. The key must
  // now parse as a private key AND derive the public key this package ships.
  const issuerExempt = (() => {
    if (!x(issuerKey)) return false;
    try {
      const { createPrivateKey, createPublicKey } = crypto;
      const k = createPrivateKey(r(issuerKey, "utf8"));
      const derived = createPublicKey(k).export({ type: "spki", format: "pem" }).trim();
      const shipped = jj(dirname(fileURLToPath(import.meta.url)), "..", "licence-public.pem");
      const expected = x(shipped) ? r(shipped, "utf8").trim() : (process.env.VALIANT_LICENCE_KEY || "").trim();
      return expected.length > 0 && derived === expected;
    } catch { return false; }
  })();
  if (issuerExempt && x(storedPath)) {
    // THE ISSUER'S OWN MACHINE IS THE ONE ITS OWNER LOOKS AT, and it used to record nothing: the whole licence block is
    // skipped when you hold the key, so `licence --list` said "used 0" on the machine that issues the licences.
    try {
      const { verifyLicence } = await import("../src/licence.mjs");
      const pub = jj(dirname(fileURLToPath(import.meta.url)), "..", "licence-public.pem");
      const v2 = verifyLicence(r(storedPath, "utf8").trim(), { publicKeyPem: x(pub) ? r(pub, "utf8") : process.env.VALIANT_LICENCE_KEY });
      if (v2.ok) {
        const id = crypto.createHash("sha256").update(`${os.hostname()}|${os.platform()}|${os.arch()}`).digest("hex").slice(0, 16);
        const seatsPath = jj(home, ".valiant", "seats.json");
        let reg = { version: 1, licences: {}, machines: {} };
        try { reg = JSON.parse(r(seatsPath, "utf8")); } catch { /* first use */ }
        const key = String(v2.claims?.jti ?? "unknown");
        const used = reg.licences?.[key] ?? [];
        if (!used.includes(id)) {
          reg.licences = reg.licences ?? {};
          reg.licences[key] = [...used, id];
          reg.machines = reg.machines ?? {};
          reg.machines[id] = { host: os.hostname(), platform: os.platform(), arch: os.arch(), at: new Date().toISOString() };
          try { writeFileSync(seatsPath, JSON.stringify(reg, null, 2) + "\n", { mode: 0o600 }); } catch { /* read-only home */ }
        }
      }
    } catch { /* recording is best effort; it must never block the issuer */ }
  }
  if (!issuerExempt) {
    let ok = false;
    let why = "";
    let seatsIssue = "";
    if (x(storedPath)) {
      const { verifyLicence, describeLicence } = await import("../src/licence.mjs");
      // VERIFY AGAINST THE KEYRING, not just the newest key. `licence --status` already used `licence-keys/`, so after
      // a rotation the two commands disagreed: status said OK and the gate refused (independent review #6, F8).
      const { loadKeyring } = await import("../src/keyring.mjs");
      const dirKeys = jj(dirname(fileURLToPath(import.meta.url)), "..", "licence-keys");
      let pemList = [];
      try { pemList = Object.values(loadKeyring(dirKeys)).filter(Boolean); } catch { pemList = []; }
      const pub = jj(dirname(fileURLToPath(import.meta.url)), "..", "licence-public.pem");
      if (!pemList.length) pemList = [x(pub) ? r(pub, "utf8") : process.env.VALIANT_LICENCE_KEY];
      // AN EXPLICIT KEY WINS. Setting VALIANT_LICENCE_KEY is a deliberate act — an issuer driving a trial key, or a test proving the
      // chain end to end — and it used to be consulted only when NO key shipped, so the very act of naming a key was ignored and every
      // licence signed with it read as forged. The shipped keyring stays the default, not the authority.
      if (process.env.VALIANT_LICENCE_KEY) pemList = [process.env.VALIANT_LICENCE_KEY, ...pemList];

      // REVOCATION BLOCKS AFTER A GRACE PERIOD, NEVER INSTANTLY (Rob, 2026-10-30: "Block after grace"). The verifier is
      // told nothing about the list; the decision is made here, once, from `revocation.mjs`, so the gate and
      // `licence --status` cannot disagree about what a revoked licence does.
      // THE GATE ITSELF KEEPS THE LIST FRESH. A revocation that arrives only when someone remembers to run `licence --sync` arrives when
      // someone remembers — and the product promises 48 hours. This is best-effort and non-blocking: a 2-second cap, no failure ever
      // marks the gate, and the cache means an offline machine still knows what it knew. Opt out with VALIANT_NO_SYNC=1.
      try {
        const rv = await import("../src/revocation.mjs");
        if (process.env.VALIANT_NO_SYNC !== "1" && rv.needsRefresh()) {
          const src = process.env.VALIANT_SYNC_URL || rv.DEFAULT_SYNC_URL;
          const { syncRevocations: syncR } = rv;
          const timeout = new Promise((res) => setTimeout(() => res({ ok: false, why: "timed out" }), 2000));
          const attempt = syncR(src, { publicKeyPem: pemList[0], verifyLicence })
            .catch((e) => ({ ok: false, why: e.message }));
          const got = await Promise.race([attempt, timeout]);
          if (got?.ok) console.error(`valiant: revocation list refreshed (${got.total} known, +${got.added} new)`);
        }
      } catch { /* a list we cannot fetch must not stop a gate that can still run */ }
      const revokedFile = x(revokedPath) ? r(revokedPath, "utf8").split("\n").map((l) => l.trim()).filter(Boolean) : [];
      const cachedRv = await (async () => { try { const rv = await import("../src/revocation.mjs"); return rv.cachedRevocations(); } catch { return []; } })();
      const revokedUnion = [...new Set([...revokedFile, ...cachedRv])];
      const revoked = revokedUnion.length ? new Set(revokedUnion) : undefined;
      // TRY EVERY KEY, AND REPORT THE MOST USEFUL FAILURE. With a keyring, the right key says "expired 3 days ago" while the others
      // say "signature does not match" — and the loop used to keep the LAST answer, so an expired licence was reported as forged. A
      // wrong-key failure is uninformative; any other reason means the key matched and the claim is the problem, so it wins.
      let v = { ok: false, reason: "no key tried" };
      let best = null;
      for (const publicKeyPem of pemList) {
        let r2;
        try { r2 = verifyLicence(r(storedPath, "utf8").trim(), { publicKeyPem }); } catch (e) { r2 = { ok: false, reason: e.message }; }
        if (r2.ok) { v = r2; break; }
        const wrongKey = /signature does not match|does not carry/i.test(r2.reason);
        if (!best || (best.wrongKey && !wrongKey)) best = { ...r2, wrongKey };
        v = r2;
      }
      if (!v.ok && best) v = best;
      if (v.ok && revoked && v.claims?.jti && revoked.has(v.claims.jti)) {
        const { revocationState, revocationNotice } = await import("../src/revocation.mjs");
        const state = revocationState(v.claims.jti);
        if (state.state === "blocked") {
          v = { ok: false, reason: revocationNotice(v.claims.jti) };
        } else if (state.state === "grace") {
          // Loud, on every run, so the customer sees it before it stops — and recorded, so the evidence shows it was known.
          // ONE WARNING, FROM THE PARENT. The mutation phase runs each guard in its own child process, so the same
          // revocation would be announced once per guard — a message that repeats is a message people learn to skip.
          // Only the command a human ran announces it. The mutation phase spawns `mutate` children per guard, and each one
          // would repeat the same sentence — a message that repeats is a message people learn to skip.
          // …and a NESTED command inherits the environment, so the first process to say it marks the tree and the rest stay
          // quiet. Without this, `gate` → `verify` printed the same sentence twice.
          const alreadySaid = process.env.VALIANT_REVOCATION_GRACE === "1";
          const spoke = process.argv.slice(2).find((a) => !a.startsWith("-"));
          const isNested = !["gate", "verify", "enforce", "setup"].includes(spoke ?? "");
          const notice = revocationNotice(v.claims.jti, { once: true });
          if (notice && !isNested && !alreadySaid) console.error(`valiant: WARNING — ${notice}`);
          process.env.VALIANT_REVOCATION_GRACE = "1";
        }
      }
      // CARRIER 1: a licence that verified may carry the revocation list. Absorbing it here means a renewal email is also a
      // revocation update, and the list arrives on machines that will never call an endpoint.
      if (v.ok && Array.isArray(v.claims?.revocations) && v.claims.revocations.length) {
        try {
          const { absorbLicenceClaims } = await import("../src/revocation.mjs");
          absorbLicenceClaims(v.claims);
        } catch { /* a list we cannot store must not break the gate */ }
      }
      ok = v.ok;
      // KEEP THE REASON. An expired licence used to be reported as "needs a licence … buy one", which tells a
      // paying customer to buy again. Found by an independent review, 2026-10-26.
      if (!v.ok) why = `  this machine's licence is not valid: ${v.reason}`;
      if (v.ok) {
        // SEATS ARE ENFORCED, NOT PRINTED. A seat count that nothing checks is decoration; this tool records
        // the distinct machines a licence has been used on (locally, no server) and refuses past its seats.
        // RECORD EVERY MACHINE, ENFORCE ONLY WHEN THE PLAN HAS A CAP.
        // An unlimited plan used to skip this block entirely, so `licence --list` said "used 0" on a licence running on
        // every machine in the rig — the owner could not tell whether it was in use at all. Usage is now always
        // recorded; `seats > 0` is the only thing that can refuse.
        // AN EXPLICIT SEAT COUNT WINS ON EVERY PLAN. Enterprise used to force "unlimited" (0), so a licence bought as
        // 6 seats could never say 6 and nothing could be counted or refused. A licence that states its seats is held to
        // them; a licence that does not is uncapped only when its plan is enterprise.
        // ONE LICENCE = ONE MACHINE + ONE CI RUNNER (Rob, 2026-11-02): "a single licence should allow you to build with vvs
        // qa". The rule and the detection live in src/seats.mjs, so the gate, `licence --status` and `licence --list` cannot
        // disagree about what is being counted.
        {
          const { claimSeat, machineId } = await import("../src/seats.mjs");
          const id = machineId();
          const seatsPath = jj(home, ".valiant", "seats.json");
          let reg = { version: 1, licences: {} };
          try { reg = JSON.parse(r(seatsPath, "utf8")); } catch { /* first use */ }
          const result = claimSeat(v.claims, reg, { id, host: os.hostname(), platform: os.platform(), arch: os.arch() });
          if (!result.ok) {
            seatsIssue = result.issue;
          } else if (result.justAdded) {
            try { writeFileSync(seatsPath, JSON.stringify(reg, null, 2) + "\n", { mode: 0o600 }); } catch { /* read-only home */ }
          }
          if (result.kind === "runner") process.env.VALIANT_ON_RUNNER = "1";
          if (seatsIssue) ok = false;
        }
      }
    }
    if (!ok) {
      if (why) {
        // An EXPIRED licence must not be told to "buy one" — it is the same customer (review #6, F16).
        console.error(`valiant: ${why.replace(/^\s+/, "")}`);
        console.error("  renew or replace it:  valiant licence <vvs1.…>   (or --file <path>)");
        process.exit(2);
      }
      if (seatsIssue) { console.error(seatsIssue); process.exit(2); }
      console.error(`valiant: ${cmd} needs a licence on this machine.`);
      if (!seatsIssue) console.error("  install one:  valiant licence <vvs1.…>   (or --file <path>)");
      console.error("  check yours:  valiant licence --status");
      console.error("  obtain one:   ask your issuer for a licence file, then: valiant licence --file <path>");
      // A BLOCK STILL RECORDS WHY, EVEN WHEN IT NEVER GOT TO RUN. When this refusal happens inside an agent hook there is no verdict,
      // and the hook's own recorder is one layer up and may not run — measured on a node: the DSH hook recorded its deny, the Claude Stop
      // hook (which runs `gate` directly) left no row at all, because the gate exited here first.
      if (process.env.VALIANT_HOOK) {
        try {
          const { recordDecision } = await import("../src/receipts.mjs");
          recordDecision({ hook: process.env.VALIANT_HOOK, tool: "agent", command: null, verdict: "deny",
            reason: `${cmd} needs a licence on this machine — no verdict could be produced` });
        } catch { /* a record that cannot be written must not change the refusal */ }
      }
      process.exit(2);
    }
  }
}

const strictFlag = process.argv.includes("--strict");

// `licence` runs BEFORE the config is loaded: it must work in a directory with no valiant.json,
// because that is exactly where a customer first runs it (a fresh install, asking "is my key good?").
if (cmd === "enforce") {
  // ENFORCEMENT WHERE THE AGENT WORKS. `valiant mcp` lets an agent ask for the verdict; nothing makes it ask, so an agent
  // that never calls the tool reports "done" with the gate untouched. A Stop hook in Claude Code fires exactly when the
  // agent tries to finish, and a non-zero exit stops it with the reason attached.
  const { installClaude, installDsh, installGrokMcp, installChatGptMcp, status } = await import("../src/agents.mjs");
  const args = process.argv.slice(3);
  const cli = process.argv[1];
  if (args.includes("--hook")) {
    // A PreToolUse HOOK THAT READS ITS EVENT. Only a command that would CLAIM COMPLETION is gated; anything else is
    // allowed immediately, because blocking every tool call in every directory is how a correct gate becomes an unusable
    // one. Exit 0 = allow · exit 2 = block, with the reason on stderr (the convention both hosts use).
    const raw = await new Promise((resolve) => {
      let buf = "";
      if (process.stdin.isTTY) return resolve("");
      process.stdin.setEncoding("utf8");
      process.stdin.on("data", (c) => { buf += c; });
      process.stdin.on("end", () => resolve(buf));
      setTimeout(() => resolve(buf), 1500);   // a host that sends nothing must not hang the session
    });
    let event = {};
    try { event = JSON.parse(raw || "{}"); } catch { event = {}; }
    const cmd = String(event?.tool_input?.command ?? event?.command ?? "");
    const completion = /\bgit\s+(commit|push)\b|\bgh\s+pr\s+(create|merge)\b/.test(cmd);
    if (!completion) process.exit(0);
    if (!existsSync(join(process.cwd(), "valiant.json"))) process.exit(0);   // nothing adopted here: not our business

    // ENFORCED OR ADVISORY, decided HERE so the mode can be toggled without reinstalling the hook (Rob, 2026-11-02).
    const { effectiveStance } = await import("../src/enforcement.mjs");
    const { stance, source } = effectiveStance(process.cwd());

    const r = spawnSync(process.execPath, [process.argv[1], "gate"], { cwd: process.cwd(), stdio: ["ignore", "inherit", "inherit"] });
    const failed = (r.status ?? 2) !== 0;
    // ADVISORY: the gate still runs and still speaks, and nothing is blocked. The message is what makes advisory worth having —
    // an advisory hook that says nothing is indistinguishable from no hook at all.
    // RECORD THE DECISION. This hook blocked correctly and wrote nothing, so its blocks were numbers: no reason, no command, nothing a
    // stranger could re-check. The pre-push hook has recorded since the beginning; this one now does too, with the gate's own verdict as
    // the reason. A hook whose evidence exists only in a terminal scrollback has no evidence.
    const { recordDecision } = await import("../src/receipts.mjs");
    const record = (verdict, reason) => recordDecision({ hook: "pretooluse:gate", tool: "shell", command: cmd, verdict, reason });
    const lastVerdict = failed ? `gate exit ${r.status}` : "gate holds";
    if (stance === "advisory") {
      if (failed) {
        console.error(`valiant: ADVISORY — the gate does not hold (exit ${r.status}). This ${/push/.test(cmd) ? "push" : "commit"} was allowed; set enforced with: valiant enforce --mode enforced`);
        record("warn", `${lastVerdict} — allowed because the stance is advisory`);
      } else {
        record("allow", lastVerdict);
      }
      process.exit(0);
    }
    if (failed) {
      console.error(`valiant: the gate does not hold (exit ${r.status}) — this ${/push/.test(cmd) ? "push" : "commit"} would claim completion without a verdict.`);
      console.error(`  (mode: enforced, from ${source}. To stop blocking: valiant enforce --mode advisory)`);
      record("deny", `${lastVerdict} — ${/push/.test(cmd) ? "push" : "commit"} blocked in enforced stance`);
      process.exit(2);
    }
    record("allow", `gate holds — ${/push/.test(cmd) ? "push" : "commit"} allowed`);
    process.exit(0);
  }
  // THE TOGGLE. `valiant enforce --mode enforced|advisory` is state, not a reinstall, so it can be flipped in one command and
  // takes effect on the next tool call.
  const modeIdx = args.indexOf("--mode");
  if (modeIdx !== -1) {
    const { writeStance, effectiveStance } = await import("../src/enforcement.mjs");
    const want = args[modeIdx + 1];
    if (!want) {
      const cur = effectiveStance(repoRoot);
      console.log(`enforcement: ${cur.stance} (from ${cur.source})`);
      process.exit(0);
    }
    const r = writeStance(want === "advisory" ? "advisory" : want === "enforced" ? "enforced" : want);
    if (!r.ok) { console.error(`valiant enforce --mode: ${r.why}`); process.exit(2); }
    console.log(`enforcement: ${r.stance} — every installed hook reads this, no reinstall needed`);
    console.log(`  to change it back: valiant enforce --mode ${want === "enforced" ? "advisory" : "enforced"}`);
    process.exit(0);
  }
  if (args.includes("--status")) {
    const st = status(repoRoot);
    // THE STANCE COMES FIRST. "Installed" and "enforcing" are different facts: a hook that is installed in advisory mode blocks
    // nothing, and a status table that only says "installed" invites exactly that misreading.
    const { effectiveStance } = await import("../src/enforcement.mjs");
    const cur = effectiveStance(repoRoot);
    console.log(`  ${"enforcement stance".padEnd(28)} ${cur.stance.padEnd(38)} from ${cur.source}`);
    for (const [where, state, how] of st.rows) console.log(`  ${where.padEnd(28)} ${state.padEnd(38)} ${how}`);
    console.log(`\n  toggle: valiant enforce --mode enforced|advisory`);
    process.exit(0);
  }
  const host = args[args.indexOf("--install") + 1];
  if (!args.includes("--install") || !["claude", "dsh", "grok", "chatgpt"].includes(host)) {
    console.error("valiant enforce: choose a host — --install claude | dsh | grok | chatgpt   (or --status)");
    process.exit(2);
  }
  const r = host === "claude" ? installClaude(repoRoot, cli)
    : host === "dsh" ? installDsh(cli)
    : host === "grok" ? installGrokMcp(cli)
    : installChatGptMcp(cli);
  if (!r.ok) { console.error(`enforce: ${r.why}`); process.exit(2); }
  console.log(`enforce: ${r.already ? "already installed" : "installed"} — ${r.path}`);
  if (host === "claude" || host === "dsh") {
    console.log(`  the hook runs: valiant gate — a non-zero exit stops the agent and hands it the reason`);
    console.log(`  declare it so a silent hook is caught:  "hooks": ["${host === "claude" ? "stop" : "pretooluse"}:gate"]`);
  }
  console.log("  MCP wired — the agent now has five tools: valiant_gate, valiant_verify, valiant_ledger, valiant_outcomes, valiant_licence_status");
  if (host === "grok" || host === "chatgpt") console.log("  advisory only — tell the agent, once: 'before you report work done, call valiant_gate and report its exit code (0 holds, 1 broken, 2 could-not-check)'");
  process.exit(0);
}

if (cmd === "hooks") {
  // PUT THE GATE IN FRONT OF THE PUSH. Until now `gate` was a command nobody was required to run: the SDK repo has no
  // CI, so a PR merged while the gate read "a contract is broken". The receipts mechanism existed with nothing to record
  // from; this installs the hook and DECLARES it, so a hook that stops firing is caught by UNEXERCISED.
  const { install, status } = await import("../src/hooks.mjs");
  const args = process.argv.slice(3);
  const cli = process.argv[1];
  if (args.includes("--install")) {
    const r = install(repoRoot, cli);
    if (!r.ok) { console.error(`hooks: ${r.why}`); process.exit(2); }
    console.log(`hooks: ${r.already ? "refreshed" : "installed"} ${r.file}`);
    // Declare it, or the UNEXERCISED check has nothing to be quiet about.
    try {
      const { readFileSync: rf, writeFileSync: wf } = await import("node:fs");
      const cfgPath = join(repoRoot, "valiant.json");
      const cfg = JSON.parse(rf(cfgPath, "utf8"));
      cfg.hooks = [...new Set([...(cfg.hooks ?? []), "pre-push:gate"])];
      wf(cfgPath, `${JSON.stringify(cfg, null, 2)}\n`);
      console.log(`hooks: declared "pre-push:gate" in valiant.json (so UNEXERCISED catches it if it stops firing)`);
    } catch { console.log('hooks: could not declare it in the config — add "hooks": ["pre-push:gate"] by hand'); }
    console.log("  the hook runs: valiant gate — 1 (broken) and 2 (could not check) both block the push");
    process.exit(0);
  }
  const gateMode = args.includes("--gate");
  const { allHooks } = await import("../src/hooks.mjs");
  // THE AGENT HOOKS ARE MACHINE STATE, NOT REPO STATE. Checking them inside a repo's gate meant a repository failed because the *user's* global
  // ~/.dsh/hooks/hooks.json did not mention valiant — measured 2026-11-01: a clean fixture repo could not pass `valiant gate` for a reason that had
  // nothing to do with it. In gate mode only the repo's own hook decides; `valiant hooks` (no --gate) still reports every one.
  // IN GATE MODE, THE REPO'S OWN HOOKS DECIDE: the git pre-push and a repo-local .claude/settings.json. The machine-global DSH config is the
  // operator's own state and is only reported. An independent review caught the first version dropping BOTH agent hooks, which made a stale
  // repo-local Claude hook invisible to the gate.
  const all = allHooks(repoRoot).filter((h) => !gateMode || h.kind === "git" || h.kind === "agent-local");
  const st = status(repoRoot);
  console.log(`hooks: ${st.why}`);
  for (const h of all) {
    if (h.kind === "git" && !h.installed) continue;      // the summary line above already says it
    console.log(`  ${h.live ? "LIVE   " : "STALE  "} ${h.name.padEnd(10)} ${h.why}`);
    if (h.file) console.log(`           ${h.file}`);
  }
  const stale = all.filter((h) => h.installed && !h.live);
  if (stale.length) {
    console.log(`\n  ${stale.length} hook(s) installed but would not run. Reinstall: valiant hooks --install`);
    process.exit(1);
  }
  // IN THE GATE, ABSENT IS A WARNING AND STALE IS A FAILURE. A repo may enforce in CI and keep no local hook — that is a choice, and failing it
  // would push people to install a hook they do not want. A hook that EXISTS and would not run is the opposite: it looks like enforcement and
  // silently blocks nothing, which is the failure this whole check exists for.
  if (gateMode) {
    if (st.installed && st.ours) { process.exit(0); }
    console.log("  no local pre-push hook — enforcement here is by whoever runs the gate (CI, a person, an agent)");
    process.exit(0);
  }
  process.exit(st.installed && st.ours ? 0 : 1);
}

// `valiant doctor` — heal the chain. The enforcement is a CHAIN of signed/versioned artifacts — issuer key →
// licence → SOP baseline → corpus → hooks — and every link has a silent "went stale" failure mode: a key rotates,
// a corpus grows, a hook unmounts, and the gate reports red while nothing heals it. `doctor --fix` regenerates what
// can be regenerated and re-mounts what can be re-mounted, so a customer (who cannot re-mint or re-derive) has a
// machine that keeps itself working instead of accumulating staleness.
if (cmd === "doctor") {
  const { spawnSync } = await import("node:child_process");
  const fix = process.argv.includes("--fix");
  const quick = process.argv.includes("--quick");
  const schedule = process.argv.includes("--schedule");
  const unschedule = process.argv.includes("--unschedule");
  const me = process.argv[1];
  const sh = (args, opts = {}) => spawnSync(process.execPath, [me, ...args], { encoding: "utf8", ...opts });
  const tool = (args) => spawnSync(process.execPath, args, { cwd: repoRoot, encoding: "utf8" });
  const report = [];
  const mark = (tag, msg) => { report.push(msg); console.log(`  [${tag}] ${msg}`); };

  // SCHEDULE — install/remove the periodic self-heal, so staleness cannot accumulate between operator visits. A customer
  // who runs `setup` (or `doctor --schedule`) gets an hourly heal: regenerate, re-mount, and a light verify, forever.
  if (schedule || unschedule) {
    // PER-REPO MARK — one heal per repo. A single shared marker meant scheduling a second repo silently replaced the first.
    const MARK = `valiant-doctor:${basename(repoRoot)}`;
    if (process.platform === "win32") {
      const r = spawnSync("schtasks", unschedule
        ? ["/delete", "/tn", MARK, "/f"]
        : ["/create", "/tn", MARK, "/tr", `cmd /c "cd /d ${repoRoot} && "${process.execPath}" "${me}" doctor --fix --quick"`, "/sc", "hourly", "/f"], { encoding: "utf8" });
      console.log(r.status === 0 ? `doctor: ${unschedule ? "removed" : "installed"} the hourly self-heal (Windows Task Scheduler)` : `doctor: could not ${unschedule ? "remove" : "install"} the schedule — ${(r.stderr || r.stdout).slice(0, 160)}`);
    } else {
      let existing = "";
      try { existing = spawnSync("crontab", ["-l"], { encoding: "utf8" }).stdout ?? ""; } catch { /* no crontab yet */ }
      const lines = existing.split("\n").filter((l) => l.trim() && !l.includes(MARK));
      const entry = `0 * * * * cd ${JSON.stringify(repoRoot)} && ${process.execPath} ${me} doctor --fix --quick >/dev/null 2>&1 ${MARK}`;
      const next = unschedule ? lines.join("\n") + (lines.length ? "\n" : "") : [...lines, entry].join("\n") + "\n";
      const w = spawnSync("crontab", ["-"], { input: next, encoding: "utf8" });
      console.log(w.status === 0 ? `doctor: ${unschedule ? "removed" : "installed"} the hourly self-heal (crontab)` : `doctor: could not ${unschedule ? "remove" : "install"} the schedule — ${(w.stderr || w.stdout).slice(0, 160)}`);
    }
    process.exit(0);
  }

  // 1. The corpus is regenerated from the code that ships — never remembered.
  const corp = tool(["tools/corpus-sdk.mjs", "--write"]);
  mark(corp.status === 0 ? "ok" : "FAIL", `corpus doc ${corp.status === 0 ? "fresh" : `could not regenerate: ${(corp.stderr || corp.stdout).slice(0, 120)}`}`);
  const cov = tool(["tools/corpus-coverage.mjs", "--write"]);
  mark(cov.status === 0 ? "ok" : "FAIL", `coverage map ${cov.status === 0 ? "fresh" : `could not regenerate: ${(cov.stderr || cov.stdout).slice(0, 120)}`}`);

  // 2. SELF.json — the SDK's own hash.
  const self = sh(["selfcheck"], { cwd: repoRoot });
  mark(self.status === 0 ? "ok" : "FAIL", `self-hash ${self.status === 0 ? "intact" : (self.stderr || self.stdout).slice(0, 120)}`);

  // 3. The hooks — mounted, not just present.
  if (fix) {
    const hooks = sh(["hooks", "--install"], { cwd: repoRoot });
    mark(hooks.status === 0 ? "ok" : "FAIL", "push gate mounted");
    for (const host of ["claude", "dsh", "grok", "chatgpt"]) {
      const ef = sh(["enforce", "--install", host], { cwd: repoRoot });
      if (ef.status === 0) mark("ok", `${host} wired`);
    }
  } else {
    mark("check", "hooks not re-mounted (run with --fix to mount)");
  }

  // 4. The licence — verifies against the shipped keyring. Re-minting needs the issuer key, so it is reported, not guessed.
  const lic = sh(["licence", "--status"]);
  if (lic.status === 0) mark("ok", `licence ${lic.stdout.split("\n").filter(Boolean).pop() ?? "holds"}`);
  else mark("FAIL", `licence does not hold — ${(lic.stderr || lic.stdout).split("\n").filter(Boolean).slice(-1)[0] ?? "unknown"}`);

  // 5. The final verdict (skipped with --quick, so the hourly schedule heals without a 5-minute verify every hour).
  if (quick) {
    console.log("");
    console.log("doctor: heal done (--quick — full verify skipped)");
    process.exit(0);
  }
  const v = sh(["verify"], { cwd: repoRoot });
  const tail = (v.stdout || "").split("\n").filter((l) => /gates? passed|contract is broken/.test(l)).slice(-1)[0] ?? "";
  mark(v.status === 0 ? "ok" : "FAIL", `verify ${tail || `exit ${v.status}`}`);
  console.log("");
  if (v.status === 0) console.log("doctor: the chain is healthy");
  else { console.log("doctor: the chain is red — re-run with --fix, or fix what is named above"); }
  process.exit(v.status);
}

if (cmd === "setup") {
  // ONE COMMAND. `init` used to end by telling the user to add a guard, then run two more commands — four commands and a
  // paste, for a product whose whole claim is that it installs and works. `setup` does the licence, the config, the
  // proved guard, the proof and the verdict, and exits with the gate's own code so a script can branch on it.
  //
  // It never invents anything: if no guard can be proved, it says so and stops with 2 rather than reporting success.
  const { existsSync: sx } = await import("node:fs");
  const args = process.argv.slice(3);
  const licFlag = args.indexOf("--licence");
  let step = 0;
  const say = (msg) => console.log(`  ${++step}. ${msg}`);

  // SHELL OUT TO THE CLI'S OWN LICENCE COMMAND. Importing internals here would be a second implementation of licensing,
  // and the one that drifts is always the copy.
  const me = process.argv[1];
  const quiet = { cwd: repoRoot, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] };
  if (licFlag !== -1 && args[licFlag + 1]) {
    const r = spawnSync(process.execPath, [me, "licence", "--file", args[licFlag + 1]], quiet);
    const out = `${r.stdout ?? ""}${r.stderr ?? ""}`.trim().split("\n").filter(Boolean).pop() ?? "";
    if (r.status !== 0) { console.error(`setup: the licence was not installed — ${out}`); process.exit(2); }
    say(`licence installed — ${out}`);
  } else {
    const r = spawnSync(process.execPath, [me, "licence", "--status"], quiet);
    const out = (r.stdout ?? "").trim().split("\n").filter(Boolean).pop() ?? "";
    say(r.status === 0 ? `licence OK — ${out}` : "no licence on this machine (the gate will refuse until there is one)");
  }

  if (!sx(join(repoRoot, "valiant.json"))) {
    const r = spawnSync(process.execPath, [process.argv[1], "init"], { cwd: repoRoot, encoding: "utf8" });
    // THE GUARD'S NAME, not the first word after "guard". The output is prose with "guard" in it ("a guard has to be
    // watched to fail"), and the old regex reported the guard as "has" — visible on the very first run, in the line that
    // is meant to tell you what it just did.
    const adopted = /^\s*guard\s+(\S+)\s+—\s+added to/m.exec(r.stdout ?? "") ?? /guard\s{2,}(\S+)\s+—\s+added to/.exec(r.stdout ?? "");
    if (r.status !== 0) { console.error((r.stdout ?? "") + (r.stderr ?? "")); process.exit(2); }
    say(`config written${adopted ? `, guard "${adopted[1]}" adopted (already proved caught)` : " — no guard could be proved, see above"}`);
    if (!adopted) { console.error("setup: no guard could be proved in this repo, so there is nothing to verify yet."); process.exit(2); }
  } else {
    say("config already exists — left alone");
  }

  const mut = spawnSync(process.execPath, [process.argv[1], "mutate"], { cwd: repoRoot, encoding: "utf8" });
  const caught = /(\d+)\/(\d+) mutations caught/.exec(mut.stdout ?? "");
  say(caught ? `${caught[1]}/${caught[2]} guard(s) proved` : "proof step finished");

  // WIRE THE ENFORCEMENT. A customer who runs `setup` expects the gate to RUN, not to be told to run three more
  // commands it has never heard of. The pre-push hook is the repo-local half (blocks a red push); the agent hooks
  // are the machine-local half (block an agent at completion), installed best-effort for whichever host is present.
  const hk = spawnSync(process.execPath, [process.argv[1], "hooks", "--install"], { cwd: repoRoot, encoding: "utf8" });
  say(hk.status === 0 ? "push gate installed — a red verify now blocks the push" : "push gate not installed here — run `valiant hooks --install` in a git repo");
  for (const host of ["claude", "dsh", "grok", "chatgpt"]) {
    const ef = spawnSync(process.execPath, [process.argv[1], "enforce", "--install", host], { cwd: repoRoot, encoding: "utf8" });
    if (ef.status === 0) say(`${host}: MCP wired${host === "claude" || host === "dsh" ? " + gate hook" : " (advisory)"}`);
  }

  // THE HOURLY SELF-HEAL — so staleness cannot accumulate between operator visits. Best-effort: a machine with no
  // cron/schtasks just skips it, and the doctor is still runnable by hand.
  const sched = spawnSync(process.execPath, [process.argv[1], "doctor", "--schedule"], { cwd: repoRoot, encoding: "utf8" });
  if (sched.status === 0) say("hourly self-heal installed — the chain regenerates itself");

  console.log("");
  const gate = spawnSync(process.execPath, [process.argv[1], "gate"], { cwd: repoRoot, encoding: "utf8", stdio: ["ignore", "inherit", "inherit"] });
  process.exit(gate.status ?? 2);
}

if (cmd === "init") {
  // THE FIRST RUN. Everything else in this tool assumes a valiant.json exists; until now the only way to
  // get one was to hand-write JSON with gates, guards, ledger and prover semantics. This writes one from
  // what the repo ALREADY has, and refuses to invent a check it cannot see.
  const { existsSync: x } = await import("node:fs");
  const { writeFileSync: w, readFileSync: r } = await import("node:fs");
  const argv = process.argv.slice(3);
  const printOnly = argv.includes("--print");
  const force = argv.includes("--force");
  // `--config X` must be where init writes; accepting the flag and writing ./valiant.json is a silent lie.
  const cfgFlagInit = process.argv.indexOf("--config");
  const target = cfgFlagInit !== -1 && process.argv[cfgFlagInit + 1]
    ? resolve(process.argv[cfgFlagInit + 1])
    : join(repoRoot, "valiant.json");

  const gates = [];
  const pkgPath = join(repoRoot, "package.json");
  if (x(pkgPath)) {
    let pkg = null;
    try { pkg = JSON.parse(r(pkgPath, "utf8")); } catch { pkg = null; }
    const scripts = pkg?.scripts ?? {};
    // Only scripts a repo actually ships, in the order a reader would run them. A script that is not
    // there is not invented: an absent gate is honest, an invented one is the fault this tool catches.
    for (const name of ["test", "check", "lint", "typecheck", "build"]) {
      if (typeof scripts[name] === "string" && scripts[name].trim()) {
        const cmd = ["npm", "run", name];
        // PROBE IT ONCE. A gate that exits 0 with its only output on stderr reads as "suspect" and the first run on
        // a generated config is red for a reason the user did not cause (review #5, F7). If that is what happens,
        // declare the noise instead of handing them a config their own gate refuses.
        let noisy = false;
        try {
          // PROBE IN A COPY. Running the probe in the live repo let a test that writes coverage/ leave files behind
          // while init reported only "wrote valiant.json" (independent review #9, F2.4).
          const { mkdtempSync: mk, cpSync: cp } = await import("node:fs");
          const { tmpdir: td } = await import("node:os");
          // A COPY, NOT A LEAK. This probe never cleaned up: 927 copies (3.1 GB) were sitting in tmpdir on this Mac,
          // each one a complete unsabotaged copy of a customer repo — which a check could then diff itself against to
          // earn CAUGHT without ever reading the sabotage (independent review #12, F1/F2).
          const probeDir = mk(join(td(), "valiant-probe-"));
          try { cp(repoRoot, join(probeDir, "repo"), { recursive: true, filter: (f) => !/[\\/](\.git|node_modules|dist|build|target|\.venv|__pycache__|sops)$/.test(String(f)) }); } catch { /* empty repo */ }
          const probe = spawnSync(cmd[0], cmd.slice(1), { cwd: join(probeDir, "repo"), encoding: "utf8", timeout: 120000 });
          try { (await import("node:fs")).rmSync(probeDir, { recursive: true, force: true }); } catch { /* best effort */ }
          const err = (probe.stderr || "").split("\n").filter((l) => !/^(npm (notice|warn)|\s*$)/i.test(l)).join("").trim();
          noisy = probe.status === 0 && err.length > 0 && (probe.stdout || "").trim().length === 0;
        } catch { noisy = false; }
        gates.push({ name, cmd, ...(noisy ? { expectStderr: true } : {}) });
      }
    }
  }
  for (const [file, name] of [["scripts/run-tests.sh", "unit-tests"], ["scripts/check.sh", "check"]]) {
    if (x(join(repoRoot, file))) gates.push({ name: name === "check" && gates.some((g) => g.name === "check") ? "repo-check" : name, cmd: ["sh", file] });
  }

  // STACK PRESETS — layer 1 of PLAN-vvs-integrations.md. A repo that is not Node had no path through `init` at all.
  // Each preset reports a command that can be shown to EXIST in the tree; if none can, `init` refuses below exactly as
  // it always has. Never invented, because an invented gate fails the customer's first run for a reason they did not cause.
  if (!gates.length) {
    const { detectPresets } = await import("../src/presets.mjs");
    const found = detectPresets(repoRoot);
    for (const f of found) {
      gates.push({ name: f.name, cmd: f.cmd });
      console.log(`  found  ${f.stack.padEnd(16)} ${f.cmd.join(" ")}`);
    }
  }

  const ledgerCandidates = ["KNOWN-HAZARDS.md", "HAZARDS.md", "docs/KNOWN-HAZARDS.md", "HAZARD-LEDGER.md"];
  const ledger = ledgerCandidates.find((f) => x(join(repoRoot, f))) ?? null;
  const externalProver = x(join(repoRoot, "mutations.json"));

  if (!gates.length) {
    console.error("valiant init: I found no check to gate on, so I will not write a config that verifies nothing.");
    console.error("  I look for: package.json scripts (test/check/lint/typecheck/build), scripts/run-tests.sh, scripts/check.sh,");
    console.error("  and — for other stacks — pyproject/pytest/tox, pom.xml, build.gradle, *.csproj/*.sln, go.mod, Cargo.toml,");
    console.error("  composer.json, Gemfile/Rakefile, or a Makefile with a `test` target. None of those are here.");
    console.error("  A config with zero gates would report 'every contract holds' having checked nothing — that is the failure this tool exists to catch.");
    process.exit(2);
  }

  const cfg = {
    sops: true,   // adoption is DECLARED here; deleting sops/ then fails the gate instead of skipping it
    // No comments in JSON, so the config explains itself in one field.
    note: "Written by `valiant init` from the checks this repo already had. The SDK runs these; it never edits them. Add guards to prove a check can fail, and a RULE/GUARD ledger to record what has gone wrong before.",
    gates,
    ledger: ledger ?? false,
  };
  if (externalProver) cfg.prover = "external";

  const text = `${JSON.stringify(cfg, null, 2)}\n`;
  if (printOnly) { process.stdout.write(text); process.exit(0); }
  if (x(target) && !force) {
    console.error(`valiant init: ${target} already exists — refusing to overwrite it (use --force if you mean to).`);
    process.exit(1);
  }
  if (x(target) && force) {
    // OVERWRITING MUST NOT BE SILENT. A review showed --force eating a 12-guard config and describing only the
    // new file. Keep the old one, and say what it contained.
    let old = null;
    try { old = JSON.parse(r(target, "utf8")); } catch { old = null; }
    const backup = `${target}.bak`;
    w(backup, r(target, "utf8"));
    console.log(`kept the previous config at ${backup}`);
    if (old) {
      const g = (old.guards ?? []).length, ga = (old.gates ?? []).length;
      console.log(`  it had ${ga} gate(s), ${g} guard(s)${old.ledger ? `, ledger ${old.ledger}` : ""}${old.strict ? ", strict" : ""}`);
      if (g > 0) console.log("  the guards are the only proof this repo had — re-add them to the new config if you meant to keep them.");
    }
  }
  w(target, text);

  console.log(`wrote ${target}`);
  for (const g of gates) console.log(`  gate  ${g.name.padEnd(12)} ${g.cmd.join(" ")}`);
  console.log(`  ledger ${ledger ?? "none found — set \"ledger\": false until you have one"}`);
  if (externalProver) console.log("  prover external   mutations.json found, so its proofs are declared as this repo's own");
  const guards = 0;
  if (guards === 0) {
    // A stranger's install ended in a red gate and no way forward. Say the two commands, and offer a guard made
    // from a file that is actually in THIS repo — not a template they must fill in blind.
    // A subject the check actually reads, where one can be guessed: README.md is a trap because `npm test` does not
    // read it, so a guard built from it survives its own mutation (independent review #6, F13).
    // A SUGGESTION IS NOT A SUGGESTION UNTIL IT HAS GONE RED. The old placeholder pointed at package.json, which
    // `npm run test` does not read, so a customer's first attempt was SURVIVED — the tool blaming their check for the
    // suggestion's fault. Here a candidate is built from a module the test files import, then PROVED through the real
    // mutation engine; only a caught one is printed.
    const { candidateGuard } = await import("../src/guard-suggest.mjs");
    let candidateGuardObj = null;
    let candidateWhy = null;
    try {
      const cand = candidateGuard(repoRoot, gates[0]?.cmd ?? ["npm", "run", "test"]);
      if (!cand) candidateWhy = "I could not find a source file your check plausibly reads";
      else {
        const { runMutation } = await import("../src/mutate.mjs");
        const verdict = runMutation(cand, repoRoot);
        if (verdict?.result === "caught") candidateGuardObj = { ...cand, _proof: verdict.detail };
        else candidateWhy = `my best guess (${cand.file}) was ${String(verdict?.result ?? "not caught").toUpperCase()} — ${verdict?.detail ?? ""}`.trim();
      }
    } catch (e) { candidateWhy = `I could not build a guard here (${e.message})`; }

    console.log("\nnothing is proved yet — the gates run, but no guard has been seen to catch anything.");
    console.log("A guard is a change to one of your files that one of these checks must catch.");
    if (candidateGuardObj && !argv.includes("--no-adopt")) {
      // ADOPT IT. Asking a user to copy a JSON block out of the terminal and paste it into a file is four commands
      // pretending to be one, and it is where a first run goes wrong. The guard is already proved, so write it.
      const cfgNow = JSON.parse(r(target, "utf8"));
      cfgNow.guards = [{ invariant: candidateGuardObj.invariant ?? 15, backs: "the check this repo already had can fail (invariant 15: prove the check can fail)", name: candidateGuardObj.name, file: candidateGuardObj.file, find: candidateGuardObj.find, replace: candidateGuardObj.replace, check: candidateGuardObj.check }];
      (await import("node:fs")).writeFileSync(target, `${JSON.stringify(cfgNow, null, 2)}\n`);
      console.log(`\n  guard  ${candidateGuardObj.name} — added to ${target}, already proved caught:`);
      console.log(`         ${candidateGuardObj._proof}`);
      console.log(`         breaks  ${candidateGuardObj.file}: ${candidateGuardObj.find} → ${candidateGuardObj.replace}`);
      console.log("\n  next:  valiant gate            # every contract now has evidence");
      // AND THE SECOND HALF OF THE RULES: the nine that are about artefacts a repo produces. A new repo learns they exist here, because a
      // convention nobody is told about is a rule that stays prose.
      console.log("         valiant conventions      # which of the nine artefact rules are checked here, and which are only counted (docs/CONVENTIONS.md)");
    } else if (candidateGuardObj) {
      const snippet = { guards: [{ invariant: candidateGuardObj.invariant ?? 15, backs: "the check this repo already had can fail", name: candidateGuardObj.name, file: candidateGuardObj.file, find: candidateGuardObj.find, replace: candidateGuardObj.replace, check: candidateGuardObj.check }] };
      console.log(`\n  1. add this guard to ${target} — I have already proved it is caught:`);
      console.log("     " + JSON.stringify(snippet, null, 2).split("\n").join("\n     "));
      console.log("\n  2. run:  valiant mutate        # re-proves it, and writes mutations.json");
      console.log("  3. run:  valiant gate          # now every contract has evidence");
    } else {
      console.log(`\n  1. add a guard by hand to ${target} — pick a file one of your checks READS, and change something in it:`);
      console.log('     { "guards": [{ "name": "first-guard", "file": "<a file your check reads>", "find": "<a string in it, once>", "replace": "<what to break it to>", "check": <one of the gates above> }] }');
      if (candidateWhy) console.log(`     why I am not suggesting one: ${candidateWhy}`);
      console.log("\n  2. run:  valiant mutate        # it tells you CAUGHT or SURVIVED");
      console.log("  3. run:  valiant gate          # now every contract has evidence");
    }
  }
  // THE BASELINE IS NOT INSTALLED INTO THE REPO. It ships inside the SDK and is verified there, so adoption is the one
  // file this command just wrote — which is what the README says. (It used to copy sops/baseline+sig+sha and a
  // local.json into the repo, which made "one valiant.json" false and gave the customer three files to break.)
  if (!Array.isArray(JSON.parse(r(target, "utf8")).sopRules)) {
    const c = JSON.parse(r(target, "utf8"));
    c.sopRules = [];
    w(target, `${JSON.stringify(c, null, 2)}\n`);
  }
  console.log(`  sops      the signed baseline ships with the SDK; your own rules go in "${"sopRules"}"`);

  // F6: a stranger with no licence followed "next: valiant gate" into `needs a licence` and stopped there.
  const { existsSync: lx } = await import("node:fs");
  const hasLicence = lx(join(os.homedir(), ".valiant", "licence")) || !!process.env.VALIANT_ISSUER_KEY;
  if (!hasLicence) {
    console.log("\nnote: `mutate` and `gate` need a licence on this machine — `valiant licence --status` says what you have,");
    console.log("      and `valiant licence <key>` installs one. Everything above works without it.");
  }
  console.log("\nnext:  valiant gate");
  process.exit(0);
}

if (cmd === "sops") {
  // THE INSTALL-TIME SOP BOOTSTRAP. `valiant sops init` lays down the baseline (ours, immutable, hash-pinned)
  // and an empty local file for the customer's own rules. `valiant sops check` enforces both and refuses a
  // local rule that would weaken, shadow or disable a baseline one.
  const { initSops, loadSops: loadS, resolveRules: resolveS, BASELINE_CHECKS: CHECKS, baselineIntact } = await import("../src/sops.mjs");
  // ONE-SHOT: read the marker the gate wrote, then delete it. Anything older than two minutes, or naming another repo, is
  // ignored — a stale file must never be able to weaken a later run.
  const fresh = (() => {
    const p = process.env.VALIANT_FRESH;
    if (!p) return null;
    try {
      const d = JSON.parse(readFileSync(p, "utf8"));
      try { rmSync(p, { force: true }); } catch { /* best effort */ }
      if (Date.now() - Number(d.at ?? 0) > 120_000) return null;
      if (d.repo !== repoRoot) return null;
      return d;
    } catch { return null; }
  })();
  const { existsSync: x, readFileSync: r, writeFileSync: w, mkdirSync: mkd } = await import("node:fs");
  const sub = process.argv[3] ?? "check";
  const dir = join(repoRoot, "sops");

  if (sub === "init") {
    // ONE FILE. The baseline ships with the SDK, so init no longer lays one down; it makes sure valiant.json has a
    // `sopRules` array and folds any legacy sops/local.json rules into it.
    const legacyPath = join(dir, "local.json");
    let cfgNow = {};
    try { cfgNow = JSON.parse(r(configPath, "utf8")); } catch { cfgNow = {}; }
    if (!Array.isArray(cfgNow.sopRules)) cfgNow.sopRules = [];
    if (x(legacyPath)) {
      try {
        const legacy = JSON.parse(r(legacyPath, "utf8")).rules ?? [];
        const have = new Set(cfgNow.sopRules.map((r) => r.id));
        for (const rule of legacy) if (!have.has(rule.id)) cfgNow.sopRules.push(rule);
        console.log(`migrated ${legacy.length} rule(s) from sops/local.json into valiant.json`);
      } catch (e) {
        console.error(`sops/local.json could not be read (${e.message}) — fix it, then run this again`);
        process.exit(2);
      }
    }
    w(configPath, `${JSON.stringify(cfgNow, null, 2)}\n`);
    console.log(`valiant.json now carries ${cfgNow.sopRules.length} of your own SOP rule(s) under "sopRules"`);
    console.log("the baseline ships with the SDK — there is nothing to install and nothing in this repo to delete");
    if (x(legacyPath)) console.log("you can delete sops/ now: valiant sops check reads your rules from valiant.json");
    process.exit(0);
  }


  const sops = loadS(repoRoot, (() => { try { return JSON.parse(r(configPath, "utf8")); } catch { return {}; } })());
  if (sops?.invalid) {
    // A rule written as a bare object used to vanish and the gate stayed green (independent review #14, F5).
    console.error(`  [FAIL] baseline-provenance — ${sops.invalid}`);
    console.error("sops: " + sops.invalid);
    process.exit(1);
  }
  if (sops?.error) { console.error(`valiant sops: ${sops.error}`); process.exit(2); }
  if (!sops) {
    console.error(`valiant sops: the installed baseline is missing — reinstall the SDK (it ships one baseline, not a copy per repo)`);
    process.exit(2);
  }
  const resolved = resolveS(sops);
  const cfg = (() => { try { return loadConfig(configPath); } catch { return null; } })();
  const proofsDoc = (() => { try { return JSON.parse(r(join(repoRoot, "mutations.json"), "utf8")); } catch { return null; } })();
  const proofs = proofsDoc?.proofs ?? [];
  const evidenceMod = await import("../src/evidence.mjs");
  const { runAllGates } = await import("../src/gates.mjs");
  const mutateMod = await import("../src/mutate.mjs");
  const cache = {};
  const ctx = {
    repoRoot, cfg, proofs, proofsDoc, sops, unenforced: resolved.unenforced, evidence: evidenceMod, fresh,
    // The sample is re-executed once per invocation, not once per rule.
    verifyEvidence: () => evidenceMod.verifyExternalEvidence({ repoRoot, k: 3, prover: cfg?.proverCmd ?? "node scripts/mutate-guards.mjs", cache }),
    runMutations: (guards) => {
      if (!cache.mut) {
        const { runAllMutations } = mutateMod;
        cache.mut = null;
        // A DEADLINE MAKES AN UNATTENDED RUN END BY ITSELF. 0 (the default) waits; CI passes --timeout so a wedged child
        // cannot hold a runner and block every job behind it.
        const mins = Number((() => { const i = process.argv.indexOf("--timeout"); return i !== -1 ? process.argv[i + 1] : (process.env.VALIANT_TIMEOUT_MINUTES ?? 0); })());
        const deadline = Number.isFinite(mins) && mins > 0 ? Date.now() + mins * 60000 : 0;
        cache.runFor = (gs) => runAllMutations(gs, repoRoot, { deadline });
      }
      const res = cache.runFor(guards);
      if (Array.isArray(res) && res.some((r) => r?.timedOut)) process.exit(124);
      return res;
    },
    fresh,
    runGates: () => {
      if (fresh?.gates === true) {
        // SAY WHAT ACTUALLY HAPPENED, with the real count: the verify segment ran them and reported each by name.
        const n = Number(fresh.gateCount ?? 0);
        return { ok: true, passed: n, total: n, detail: `${n} gate(s) ran in this invocation — the verify segment above reported each one by name` };
      }
      if (!cache.gates) {
        const res = runAllGates(cfg?.gates ?? [], repoRoot);
        const passed = res.filter((r) => r.ok).length;
        const failed = res.filter((r) => !r.ok);
        cache.gates = { ok: failed.length === 0, passed, total: res.length, detail: failed.length ? `${failed.length} gate(s) failed: ${failed.slice(0, 2).map((f) => f.name).join(", ")}` : `${passed}/${res.length} gate(s) ran and passed` };
      }
      return cache.gates;
    },
  };

  if (sub === "list") {
    for (const rule of sops.baseline.rules) console.log(`  baseline  ${rule.id.padEnd(30)} ${rule.title}`);
    for (const rule of resolved.enforced) console.log(`  local     ${String(rule.id).padEnd(30)} ${rule.title ?? ""}  → ${rule.check.join(" ")}`);
    for (const rule of resolved.unenforced) {
      const hasCheck = Array.isArray(rule.check) && rule.check.length > 0;
      console.log(`  accepted  ${String(rule.id).padEnd(30)} ${rule.title ?? ""}  (${hasCheck ? "its check is never shown to be able to fail" : "no check"} — counted, not enforced)`);
    }
    // A list that says "6 baseline" while `sops check` is red is paste-able evidence of adoption that is not
    // true. It runs the checks and reports the same verdict.
    let failed = resolved.conflicts.length;
    // The provenance check FIRST, selected from outside the file it protects — `list` used to iterate only the
    // rules inside baseline.json, so deleting B4 made an edited baseline "hold" (review #4, F5).
    if (!baselineIntact(sops).ok) failed++;
    for (const rule of sops.baseline.rules) {
      const fn = CHECKS[rule.enforcedBy];
      if (!fn || !(await fn(ctx)).ok) failed++;
    }
    // …and the same local-rule proof `sops check` runs, so list cannot print a green over a red rule (F4).
    for (const rule of resolved.enforced) {
      const proof = (await import("../src/sops.mjs")).proveLocalRule(rule, repoRoot);
      if (!proof.ok) failed++;
    }
    console.log(`\n${sops.baseline.rules.length} baseline · ${resolved.enforced.length} local enforced · ${resolved.unenforced.length} accepted-unenforced`);
    console.log(failed === 0 ? "verdict: the baseline holds" : `verdict: ${failed} rule(s) are not satisfied — run: valiant sops check`);
    process.exit(failed === 0 ? 0 : 1);
  }

  let bad = 0;
  const intact = baselineIntact(sops);
  if (!intact.ok) {
    console.log(`  [FAIL] baseline-provenance — ${intact.reason}`);
    console.log("         the SDK's own files have been edited; reinstall it — a customer copy is not a baseline anybody can trust");
    bad++;
  } else {
    console.log(`  [PASS] baseline-provenance — signed by this SDK's key (sha256 ${intact.sha.slice(0, 12)})`);
  }
  if (resolved.conflicts.length) {
    for (const c of resolved.conflicts) console.log(`  [CONFLICT] ${c.rule} — ${c.why}`);
    bad++;
  } else {
    console.log(`  [PASS] no local rule conflicts with the baseline`);
  }
  for (const rule of sops.baseline.rules) {
    const fn = CHECKS[rule.enforcedBy];
    if (!fn) { console.log(`  [FAIL] ${rule.id} — the SDK does not ship the check "${rule.enforcedBy}"`); bad++; continue; }
    const res = await fn(ctx);
    if (!res.ok) bad++;
    console.log(`  ${res.ok ? "[PASS]" : "[FAIL]"} ${rule.id} — ${res.detail}`);
  }
  for (const rule of resolved.enforced) {
    // ENFORCED MEANS PROVEN BOTH WAYS, not just "its check exited 0" — an always-green check is a claim.
    const proof = (await import("../src/sops.mjs")).proveLocalRule(rule, repoRoot);
    if (!proof.ok) bad++;
    console.log(`  ${proof.ok ? "[PASS]" : "[FAIL]"} local:${rule.id} — ${proof.why}`);
  }
  for (const rule of resolved.unenforced) {
    const hasCheck = Array.isArray(rule.check) && rule.check.length > 0;
    if (!hasCheck) { console.log(`  [counted] local:${rule.id} — no check: nothing enforces this`); continue; }
    // It HAS a check. Run it once: a red check with no sabotage proves nothing, and that is a finding, not a footnote.
    // IN A COPY. This ran in the LIVE repo on every gate, so a rule's check could leave files in the customer's tree
    // (independent review #12 F8, which I recorded as fixed and had not; confirmed again as #13 F3).
    const probeDir = mkdtempSync(join(tmpdir(), "valiant-probe-"));
    let probe = { status: 0 };
    try {
      cpSync(repoRoot, join(probeDir, "repo"), { recursive: true, filter: (q) => !/[\\/](\.git|node_modules|dist|build|target|\.venv|__pycache__|sops)$/.test(String(q)) });
      probe = spawnSync(rule.check[0], rule.check.slice(1), { cwd: join(probeDir, "repo"), encoding: "utf8" });
    } catch { /* an unreadable repo shows as a pass below, which is the conservative answer for counting */ }
    finally { try { rmSync(probeDir, { recursive: true, force: true }); } catch { /* best effort */ } }
    const sab = rule.sabotage ?? {};
    const shape = !sab.file ? "no sabotage declared"
      : String(sab.file).includes("..") ? "its sabotage points outside the repo"
      : `its sabotage (${sab.file}) is not a readable file with exactly one match`;
    if ((probe.status ?? 0) !== 0) {
      bad++;
      console.log(`  [FAIL] local:${rule.id} — its check is red (exit ${probe.status}) and ${shape} — a red check with no sabotage proves nothing`);
    } else {
      console.log(`  [counted] local:${rule.id} — its check passes, but ${shape}, so nothing shows it can fail`);
    }
  }
  const noEvidence = !(ctx.proofs ?? []).length;
  if (bad > 0 && noEvidence) {
    console.log("\n      these rules are waiting for your first proof, not broken: with no mutations.json there is");
    console.log("      nothing yet that could be shown to fail. Run: valiant mutate");
  }
  console.log(`\nsops: ${bad === 0 ? "the baseline holds and no local rule conflicts" : "a rule is broken or conflicting"} — ${resolved.enforced.length} local enforced, ${resolved.unenforced.length} accepted-unenforced`);
  // Draining here too: `sops` can run a local rule's check, and a machine that only reviews its SOPs should not accumulate a queue.
  // (This block first landed here because its anchor matched the wrong command — `mutate` had none, which the queue proved.)
  try {
    const { maybeFlush, consent } = await import("../src/consent.mjs");
    const c = consent();
    if (c.enabled) await maybeFlush({ installId: c.installId });
  } catch { /* collection must never affect the verdict */ }
  process.exit(bad === 0 ? 0 : 1);
}

if (cmd === "sample-proofs") {
  // The command the external-prover rule points at. It shipped as a dev tool (`tools/sample-proofs.mjs`) that a
  // customer never gets, so the advice named something they could not run.
  const argv = process.argv.slice(3);
  const num = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] ? Number(argv[i + 1]) : d; };
  if (argv.includes("--prover")) {
    // A caller-supplied prover command can be made to print "caught" and be recorded as a reproduction (review #6,
    // F11). The SDK re-runs the proofs itself now; this flag would only re-introduce the hole.
    console.error("valiant sample-proofs: --prover is not accepted — the SDK re-runs each proof itself, from its own recipe");
    process.exit(2);
  }
  // IT RE-RUNS THE PROOFS ITSELF. This command used to exec the repo's own prover and grep its stdout for "caught",
  // so a three-line script printing that word was recorded as "re-executed" (independent review #8, D).
  const { verifyExternalEvidence } = await import("../src/evidence.mjs");
  const ev = await verifyExternalEvidence({ repoRoot, k: num("--k", 3) });
  console.log(ev.ok ? `  ${ev.detail}` : `  [FAIL] ${ev.reason}`);
  process.exit(ev.ok ? 0 : 2);
}

if (cmd === "method") {
  // The operating rules that make an agent consistent between sessions: memory, verification, build order,
  // reporting. Shipped because they are the part every team rewrites badly and nobody publishes.
  const args = process.argv.slice(3);
  const here = join(dirname(fileURLToPath(import.meta.url)), "..");
  const file = join(here, "corpus", "seed-method.json");
  if (!existsSync(file)) {
    console.error("method: the method corpus is missing from this build");
    process.exit(2);
  }
  let m;
  try {
    m = JSON.parse(readFileSync(file, "utf8"));
  } catch (e) {
    console.error(`method: the method corpus is not valid JSON (${e.message})`);
    process.exit(1);
  }
  const rules = Array.isArray(m.method) ? m.method : [];

  if (args.includes("--check")) {
    // ENFORCE THE CORPUS, NOT JUST PRINT IT. The method shipped as a printable doc, so a malformed or incomplete
    // corpus was invisible — a doc nobody reads fails nobody. The gate now checks it: every rule carries the fields
    // the printed METHOD.md depends on, an id never repeats, and no group is empty.
    const GROUPS = ["memory", "verify", "build", "report"];
    const problems = [];
    const seen = new Set();
    for (const r of rules) {
      const id = typeof r?.id === "string" ? r.id.trim() : "";
      if (!id) { problems.push("a rule with no id"); continue; }
      if (seen.has(id)) problems.push(`duplicate rule id "${id}"`);
      seen.add(id);
      if (typeof r?.name !== "string" || !r.name.trim()) problems.push(`${id}: missing name`);
      if (typeof r?.rule !== "string" || !r.rule.trim()) problems.push(`${id}: missing rule text`);
      if (!GROUPS.includes(r?.group)) problems.push(`${id}: group "${r?.group}" is not one of ${GROUPS.join(", ")}`);
    }
    for (const g of GROUPS) {
      if (!rules.some((r) => r?.group === g)) problems.push(`no rules in group "${g}"`);
    }
    if (problems.length) {
      for (const p of problems) console.error(`  [FAIL] ${p}`);
      console.error(`method: ${problems.length} problem(s) in the corpus — fix corpus/seed-method.json`);
      process.exit(1);
    }
    console.log(`  [PASS] method — ${rules.length} rules, ${GROUPS.length} groups, no duplicates`);
    process.exit(0);
  }

  if (args.includes("--install")) {
    // A file a customer can include in their own agent instructions. Written, not printed, because "include
    // this in your config" is the step people skip.
    const dir = join(process.env.HOME || os.homedir(), ".valiant");
    mkdirSyncRecursive(dir);
    const out = join(dir, "METHOD.md");
    const lines = ["# Operating method", "", m.intro, ""];
    for (const g of ["memory", "verify", "build", "report"]) {
      const group = rules.filter((r) => r.group === g);
      if (!group.length) continue;
      lines.push(`## ${g.toUpperCase()}`, "");
      for (const r of group) lines.push(`- **${r.id} ${r.name}** — ${r.rule}`);
      lines.push("");
    }
    writeFileSync(out, lines.join("\n"));
    console.log(`method: ${rules.length} rules written to ${out}`);
    console.log("  include it in your agent instructions, or read it before a review");
    process.exit(0);
  }

  const groupFilter = args.find((a) => ["memory", "verify", "build", "report"].includes(a));
  if (args.includes("--count")) {
    console.log(`method: ${rules.length} rules`);
    process.exit(0);
  }
  console.log(`\nOperating method — ${rules.length} rules\n`);
  for (const r of rules) {
    if (groupFilter && r.group !== groupFilter) continue;
    console.log(`  ${r.id}  ${r.name}`);
    console.log(`      ${r.rule}`);
  }
  console.log("\n  install a copy: valiant method --install");
  process.exit(0);
}

if (cmd === "corpus" && process.argv.includes("--coverage")) {
  // WHAT THE CORPUS ACTUALLY ENFORCES. Rob, 2026-11-02: "are all the current corpus entries here actually enforcable gates or are
  // they just sitting there". The honest answer is a count, computed from the ledger that names GUARDs — the shipped corpus is a
  // catalogue of hazards, and the ledger is the only part that can fail a build.
  const { readFileSync: rf, existsSync: ex } = await import("node:fs");
  const { join: jp } = await import("node:path");
  const shipped = JSON.parse(rf(jp(dirname(fileURLToPath(import.meta.url)), "..", "corpus", "seed-hazards.json"), "utf8"));
  const hazards = Array.isArray(shipped) ? shipped : shipped.hazards ?? [];
  const ledgerPath = process.argv.includes("--ledger") ? process.argv[process.argv.indexOf("--ledger") + 1] : jp(repoRoot, "KNOWN-HAZARDS.md");
  const ledgerText = ex(ledgerPath) ? rf(ledgerPath, "utf8") : "";
  const entries = ledgerText.split(/\n## /).slice(1);
  const withGuard = entries.filter((e) => /^- GUARD:/m.test(e)).length;
  const withReplay = entries.filter((e) => /^- REPLAY:/m.test(e)).length;
  console.log(`corpus: ${hazards.length} hazard(s) shipped as knowledge (title + rule + invariant)`);
  console.log(`        ${hazards.length - hazards.filter((h) => h.guard || h.check).length} of them carry NO guard of their own`);
  const { readdirSync: rdir } = await import("node:fs");
  const refDir = jp(dirname(fileURLToPath(import.meta.url)), "..", "corpus", "reference-guards");
  const refGuards = ex(refDir) ? rdir(refDir).filter((f) => f.endsWith(".mjs")).length : 0;
  console.log(`guards: ${refGuards} reference guard(s) in corpus/reference-guards/, each run by the \`corpus-guards\` gate`);
  console.log(`ledger: ${entries.length} entr(ies) in ${ledgerPath}`);
  console.log(`        ${withGuard} with a GUARD, ${withReplay} with a REPLAY command — these are the enforceable ones`);
  console.log("");
  console.log(`enforceable today: ${refGuards} reference guard(s) + ${withGuard} ledger entr(ies) with a GUARD`);
  console.log(`the other ${hazards.length} shipped hazards are a catalogue: enforcing one means writing a guard and proving it can fail`);
  process.exit(0);
}
if (cmd === "corpus" && process.argv.includes("--consent")) {
  const { consent, optOut, queueDepth, flush } = await import("../src/consent.mjs");
  const c = consent();
  console.log(`corpus collection: ${c.enabled ? "ON" : "OFF"} (${c.why})`);
  console.log(`  what is sent: a salted recipe hash, the verdict, the trial count, the shape of the check — never your code`);
  console.log(`  queued locally: ${queueDepth()} observation(s)`);
  console.log(`  turn it off:  valiant corpus --consent --off      turn it back on:  valiant corpus --consent --on`);
  if (process.argv.includes("--flush")) {
    const r = await flush({ installId: c.installId });
    console.log(r.ok ? `  flushed ${r.sent} (${r.remaining ?? 0} left)` : `  not flushed: ${r.why}`);
  }
  process.exit(0);
}
if (cmd === "corpus" && (process.argv.includes("--off") || process.argv.includes("--on"))) {
  // Turning it back ON is not the same code path as opting out: one writes a refusal, the other withdraws it, and a shared
  // helper that does both is how "off" and "on" end up meaning the same thing.
  const { optOut, readConsentFile, enable } = await import("../src/consent.mjs");
  const on = process.argv.includes("--on");
  const r = on ? enable() : optOut({ why: "opted out from the CLI" });
  if (!r.ok) { console.error(`valiant corpus ${on ? "--on" : "--off"}: ${r.why}`); process.exit(2); }
  console.log(on
    ? "corpus collection: ON — a salted recipe hash, the verdict and the shape of the check; never your code"
    : "corpus collection: OFF on this machine — nothing is queued or sent");
  process.exit(0);
}
if (cmd === "corpus" && process.argv.includes("--publish")) {
  // PUBLISH THE FEED THE SITE SELLS. The page has said "the corpus arrives as a signed, dated feed, so it grows after the sale" since October, and a
  // feed did exist — signed with the RETIRED key, dated 2026-10-26, carrying 41 invariants while the corpus held 43. Nobody regenerated it because
  // nothing could: publishing was a hand-built payload.
  const { signCorpusFile, verifyCorpusFeed } = await import("../src/corpus-feed.mjs");
  const { readFileSync: rf, writeFileSync: wf, readdirSync: rd, existsSync: ex } = await import("node:fs");
  const { createPublicKey } = await import("node:crypto");
  const load = (rel, pick) => { const d = JSON.parse(rf(join(repoRoot, rel), "utf8")); return pick(d); };
  const method = load("corpus/seed-method.json", (d) => d.method ?? d.methods ?? d.rules ?? []);

  // THE KID IS DERIVED FROM THE KEY, NOT TYPED. A hard-coded "vvs-2026-11" signed happily with a retired key and reported success (an independent
  // review reproduced exactly that on 2026-11-02), and two publishers disagreed about the default. Matching the private key's public half against
  // the shipped keyring gives the kid the key actually is — or none, which is a refusal.
  // THE DOCUMENTED VARIABLE IS `VALIANT_ISSUER_KEY` — every other signing path uses it (tools/issuer.mjs, licence minting, docs/OPERATING.md).
  // This one read `VALIANT_ISSUER_KEY_PATH` only, so an operator following the documented convention had their override silently dropped: an
  // independent review demonstrated it signing with the current key while the retired one was named (2026-11-02). Both names are accepted.
  const keyPath = process.env.VALIANT_ISSUER_KEY || process.env.VALIANT_ISSUER_KEY_PATH || join(process.env.HOME ?? "", ".valiant", "issuer-key.pem");
  if (!ex(keyPath)) {
    console.error(`corpus --publish: no issuer key at ${keyPath} — the feed must be signed, and an unsigned one is not the product.`);
    process.exit(2);
  }
  const priv = rf(keyPath, "utf8");
  const keysDir = join(repoRoot, "licence-keys");
  const derOf = (pem) => createPublicKey(pem).export({ type: "spki", format: "der" });
  let kid = null;
  let privDer = null;
  try { privDer = derOf(priv); } catch (e) { console.error(`corpus --publish: the key at ${keyPath} is not a readable private key (${e.message})`); process.exit(2); }
  try {
    for (const f of rd(keysDir)) {
      if (!f.endsWith(".pem")) continue;
      if (Buffer.compare(derOf(rf(join(keysDir, f), "utf8")), privDer) === 0) { kid = f.replace(/\.pem$/, ""); break; }
    }
  } catch { kid = null; }
  if (!kid) {
    console.error(`corpus --publish: the key at ${keyPath} matches no public key this SDK ships, so the feed it produced would not verify anywhere.`);
    console.error("  Publish with the issuer key that belongs to a kid in licence-keys/.");
    process.exit(2);
  }
  // RETIRED IS DECLARED, NOT GUESSED. The first version matched /retired/ against the kid and passed "vvs-2026-10" — the file is named
  // issuer-key-retired-2026-10.pem but the kid carries no such word (an independent review's repro). The keyring now states which kids are current.
  const statusPath = join(keysDir, "status.json");
  let retired = [];
  try { retired = JSON.parse(rf(statusPath, "utf8")).retired ?? []; } catch { retired = []; }
  if (retired.includes(kid)) {
    console.error(`corpus --publish: ${kid} is RETIRED (declared in licence-keys/status.json) — a feed signed with it stops verifying the day the old`);
    console.error("  public half is dropped. Publish with the current key.");
    process.exit(2);
  }

  const corpusObj = {
    // THE FEED'S DATE IS THE CORPUS DATE. `new Date()` let a re-signature advance the version while the content was unchanged — the opposite of a
    // feed a customer can pin, and it contradicted this file's own rationale (an independent review's N2). The seeds carry the date.
    version: (() => { try { return load("corpus/seed-hazards.json", (d) => d.version) ?? new Date().toISOString().slice(0, 10); } catch { return new Date().toISOString().slice(0, 10); } })(),
    kid,
    invariants: load("corpus/seed-invariants.json", (d) => (Array.isArray(d) ? d : d.invariants)),
    hazards: load("corpus/seed-hazards.json", (d) => (Array.isArray(d) ? d : d.hazards)),
    method,
    referenceGuards: (() => { try { return rd(join(repoRoot, "corpus", "reference-guards")).filter((f) => f.endsWith(".mjs")).map((f) => f.replace(/\.mjs$/, "")).sort(); } catch { return []; } })(),
  };
  const token = signCorpusFile(corpusObj, priv);

  // VERIFY BEFORE WRITING. Signing and then trusting the signature is how a wrong-key feed reported success.
  const keyring = {};
  try { for (const f of rd(keysDir)) if (f.endsWith(".pem")) keyring[f.replace(/\.pem$/, "")] = rf(join(keysDir, f), "utf8"); } catch { /* no keyring */ }
  const check = verifyCorpusFeed(token, { keyring });
  if (!check.ok) {
    console.error(`corpus --publish: the feed it just signed does NOT verify (${check.reason}) — nothing written.`);
    process.exit(2);
  }
  const outAt = process.argv.indexOf("--out");
  if (outAt !== -1 && process.argv[outAt + 1]) {
    wf(process.argv[outAt + 1], token + "\n");
    console.log(`corpus --publish: ${corpusObj.invariants.length} invariants, ${corpusObj.hazards.length} hazards, ${method.length} method rules`);
    console.log(`  kid ${kid} · version ${corpusObj.version} · verified against the shipped keyring · written to ${process.argv[outAt + 1]}`);
  } else {
    process.stdout.write(token + "\n");
  }
  process.exit(0);
}

if (cmd === "corpus") {
  // absorb <shard>: merge another node's observations into the local corpus store. A shard is checked for shape and hash,
  // and what arrives is marked as a LEAD, not a rule.
  const absorbArgs = process.argv.slice(3);
  if (absorbArgs[0] === "absorb") {
    const { absorb, storeSummary } = await import("../src/ship.mjs");
    const file = absorbArgs[1];
    if (!file) { console.error("valiant corpus absorb <shard.json>"); process.exit(2); }
    const r = absorb(resolve(file));
    if (!r.ok) { console.error(`corpus absorb: ${r.why}`); process.exit(2); }
    const s2 = storeSummary();
    console.log(`corpus absorb: +${r.added} new, ${r.seen} already known, from ${r.host} (${r.node})`);
    console.log(`  store: ${s2.total} recipe(s) from ${s2.nodes} node(s) · ${s2.unproven} still unproven here`);
    console.log(`  by verdict: ${Object.entries(s2.byVerdict).map(([k, v]) => `${k} ${v}`).join(" · ")}`);
    process.exit(0);
  }
  if (absorbArgs[0] === "leads") {
    const { storeSummary } = await import("../src/ship.mjs");
    const s2 = storeSummary();
    if (!s2.total) { console.log("no absorbed leads yet — run: valiant corpus absorb <shard.json>"); process.exit(0); }
    const interesting = s2.rows.filter((r) => r.verdict === "survived" || r.verdict === "always-red");
    console.log(`  ${s2.total} recipe(s) from ${s2.nodes} node(s) · ${s2.unproven} unproven here`);
    for (const r of interesting.slice(0, 10)) console.log(`  [${r.verdict}] ${r.diff?.file} — ${String(r.diff?.find).slice(0, 50)}  (${r.verdict} on ${r.host})`);
    if (interesting.length > 10) console.log(`  … and ${interesting.length - 10} more`);
    process.exit(0);
  }
  // The corpus as a feed: what a licensee gains after the sale. Not gated - status must always work, and
  // installing a feed is how the rules they paid for arrive.
  const { verifyCorpusFeed, installFeed, installedFeeds, latestFeed } = await import("../src/corpus-feed.mjs");
  const { loadKeyring } = await import("../src/keyring.mjs");
  const args = process.argv.slice(3);
  const home = process.env.HOME || os.homedir();
  const keyring = loadKeyring(join(dirname(fileURLToPath(import.meta.url)), "..", "licence-keys"));
  const single = (() => {
    const p = join(dirname(fileURLToPath(import.meta.url)), "..", "licence-public.pem");
    return existsSync(p) ? readFileSync(p, "utf8") : undefined;
  })();

  const idx = args.findIndex((a) => a === "--update" || a === "--verify");
  if (idx === -1) {
    const latest = latestFeed(home);
    const all = installedFeeds(home);
    if (!latest) {
      console.log("corpus: no feed installed — this build carries the seed corpus only");
      console.log("  install one: valiant corpus --update <feed-file>");
      process.exit(0);
    }
    console.log(`corpus: ${latest.version}${all.length > 1 ? ` (${all.length} versions installed)` : ""}`);
    console.log(`  invariants: ${(latest.invariants || []).length}   hazards: ${(latest.hazards || []).length}`);
    console.log(`  installed at ${join(home, ".valiant", "corpus")}`);
    process.exit(0);
  }

  const file = args[idx + 1];
  if (!file || !existsSync(file)) {
    console.error(`usage: valiant corpus --${args[idx].slice(2)} <feed-file>`);
    process.exit(2);
  }
  const v = verifyCorpusFeed(readFileSync(file, "utf8"), { keyring, publicKeyPem: single });
  if (!v.ok) {
    console.error(`corpus: this feed is not acceptable — ${v.reason}`);
    console.error("Nothing was installed.");
    process.exit(1);
  }
  if (args[idx] === "--verify") {
    console.log(`corpus: ${v.version} verifies · ${(v.corpus.invariants || []).length} invariants, ${(v.corpus.hazards || []).length} hazards`);
    process.exit(0);
  }
  const path = installFeed(home, v.corpus);
  console.log(`corpus: ${v.version} installed at ${path}`);
  console.log(`  ${(v.corpus.invariants || []).length} invariants, ${(v.corpus.hazards || []).length} hazards`);
  process.exit(0);
}

if (cmd === "licence") {
  const { verifyLicence, describeLicence } = await import("../src/licence.mjs");
  // The licence view: every licence this machine knows, verified. No server, no account — a tool that needs the
  // internet to answer "is this still valid" is unusable on exactly the machines it exists for.
  if (process.argv.includes("--list") || process.argv.includes("--html")) {
    const { licenceView } = await import("../src/licenceview.mjs");
    const r = await licenceView({ html: process.argv.includes("--html") });
    if (!r.ok) { console.error(r.message); process.exit(r.code); }
    process.stdout.write(r.text + "\n");
    process.exit(0);
  }

  const { readFileSync, existsSync, writeFileSync, mkdirSync } = await import("node:fs");
  const { join: j, dirname: d } = await import("node:path");
  const { fileURLToPath } = await import("node:url");
  const HERE = d(fileURLToPath(import.meta.url));
  const store = j(process.env.HOME || os.homedir(), ".valiant", "licence");
  // U-04: revocation that works with no network. One jti per line; the tool carries the list rather than
  // asking a server, because a verification tool that needs the internet to answer "is this still valid"
  // is unusable on exactly the machines it exists for.
  const revokedFile = j(process.env.HOME || os.homedir(), ".valiant", "revoked.txt");
  const readRevoked = () => {
    if (!existsSync(revokedFile)) return new Set();
    return new Set(readFileSync(revokedFile, "utf8").split("\n").map((l) => l.trim()).filter(Boolean));
  };
  const args = process.argv.slice(3);
  // U-08: prefer the shipped keyring so a rotation does not invalidate licences already sold. A build with
  // only the single PEM still works — the ring is additive, not a replacement.
  const { loadKeyring } = await import("../src/keyring.mjs");
  const ring = loadKeyring(j(HERE, "..", "licence-keys"));
  const pub = j(HERE, "..", "licence-public.pem");
  // AN EXPLICIT KEY WINS — the same rule the gate now follows. Without this, a licence minted with a key supplied in
  // VALIANT_LICENCE_KEY (a trial key, or an end-to-end test) was refused by `--status` as a bad signature while the gate accepted
  // it: two commands disagreeing about the same file.
  const publicKeyPem = process.env.VALIANT_LICENCE_KEY
    || (Object.keys(ring).length > 0 ? ring : (existsSync(pub) ? readFileSync(pub, "utf8") : undefined));

  // ONLINE VERIFICATION (Rob, 2026-11-02: verification online, 24-hour cache). OPT-IN, because making every gate run depend on a
  // network call would change what an existing install does the day it updates — and a suite that mints its own licences in a
  // temp home must be able to run without a server. Turned on per machine with `valiant licence --online --enable`.
  const onlineIdx = args.indexOf("--online");
  if (onlineIdx !== -1) {
    const { evaluateOnline, readCache, CACHE_HOURS } = await import("../src/licence-online.mjs");
    const lic = existsSync(store) ? readFileSync(store, "utf8").trim() : null;
    if (!lic) { console.error("licence --online: no licence on this machine"); process.exit(2); }
    if (args.includes("--enable") || args.includes("--disable")) {
      const want = args.includes("--enable");
      const cfgPath = j(process.env.HOME || os.homedir(), ".valiant", "online.json");
      mkdirSync(d(j(process.env.HOME || os.homedir(), ".valiant")), { recursive: true });
      writeFileSync(cfgPath, JSON.stringify({ online: want, at: new Date().toISOString() }, null, 2) + "\n");
      console.log(`online verification: ${want ? "ON — every gate asks the issuer, cache good for " + CACHE_HOURS + "h" : "OFF"}`);
      process.exit(0);
    }
    const { verifyLicence: verifyLocal } = await import("../src/licence.mjs");
    const local = verifyLocal(lic, { publicKeyPem });
    const jti = local.ok ? local.claims?.jti : null;
    const r = await evaluateOnline(lic, { jti });
    const c = readCache();
    console.log(r.ok
      ? `online: OK (${r.source}${r.staleHours !== undefined ? `, ${r.staleHours}h old` : ""})`
      : `online: REFUSED — ${r.why}${r.revoked ? " (revoked)" : ""}`);
    if (c?.at) console.log(`  verdict cached at ${c.at} · good for ${CACHE_HOURS}h`);
    process.exit(r.ok ? 0 : 2);
  }
  const syncIdx = args.indexOf("--sync");
  if (syncIdx !== -1) {
    // CARRIER 2: immediate action, cached locally with its issue date so staleness is visible rather than trusted.
    const { syncRevocations, meta } = await import("../src/revocation.mjs");
    const { verifyLicence } = await import("../src/licence.mjs");
    // WITH NO ARGUMENT it asks the issuer's own endpoint, which replaced the file published from the issuing Mac.
    const { DEFAULT_SYNC_URL } = await import("../src/revocation.mjs");
    // THE ISSUER CAN BE NAMED WITHOUT EDITING THE TOOL. `--sync <url>` was the only way, so a customer whose issuer is not ours (or a
    // self-hosted deployment, or a test) could not point the SDK at it from a hook or a script — and an explicit URL argument still
    // wins over the variable.
    const src = args[syncIdx + 1] && !args[syncIdx + 1].startsWith("--")
      ? args[syncIdx + 1]
      : (process.env.VALIANT_SYNC_URL || DEFAULT_SYNC_URL);
    const r = await syncRevocations(src, { publicKeyPem, verifyLicence });
    if (!r.ok) { console.error(`licence --sync: ${r.why}`); process.exit(2); }
    const m = meta();
    const issued = r.issuedAt ? new Date(r.issuedAt * 1000).toISOString().slice(0, 10) : "unknown";
    console.log(`licence --sync: +${r.added} new, ${r.total} revoked id(s) held · list issued ${issued} (${m.from ?? "unknown source"})`);
    if (r.issuedAt && Math.floor(Date.now() / 1000) - Number(r.issuedAt) > 30 * 86_400) {
      console.log("  WARNING — this list is more than 30 days old; ask the issuer for a fresher one");
    }
    process.exit(0);
  }
  const fileIdx = args.indexOf("--file");
  const stringArg = args.find((a) => a.startsWith("vvs1."));
  let licence = stringArg || null;
  if (fileIdx !== -1 && args[fileIdx + 1]) licence = readFileSync(args[fileIdx + 1], "utf8").trim();
  if (!licence && (args.includes("--status") || args.length === 0) && existsSync(store)) licence = readFileSync(store, "utf8").trim();

  const revokeIdx = args.indexOf("--revoke");
  if (revokeIdx !== -1) {
    const jti = args[revokeIdx + 1];
    if (!jti) { console.error("usage: valiant licence --revoke <jti>"); process.exit(2); }
    mkdirSync(d(revokedFile), { recursive: true, mode: 0o700 });
    const already = readRevoked();
    if (already.has(jti)) { console.log(`${jti} was already revoked`); process.exit(0); }
    const next = [...already, jti].join("\n") + "\n";
    writeFileSync(revokedFile, next, { mode: 0o600 });
    console.log(`revoked ${jti} — it will be refused on this machine from now on`);
    console.log("the list lives at " + revokedFile + " (mode 600); remove the line to undo it here");
    process.exit(0);
  }
  if (args.includes("--revoked")) {
    const list = readRevoked();
    if (list.size === 0) console.log("no revoked licences on this machine");
    else for (const jti of list) console.log(jti);
    process.exit(0);
  }

  if (!licence) {
    console.error("usage: valiant licence <vvs1.…> | --file <path> | --status | --revoke <jti> | --revoked");
    console.error(`no licence given and nothing stored at ${store}`);
    process.exit(2);
  }
  const v = verifyLicence(licence, { publicKeyPem, graceDays: 0, revoked: readRevoked() });
  if (!v.ok) {
    console.error(`valiant: this licence is not valid — ${v.reason}`);
    process.exit(1);
  }
  console.log(`licence OK · ${describeLicence(v.claims)}`);
  if (!args.includes("--status") && typeof store === "string") {
    mkdirSync(d(store), { recursive: true, mode: 0o700 });
    writeFileSync(store, licence + "\n", { mode: 0o600 });
    console.log(`stored at ${store} (mode 600)`);
  }
  process.exit(0);
}

function failExit(detail) {
  console.error(`valiant: ${detail}`);
  process.exit(1);
}

let cfg;
try {
  // --corpus supplies gates of its own, so an empty config is not a lie in that mode.
  cfg = loadConfig(configPath, { allowEmpty: process.argv.includes("--corpus") });
} catch (e) {
  // A CONFIG THAT CANNOT BE LOADED IS "CANNOT CHECK" (2), not "a contract is broken" (1): nothing was checked. The
  // documented exit codes are 0 holds / 1 broken / 2 cannot check, and this was answering 1 (review #14, F12).
  console.error(`valiant: ${e.message}`);
  process.exit(2);
}

if (cmd === "selfcheck") {
  // THE VERIFIER PROVES IT IS THE VERIFIER. Every other check trusts the code running it: one edited line in gates.mjs and a broken contract reads
  // green, and no gate notices because the gate IS the edited code. This compares the running engine (bin/, src/, corpus/reference-guards/) to the
  // sha256 set written at pack time. A changed or removed engine file is named; a new file is allowed, because a new check is not a tamper.
  const { verify: selfVerify, write: selfWrite, SELF } = await import("../src/selfcheck.mjs");
  const selfRoot = join(fileURLToPath(import.meta.url), "..", "..");
  if (process.argv.includes("--write")) {
    const body = selfWrite(selfRoot, JSON.parse((await import("node:fs")).readFileSync(join(selfRoot, "package.json"), "utf8")).version);
    (await import("node:fs")).writeFileSync(join(selfRoot, SELF), `${JSON.stringify(body, null, 2)}\n`);
    console.log(`selfcheck: wrote ${SELF} — ${Object.keys(body.files).length} engine file(s), engine ${body.engine.slice(0, 12)}`);
    process.exit(0);
  }
  const r = selfVerify(selfRoot);
  const tag = r.ok ? (r.unrecorded ? "WARN" : "PASS") : "FAIL";
  console.log(`  [${tag}] selfcheck — ${r.detail}`);
  if (!r.ok) {
    console.log("  The engine that decides verdicts has been edited since it was packed. A verifier whose own code can be changed quietly proves");
    console.log("  nothing: re-install the released tarball, or rebuild it (valiant selfcheck --write) and record why in the change.");
    console.log("  For provenance rather than change detection: valiant pack --verify (against the issuer key).");
  }
  process.exit(r.ok ? 0 : 1);
}

if (cmd === "ratchet") {
  // RECORD WHAT THIS REPO CHECKS, AND THEN KEEP THE RECORD HONEST. Without it a gate could be deleted — or swapped for one with the same count —
  // and the verdict stayed green; and a guard that WAS proven could lose its proof and be absorbed by `unprovenBaseline`.
  const { writeLock, compare, readLock, LOCK } = await import("../src/ratchet.mjs");
  const { readFileSync: readProofs } = await import("node:fs");
  let proofs = [];
  try { proofs = JSON.parse(readProofs(join(repoRoot, "mutations.json"), "utf8")).proofs ?? []; } catch { proofs = []; }
  if (process.argv.includes("--write")) {
    const lock = writeLock(repoRoot, cfg, proofs);
    // SIGN IT WHEN THIS MACHINE CAN. The body is what was written; the signature is what makes "the record was edited" detectable rather than
    // merely unlikely.
    const { signLock } = await import("../src/ratchet.mjs");
    const sig = signLock(repoRoot, readProofs(join(repoRoot, LOCK), "utf8"));
    console.log(`  ${sig.signed ? "signed" : "unsigned"} — ${sig.signed ? sig.file : sig.why}`);
    console.log(`\nratchet: recorded ${lock.gates.length} gate(s) and ${lock.proven.length} proof(s) in ${LOCK}`);
    console.log("  gates and proofs may be ADDED freely; removing one, renaming one, or losing a proof now fails the gate.");
    process.exit(0);
  }
  const r = compare(repoRoot, cfg, proofs);
  console.log(`\nratchet — ${r.ok ? "the record and reality agree" : "the record has drifted"}\n`);
  console.log(`  ${r.detail}`);
  if (!r.ok) {
    console.log("\n  If the removal is intended, re-record it:  valiant ratchet --write");
    console.log("  (a diff on " + LOCK + " is then the record of the decision, which is the point)");
  }
  console.log("");
  process.exit(r.ok ? 0 : 1);
}

if (cmd === "conventions") {
  // THE NINE ARTEFACT CONVENTIONS, reported the way a rule should be: declared, broken, or ABSENT WITH ITS COST.
  // A repo that declares none is not failing — it is being told, by name, which invariants nothing is checking.
  const { conventionReport, CONVENTIONS } = await import("../src/conventions.mjs");
  const rows = conventionReport(cfg, repoRoot);
  const wide = process.argv.includes("--json");
  if (wide) {
    console.log(JSON.stringify(rows, null, 2));
    process.exit(rows.some((r) => r.state === "broken") ? 1 : 0);
  }
  const mark = { declared: "DECLARED", broken: "BROKEN  ", absent: "absent  " };
  console.log(`\nconventions — ${rows.filter((r) => r.state === "declared").length} declared · ${rows.filter((r) => r.state === "broken").length} broken · ${rows.filter((r) => r.state === "absent").length} absent\n`);
  for (const r of rows) {
    console.log(`  ${mark[r.state]}  ${r.key.padEnd(9)} unlocks invariant ${r.unlocks.join(", ")}`);
    if (r.state !== "declared") console.log(`            ${r.detail}`);
  }
  const absent = rows.filter((r) => r.state === "absent");
  if (absent.length) {
    console.log(`\n  ${absent.length} convention(s) absent, so ${[...new Set(absent.flatMap((r) => r.unlocks))].sort((a, b) => a - b).join(", ")} are counted and not checked.`);
    console.log("  Declare one in valiant.json under \"conventions\" to turn its rule into a check; docs/CONVENTIONS.md has the shape.");
  }
  console.log("");
  process.exit(rows.some((r) => r.state === "broken") ? 1 : 0);
}

if (cmd === "gate") {
  // ONE COMMAND THAT IS THE WHOLE GATE. This exists because the three contracts were being run by
  // whatever CI job somebody remembered to wire, and a required check that depends on a hosted queue is
  // not a gate — it is a wait. `valiant gate` is the thing to run on hardware you control.
  //
  // It is deliberately not a fourth implementation: it drives the three existing commands in one
  // process, in this order (gates by name → ledger contract → guards proved), with strict ON, and
  // exits non-zero if ANY of them fails. exit 0 every contract holds · 1 broken · 2 cannot check.
  const { spawnSync: spawn } = await import("node:child_process");
  const self = process.argv[1];
  const cfgArgs = configPath ? ["--config", configPath] : [];
  const parts = [
    ["gates by name", ["verify", "--include-release", ...cfgArgs]],
    ["ledger contract", ["ledger", ...cfgArgs]],
    ["method corpus", ["method", "--check"]],
    // THE RECORD OF WHAT THIS REPO CHECKS. Without it a gate can be deleted — or swapped for one with the same count — with the verdict green,
    // and a guard that WAS proven can lose its proof and be called maintenance. Additions stay free; removals are red.
    ["ratchet", ["ratchet", ...cfgArgs]],
    ["hooks installed", ["hooks", "--gate", ...cfgArgs]],
    ["guards proved", ["mutate", "--strict", ...cfgArgs]],
  ];
  // The SOP baseline is part of the verdict once an install has laid it down (valiant sops init).
  // ADOPTION IS baseline.json + local.json. The SDK ships a baseline as package content, so the presence of
  // the baseline alone must not make the tool look like one of its own customers (`sops init` writes both).
  // ONE FILE IS ENOUGH TO ADOPT. Requiring both let `rm sops/local.json` switch the whole baseline off while the
  // gate stayed green — the smallest falsifier an independent review found on 2026-10-26.
  const sopsFlag = (() => { try { return JSON.parse(readFileSync(configPath, "utf8")).sops; } catch { return undefined; } })();
  if (sopsFlag === false) {
    // It used to be accepted and ignored, so a repo could believe it had opted out while the gate enforced anyway
    // (independent review #7, F7). The baseline is not optional: say so rather than silently overriding the field.
    console.error('valiant: "sops": false is not supported — the installed SOP baseline is not optional.');
    console.error("  Remove the field: the baseline is enforced from the SDK itself, so there is nothing in your repo to opt out of.");
    process.exit(2);
  }
  if (existsSync(configPath)) {
    // ALWAYS. The baseline ships in the package; a repo cannot opt out by deleting a directory, and there is no
    // directory to delete. Review #6's "rm -rf sops" attack has nothing left to remove.
    parts.push(["sop baseline", ["sops", "check", ...cfgArgs]]);
  }
  let worst = 0;
  const passed = {};
  // A SINGLE-USE MARKER, NOT AN INHERITABLE ENV VAR. An env var can be set by anyone — including a repo's own CI — and
  // would then tell `sops` to skip the re-execution for good. This file is written per gate run, carries a timestamp, is
  // deleted the moment `sops` reads it, and is ignored if it is older than two minutes or names a different repo.
  const { mkdtempSync: mkFresh, writeFileSync: wFresh, rmSync: rmFresh } = await import("node:fs");
  const { tmpdir: tdFresh } = await import("node:os");
  const freshDir = mkFresh(join(tdFresh(), "valiant-gate-"));
  const freshFile = join(freshDir, "fresh.json");
  const writeFresh = (o) => { try { wFresh(freshFile, JSON.stringify({ ...o, at: Date.now(), repo: repoRoot })); } catch { /* best effort */ } };
  writeFresh({ gates: false, proof: false });
  for (const [label, args] of parts) {
    // THE SEGMENTS TELL `sops` WHAT HAS ALREADY RUN. Without this, `gate` proves every guard and then `sops check`
    // re-executes a sample of those very proofs — measured at 5.0s of an 8.0s gate. The hints are only set for segments
    // that ACTUALLY PASSED, and `sops` still validates the proof's shape, so nothing is taken on trust.
    const env = { ...process.env };
    if (label === "sop baseline") {
      // CARRY THE REAL COUNT, not just a flag. B1 reported "0/0 gate(s) ran and passed" while passing, which reads as
      // "nothing was checked" and is exactly the kind of green this tool exists to refuse.
      writeFresh({ gates: !!passed["gates by name"], proof: !!passed["guards proved"], gateCount: (() => { try { return JSON.parse(readFileSync(configPath, "utf8")).gates?.length ?? 0; } catch { return 0; } })() });
      env.VALIANT_FRESH = freshFile;
    }
    // STDIN IS NOT INHERITED. `gate` can be run from a hook or a pipeline where the parent's stdin is a pipe that nobody closes, and
    // a child inheriting it can block for ever — a hang with no message, which is worse than a red. stdout and stderr stay inherited:
    // the evidence must still reach the terminal (flagging this line was the closed-stdin reference guard's only real finding).
    const r = spawn(process.execPath, [self, ...args], { stdio: ["ignore", "inherit", "inherit"], env });
    if ((r.status ?? 2) === 0) passed[label] = true;
    const code = r.status === null ? 2 : r.status;
    console.log(`  ${code === 0 ? "PASS" : "FAIL"}  ${label} (exit ${code})`);
    if (code === 2) worst = 2;
    else if (code !== 0 && worst === 0) worst = 1;
  }
  // THE SENTENCE THE CUSTOMER READS IS A VERDICT TOO — record it beside the per-guard pairs, so the record covers what
  // was decided and not only what was observed.
  {
    const { recordVerdict } = await import("../src/outcomes.mjs");
    recordVerdict({ repoRoot, command: "gate", exitCode: worst === 0 ? 0 : worst === 1 ? 1 : 2,
      summary: worst === 0 ? "every contract holds" : worst === 1 ? "a contract is broken" : "a contract could not be checked" });
  }
  {
    // ROLLOUT MODES. In warn/observe a failing gate is recorded as a would-deny and the command is allowed to exit 0 —
    // but the report must say that is what happened, and the mode is stamped so an aged warn shows up as RED.
    const { mode, noteMode } = await import("../src/enforcement.mjs");
    const m = mode();
    noteMode(m);
    if (m !== "enforce" && worst !== 0) {
      const { recordDecision } = await import("../src/receipts.mjs");
      recordDecision({ hook: `gate:${m}`, tool: "gate", verdict: "warn",
        reason: worst === 1 ? "a contract is broken (would have failed)" : "a contract could not be checked (would have failed)" });
      console.log(`\n[WARN] VALIANT_ENFORCEMENT=${m} — the verdict above would have failed this run; it is recorded and allowed.`);
      process.exit(0);
    }
  }
  try { rmFresh(freshDir, { recursive: true, force: true }); } catch { /* best effort */ }
    // DRAIN THE CORPUS QUEUE, at the end of the run, best effort. The queue was filling to its 500 cap with nothing ever sending it —
  // "collected by default" was true of writing and false of arriving.
  if (!process.argv.includes("--only")) {
    try {
      const { maybeFlush, consent } = await import("../src/consent.mjs");
      const c = consent();
      // AWAITED, NOT `void`. A fire-and-forget flush followed by `process.exit()` is a flush that never happens: the promise is created,
      // the process exits, the fetch is killed — which is exactly how the queue grew to 421 while every gate claimed to drain it. The
      // budget is capped so a slow collector cannot stretch the gate.
      if (c.enabled) await maybeFlush({ installId: c.installId, budgetMs: 4000 });
    } catch { /* collection must never affect the verdict */ }
  }
// WHEN THE GATE IS A HOOK, IT LEAVES THE SAME RECORD A HOOK LEAVES. The Claude Stop hook runs `valiant gate` itself, so without this its
// blocks produced no evidence at all. `VALIANT_HOOK=<name>` names the hook; the verdict and the sentence are the reason.
if (process.env.VALIANT_HOOK) {
  try {
    const { recordDecision } = await import("../src/receipts.mjs");
    const line = worst === 0 ? "gate: every contract holds" : worst === 1 ? "gate: a contract is broken" : "gate: a contract could not be checked";
    recordDecision({ hook: process.env.VALIANT_HOOK, tool: "agent", command: null,
      verdict: worst === 0 ? "allow" : "deny", reason: `${line} (exit ${worst})` });
  } catch { /* a record that cannot be written must not change the verdict */ }
}
// A GREEN GATE WITH ENFORCEMENT OFF MUST NOT READ LIKE A GREEN GATE. The stance decides whether a hook blocks; in advisory the gate still runs and
// still speaks, and every commit and push goes through with a warning. That is a legitimate choice, and a verdict that omits it is the quieter lie:
// "every contract holds" is true about the code and misleading about the repo. Measured 2026-11-01: advisory allowed a commit with a red gate and
// nothing in the gate's output said so.
let stanceLine = "";
try {
  const { effectiveStance } = await import("../src/enforcement.mjs");
  const { stance, source } = effectiveStance(repoRoot);
  if (stance === "advisory") {
    stanceLine = "\nenforcement: ADVISORY (from " + source + ") — a red gate does not block a commit or a push; it only warns.";
    stanceLine += "\n             To enforce:  valiant enforce --mode enforced";
    console.warn(stanceLine);
    // and in the record, so a later reader of decisions.jsonl sees the window in which nothing was blocked
    try {
      const { recordDecision } = await import("../src/receipts.mjs");
      recordDecision({ hook: "gate:stance", tool: "gate", command: null, verdict: "warn",
        reason: `advisory stance from ${source} — nothing was blocked for this run` });
    } catch { /* a record that cannot be written must not change the verdict */ }
  }
} catch { /* no stance module: treated as enforced, which is the strict default */ }
console.log(worst === 0 ? "\ngate: every contract holds" + (stanceLine ? "  [ADVISORY — nothing blocked]" : "") : worst === 1 ? "\ngate: a contract is broken" : "\ngate: a contract could not be checked");
  process.exit(worst);
}

if (cmd === "verify") {
  // --corpus: run the SHIPPED reference guards against this repo, without the adopter copying them in.
  // Without this flag the corpus was documentation a customer had to wire by hand, which is the difference
  // between "we sell a spec" and "we sell a tool that does something on install".
  let corpusGates = [];
  if (process.argv.includes("--corpus")) {
    const { readdirSync: rd, existsSync: ex } = await import("node:fs");
    const { join: jj } = await import("node:path");
    const dir = jj(dirname(fileURLToPath(import.meta.url)), "..", "corpus", "reference-guards");
    const files = ex(dir) ? rd(dir).filter((f) => f.endsWith(".mjs")).sort() : [];
    corpusGates = files.map((f) => ({
      name: `corpus:${f.replace(/\.mjs$/, "")}`,
      cmd: [process.execPath, jj(dir, f)],
      // These guards print their finding on stderr when they fail and stay quiet when they pass.
      quiet: true,
    }));
    if (corpusGates.length === 0) {
      console.error(`verify: --corpus found no reference guards at ${dir}`);
      process.exit(2);
    }
  }
  // --only <name[,name]>: run THESE gates and nothing else. Sometimes the question is about one guard — is it green, why
  // is it red, did my fix land — and re-running the other thirty-five to answer it wastes the only thing the operator is
  // short of. A name that matches nothing is exit 2 ("could not check"), never a quiet "0/0 passed" that looks green.
  const onlyArg = process.argv.indexOf("--only");
  if (onlyArg !== -1 && !process.argv[onlyArg + 1]) {
    console.error("verify: --only needs a gate name (or comma list) — a bare --only would silently run everything");
    process.exit(2);
  }
  let all = [...cfg.gates, ...corpusGates];
  const onlyWant = onlyArg !== -1 && process.argv[onlyArg + 1]
    ? process.argv[onlyArg + 1].split(",").map((x) => x.trim()).filter(Boolean)
    : [];
  if (onlyWant.length) {
    const missing = onlyWant.filter((n) => !all.some((g) => g.name === n));
    if (missing.length) { console.error(`verify: no gate named ${missing.join(", ")} — --only names gates, not files`); process.exit(2); }
    all = all.filter((g) => onlyWant.includes(g.name));
  }
  // releaseOnly gates run at release (valiant gate, which passes --include-release), not on the everyday
  // verify. `selfcheck` is one: it compares the engine to the last pack, so it must not make an engine
  // change red on a PR — that is the release gate's job.
  let skippedReleaseOnly = [];
  if (!process.argv.includes("--include-release")) {
    // --only NAMED a releaseOnly gate: refusing is honest; silently dropping it after passing the name check
    // would print "0/0 gates passed" in green over a gate that never ran (release review finding 2).
    const namedReleaseOnly = all.filter((g) => g.releaseOnly === true).map((g) => g.name);
    if (onlyWant.length && namedReleaseOnly.length) {
      console.error(`verify: ${namedReleaseOnly.join(", ")} is releaseOnly — pass --include-release to run it (the everyday verify skips it)`);
      process.exit(2);
    }
    skippedReleaseOnly = all.filter((g) => g.releaseOnly === true).map((g) => g.name);
    all = all.filter((g) => !g.releaseOnly);
    // A config whose gates are ALL releaseOnly must not print "0/0 gates passed" in green (release review N2).
    if (all.length === 0) {
      console.error("verify: no gates to run — every gate is releaseOnly; run `valiant gate` to check them");
      process.exit(2);
    }
  }
  const results = runAllGates(all, repoRoot);
  let bad = 0;
  for (const r of results) {
    if (!r.ok) bad++;
    // SARIF IS THE WHOLE OUTPUT WHEN ASKED FOR: a dashboard parses stdout, so a human line before the JSON makes the
    // document unreadable. The exit code still carries the verdict.
    if (!process.argv.includes("--format") && !process.argv.includes("--json")) {
      console.log(`  [${r.ok ? "PASS" : "FAIL"}] ${r.name} — ${r.detail}${r.show ? ` :: ${r.show}` : ""}`);
      // THE COACHING LOOP: a block without a fix is a dead end (invariant 41) — hand the AI the way out.
      if (!r.ok && r.remediation) console.log(`      fix: ${r.remediation}`);
    }
  }
  if (skippedReleaseOnly.length && !process.argv.includes("--format") && !process.argv.includes("--json")) {
    console.log(`  (${skippedReleaseOnly.length} releaseOnly gate(s) skipped: ${skippedReleaseOnly.join(", ")} — run \`valiant gate\` to check them)`);
  }
  if (process.argv.includes("--format")) {
    const fmt = process.argv[process.argv.indexOf("--format") + 1];
    if (fmt !== "sarif") { console.error(`verify: unknown --format "${fmt}" (known: sarif)`); process.exit(2); }
    const { toSarif } = await import("../src/sarif.mjs");
    const doc = toSarif({ results, configPath: configPath.replace(repoRoot + "/", ""), command: "verify", skipped: skippedReleaseOnly });
    process.stdout.write(`${JSON.stringify(doc, null, 2)}\n`);
    if (results.some((r) => r.cannotCheck)) process.exit(2);
    process.exit(bad === 0 ? 0 : 1);
  }
  // --json IS THE MACHINE-READABLE VERDICT: the same results, plus the typed code, confidence, coverage
  // and remediation a consumer needs to act without reading prose. The exit code still carries the verdict.
  if (process.argv.includes("--json")) {
    let version = "unknown";
    try { version = JSON.parse(readFileSync(join(dirname(fileURLToPath(import.meta.url)), "..", "package.json"), "utf8")).version ?? "unknown"; } catch { /* no package.json */ }
    const doc = {
      tool: "valiant",
      version,
      command: "verify",
      repo: repoRoot,
      configPath: configPath.replace(repoRoot + "/", ""),
      at: new Date().toISOString(),
      gates: results,
      summary: {
        total: results.length,
        passed: results.filter((r) => r.ok).length,
        broken: results.filter((r) => !r.ok && !r.cannotCheck).length,
        cannotCheck: results.filter((r) => r.cannotCheck).length,
        skippedReleaseOnly: skippedReleaseOnly.length,
        skippedNames: skippedReleaseOnly,
      },
    };
    process.stdout.write(`${JSON.stringify(doc, null, 2)}\n`);
    if (results.some((r) => r.cannotCheck)) process.exit(2);
    process.exit(bad === 0 ? 0 : 1);
  }
  console.log(`verify: ${results.length - bad}/${results.length} gates passed`);
  // "cannot check" and "broken" are different answers, and the exit code is the contract (0/1/2).
  if (results.some((r) => r.cannotCheck)) process.exit(2);
  process.exit(bad === 0 ? 0 : 1);
}

if (cmd === "mutate") {
  const shardArg = process.argv.find((a) => a === "--shard" || a.startsWith("--shard="));
  const shardSpec = (() => {
    if (!shardArg) return null;
    const m = /^--shard=(\d+)\/(\d+)$/.exec(shardArg);
    if (!m) return { error: 'use --shard=<i>/<n> (for example --shard=1/2) — a bare --shard cannot be partitioned' };
    const i = Number(m[1]), n = Number(m[2]);
    if (i < 1 || n < 2 || i > n) return { error: `--shard=${i}/${n} is out of range — i must be between 1 and n, and n at least 2` };
    return { i, n };
  })();
  if (shardSpec?.error) { console.error(`valiant mutate: ${shardSpec.error}`); process.exit(2); }
  // --only <name>: prove exactly one guard and print its verdict as JSON. This is how the parallel runner fans out; it
  // writes nothing, so several can run at once without racing on mutations.json.
  const onlyAt = process.argv.indexOf("--only");
  if (onlyAt !== -1) {
    const only = process.argv[onlyAt + 1];
    const g = (cfg.guards ?? []).find((x) => x.name === only);
    if (!g) { console.log(JSON.stringify({ name: only, result: "error", detail: "no guard with that name" })); process.exit(2); }
    const { runMutation } = await import("../src/mutate.mjs");
    const one = runMutation(g, repoRoot);
    console.log(JSON.stringify(one));
    process.exit(one.result === "caught" ? 0 : 1);
  }

  const beforeGit = gitStatus(repoRoot);
  // THE WHOLE TREE, both times. Narrowing this to "files that were clean at start" was exactly blind to the failure it exists to catch: a sabotage
  // into a file the author is already editing leaves `git status` unchanged, so the leak is invisible twice over (independent review, 2026-11-02).
  // The tool's OWN OUTPUTS are the only allowance, and they are named — an allowlist by name can be read and argued with; a filter by cleanliness
  // cannot.
  // The tool's own records, and `.git/index` — which any `git status` refreshes. `.git/hooks` and `.git/config` stay IN the hash: a planted hook
  // executes on the next commit, which is the reason they were added.
  const RUN_OUTPUTS = [/^mutations\.json$/, /^mutations\.shard-\d+-of-\d+\.json$/, /^SELF\.json$/, /^valiant\.lock\.json$/, /^valiant\.lock\.json\.sig$/, /^\.git\/index$/, /^\.git\/index\.lock$/];
  const snapshot = () => {
    const m = new Map();
    const walk = (dir, rel) => {
      let entries = [];
      try { entries = readdirSync(dir).sort(); } catch { return; }
      for (const e of entries) {
        if (e === "node_modules" || e === ".venv" || e === "dist") continue;
        const full = join(dir, e);
        const name = rel ? `${rel}/${e}` : e;
        let st = null; try { st = statSync(full); } catch { continue; }
        if (st.isDirectory()) { walk(full, name); continue; }
        if (RUN_OUTPUTS.some((re) => re.test(name))) continue;
        try { m.set(name, createHash("sha256").update(readFileSync(full)).digest("hex")); } catch { /* unreadable */ }
      }
    };
    walk(repoRoot, "");
    return m;
  };
  const treeBefore = snapshot();
  // (snapshot above)
  // A SHARD RUNS ITS OWN SLICE AND WRITES ITS OWN FILE, so several machines can prove different guards and
  // `merge-shards` can join the results. Before this, `--shard=1/2` ran every guard and wrote a full-set
  // mutations.json — a shard that is not a shard (independent review #14, F7).
  const shardGuards = shardSpec ? cfg.guards.filter((_, i) => i % shardSpec.n === shardSpec.i - 1) : cfg.guards;
  if (shardSpec) console.log(`shard ${shardSpec.i}/${shardSpec.n}: ${shardGuards.length} of ${cfg.guards.length} guard(s)`);
  // PROOF RUNS IN PARALLEL ACROSS GUARDS. Serially the wall clock is the sum of every guard's five check runs; the guards
  // share nothing (each works in its own copy), so the cost becomes roughly the slowest one. VALIANT_CONCURRENCY caps it.
  // --changed: INCREMENTAL MUTATION (the low-entanglement speedup, from SEXTANT). Guards share nothing and each proves its
  // own file, so a guard whose definition and subject are byte-identical to its last `caught` proof has provably not changed
  // — re-running it is the blowup this flag avoids. Skip it and carry the proof over.
  const fingerprint = (g) => {
    const h = createHash("sha256");
    h.update(JSON.stringify({ i: g.invariant ?? null, n: g.name, f: g.file ?? null, d: g.find ?? null, r: g.replace ?? null, c: g.check ?? null, x: g.fixture ?? null, o: g.oracle ?? "empirical", z: g.falsifier ?? null }));
    try { h.update(readFileSync(join(repoRoot, g.file))); } catch { /* subject absent — the guard itself reports it */ }
    return h.digest("hex");
  };
  let carriedOver = [];
  let toRun = shardGuards;
  if (process.argv.includes("--changed")) {
    const prev = (() => { try { return JSON.parse(readFileSync(join(repoRoot, "mutations.json"), "utf8")).proofs || []; } catch { return []; } })();
    const prevFp = new Map(prev.filter((p) => p.result === "red" && p.fingerprint).map((p) => [p.guard, p.fingerprint]));
    const run = [];
    for (const g of shardGuards) {
      const f = fingerprint(g);
      if (prevFp.get(g.name) === f) {
        carriedOver.push({ name: g.name, result: "caught", carried: true, oracle: g.oracle ?? "empirical", falsifier: g.falsifier ?? `${g.find} → ${g.replace}`, fingerprint: f, detail: "carried over — definition and subject unchanged since the last caught proof" });
      } else {
        run.push(g);
      }
    }
    toRun = run;
    if (carriedOver.length) console.log(`  --changed: carrying ${carriedOver.length} of ${shardGuards.length} guard(s) unchanged, re-verifying ${run.length}`);
  }
  const { runAllMutationsParallel } = await import("../src/mutate.mjs");
  const results = await runAllMutationsParallel(toRun, repoRoot, fileURLToPath(import.meta.url));
  results.push(...carriedOver);
  {
    const { recordOutcome } = await import("../src/outcomes.mjs");
    for (const r of results) {
      if (r.carried) continue;   // carried-over proofs were already recorded — do not re-record them
      const g = (cfg.guards ?? []).find((x) => x.name === r.name) ?? {};
      recordOutcome({ repoRoot, guard: g, result: r, trials: r.trials ?? null });
    }
  }
  // GATES ARE PROVED TOO. A guard is shown able to fail; a gate is the thing that decides the verdict, and until now it was trusted on its
  // own output — a command printing "24 checks passed" passed the gate (measured 2026-11-01). Gates that declare a sabotage are run with the
  // sabotage applied and must go non-zero; gates that declare none are counted as unproven and ratcheted.
  const { proveGate, unprovenGates } = await import("../src/gateproof.mjs");
  const gateProofs = (cfg.gates ?? []).filter((g) => g.sabotage).map((g) => proveGate(g, repoRoot));
  const gateCaught = gateProofs.filter((r) => r.result === "caught").length;
  const gateDeclared = (cfg.gates ?? []).filter((g) => g.sabotage).length;
  console.log(`  gates proved ${gateCaught}/${gateDeclared} declared, ${(cfg.gates ?? []).length - gateCaught} unproven in total`);
  for (const r of gateProofs) {
    const mark = r.result === "caught" ? "caught" : r.result.toUpperCase();
    console.log(`  [${mark}] gate ${r.name} — ${r.detail}`);
  }
  // THE CEILING IS A DECISION, AND SILENCE IS ITS DEFAULT-ONLY-FOR-ADOPTION. When `unprovenGates` is absent the ceiling is the whole gate list —
  // so an existing repo is not broken by this rule — and the count is PRINTED every run. Setting it (0 is the strict answer) turns the debt into a
  // ratchet. A rule that reds every repo on upgrade teaches people to switch the rule off.
  const gateCeiling = Number.isInteger(cfg.unprovenGates) ? cfg.unprovenGates : (cfg.gates ?? []).length;
  const neverProved = unprovenGates(cfg);
  if (neverProved.length > gateCeiling) {
    console.log(`  [UNPROVEN] ${neverProved.length} gate(s) declare no sabotage (ceiling ${gateCeiling}): ${neverProved.slice(0, 6).map((g) => g.name).join(", ")}${neverProved.length > 6 ? "…" : ""}`);
    console.log(`             a gate nobody has broken is a claim. Give it a subject + sabotage, or record the ceiling in "unprovenGates".`);
  }

  const treeAfter = snapshot();
  const afterGit = gitStatus(repoRoot);
  const before = beforeGit, after = afterGit;
  let bad = 0;
  // A non-caught guard only fails the run when it takes the count ABOVE the recorded baseline — that is what the
  // ratchet means, and before this it could never be satisfied (independent review #6, F9).
  const baselineForCount = cfg.unprovenBaseline ?? 0;
  let unprovenSoFar = 0;
  for (const r of gateProofs) {
    if (r.result !== "caught") bad++;
  }
  if (neverProved.length > gateCeiling) bad++;
  // THE COACHING LOOP (mutation half): each non-caught verdict carries the exact next step, so the AI
  // can fix it rather than just see "SURVIVED" (invariant 41: no dead ends).
  const MUTATION_FIX = {
    survived: "the check passed with the subject broken — fix the check or the guard so it actually detects the breakage",
    stale: "the sabotage's find matched 0 or more than 1 site — fix the find string so it matches the subject exactly once",
    "always-red": "the check is red with nothing sabotaged — fix the check (it is broken), not the guard",
    unstable: "the check stayed red after the sabotage was undone — isolate it so it depends only on the copy",
    "cannot-run": "the check could not run — fix the environment, then re-run",
    error: "the guard's config is invalid — fix its file/find/replace in valiant.json",
  };
  for (const r of results) {
    const caught = r.result === "caught";
    if (!caught) {
      unprovenSoFar++;
      // A SURVIVOR IS ALWAYS A FAILURE. `unprovenBaseline` is for maintenance states (stale, not-run) — a guard that
      // passed with the sabotage applied was being absorbed by a large baseline, which reopened "0/N caught, exit 0"
      // (independent review #11, F4).
      if (r.result === "survived" || r.result === "error" || unprovenSoFar > baselineForCount) bad++;
    }
    console.log(`  [${r.result.toUpperCase()}] ${r.name} — ${r.detail}`);
    if (!caught && MUTATION_FIX[r.result]) console.log(`      fix: ${MUTATION_FIX[r.result]}`);
  }
  // NAME THE FILE. "a file changed" cost a whole round of diagnosis on 2026-11-02; a check that cannot say what it saw is a check that cannot be
  // acted on.
  const changed = [...new Set([...treeBefore.keys(), ...treeAfter.keys()])].filter((k) => treeBefore.get(k) !== treeAfter.get(k));
  if (changed.length) {
    bad++;
    console.log(`  [FAIL] no-disruption — ${changed.length} file(s) changed during mutate: ${changed.slice(0, 8).join(", ")}${changed.length > 8 ? " …" : ""}`);
    console.log("         a sabotage was not restored, or a gate wrote into the tree — restore it before committing");
  } else {
    console.log("  [PASS] no-disruption — working tree untouched");
  }
  const unproven = results.filter((r) => r.result !== "caught").length;
  const baseline = cfg.unprovenBaseline;
  // `bad` counted every unproven guard before the ratchet was consulted, so `unprovenBaseline` could never let a run
  // pass — the field was decorative (independent review #6, F9).
  const aboveBaseline = Math.max(0, unproven - baseline);
  const strict = strictFlag || cfg.strict === true;
  // "0/0 mutations caught" used to print and exit 0 — a run that proves nothing reporting success, which is
  // the exact failure this tool exists to catch. A repo whose guards are proved by its OWN runner must say
  // so, and must publish the evidence; otherwise zero guards is a refusal, not a pass.
  const external = cfg.prover === "external";
  if (results.length === 0) {
    const proofs = (() => {
      try { return JSON.parse(readFileSync(join(repoRoot, "mutations.json"), "utf8")).proofs || []; } catch { return null; }
    })();
    const redProofs = proofs ? proofs.filter((p) => p.result === "red") : [];
    const red = redProofs.length;
    // WHICH GUARDS EXIST? A proof names a guard; the guard must be named somewhere in the repo's own
    // scripts, or it is a row about nothing. This is what makes a hand-written mutations.json fail:
    // {"guard": "does-not-exist"} is not mentioned anywhere, so the file proves nothing.
    // A PROOF MUST NAME A SUBJECT THAT EXISTS — a file in this repo. It used to be a substring search over
    // every script, so a guard's name in a COMMENT counted as proof (an independent review broke it with one
    // line: `// TODO: audit-guard would run here one day.`). A path cannot be conjured by mentioning it.
    let named = 0;
    if (red) {
      const { existsSync: ex } = await import("node:fs");
      const bogus = [];
      for (const p of redProofs) {
        const subject = p.file ?? p.guard;
        const okPath = typeof subject === "string" && subject.length > 0 && !subject.includes("..") && ex(join(repoRoot, subject));
        if (okPath) named++; else bogus.push(p.guard ?? subject ?? "?");
      }
      // SELF-ATTESTED PROOFS ARE RE-RUN, NOT READ. A typed `mutations.json` satisfied this rule, and then a typed
      // `sampled-proofs.json` satisfied the fix — the fabrication just moved one file deeper (independent review
      // #3, F1/F11). So the SDK re-executes a seeded sample itself and ignores any record the repo supplies.
      const { verifyExternalEvidence } = await import("../src/evidence.mjs");
      const ev = await verifyExternalEvidence({ repoRoot, k: 3, prover: cfg.proverCmd ?? "node scripts/mutate-guards.mjs" });
      if (!ev.ok) {
        console.log(`  [FAIL] external prover — ${ev.reason}`);
        console.log("mutate: cannot check — these proofs are not evidenced by a re-run");
        process.exit(2);
      }
      console.log(`  [PASS] external prover — ${ev.detail}`);
      if (!ev.ok) {
        console.log(`  [FAIL] external prover — ${bogus.length} proof(s) name no file in this repo: ${bogus.slice(0, 3).join(", ")}${bogus.length > 3 ? ", …" : ""}`);
        console.log("mutate: cannot check — a proof must name the file it is about; a name in a comment is not a guard");
        process.exit(2);
      }
    }
    if (!external || red === 0) {
      // A GATE PROVED IS EVIDENCE TOO. A repo whose checks are gates (a service, a deployment) and which has proved those gates can fail has
      // shown something real; "no guards" then means "no mutation catalogue", not "nothing was proved". Saying "cannot check" over the top of a
      // proved gate would be the same defect in the other direction.
      const gatesProved = (typeof gateProofs !== "undefined" ? gateProofs : []).filter((r) => r.result === "caught").length;
      if (gatesProved > 0) {
        console.log(`  [PASS] gates proved — ${gatesProved} gate(s) went red when their subject was broken (no guard catalogue in this repo)`);
      } else {
        console.log(`  [FAIL] no guards proved — 0 mutations declared and ${external ? "no red proof in mutations.json" : "no \"prover\": \"external\" declaration"}`);
        console.log(`mutate: cannot check — an empty guard set is not a pass`);
        process.exit(2);
      }
    }
    console.log(`  [PASS] external prover — ${red} red proof(s) in mutations.json, ${new Set(proofs.filter((p) => p.result === "red").map((p) => p.guard)).size} guard(s)`);
  }
  if (strict) {
    if (aboveBaseline > 0) {
      bad++;
      console.log(`  [FAIL] strict ratchet — ${unproven} unproven > baseline ${baseline}`);
    } else {
      console.log(`  [PASS] strict ratchet — ${unproven} unproven <= baseline ${baseline}`);
    }
  } else {
    console.log(`  [info] unproven ${unproven} / baseline ${baseline} (--strict gates it)`);
  }
  // WRITE THE EVIDENCE. The SOP baseline requires a record a stranger could re-check (B6) and proofs that name
  // their subject (B2); the tool printed verdicts and wrote nothing, so following its own instructions led to a
  // red gate. A `--shard` run writes a shard file instead; a filtered run writes nothing.
  if (!process.argv.includes("--no-write") && !shardArg && (cfg.guards ?? []).length === 0) {
    // NOTHING TO WRITE. With no declared guards there is no first-party evidence, and writing an empty proofs
    // array over a repo's real mutations.json destroys it — which is how the mesh lost 33 proofs to one run.
    console.log("evidence: no guards declared here, so mutations.json was left untouched");
  } else if (!process.argv.includes("--no-write")) {
    const { createHash: ch } = await import("node:crypto");
    const proofs = results.map((r) => {
      const g = (cfg.guards ?? []).find((x) => x.name === r.name) ?? {};
      return {
        guard: r.name,
        file: g.file ?? null,
        // Identity is the mutation SITE, not the guard: several guards can hit one file.
        site: g.file && g.find ? ch("sha1").update(`${g.file}\u0000${g.find}\u0000${g.replace ?? ""}`).digest("hex").slice(0, 12) : null,
        verdict: r.result,
        // ITS OWN RECIPE. Without find/replace/check a stranger cannot re-run the row, and `sample-proofs` failed on
        // the tool's own output — a proof that cannot be re-executed is a claim (independent review #12, F9).
        find: g.find ?? null,
        replace: g.replace ?? "",
        check: g.check ?? g.fixture ?? null,
        result: r.result === "caught" ? "red" : "green",
        fingerprint: r.fingerprint ?? fingerprint(g),
      };
    });
    // GATE PROOFS LIVE IN THE SAME DOCUMENT. Writing them separately was overwritten by this very block moments later, so `status --json` counted
    // zero proven gates while the terminal said "30/34 caught" — the same class of bug as the test counter that counted cases it never ran.
    for (const r of (typeof gateProofs !== "undefined" ? gateProofs : [])) {
      proofs.push({
        kind: "gate", guard: r.name, name: r.name,
        result: r.result === "caught" ? "red" : r.result,
        file: r.file ?? null, find: r.find ?? null, replace: r.replace ?? null, check: r.check ?? null,
        detail: r.detail,
      });
    }
    const doc = {
      shard: shardSpec ? `${shardSpec.i}/${shardSpec.n}` : undefined,
      note: "Written by `valiant mutate` — one row per guard, with the verdict the check actually produced. result red means the check went red when the thing it protects was broken.",
      writtenBy: "valiant mutate",
      commit: (() => { try { return spawnSync("git", ["rev-parse", "HEAD"], { cwd: repoRoot, encoding: "utf8" }).stdout.trim() || null; } catch { return null; } })(),
      at: new Date().toISOString(),
      red: proofs.filter((p) => p.result === "red").length,
      proofs,
    };
    const outName = shardSpec ? `mutations.shard-${shardSpec.i}-of-${shardSpec.n}.json` : "mutations.json";
    try {
      writeFileSync(join(repoRoot, outName), `${JSON.stringify(doc, null, 2)}\n`);
      console.log(`evidence: ${outName} written — ${doc.red}/${proofs.length} red`);
    } catch (e) {
      console.log(`evidence: could not write mutations.json (${e.message})`);
    }
  }

  const caughtCount = results.filter((r) => r.result === "caught").length;
  if (results.length === 0) {
    // The external path proves by re-running published proofs, so the count is theirs — printing "0/0 caught" on a
    // green run was the exact string this tool exists to stop printing (review #6, F14).
    console.log("mutate: no guards declared here — the evidence was re-run from mutations.json (see above)");
  } else {
    console.log(`mutate: ${caughtCount}/${results.length} mutations caught${caughtCount !== results.length ? " — the rest prove nothing" : ""}`);
  }
  // DRAIN THE CORPUS AFTER MUTATE. Mutate is the biggest producer of observations — every proof it runs is one — and it used to queue
  // them and walk away; only the gate drained, so a machine that only ran proofs grew a queue nobody read.
  try {
    const { maybeFlush, consent } = await import("../src/consent.mjs");
    const c = consent();
    if (c.enabled) await maybeFlush({ installId: c.installId, budgetMs: 4000 });
  } catch { /* collection must never affect the verdict */ }
  process.exit(bad === 0 ? 0 : 1);
}

if (cmd === "ledger") {
  const { parseEntries, verifyChain, replayLedger } = await import("../src/ledger.mjs");
  const r = checkLedger(repoRoot, cfg.ledger);
  const tag = r.absent ? "ABSENT" : r.ok ? "PASS" : "FAIL";
  console.log(`  [${tag}] ledger — ${r.detail}`);
  if (r.absent || !cfg.ledger) process.exit(r.ok ? 0 : 1);

  const text = (() => { try { return r2(join(repoRoot, cfg.ledger), "utf8"); } catch { return ""; } })();
  const entries = parseEntries(cfg.ledger, text);
  let bad = r.ok ? 0 : 1;

  // --write-chain stamps the chain into a ledger that predates it. Anything else reads it.
  if (process.argv.includes("--write-chain")) {
    const { chainOf } = await import("../src/ledger.mjs");
    const blocks = entries.map((e) => e.block);
    const chain = chainOf(blocks);
    let out = text;
    entries.forEach((e, i) => {
      const stripped = e.block.split("\n").filter((l) => !/^[-*]*\s*CHAIN:/i.test(l)).join("\n").replace(/\s+$/, "");
      const trailing = e.block.match(/\n*$/)[0];
      out = out.replace(e.block, stripped + "\n- CHAIN: " + chain[i] + trailing);
    });
    writeFileSync(join(repoRoot, cfg.ledger), out);
    console.log(`  [CHAINED] ${entries.length} entr${entries.length === 1 ? "y" : "ies"} stamped — editing any of them now shows`);
    process.exit(0);
  }

  const chain = verifyChain(entries);
  console.log(`  [${chain.ok ? "PASS" : "FAIL"}] chain — ${chain.detail}`);
  if (!chain.ok) bad++;

  if (process.argv.includes("--replay")) {
    const results = replayLedger(entries, repoRoot);
    const counts = results.reduce((a, x) => ({ ...a, [x.outcome]: (a[x.outcome] ?? 0) + 1 }), {});
    for (const x of results) console.log(`  [${x.outcome}] ${x.id} — ${x.detail}`);
    console.log(`\nreplay: ${counts.OK ?? 0} OK · ${counts.DRIFTED ?? 0} drifted · ${counts.REFUTED ?? 0} refuted · ${counts.UNREPLAYABLE ?? 0} unreplayable`);
    if ((counts.REFUTED ?? 0) > 0) bad++;
    // UNREPLAYABLE is the backlog, and --strict makes it a failure: a claim nobody can re-check is not evidence.
    if (process.argv.includes("--strict") && (counts.UNREPLAYABLE ?? 0) > 0) bad++;
  }
  process.exit(bad ? 1 : 0);
}

if (cmd === "outcomes") {
  // --export: get this node's observations OFF the node, deduped by recipe, as a shard another machine can absorb.
  if (process.argv.includes("--export")) {
    const { buildShard, writeShard, recipeKey } = await import("../src/ship.mjs");
    const outAt = process.argv.indexOf("--export");
    const nextArg = process.argv[outAt + 1];
    const out = nextArg && !nextArg.startsWith("--") ? nextArg : join(repoRoot, "valiant-outcomes.json");
    const sinceAt = process.argv.indexOf("--since");
    const since = sinceAt !== -1 ? process.argv[sinceAt + 1] : null;
    const exclude = process.argv.flatMap((a, i) => (a === "--exclude" && process.argv[i + 1] ? [process.argv[i + 1]] : []));
    const shard = buildShard({ since, exclude });
    writeShard(out, shard);
    console.log(`outcomes: ${shard.count} distinct recipe(s) from ${shard.rowsRead} record(s) → ${out}`);
    console.log(`  shard hash ${shard.hash.slice(0, 16)} · node ${shard.node} (${shard.platform})`);
    console.log("  every row is a LEAD (proven: false) until the same class is proven here by re-execution");
    process.exit(0);
  }
  const { readOutcomes, pairs } = await import("../src/outcomes.mjs");
  const o = readOutcomes();
  if (process.argv.includes("--pairs")) {
    // The training shape: one (diff, verdict) pair per line.
    for (const p2 of pairs()) process.stdout.write(`${JSON.stringify(p2)}\n`);
    process.exit(0);
  }
  if (!o.rows.length) { console.log("no outcomes recorded yet — run `valiant mutate` once"); process.exit(0); }
  console.log(`outcomes: ${o.rows.length} record(s) in ${o.file}`);
  for (const [k, n] of Object.entries(o.counts).sort((a, b) => b[1] - a[1])) console.log(`  ${String(n).padStart(5)}  ${k}`);
  console.log("\n`valiant outcomes --pairs` prints the (diff, verdict) pairs; VALIANT_NO_OUTCOMES=1 stops recording");
  process.exit(0);
}

if (cmd === "decisions") {
  const { recordDecision, readDecisions, verifyDecisions, summarise, unexercised, writeInToto } = await import("../src/receipts.mjs");
  const argv = process.argv.slice(3);
  const flag = (n) => { const i2 = argv.indexOf(n); return i2 >= 0 ? argv[i2 + 1] : undefined; };

  // The recording entry point for a HOOK. It always exits 0: a hook must not fail because the log failed, and the
  // hook's own verdict is what decides the command — this only records it.
  if (argv.includes("--record")) {
    const r = recordDecision({ hook: flag("--hook"), tool: flag("--tool"), command: flag("--command"),
      // --reason IS THE POINT. A deny with an empty reason is a block nobody can act on, and every pre-push deny on this Mac was
      // recorded that way because this line only knew the environment variable. The flag wins; the variable is the fallback.
      verdict: flag("--verdict") ?? "allow", reason: flag("--reason") ?? process.env.VALIANT_DECISION_REASON ?? "" });
    if (!r.ok) console.error(`valiant decisions: the record could not be written (${r.why}) — the hook's verdict still stands`);
    process.exit(0);
  }

  const rows = readDecisions();
  if (argv.includes("--export")) {
    const out = flag("--export") || "valiant-decisions.intoto.json";
    console.log(`wrote ${writeInToto(out, rows)} — ${rows.length} decision(s) as an in-toto statement`);
    process.exit(0);
  }
  if (!rows.length) { console.log("no decisions recorded — a hook records with: valiant decisions --record --hook <name> --verdict deny|allow|warn"); process.exit(0); }

  const chain = verifyDecisions(rows);
  console.log(`decisions: ${rows.length} record(s) in ${(await import("../src/receipts.mjs")).FILE()}`);
  console.log(`  [${chain.ok ? "PASS" : "FAIL"}] chain — ${chain.ok ? "intact" : chain.detail}`);
  let bad = chain.ok ? 0 : 1;
  for (const [hook, s] of Object.entries(summarise(rows))) {
    console.log(`  ${hook.padEnd(24)} allow ${s.allow ?? 0} · deny ${s.deny ?? 0} · warn ${s.warn ?? 0} · last ${String(s.last).slice(0, 19)}` + (s.lastDeny ? ` · last deny at ${s.lastDeny.at.slice(0, 19)} (${s.lastDeny.reason})` : ""));
  }
  // A hook declared in the config but silent for N days is reported — redundant or broken, both worth knowing.
  // The config is loaded HERE because this command is not licence-gated and never loads it.
  const localCfg = (() => { try { return loadConfig(configPath, { allowEmpty: true }); } catch { return {}; } })();
  const declared = localCfg.hooks ?? [];
  const days = Number(flag("--days") ?? localCfg.decisionMaxAgeDays ?? 7);
  if (declared.length) {
    const quiet = unexercised(declared, days, rows);
    console.log(`\n  [${quiet.length ? "FAIL" : "PASS"}] exercised — ${declared.length - quiet.length}/${declared.length} hook(s) recorded a decision in the last ${days} day(s)`);
    for (const h of quiet) console.log(`  [UNEXERCISED] ${h} — no decision in ${days} day(s): redundant, or it stopped firing without saying so`);
    if (quiet.length) bad++;
  }

  // A WARN MODE WITH NO END DATE IS A DISABLE NOBODY DECIDED. The mode is stamped when first used; if it is older than
  // the configured limit, this is RED and says how to clear it.
  {
    const { aged } = await import("../src/enforcement.mjs");
    const a = aged(Number(localCfg.enforcementMaxDays ?? 7));
    if (a.mode !== "enforce") {
      console.log(`\n  [${a.ok ? "WARN" : "FAIL"}] enforcement — VALIANT_ENFORCEMENT=${a.mode} since ${String(a.since).slice(0, 10)} (${a.days} day(s), limit ${a.maxDays})`);
      if (!a.ok) {
        console.log(`  a warn/observe mode left on for more than ${a.maxDays} day(s) is a silent disable — set VALIANT_ENFORCEMENT=enforce (or raise enforcementMaxDays deliberately)`);
        bad++;
      }
    }
  }
  process.exit(bad ? 1 : 0);
}


if (cmd === "contract") {
  const { checkContract } = await import("../src/contract.mjs");
  const argv = process.argv.slice(3);
  const path = argv.find((a) => !a.startsWith("--"));
  // Read the RAW config: loadConfig normalises to the fields the engine uses and would drop `contract`.
  const localCfg = (() => {
    for (const candidate of [configPath, join(repoRoot, "valiant.json")]) {
      try { return JSON.parse(readFileSync(candidate, "utf8")); } catch { /* try the next */ }
    }
    return {};
  })();
  if (!localCfg.contract) {
    console.log("no contract declared — add one to valiant.json:\n  \"contract\": { \"exit\": 0, \"artifacts\": [\"dist/report.json\"] }");
    process.exit(0);
  }
  if (!path) {
    console.error("usage: valiant contract <record.json>   (a record is {exitCode, stdout, stderr, artifacts} or a mesh result.json)");
    process.exit(2);
  }
  let record = null;
  try { record = JSON.parse(readFileSync(path, "utf8")); } catch (e) {
    console.error(`valiant contract: ${path} is not readable JSON (${e.message})`);
    process.exit(2);
  }
  // A mesh job's result.json uses different names; accept it as-is so the same checker reads a real job record.
  if (record.state !== undefined && record.exitCode === undefined) record.exitCode = record.state === "pass" ? 0 : 1;
  record.repoRoot ??= repoRoot;
  const res = checkContract(localCfg.contract, record);
  for (const f of res.findings) console.log(`  [FAIL] ${f.what} — ${f.detail}`);
  console.log(`contract: ${res.ok ? "the record matches what the run declared" : `${res.findings.length} finding(s) — the run did not produce what it declared`}`);
  process.exit(res.ok ? 0 : 1);
}


if (cmd === "pack") {
  const { createPack, verifyPack } = await import("../src/pack.mjs");
  const argv = process.argv.slice(3);

  // VERIFY IS NOT GATED. A pack that needs a licence to check is not evidence an auditor can use.
  if (argv.includes("--verify")) {
    const dir = argv.find((a) => !a.startsWith("--")) ?? "valiant-pack";
    const r = verifyPack(dir);
    console.log(`  [${r.ok ? "PASS" : "FAIL"}] pack — ${r.detail}`);
    process.exit(r.ok ? 0 : 1);
  }

  const outDir = (() => { const i2 = argv.indexOf("--out"); return i2 >= 0 ? argv[i2 + 1] : "valiant-pack"; })();
  const r = createPack({ repoRoot, cfg, outDir });
  for (const [k, v] of Object.entries(r.manifest.included)) {
    if (!v) console.log(`  [absent] ${k} — not in this repo, so not in the pack`);
  }
  console.log(`pack: ${r.files.length} file(s) in ${outDir}${r.signed ? ", manifest signed with the issuer key" : " (unsigned — hashes only)"}`);
  console.log(`verify it with no network and no licence: valiant pack --verify ${outDir}`);
  process.exit(0);
}


if (cmd === "status") {
  // --json IS THE MACHINE-READABLE FORM, and it exists because a website published four numbers that were true when typed and stale within a week
  // (41 invariants while the corpus held 43). A page cannot be checked against prose; it can be checked against this.
  const counts = await (async () => {
    const { readFileSync: rf } = await import("node:fs");
    const one = (rel, pick) => { try { const d = JSON.parse(rf(join(repoRoot, rel), "utf8")); return pick(d); } catch { return null; } };
    const inv = one("corpus/seed-invariants.json", (d) => (Array.isArray(d) ? d : d.invariants)?.length);
    const hz = one("corpus/seed-hazards.json", (d) => (Array.isArray(d) ? d : d.hazards)?.length);
    const method = one("corpus/seed-method.json", (d) => (d?.method ?? d?.methods ?? d?.rules)?.length);
    const proofs = one("mutations.json", (d) => (d?.proofs ?? []).length);
    // GUARDS AND GATES ARE COUNTED SEPARATELY. Both live in mutations.json now, so a single set of `guard` names counted 40 "guards" for a repo with
    // 4 guards and 36 gates — a number that reads as a leap in guard coverage and is really the gates. Gate rows carry kind: "gate".
    const guardsProven = one("mutations.json", (d) => new Set((d?.proofs ?? []).filter((p) => p.result === "red" && p.kind !== "gate").map((p) => p.guard)).size);
    const { GATE_FAILURE_MODES } = await import("../src/gates.mjs");
    // A GATE COUNTS AS PROVEN ONLY IF A RECORDED GATE PROOF CAUGHT. Reporting "gates with a sabotage" as "proven" was the same mistake as the test
    // counter that counted cases it never ran.
    const gateProofsRecorded = one("mutations.json", (d) => (d?.proofs ?? []).filter((p) => p.kind === "gate" && (p.result === "red" || p.result === "caught")).map((p) => p.guard ?? p.name)) ?? [];
    const gateNames = (cfg.gates ?? []).map((g) => g.name);
    const gatesProven = new Set(gateProofsRecorded).size;
    return { invariants: inv, hazards: hz, methodRules: method, mutationProofs: proofs, guardsProven, gates: gateNames.length, gatesProven,
      gateFailureModes: GATE_FAILURE_MODES.length };
  })();
  const { readFileSync: rfPkg } = await import("node:fs");
  let version = null;
  try { version = JSON.parse(rfPkg(join(fileURLToPath(import.meta.url), "..", "..", "package.json"), "utf8")).version; } catch { version = null; }
  if (process.argv.includes("--json")) {
    console.log(JSON.stringify({ version, gates: cfg.gates.length, guards: cfg.guards.length, ledger: cfg.ledger ?? null, ...counts }, null, 2));
    process.exit(0);
  }
  console.log(`gates: ${cfg.gates.length}  guards: ${cfg.guards.length}  ledger: ${cfg.ledger}`);
  process.exit(0);
}

failExit(`unknown command "${cmd}" (verify | mutate | ledger | outcomes | decisions | contract | pack | ci-init | mcp | status)`);
