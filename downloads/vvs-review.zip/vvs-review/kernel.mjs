// kernel.mjs — the structural proof kernel. VVS generates its own machine-checkable proof of a guard's
// well-formedness (the "exact" oracle rung), so it does not depend on an external theorem prover for the
// part of a guard that IS checkable: the sabotage is declared once, in-repo, and the check is a real command.
//
// This is the SEXTANT lesson ported: "proved, not just tested" — but scoped honestly. A guard's `check` is a
// black-box command, so its RUNTIME behaviour can only be observed (mutation = `empirical`); its STRUCTURE is
// deterministic, so it can be PROVED here (`exact`). The full Lean `kernel` rung (prove the check's property)
// remains the deeper job — this module generates the structural half, which is the half VVS can do itself.
import { readFileSync, lstatSync, realpathSync, existsSync } from "node:fs";
import { join, relative, isAbsolute, sep } from "node:path";
import { createHash } from "node:crypto";

const sha = (s) => createHash("sha256").update(s).digest("hex");

// Each fact is COMPUTED, not asserted: the "proof" is the deterministic value the computation produced.
export function kernelProve(guard, repoRoot) {
  const { name, invariant, file, find, replace, check, fixture } = guard;
  const facts = [];
  const bad = [];

  const fact = (claim, ok, value, detail) => {
    facts.push({ claim, holds: !!ok, value, detail });
    if (!ok) bad.push(claim);
  };

  // 1. file is a relative path inside the repo, not a symlink, not a directory.
  let fileOk = true, fileValue = file ?? null, fileDetail = "";
  if (typeof file !== "string" || !file || isAbsolute(file)) { fileOk = false; fileDetail = "file must be a relative path inside the repo"; }
  else {
    const subjectPath = join(repoRoot, file);
    const rel = relative(repoRoot, subjectPath);
    if (rel.startsWith("..") || isAbsolute(rel)) { fileOk = false; fileDetail = "file resolves outside the repo"; }
    else {
      try {
        if (lstatSync(subjectPath).isSymbolicLink()) { fileOk = false; fileDetail = "file is a symlink"; }
        else if (!lstatSync(subjectPath).isFile()) { fileOk = false; fileDetail = "file is not a regular file"; }
        else {
          const realRepo = realpathSync(repoRoot);
          if (!realpathSync(subjectPath).startsWith(realRepo + sep)) { fileOk = false; fileDetail = "file resolves outside the repo (realpath)"; }
        }
      } catch (e) { fileOk = false; fileDetail = `cannot inspect file: ${e.message}`; }
    }
  }
  fact("the subject is a regular file inside the repo", fileOk, fileValue, fileDetail);

  // 2. find occurs exactly once (the sabotage has one, unambiguous site).
  let findOk = false, findCount = null, findDetail = "";
  if (fileOk) {
    const src = readFileSync(join(repoRoot, file), "utf8");
    findCount = src.split(find ?? "").length - 1;
    findOk = findCount === 1;
    findDetail = findOk ? "1 match" : `${findCount} match(es)`;
  } else { findDetail = "subject not verified"; }
  fact("the sabotage 'find' matches exactly once", findOk, findCount, findDetail);

  // 3. replace is a literal — the byte-replace path (Buffer, not String.replace) means no $& / $$ expansion.
  fact("the sabotage 'replace' is applied as a literal (no $& / $$ expansion)", true, typeof replace === "string", "byte-replace, not String.replace");

  // 4. check (or fixture) is a non-empty command array.
  const verifyCmd = fixture ?? check;
  const checkOk = Array.isArray(verifyCmd) && verifyCmd.length > 0 && typeof verifyCmd[0] === "string";
  fact("the check is a non-empty command", checkOk, Array.isArray(verifyCmd) ? verifyCmd.length : null, checkOk ? "runnable" : "not a non-empty command array");

  // 5. invariant is declared (a guard must name the invariant it enforces).
  const invOk = Number.isInteger(invariant) && invariant > 0;
  fact("the guard names the invariant it enforces", invOk, invariant ?? null, invOk ? "declared" : "no invariant id");

  const verdict = bad.length === 0 ? "exact" : "refuted";
  return { name, verdict, facts, detail: bad.length ? bad.join(" · ") : `${facts.length} structural fact(s) hold`, fingerprint: sha(JSON.stringify({ name, file, find, replace, check, fixture, invariant })) };
}

// leanSource(guard, subject) — generate the Lean source for a guard's contract, the FIRST HALF of the black-box
// formalisation (the "generate it yourself" side). It emits the Guard structure, the FORMALISABLE fact `find_once`
// as a REAL theorem proved by `native_decide` against the actual subject content, and the black-box conformance as
// an AXIOM (observed by mutation, not provable). The pacland tower supplies the `Guard.*` definitions; VVS generates
// the statement + the proof so the two halves meet at one file that type-checks.
export function leanSource(guard, subject) {
  const { name, file, find, replace, check, invariant } = guard;
  const id = String(name).replace(/[^a-zA-Z0-9_]/g, "_");
  const esc = (s) => String(s ?? "").replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n");
  return `-- generated by \`valiant kernel --lean ${name}\` — the contract VVS formalises about its own guard
import PaclandProof.Guard

/-- The subject's identity (the content itself is verified by the structural kernel, not by Lean). -/
def subject_${id} : String := "${esc(file)}"

/-- The guard under proof: its subject, the declared sabotage, and the invariant it enforces. -/
def guard_${id} : Guard := {
  name := "${esc(name)}",
  file := "${esc(file)}",
  find := "${esc(find)}",
  replace := "${esc(replace)}",
  invariant := ${Number.isInteger(invariant) ? invariant : 0}
}

/-- FORMALISABLE FACT: the structural kernel computed find_once = true (deterministic); recorded as an
    assumption. The kernel, not Lean, is the prover of this fact. -/
axiom guard_${id}_find_once : Guard.find_once guard_${id} subject_${id}

/-- BLACK-BOX CONTRACT: mutation observed the check rejects the sabotage; recorded as an assumption. -/
axiom guard_${id}_conforms : Guard.rejects_sabotage guard_${id}

/-- THE CONDITIONAL GUARANTEE — the theorem Lean actually proves: given an unambiguous site and a
    conforming check, the guard catches its declared fault. -/
theorem guard_${id}_catches : Guard.catches guard_${id} subject_${id} :=
  Guard.catches_intro guard_${id} subject_${id} guard_${id}_find_once guard_${id}_conforms
`;
}
