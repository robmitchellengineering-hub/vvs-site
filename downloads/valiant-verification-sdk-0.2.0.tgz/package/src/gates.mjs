import { spawnSync } from "node:child_process";

// The named-gate contract (Valiant principle 1): a gate is run BY NAME, and a gate
// that is missing, cannot-check (exit 2), or passes with no evidence is a FAIL —
// never a silent pass (H17).
export function runGate(gate, repoRoot) {
  const { name, cmd, expectStderr = false, quiet = false } = gate;
  const res = spawnSync(cmd[0], cmd.slice(1), { cwd: repoRoot, encoding: "utf8" });

  if (res.error) {
    return { name, ok: false, detail: `did not run: ${res.error.message}` };
  }
  const status = res.status;
  const out = (res.stdout || "").trim();
  const err = (res.stderr || "").trim();

  if (status === null) return { name, ok: false, detail: "killed by signal" };
  if (status === 2) return { name, ok: false, detail: "cannot check (exit 2) — never a silent pass" };
  if (status !== 0) {
    return { name, ok: false, detail: `exit ${status}`, show: (err || out).slice(0, 200) };
  }

  if (!quiet) {
    const hasOut = out.length > 0;
    const hasErr = err.length > 0;
    if (!hasOut && !hasErr) {
      return { name, ok: false, detail: "exit 0 with no output — suspect (a pass must produce evidence)" };
    }
    if (!hasOut && hasErr && !expectStderr) {
      return { name, ok: false, detail: "exit 0 with empty stdout — suspect (declare expectStderr if stderr is the evidence)" };
    }
    if (hasOut && hasErr && !expectStderr) {
      return { name, ok: false, detail: "exit 0 with unexpected stderr — suspect (declare expectStderr to allow it)" };
    }
  }
  return { name, ok: true, detail: "exit 0", show: (out || err).slice(0, 200) };
}

export function runAllGates(gates, repoRoot) {
  return gates.map((g) => runGate(g, repoRoot));
}
