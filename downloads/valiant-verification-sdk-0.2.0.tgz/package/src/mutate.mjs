import { spawnSync } from "node:child_process";
import { readFileSync, writeFileSync, cpSync, rmSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

// The mutation-test contract (Valiant principle 2): a guard is proven only by a
// recorded run where a seeded fault was injected and the guard went RED. The real
// repo is never touched — the sabotage is applied to a throwaway copy, so a SIGKILL
// cannot leave a mutated guard behind. A find that matches 0 or >1 times is STALE,
// reported, never skipped silently (H19).
const EXCLUDE = /(^|\/)(\.git|node_modules|\.venv|target|dist|build|__pycache__)(\/|$)/;

export function runMutation(guard, repoRoot) {
  const { name, file, find, replace, check, fixture } = guard;
  // Subject flavour: `file` is the thing being guarded, `check` is the guard.
  // Guard-logic flavour: `file` is the guard's own logic, `fixture` is a synthetic
  // exerciser that must go red once that logic is weakened.
  const verifyCmd = fixture ?? check;
  const subjectPath = join(repoRoot, file);

  let src;
  try {
    src = readFileSync(subjectPath, "utf8");
  } catch (e) {
    return { name, result: "error", detail: `cannot read ${file}: ${e.message}` };
  }

  const count = src.split(find).length - 1;
  if (count === 0) return { name, result: "stale", detail: `find not present in ${file} (0 matches)` };
  if (count > 1) return { name, result: "stale", detail: `find matches ${count} times (must be exactly once)` };

  const tmp = mkdtempSync(join(tmpdir(), "valiant-"));
  try {
    const copy = join(tmp, "repo");
    cpSync(repoRoot, copy, { recursive: true, filter: (s) => !EXCLUDE.test(s) });
    writeFileSync(join(copy, file), src.replace(find, replace), "utf8");
    const res = spawnSync(verifyCmd[0], verifyCmd.slice(1), { cwd: copy, encoding: "utf8" });
    const status = res.status ?? null;
    if (status === null) return { name, result: "caught", detail: "guard died on the sabotage (signal)" };
    if (status === 0) return { name, result: "survived", detail: "guard PASSED with the sabotage applied — it does not catch what it claims" };
    return { name, result: "caught", detail: `guard went red (exit ${status})` };
  } finally {
    rmSync(tmp, { recursive: true, force: true });
  }
}

export function runAllMutations(guards, repoRoot) {
  return guards.map((g) => runMutation(g, repoRoot));
}
