// keyring.mjs — carry SEVERAL signing keys, so a rotation does not invalidate every licence in the wild.
//
// THE PROBLEM (U-08). One public key in the package means rotation is a hard cut: the moment the issuer
// starts signing with a new key, every licence already sold fails to verify until the customer updates the
// tool — and a customer who does not update has a product that silently stops working. This deployment has
// already rotated once (the issuer key was replaced after it was emailed in plaintext), so the failure was
// not hypothetical.
//
// THE SHAPE. A directory, one file per key, named by the `kid` the licence carries:
//
//     licence-keys/vvs-2026-10.pem      ← what old licences name
//     licence-keys/vvs-2026-11.pem      ← what new ones name
//
// `verifyLicence` already accepts a map keyed by kid and refuses an unknown kid with "update the tool"
// rather than accusing the customer of forgery, so this module only has to find and load them.
//
// ADD, NEVER REPLACE. A key that has signed anything sold stays in the ring: the build that carries it is
// the build that can verify it. Removing one is a decision to break those licences, and it should have to
// be an explicit act, not a side effect of a release.
import { readdirSync, readFileSync, existsSync } from "node:fs";
import { join } from "node:path";

/** @returns {Record<string,string>} kid → PEM, empty when there is no ring (caller falls back to one key). */
export function loadKeyring(dir) {
  if (!existsSync(dir)) return {};
  const ring = {};
  for (const f of readdirSync(dir)) {
    if (!f.endsWith(".pem")) continue;
    const kid = f.slice(0, -4);
    try {
      const pem = readFileSync(join(dir, f), "utf8");
      if (pem.includes("BEGIN PUBLIC KEY")) ring[kid] = pem;
    } catch {
      /* an unreadable file is not a key */
    }
  }
  return ring;
}

/** The kids this build can verify, for `--status` and for an error message that says what to do. */
export function describeKeyring(ring) {
  const kids = Object.keys(ring).sort();
  return kids.length === 0 ? "no keyring (single-key build)" : `${kids.length} key(s): ${kids.join(", ")}`;
}
