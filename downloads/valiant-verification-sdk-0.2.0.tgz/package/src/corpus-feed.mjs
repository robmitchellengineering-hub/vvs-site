// corpus-feed.mjs — the corpus as a SIGNED, DATED FEED, so it can grow after the sale.
//
// THE PROBLEM THIS SOLVES. `corpus/README.md` already says the right thing: new invariants arrive only from a
// real incident, are additive, and are versioned and dated. But there was no mechanism, so in practice a
// customer received whatever corpus existed on the day they installed — the "expands when people use it"
// promise was documentation, not a product.
//
// With a feed it becomes real: we publish `vvc1.<payload>.<sig>` when the corpus grows, and `valiant corpus
// --update` verifies and installs it. Same key infrastructure as licences, different prefix, so a corpus blob
// can never be mistaken for a licence or vice versa.
//
// WHAT A TAMPERED FEED CANNOT DO. The signature covers the whole payload, so adding an invariant, editing a
// rule, or back-dating a version all fail verification before anything is written. A feed that fails is not
// installed and not partially applied.
//
// WHAT THIS DELIBERATELY DOES NOT DO: fetch from a URL. A verification tool that makes a network call on
// `verify` is unusable in the places it matters (CI behind a proxy, an airgapped box), so the feed arrives as
// a file the operator obtained however they obtain files. `--update` takes a path, and says so.
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { createPublicKey, createPrivateKey, sign as cryptoSign, verify as cryptoVerify } from "node:crypto";

export const FEED_PREFIX = "vvc1";

const b64url = (buf) => Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const fromB64url = (s) => Buffer.from(s.replace(/-/g, "+").replace(/_/g, "/"), "base64");

/** Sign a corpus document. Issuer-side only; the private key never ships. */
export function signCorpusFile(corpusObject, privateKeyPem) {
  const payload = b64url(JSON.stringify(corpusObject));
  const key = createPrivateKey(privateKeyPem);
  const sig = cryptoSign(null, Buffer.from(payload), key);
  return `${FEED_PREFIX}.${payload}.${b64url(sig)}`;
}

/**
 * Verify a feed token against a keyring (kid → PEM) or a single PEM.
 * @returns {{ok: true, corpus: object, version: string} | {ok: false, reason: string}}
 */
export function verifyCorpusFeed(token, { keyring, publicKeyPem } = {}) {
  const parts = String(token || "").trim().split(".");
  if (parts.length !== 3) return { ok: false, reason: "not a corpus feed (expected vvc1.<payload>.<signature>)" };
  const [pre, payload, sig] = parts;
  if (pre !== FEED_PREFIX) return { ok: false, reason: `this is not a corpus feed (prefix "${pre}")` };

  let corpus;
  try {
    corpus = JSON.parse(fromB64url(payload).toString("utf8"));
  } catch {
    return { ok: false, reason: "the feed payload is not readable JSON" };
  }

  const kid = corpus?.kid;
  const pem = keyring && kid ? keyring[kid] : publicKeyPem;
  if (!pem) {
    return { ok: false, reason: kid ? `feed was signed with key "${kid}", which this build does not carry — update the tool` : "no key to check this feed against" };
  }

  let good = false;
  try {
    good = cryptoVerify(null, Buffer.from(payload), createPublicKey(pem), fromB64url(sig));
  } catch {
    good = false;
  }
  if (!good) return { ok: false, reason: "the signature does not match — the feed was altered after signing, or it was signed with a different key" };

  const version = String(corpus?.version || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(version)) return { ok: false, reason: `feed version "${version}" is not a date (YYYY-MM-DD); a corpus without a date cannot be pinned` };
  if (!Array.isArray(corpus?.invariants)) return { ok: false, reason: "feed carries no invariants array" };

  return { ok: true, corpus, version };
}

/** Where installed feeds live. One file per version, so a customer can pin and go back. */
export function corpusDir(home) {
  return join(home, ".valiant", "corpus");
}

export function installedFeeds(home) {
  const dir = corpusDir(home);
  if (!existsSync(dir)) return [];
  return readdirSync(dir)
    .filter((f) => f.endsWith(".json"))
    .map((f) => ({ file: f, path: join(dir, f), version: f.replace(/\.json$/, "") }))
    .sort((a, b) => (a.version < b.version ? -1 : 1));
}

export function installFeed(home, corpus) {
  const dir = corpusDir(home);
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  const path = join(dir, `${corpus.version}.json`);
  writeFileSync(path, JSON.stringify(corpus, null, 2), { mode: 0o600 });
  return path;
}

/** The newest installed feed, or null. Used by `verify --corpus` to decide which rules exist. */
export function latestFeed(home) {
  const all = installedFeeds(home);
  return all.length ? JSON.parse(readFileSync(all[all.length - 1].path, "utf8")) : null;
}
