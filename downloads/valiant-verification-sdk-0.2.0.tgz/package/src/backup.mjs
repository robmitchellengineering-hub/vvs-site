// backup.mjs — encrypt and decrypt the issuer key with NO external binary.
//
// WHY THIS FILE EXISTS (U-09). `tools/issuer.mjs` used to shell out to `openssl enc` for backup and
// restore. That works on the Mac and on Linux and **does not exist on stock Windows** — so the one
// operation that protects the key every licence depends on was the one operation a Windows operator
// could not perform. The mesh's rule is that no capability exists on one OS only, and this was the
// measured violation.
//
// node:crypto has the same primitives, so the fix needs no dependency and no binary: PBKDF2-SHA256 to
// stretch the passphrase, AES-256-GCM to encrypt AND authenticate. GCM is a deliberate upgrade on
// `openssl enc -aes-256-cbc`, which is unauthenticated — a corrupted or tampered archive would decrypt
// to garbage and only fail later, when the key was needed and the backup had already been trusted.
//
// FILE FORMAT, all ASCII so it survives any email client or clipboard:
//
//     valiant-issuer-backup/1
//     salt: <base64>
//     iv: <base64>
//     tag: <base64>
//     data: <base64>
//
// The passphrase is never written anywhere and never passed in argv (argv is visible in `ps` and lands in
// shell history). It comes from VALIANT_PASSPHRASE, or from stdin — which works the same whether it is
// piped or typed at a prompt.
import { randomBytes, pbkdf2Sync, createCipheriv, createDecipheriv } from "node:crypto";
import { readFileSync, writeFileSync, chmodSync } from "node:fs";

const MAGIC = "valiant-issuer-backup/1";
const ITERATIONS = 310000; // OWASP-era figure for PBKDF2-HMAC-SHA256
const KEY_LEN = 32;

/** Read the passphrase without putting it in argv. Throws a clear error when there is none. */
export function readPassphrase(env = process.env, stdin = process.stdin) {
  const fromEnv = env.VALIANT_PASSPHRASE;
  if (fromEnv && fromEnv.length >= 8) return fromEnv;
  if (fromEnv && fromEnv.length < 8) {
    throw new Error("VALIANT_PASSPHRASE is shorter than 8 characters — that is not a lock on a signing key.");
  }
  // Piped or typed: either way it arrives on stdin. A TTY echoes, which is a known limitation of doing
  // this with no dependency; the environment variable is the quiet path.
  let data;
  try {
    data = readFileSync(0, "utf8");
  } catch {
    data = "";
  }
  const v = (data || "").trim();
  if (!v) {
    throw new Error(
      "No passphrase. Set VALIANT_PASSPHRASE, or pipe one in:\n" +
        "  printf '%s' 'your passphrase' | node tools/issuer.mjs backup",
    );
  }
  if (v.length < 8) throw new Error("Passphrase shorter than 8 characters — that is not a lock on a signing key.");
  return v;
}

export function encryptKey(plaintext, passphrase) {
  const salt = randomBytes(16);
  const iv = randomBytes(12);
  const key = pbkdf2Sync(passphrase, salt, ITERATIONS, KEY_LEN, "sha256");
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const data = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [
    MAGIC,
    `salt: ${salt.toString("base64")}`,
    `iv: ${iv.toString("base64")}`,
    `tag: ${tag.toString("base64")}`,
    `data: ${data.toString("base64")}`,
    "",
  ].join("\n");
}

export function decryptKey(archive, passphrase) {
  const lines = String(archive).split(/\r?\n/); // CRLF: a Windows-written file must restore on Linux too
  if (lines[0]?.trim() !== MAGIC) {
    throw new Error(`not a valiant issuer backup (expected first line "${MAGIC}")`);
  }
  const field = (name) => {
    const l = lines.find((x) => x.toLowerCase().startsWith(`${name}:`));
    if (!l) throw new Error(`archive is missing its ${name} line`);
    return Buffer.from(l.slice(l.indexOf(":") + 1).trim(), "base64");
  };
  const salt = field("salt");
  const iv = field("iv");
  const tag = field("tag");
  const data = field("data");
  const key = pbkdf2Sync(passphrase, salt, ITERATIONS, KEY_LEN, "sha256");
  const decipher = createDecipheriv("aes-256-gcm", key, iv);
  decipher.setAuthTag(tag);
  // GCM throws here on a wrong passphrase or a tampered archive — before anything is written.
  return Buffer.concat([decipher.update(data), decipher.final()]);
}

export function writeArchive(path, contents) {
  writeFileSync(path, contents, { mode: 0o600 });
  try {
    chmodSync(path, 0o600);
  } catch {
    /* Windows ignores POSIX modes; the file is still the user's own. */
  }
}

export { MAGIC, ITERATIONS };
