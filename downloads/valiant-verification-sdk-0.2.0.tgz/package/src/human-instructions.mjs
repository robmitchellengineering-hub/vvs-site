// human-instructions — the checkable half of "how you talk to Rob".
//
// SOURCE OF THE RULES. `.dsh/skills/working-with-rob`, in his own words:
//
//   "I need to be stepped through things taken to url and have compilable input to put in there if
//    you need me to physically do things, I'm operating you on mobile over a remote connection so my
//    ability is restricted."
//   "I cant see where the there are too many tabs."
//
// On 2026-10-26 an instruction said: copy the issuer key to
// "<your password manager or encrypted folder>/valiant-issuer-key.pem". The angle brackets are a
// placeholder, not a path; the command could not work, and what he did instead was paste a private
// key into email. That was not carelessness on his part — it was a defective instruction, and it took
// a security incident to notice.
//
// So this module lints instructions written FOR A HUMAN. It is deliberately narrow: it checks what
// can be checked mechanically, and says which rules it cannot (see docs/RULES-WORKING-WITH-ROB.md).
//
// Five checks, each traceable to a sentence he actually said:
//   H0 should-not-exist  an instruction to the human with no reason it cannot be the agent's job.
//                        Rob, 2026-10-26: "ideally i dont want to be copy pasting terminalling at all"
//                        — copy-paste is the WORST case, not the good one. The only legitimate human
//                        steps are his credentials, his consent, his payment, a physical action, or a
//                        secret only he may hold. Everything else is the agent's failure to execute.
//   H1 placeholder   `<…>`, `…`, or PASTE/YOUR_ inside a code block — the command cannot run as given
//   H2 mac-path      a code block telling him to `cd ~/…` or use a /Users/… path: he is on a phone
//   H3 no-success    a code block with no sentence nearby saying what working looks like
//   H4 ui-no-url     an instruction to open/press/click with no URL anywhere in the document
//
// Exit codes live in the CLI (tools/check-instructions.mjs); this module only reports findings.

/** Fenced code blocks with their line numbers. */
function codeBlocks(markdown) {
  const lines = markdown.split("\n");
  const blocks = [];
  let open = null;
  for (let i = 0; i < lines.length; i++) {
    const fence = /^\s*(```|~~~)/.exec(lines[i]);
    if (fence && !open) {
      open = { start: i, body: [] };
      continue;
    }
    if (fence && open) {
      blocks.push({ startLine: open.start + 1, endLine: i, body: open.body.join("\n"), lines: open.body });
      open = null;
      continue;
    }
    if (open) open.body.push(lines[i]);
  }
  return { blocks, lines };
}

const PLACEHOLDER = [
  { re: /<[A-Za-z][^>\n]{0,80}>/, why: 'angle-bracket placeholder — a real value goes here, so this cannot be pasted as-is' },
  { re: /…|\.\.\.(?=\s*(?:#|\/|$))/, why: 'an ellipsis stands in for real content' },
  { re: /\b(?:PASTE|YOUR_[A-Z_]+|YOUR-[A-Z-]+|INSERT_[A-Z_]+|REPLACE_ME)\b/, why: 'a placeholder token, not a value' },
];

const MAC_PATH = /(?:^|\s)(?:cd\s+)?(?:~\/|\/Users\/[A-Za-z])/;

// The five things that genuinely are not the agent's to do. Anything else is a dodged task.
const HUMAN_ONLY = /only you can:\s*([^\n]*)/i;
const REASONS = [
  { re: /credential|password|token|key of yours|api key/i, why: 'a credential only he holds' },
  { re: /consent|approve|authori[sz]e|permission|agree/i, why: 'his consent' },
  { re: /pay|purchase|card|billing|buy/i, why: 'his money' },
  { re: /physical|plug|insert|press the button|scan|photograph/i, why: 'a physical action' },
  { re: /secret (?:you|he) must (?:remember|hold)|passphrase/i, why: 'a secret only he may hold' },
];

/**
 * Lint a markdown document of instructions meant for a human.
 * @param {string} markdown
 * @param {object} [opts]
 * @param {boolean} [opts.humanOnPhone] default true — H2 only fires when the reader is mobile/remote
 * @returns {{findings: Array<{rule: string, line: number, detail: string, text: string}>}}
 */
export function checkInstructions(markdown, { humanOnPhone = true } = {}) {
  const { blocks, lines } = codeBlocks(markdown);
  const findings = [];

  for (const b of blocks) {
    // H1 — a placeholder inside a block is a command that cannot be pasted.
    b.lines.forEach((line, off) => {
      for (const p of PLACEHOLDER) {
        if (p.re.test(line)) {
          findings.push({
            rule: "H1",
            line: b.startLine + off,
            detail: p.why,
            text: line.trim().slice(0, 120),
          });
          break; // one finding per line is enough to fix it
        }
      }
    });

    // H2 — a Mac-only path handed to someone on a phone.
    if (humanOnPhone) {
      b.lines.forEach((line, off) => {
        if (MAC_PATH.test(line) && !/#\s*on the mac/i.test(line)) {
          findings.push({
            rule: "H2",
            line: b.startLine + off,
            detail: "this needs a terminal on that machine; the reader is on a phone over a remote connection",
            text: line.trim().slice(0, 120),
          });
        }
      });
    }

    // H3 — no statement of what working looks like, within 6 lines either side of the block.
    const from = Math.max(0, b.startLine - 7);
    const to = Math.min(lines.length, b.endLine + 6);
    const around = lines.slice(from, to).join("\n");
    if (!/(should see|you'll see|you will see|it should print|expect|looks like|prints|returns|when it works|what working)/i.test(around)) {
      findings.push({
        rule: "H3",
        line: b.startLine,
        detail: "nothing nearby says what success looks like, so the reader cannot tell if it worked",
        text: (b.lines[0] || "").trim().slice(0, 120),
      });
    }
  }

  // H4 — UI verbs with no URL anywhere. A path through menus is a dead end on a phone.
  const hasUrl = /https?:\/\//.test(markdown);
  if (!hasUrl) {
    // Must be an actual UI ACTION: a verb followed by a UI noun. "open work must have its items
    // here" is a noun phrase and matching it made this rule noisy enough to ignore — the first run
    // flagged PLAN.md and UNBUILT.md for the word "open" alone.
    const verb = /\b(?:open|press|click|tap|go to|navigate to|find)\s+(?:the\s+)?(?:settings|page|tab|menu|dashboard|panel|dialog|window|screen|link|option|button|section|dropdown)\b/i.exec(markdown);
    if (verb) {
      findings.push({
        rule: "H4",
        line: markdown.slice(0, verb.index).split("\n").length,
        detail: "an instruction to navigate with no URL in the document — a path through the UI is a dead end on a phone",
        text: markdown.slice(verb.index, verb.index + 80).replace(/\n/g, " "),
      });
    }
  }

  // H0 — an instruction block with no justification. This is the rule that would have stopped the
  // issuer-key command from existing at all: the agent held the key and the machine.
  const sections = markdown.split(/^(#{1,4}\s)/m);
  for (let i = 1; i < sections.length; i += 2) {
    const heading = sections[i + 1] ? sections[i + 1].split("\n")[0] : "";
    const body = sections[i + 1] || "";
    const addressed =
      /your turn|you need to|what you need to do|do this|action required|over to you/i.test(heading) ||
      /\b(?:you(?:'ll| will)? need to|please run|please open|please paste|please copy)\b/i.test(body);
    if (!addressed) continue;
    const m = HUMAN_ONLY.exec(body);
    const justified = m && REASONS.some((r) => r.re.test(m[1]));
    if (!justified) {
      const line = markdown.slice(0, markdown.indexOf(heading)).split("\n").length;
      findings.push({
        rule: "H0",
        line,
        detail:
          m
            ? `the stated reason ("${m[1].trim().slice(0, 60)}") is not one of the five only-he-can-do cases`
            : "an instruction for the human with no stated reason the agent cannot do it — copy-paste is the worst case, not the target",
        text: `## ${heading}`.slice(0, 120),
      });
    }
  }

  return { findings };
}

/** Human-readable one-per-line rendering, used by the CLI and the self-test. */
export function renderFindings(findings) {
  return findings
    .map((f) => `  ${f.rule}  line ${f.line}: ${f.detail}\n      ${f.text}`)
    .join("\n");
}

export const RULES = {
  H0: "an instruction for Rob must name which of the five only-he-can-do cases it is, or it is the agent's job",
  H1: "no placeholders inside a code block — the reader must be able to paste it",
  H2: "no Mac-only paths for a reader on a phone",
  H3: "say what they should see when it worked",
  H4: "give a URL, not a path through the UI",
};
