import { readFileSync } from "node:fs";

// Load and validate a config file. A config that does not name its gates and guards
// is refused, never guessed at. The config path is independent of the repo root so
// the SDK can drive a repo's checks without writing anything into that repo.
export function loadConfig(configPath) {
  let raw;
  try {
    raw = readFileSync(configPath, "utf8");
  } catch (e) {
    throw new Error(`cannot read config ${configPath} (${e.message})`);
  }
  let cfg;
  try {
    cfg = JSON.parse(raw);
  } catch (e) {
    throw new Error(`config ${configPath} is not valid JSON: ${e.message}`);
  }

  const gates = Array.isArray(cfg.gates) ? cfg.gates : [];
  const guards = Array.isArray(cfg.guards) ? cfg.guards : [];

  for (const [i, g] of gates.entries()) {
    if (!g.name || !Array.isArray(g.cmd) || g.cmd.length === 0) {
      throw new Error(`gates[${i}] needs a string "name" and a non-empty "cmd" array`);
    }
  }
  for (const [i, g] of guards.entries()) {
    if (!g.name || !g.file || typeof g.find !== "string") {
      throw new Error(`guards[${i}] needs "name", "file", and "find"`);
    }
    if (typeof g.replace !== "string") {
      throw new Error(`guards[${i}] needs a "replace" string`);
    }
    const hasCheck = Array.isArray(g.check) && g.check.length > 0;
    const hasFixture = Array.isArray(g.fixture) && g.fixture.length > 0;
    if (hasCheck === hasFixture) {
      throw new Error(`guards[${i}] needs exactly one of "check" (subject flavour) or "fixture" (guard-logic flavour)`);
    }
    if (g.kind !== undefined && g.kind !== "check" && g.kind !== "claim") {
      throw new Error(`guards[${i}] has an unknown "kind" "${g.kind}" — use "check" or "claim"`);
    }
  }

  const ledger = (cfg.ledger === false || cfg.ledger === null) ? null : (cfg.ledger ?? "KNOWN-HAZARDS.md");
  const unprovenBaseline = cfg.unprovenBaseline ?? 0;
  if (!Number.isInteger(unprovenBaseline) || unprovenBaseline < 0) {
    throw new Error(`config "unprovenBaseline" must be a non-negative integer, got ${JSON.stringify(cfg.unprovenBaseline)}`);
  }
  return { gates, guards, ledger, strict: cfg.strict === true, unprovenBaseline };
}
