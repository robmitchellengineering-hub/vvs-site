import { readFileSync } from "node:fs";
import { join } from "node:path";

// The incident ledger (Valiant principle 4): failures become memory. Every HAZARD
// entry must name a detection RULE and the GUARD that now enforces it — a hazard
// with no guard is a rule that can silently stop catching. Only headings that carry
// a hazard id (H1, HM1, HV1, ...) are held to the RULE+GUARD contract; other `## `
// sections (e.g. "Still open") are notes, not hazards.
const HAZARD_ID = /^H[A-Z0-9]+$/i;

// Does the block MENTION the word at all (anywhere, any shape)? Used only to tell "you never wrote
// a guard" apart from "you wrote one and the contract cannot read it" — two different fixes, and
// reporting them as one wastes the author's time.
function mentions(block, word) {
  return new RegExp(`(^|[\\s*_-])${word}\\b`, "im").test(block);
}

/** Which half of the contract is missing, and whether it looks like a near-miss. */
function misses(block, ruleRe, guardRe) {
  const out = [];
  if (!ruleRe.test(block)) out.push(mentions(block, "RULE") ? "RULE written in a shape the contract does not read" : "no RULE");
  if (!guardRe.test(block)) out.push(mentions(block, "GUARD") ? "GUARD written in a shape the contract does not read" : "no GUARD");
  return out;
}

export function checkLedger(repoRoot, ledgerFile) {
  if (ledgerFile == null) {
    return { ok: true, absent: true, detail: "absent (declared in config) — principle 4 not yet adopted" };
  }
  const path = join(repoRoot, ledgerFile);
  let text;
  try {
    text = readFileSync(path, "utf8");
  } catch (e) {
    return { ok: false, detail: `ledger ${ledgerFile} missing: ${e.message}` };
  }

  const sections = text.split(/^## /m).slice(1).map((block) => {
    const heading = block.split("\n")[0].trim();
    const id = heading.split(/\s+/)[0] || "";
    return { heading, id, isHazard: HAZARD_ID.test(id), block };
  });
  const hazards = sections.filter((s) => s.isHazard);
  const notes = sections.filter((s) => !s.isHazard);

  if (hazards.length === 0) {
    return { ok: false, detail: `no hazard entries in ${ledgerFile} (expected "## Hxx" headings)` };
  }
  // The contract is a line that BEGINS "RULE:" or "GUARD:" (a leading "- " or "* " is fine, any
  // case). Anything else is prose, however true it is. That is worth saying at the failure, because
  // a hazard that names its guard as "- GUARD (built, mutation-proven ...):" looks like compliance
  // to the person who wrote it and is invisible to this regex — measured 2026-10-26 on harness-mesh,
  // where three hazards "had no guard" and two of them did, in bold or behind a parenthesis. A
  // verification tool whose failure message does not teach the accepted shape sends the author
  // hunting for a guard they already wrote.
  const RULE = /^[-*]*\s*RULE:/im;
  const GUARD = /^[-*]*\s*GUARD:/im;
  const bad = hazards.filter((s) => !RULE.test(s.block) || !GUARD.test(s.block));
  if (bad.length > 0) {
    const detail = bad.map((s) => `${s.id} (${misses(s.block, RULE, GUARD).join(", ")})`).join("; ");
    return {
      ok: false,
      detail:
        `hazards missing RULE or GUARD: ${detail}. ` +
        `The contract is a line starting "RULE:" and a line starting "GUARD:" ` +
        `(a leading "- " or "* " is allowed). Bold markup ("**RULE:**") and a qualifier before the ` +
        `colon ("GUARD (built):") do NOT match — state the qualifier after the colon instead.`,
    };
  }
  const noteSuffix = notes.length ? `, ${notes.length} note(s)` : "";
  return { ok: true, detail: `${hazards.length} hazards, each with RULE + GUARD${noteSuffix}` };
}
