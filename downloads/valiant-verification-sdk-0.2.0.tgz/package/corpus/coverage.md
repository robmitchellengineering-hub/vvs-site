# Invariant coverage — how each of the 22 is enforced

The SDK does not pretend every invariant is a drop-in static check — that would be dishonest. Each
of the 22 splits into one of three enforcement paths:

| # | invariant | enforcement |
|---|---|---|
| 1 | Contract integrity | reference guard (named-export resolution) — same shape as `resolve-imports.mjs` but reads exports |
| 2 | Silent no-op edits forbidden | **engine** — `valiant mutate` refuses a `find` matching 0 or 2+ sites |
| 3 | Bound the model's output | process rule (adopter's AI-call convention) |
| 4 | Schema ships with its migration | process rule (adopter's schema/migration layout) |
| 5 | Sync against the live source | process rule (needs a drift check against the adopter's remote) |
| 6 | Verify before depending | process rule (planner behaviour) |
| 7 | Schema drift degrades gracefully | process rule (runtime behaviour) |
| 8 | A module is not verified until loaded | **reference guard** — `reference-guards/resolve-imports.mjs` |
| 9 | A silent zero is a bug | process rule (needs a known-good sample to sample against) |
| 10 | Never neutralise a build step | **reference guard** — `reference-guards/no-swallowed-build.mjs` |
| 11 | Review behaviour, not the surface | process rule (needs a diff + judgement) |
| 12 | Data isolation is a decision | process rule (adopter's data model) |
| 13 | "Nothing failed" is not "the gates ran" | **engine** — `valiant verify` |
| 14 | A declaration outlives its block | process rule (lint `no-undef`, stack-specific) |
| 15 | Prove the check can fail | **engine** — `valiant mutate` |
| 16 | Name the machines the output runs on | process rule (adopter's build/release layout) |
| 17 | The verdict is the build's | process rule (runtime behaviour) |
| 18 | Lint coverage, render the surface | process rule (lint config + a real browser) |
| 19 | A tool that rewrites the tree owns it | **engine** — `valiant mutate`'s conflict check |
| 20 | Close stdin on subprocesses | **reference guard** — `reference-guards/closed-stdin.mjs` |
| 21 | Portable filenames | **reference guard** — `reference-guards/portable-filenames.mjs` |
| 22 | The loop survives its own queue | process rule (adopter's loop structure) |

## The three paths, counted

- **engine (4):** 2, 13, 15, 19 — the CLI already enforces these by construction.
- **reference guard (4):** 8, 10, 20, 21 — shipped here, zero-dependency, portable to any Node tree.
- **process rule (14):** the rest — the SDK ships the *rule*; the adopter writes the *guard* against
  their own stack, because the check depends on their layout, convention, or runtime behaviour. This is
  the honest onboarding cost, not a gap: a rule whose check depends on the adopter's schema or build
  layout cannot be shipped as a drop-in script without pretending.

Each reference guard is a standalone script (exit 0 = pass, non-zero = fail). Wire it into a
`valiant.json` with a mutation against your own subject, exactly like any other guard — the proof of
failure is what makes it count.
