# The guard corpus — seed

This is the **content** half of the SDK (the engine is `bin/` + `src/`). The engine enforces the
contracts; this corpus is *what* gets caught — the failure modes bought with real incidents.

## What is here

`seed-invariants.json` — the **22 universal invariants**, extracted verbatim from
`morpheus-self-hosted/public/verification-spec.md` §6. Each is a rule any agent toolchain will meet,
independent of language or stack.

`seed-hazards.json` — the **26 hazards** that bought those invariants, each mapped to its invariant
(`invariant: 1-22`) or marked product-specific (`invariant: null`). 22 universal + 4 product-specific
(a data model's scoping, a build step that rewrites a specific file, a lockfile policy, and one
product's protected paths). The hazard name is the incident framing; the invariant it points at is
the portable rule. The full incident records live in Morpheus's `KNOWN-HAZARDS.md`.

## How it grows

- **Only by real incident, never by imagination.** A new invariant is filed the way the first 26 were:
  a breakage happened, a detection rule was written, and a guard was proven to fail on it.
- **Additive.** A new invariant does not invalidate an older one; the corpus version advances, the
  rules already shipped stay.
- **Versioned, dated.** The corpus is a dated feed (`2026-10-20`), not a "latest" pointer. A customer
  pins a version and upgrades deliberately. The engine's version is separate (semver, in `package.json`).

## The full shape (engine + corpus)

A conforming adopter gets: the `valiant` CLI (engine) + this corpus (seed content) + their own
guards mapped from the invariants against their own code. The invariants are rules, not drop-in
scripts — a Node shop ships reference guards; other stacks implement each invariant against the rule.
