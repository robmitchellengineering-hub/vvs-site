#!/usr/bin/env node
// Reference guard — invariant 20: "close stdin on spawned subprocesses."
// Flags spawn/exec calls that re-inherit stdin, so a child that prompts hangs the loop instead of EOF.
// Usage: node closed-stdin.mjs [dir]   (exit 0 = clean, 1 = inherited stdin found)
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';

const root = resolve(process.argv[2] || '.');
const SKIP = new Set(['node_modules', '.git', 'dist', 'build', '.vv']);
const LOOK = ['.mjs', '.js', '.cjs', '.ts'];

const problems = [];
function walk(dir) {
  for (const name of readdirSync(dir)) {
    if (SKIP.has(name)) continue;
    const p = join(dir, name);
    const s = statSync(p);
    if (s.isDirectory()) { walk(p); continue; }
    if (!LOOK.some((e) => name.endsWith(e))) continue;
    const text = readFileSync(p, 'utf8');
    const lines = text.split('\n');
    lines.forEach((line, i) => {
      if (/stdio:\s*['"]inherit['"]|stdio:\s*\[\s*['"]inherit['"]/.test(line)) {
        problems.push(`${p}:${i + 1}: ${line.trim()}`);
      }
    });
  }
}
walk(root);

if (problems.length) {
  console.error('spawns that inherit stdin:\n  ' + problems.join('\n  '));
  process.exit(1);
}
console.log('no subprocess inherits stdin');
