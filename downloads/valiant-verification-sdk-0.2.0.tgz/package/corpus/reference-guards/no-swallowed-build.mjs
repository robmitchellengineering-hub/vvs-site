#!/usr/bin/env node
// Reference guard — invariant 10: "never neutralise a build step."
// Flags shell `|| true` / `|| :` swallows, which turn a failed install/build into a green one.
// Usage: node no-swallowed-build.mjs [dir]   (exit 0 = clean, 1 = swallow found)
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';

const root = resolve(process.argv[2] || '.');
const SKIP = new Set(['node_modules', '.git', 'dist', 'build', '.vv']);
const LOOK = ['.sh', '.yml', '.yaml', '.json', '.mjs', '.js', '.ts', 'Dockerfile', '.txt'];

const problems = [];
function walk(dir) {
  for (const name of readdirSync(dir)) {
    if (SKIP.has(name)) continue;
    const p = join(dir, name);
    const s = statSync(p);
    if (s.isDirectory()) { walk(p); continue; }
    if (!LOOK.some((e) => name.endsWith(e))) continue;
    const lines = readFileSync(p, 'utf8').split('\n');
    lines.forEach((line, i) => {
      if (/\|\|\s*(true|:)\b/.test(line)) {
        problems.push(`${p}:${i + 1}: ${line.trim()}`);
      }
    });
  }
}
walk(root);

if (problems.length) {
  console.error('swallowed build steps found:\n  ' + problems.join('\n  '));
  process.exit(1);
}
console.log('no swallowed build steps');
