#!/usr/bin/env node
// Reference guard — invariant 21: "portable filenames."
// Flags committed paths a Windows checkout cannot represent: reserved chars, or a trailing dot/space.
// Usage: node portable-filenames.mjs [dir]   (exit 0 = clean, 1 = illegal name found)
import { readdirSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';

const root = resolve(process.argv[2] || '.');
const SKIP = new Set(['node_modules', '.git']);
const problems = [];

function walk(dir) {
  for (const name of readdirSync(dir)) {
    if (SKIP.has(name)) continue;
    if (/[<>:"|?*]/.test(name) || /[. ]$/.test(name)) {
      problems.push(join(dir, name));
    }
    const p = join(dir, name);
    let s;
    try { s = statSync(p); } catch { continue; }
    if (s.isDirectory()) walk(p);
  }
}
walk(root);

if (problems.length) {
  console.error('non-portable paths:\n  ' + problems.join('\n  '));
  process.exit(1);
}
console.log('all filenames are portable');
