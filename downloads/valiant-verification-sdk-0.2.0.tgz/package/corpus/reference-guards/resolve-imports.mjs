#!/usr/bin/env node
// Reference guard — invariant 8: "a module is not verified until it is loaded."
// Resolves every relative import specifier in a tree and fails on any that does not
// point at a real file. Syntax and lint do not resolve specifiers; this does.
// Usage: node resolve-imports.mjs [dir]   (exit 0 = clean, 1 = unresolved import found)
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';

const root = resolve(process.argv[2] || '.');
const SKIP = new Set(['node_modules', '.git', 'dist', 'build', '.vv']);
const EXT = ['.js', '.mjs', '.cjs', '.jsx', '.ts', '.tsx'];

const isFile = (p) => { try { return statSync(p).isFile(); } catch { return false; } };
const candidates = (base) => {
  const out = [base]; // exact — covers a specifier that already carries its extension
  for (const e of EXT) {
    out.push(base + e);
    out.push(join(base, 'index' + e));
  }
  return out;
};

const problems = [];
function walk(dir) {
  for (const name of readdirSync(dir)) {
    if (SKIP.has(name)) continue;
    const p = join(dir, name);
    const s = statSync(p);
    if (s.isDirectory()) { walk(p); continue; }
    if (!EXT.some((e) => name.endsWith(e))) continue;
    const text = readFileSync(p, 'utf8');
    for (const m of text.matchAll(/(?:from\s+|import\s*\(\s*|import\s+)['"](\.{1,2}\/[^'"]+)['"]/g)) {
      const base = resolve(dirname(p), m[1]);
      if (!candidates(base).some(isFile)) {
        problems.push(`${p}: unresolved import "${m[1]}"`);
      }
    }
  }
}

walk(root);

if (problems.length) {
  console.error('unresolved imports:\n  ' + problems.join('\n  '));
  process.exit(1);
}
console.log('all relative imports resolve');
