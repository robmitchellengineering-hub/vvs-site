# Valiant Verification SDK

The standalone runner for **Valiant Verification** — the discipline that makes "done"
mean "verified". The open specification is `robmitchellengineering-hub/valiant-verification`;
this repository is the licensed **SDK** that implements it as an installable tool.

> **Repo:** https://github.com/robmitchellengineering-hub/valiant-verification-sdk (private — it is the licensed SDK layer; the spec is the public Apache-2.0 repo).

A repo adopts the SDK by adding one `valiant.json` that *references its existing checks*.
The SDK never edits them — it runs a throwaway copy.

## Install

```sh
npm install -g valiant-verification-sdk
valiant status
```

You should see the gate, guard and ledger counts for the repo you are in. From a checkout without
installing, run `node bin/valiant.mjs status` instead.

## Commands

| command | what it enforces |
|---|---|
| `valiant verify` | runs every gate **by name**; missing / cannot-check (exit 2) / exit-0-with-no-output = fail |
| `valiant mutate` | injects each guard's seeded fault into a throwaway copy and requires the guard to go red; `survived` / `stale` = fail |
| `valiant ledger` | validates the incident ledger — every entry must name a RULE and a GUARD |
| `valiant status` | prints gate / guard / ledger counts |

## The config (`valiant.json`)

```json
{
  "gates": [
    { "name": "lint", "cmd": ["npm", "run", "lint"] }
  ],
  "guards": [
    {
      "name": "lint",
      "file": "src/app.js",
      "find": "const ok = true",
      "replace": "const ok = false",
      "check": ["npm", "run", "lint"]
    }
  ],
  "ledger": "KNOWN-HAZARDS.md"
}
```

A gate is a named command that must exit 0 *and* produce evidence. A guard declares the
file to sabotage, the exact `find`/`replace` (must match exactly once), and the command
that must go red — `check` for the subject flavour (sabotage the guarded file, the guard
goes red) or `fixture` for the guard-logic flavour (sabotage the guard's own logic, a
synthetic exerciser goes red). A guard may carry `"kind": "claim"` to mark a reality-guard — a
guard whose subject is a published claim and whose `check` asserts it against the live system
(the "docs say N, reality has M" class). The incident ledger is validated for RULE + GUARD on every entry.

## Proof is the adoptions, not a self-test

The SDK deliberately does **not** validate itself (no dogfooding — a verifier that verifies
itself is circular). It is proven by driving real repos: the recipes in `examples/` and the
adopted `valiant.json` files in harness-mesh, pacland and morpheus. Each guard in `corpus/` is
proven against one of those repos, never against a toy fixture shipped here.

## Install into a repo (recipes in `examples/`)

A repo is adopted by adding a `valiant.json` (or running `valiant --config <file>`) that
*references its existing checks* — nothing in the target repo is edited. Each recipe is a
ready-to-use config pointing at a repo's real verification entry points:

| recipe | target | status |
|---|---|---|
| `examples/harness-mesh.json` | `~/harness-mesh` | ✅ verify 3/3, ledger 7 hazards — proven |
| `examples/pacland.json` | `pacland` | ✅ verify 1/1 (114 tests) — proven; ⚠️ no ledger |
| `examples/morpheus.json` | `morpheus-self-hosted` | ✅ driven — SDK ran the real ~130-guard `verify.mjs`; the shared checkout was on another session's `dsh/aggregate-guards` branch, so a clean-`main` result needs a worktree |
| `examples/airmatrix.json` | `airmatrix` | recipe written — full run needs a clean worktree (checkout was mid `rob-core`→`amt-core` rename) and must not run on the CI-shared Mac (cargo build = unattributable measurement) |
| `examples/morpheos.json` | `MorpheOS` | recipe written — `check.sh` refuses on macOS (H16, Linux-only compositor tests); run on the `studio-linux` VM |

Run one: `cd <repo> && valiant verify --config <sdk>/examples/<name>.json`

**Notes from the first two installs.** A gate that passes with empty stdout (e.g. Python's
`unittest`, which writes its summary to stderr) must declare `"expectStderr": true`, or it is
rightly flagged suspect — a pass must produce evidence. A ledger whose non-hazard `## ` sections
(e.g. "Still open") are held to the RULE+GUARD contract only when they carry a hazard id.

