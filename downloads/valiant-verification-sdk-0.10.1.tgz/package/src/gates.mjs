import { spawnSync } from "node:child_process";
import { runCheck } from "./spawn.mjs";

// The named-gate contract (Valiant principle 1): a gate is run BY NAME, and a gate
// that is missing, cannot-check (exit 2), or passes with no evidence is a FAIL —
// never a silent pass (H17).
/**
 * A POLICY TEST is a gate whose own rule is exercised: the same check is run against inputs that must pass and inputs
 * that must fail, and a rule with no failing case is rejected by the TOOL, not by a reviewer.
 *
 * Plan item 2, borrowed in pattern from cfn-guard (Apache-2.0): "a rule that has never been shown to fail is not a
 * rule". It is the same argument as mutation testing, applied to policy instead of code — and no engine, because our
 * gates are commands rather than rules over documents.
 *
 * Shape:  { "name": "no-secrets", "type": "policy-tests", "cmd": ["./policy"], "cases": [
 *           { "input": "fixtures/clean.json", "expect": "pass" },
 *           { "input": "fixtures/leaky.json", "expect": "fail" } ] }
 * The case's input is appended to the command, so a policy script takes one argument.
 */
export function runPolicyTests(gate, repoRoot) {
  const { name, cmd, cases = [] } = gate;
  const fails = cases.filter((c) => c.expect === "fail").length;
  if (fails === 0) {
    // THE POINT OF THE GATE TYPE. A policy whose only evidence is inputs it accepts has not been shown to be able to
    // reject anything, which is the failure this whole product exists to catch.
    return { name, ok: false, detail: "no case expects failure — a policy that has never been shown to reject something is not a policy" };
  }
  const out = [];
  let bad = 0;
  for (const c of cases) {
    const res = runCheck(cmd, [...cmd.slice(1), c.input], { cwd: repoRoot });
    const status = res.error ? null : res.status;
    const expected = c.expect === "pass" ? 0 : null;
    const ok = c.expect === "pass" ? status === 0 : status !== 0 && status !== null;
    if (!ok) bad++;
    out.push({ input: c.input, expect: c.expect, exit: status, ok, err: res.error ? res.error.message : null });
  }
  const detail = bad === 0
    ? `${cases.length} case(s): ${cases.length - fails} pass-fixture(s) accepted, ${fails} fail-fixture(s) rejected`
    : `${bad} of ${cases.length} case(s) did not behave: ` + out.filter((o) => !o.ok).map((o) => `${o.input} expected ${o.expect}, got exit ${o.exit}`).join("; ");
  return { name, ok: bad === 0, detail, cases: out };
}

export function runGate(gate, repoRoot) {
  if (gate?.type === "policy-tests") return runPolicyTests(gate, repoRoot);
  const { name, cmd, expectStderr = false, quiet: wantQuiet = false } = gate;
  // A CUSTOMER MAY NOT BUY SILENCE. `quiet: true` in valiant.json skipped the "a pass must produce evidence" rule, so
  // `{"cmd":["node","-e",""],"quiet":true}` passed having printed nothing (independent review #6, F12).
  const quiet = wantQuiet && process.env.VALIANT_INTERNAL_QUIET === "1";
  const res = runCheck(cmd, cmd.slice(1), { cwd: repoRoot });

  if (res.error) {
    return { name, ok: false, detail: `did not run: ${res.error.message}` };
  }
  const status = res.status;
  const out = (res.stdout || "").trim();
  // NOISE IS NOT EVIDENCE. npm's update notice goes to stderr, so the first run on a clean machine read
  // as "exit 0 with unexpected stderr — suspect" and the second passed with nothing changed. A gate that
  // flips colour because a package manager mentioned a new version teaches people to ignore it.
  const NOISE = /^(npm (notice|warn)|\s*$)/i;
  const err = (res.stderr || "").split("\n").filter((l) => !NOISE.test(l)).join("\n").trim();

  if (status === null) return { name, ok: false, detail: "killed by signal" };
  if (status === 2) return { name, ok: false, cannotCheck: true, detail: "cannot check (exit 2) — never a silent pass" };
  if (status !== 0) {
    return { name, ok: false, detail: `exit ${status}`, show: (err || out).slice(0, 200) };
  }

  if (!quiet) {
    const hasOut = out.length > 0;
    const hasErr = err.length > 0;
    if (!hasOut && !hasErr) {
      return { name, ok: false, detail: "exit 0 with no output — suspect (a pass must produce evidence)" };
    }
    if (!hasOut && hasErr && !expectStderr) {
      return { name, ok: false, detail: "exit 0 with empty stdout — suspect (declare expectStderr if stderr is the evidence)" };
    }
    if (hasOut && hasErr && !expectStderr) {
      return { name, ok: false, detail: "exit 0 with unexpected stderr — suspect (declare expectStderr to allow it)" };
    }
  }
  return { name, ok: true, detail: "exit 0", show: (out || err).slice(0, 200) };
}

export function runAllGates(gates, repoRoot) {
  return gates.map((g) => runGate(g, repoRoot));
}
