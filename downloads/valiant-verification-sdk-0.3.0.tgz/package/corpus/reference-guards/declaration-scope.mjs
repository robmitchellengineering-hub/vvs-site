#!/usr/bin/env node
// Reference guard — invariant 14: "a declaration outlives its block."
//
// `const` inside a block is scoped to it. Code that reads it after the closing brace is either a bug that only shows
// under some paths, or a declaration that belongs one level out. This is a deliberately small, dependency-free
// approximation: it tracks brace depth, records declarations made at depth > 0, and reports a use of that name after
// its block has closed.
// Usage: node declaration-scope.mjs [dir]   (exit 0 = no outliving declaration, 1 = one found)
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';

const root = resolve(process.argv[2] || '.');
const SKIP = new Set(['node_modules', '.git', 'dist', 'build', '.venv', '__pycache__', 'target']);
const files = [];
(function walk(dir) {
  let entries = [];
  try { entries = readdirSync(dir); } catch { return; }
  for (const e of entries) {
    if (SKIP.has(e)) continue;
    const p = join(dir, e);
    let s = null;
    try { s = statSync(p); } catch { continue; }
    if (s.isDirectory()) { walk(p); continue; }
    if (/\.[cm]?[jt]sx?$/.test(e) && !/\.min\./.test(e)) files.push(p);
  }
})(root);

let bad = 0;
for (const f of files) {
  const src = readFileSync(f, 'utf8').split('\n');
  const stack = [];                      // {names:Set, depth}
  let depth = 0;
  const reported = new Set();
  src.forEach((line, i) => {
    const open = (line.match(/\{/g) || []).length;
    const close = (line.match(/\}/g) || []).length;
    const decl = /^\s*(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=/.exec(line);
    if (decl && depth > 0) stack.push({ names: new Set([decl[1]]), depth });
    // A use of a name declared in a block that has already closed.
    for (const entry of [...stack]) {
      if (depth < entry.depth) {
        for (const name of entry.names) {
          const re = new RegExp(`\\b${name}\\b`);
          if (re.test(line) && !reported.has(`${name}:${i}`)) {
            console.log(`  FAIL ${relative(root, f)}:${i + 1} — "${name}" was declared inside a block (depth ${entry.depth}) and is used after it closed`);
            reported.add(`${name}:${i}`);
            bad++;
          }
        }
        stack.splice(stack.indexOf(entry), 1);
      }
    }
    depth += open - close;
    if (depth < 0) depth = 0;
  });
}
if (!bad) console.log(`  ok   ${files.length} source file(s): no declaration outlives its block`);
process.exit(bad ? 1 : 0);
