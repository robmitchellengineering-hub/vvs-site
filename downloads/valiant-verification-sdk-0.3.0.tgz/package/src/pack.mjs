// pack.mjs — one bundle a third party can verify offline, with no licence, no network and no account.
//
// Plan item 6. Proofs were scattered across the ledger, receipts, job results and the corpus; nothing packaged them, so
// an auditor had to trust our narrative. A pack is the claims, the evidence, a MANIFEST of every hash, and — when this
// machine holds the issuer key — a signature over the manifest that verifies against the public key the SDK ships.
//
// The verify path is deliberately outside everything gated: a pack that needs a licence to check is not evidence an
// auditor can use.
import { createHash, sign as signBytes, verify as verifyBytes } from "node:crypto";
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from "node:fs";
import { join, relative, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));
const sha = (b) => createHash("sha256").update(b).digest("hex");

export function createPack({ repoRoot, cfg, outDir = "valiant-pack" }) {
  const dir = join(repoRoot, outDir);
  mkdirSync(dir, { recursive: true });
  const files = [];
  const add = (from, to) => {
    try {
      if (!existsSync(from)) return false;
      const dest = join(dir, to);
      mkdirSync(dirname(dest), { recursive: true });
      const body = readFileSync(from);
      writeFileSync(dest, body);
      files.push({ path: to, sha256: sha(body), bytes: body.length });
      return true;
    } catch { return false; }
  };

  // The evidence this repo already produced. Missing pieces are recorded as missing, not skipped silently.
  const included = {
    ledger: cfg.ledger ? add(join(repoRoot, cfg.ledger), "ledger.md") : false,
    mutations: add(join(repoRoot, "mutations.json"), "mutations.json"),
    config: add(join(repoRoot, "valiant.json"), "valiant.json"),
  };
  // The verifier's own record, when this machine has one: the (diff, verdict) pairs it actually judged.
  const home = join(process.env.HOME || ".", ".valiant");
  included.outcomes = add(join(home, "outcomes.jsonl"), "outcomes.jsonl");
  included.decisions = add(join(home, "decisions.jsonl"), "decisions.jsonl");
  // The corpus version this pack was produced against.
  const corpus = join(HERE, "..", "corpus", "current.txt");
  included.corpus = add(corpus, "corpus-version.txt");

  const manifest = {
    kind: "valiant-evidence-pack",
    at: new Date().toISOString(),
    included,
    files,
    note: "Every file's sha256 is listed. The manifest is signed with the issuer key when this machine has one; the public key ships with the SDK, so verification needs no network and no account.",
  };
  const body = Buffer.from(`${JSON.stringify(manifest, null, 2)}\n`);
  writeFileSync(join(dir, "MANIFEST.json"), body);

  // Sign the manifest when the issuer key is here. A customer without one still gets a tamper-evident pack.
  let signed = false;
  try {
    const keyPath = join(home, "issuer-key.pem");
    if (existsSync(keyPath)) {
      const sig = signBytes(null, body, readFileSync(keyPath, "utf8"));
      writeFileSync(join(dir, "MANIFEST.sig"), sig.toString("base64") + "\n");
      signed = true;
    }
  } catch { signed = false; }

  writeFileSync(join(dir, "HOW-TO-VERIFY.md"),
    `# Verifying this pack\n\n` +
    `No network, no account, no licence is needed.\n\n` +
    "```sh\nvaliant pack --verify <this directory>\n```\n\n" +
    `It checks the sha256 of every file against MANIFEST.json${signed ? ", then verifies MANIFEST.sig against the public key shipped with the SDK" : " (this pack is unsigned — hashes only)"}, ` +
    "and names the first file that does not match.\n");
  return { dir, files, signed, manifest };
}

export function verifyPack(dir) {
  const manifestPath = join(dir, "MANIFEST.json");
  if (!existsSync(manifestPath)) return { ok: false, detail: `no MANIFEST.json in ${dir} — this is not a pack` };
  let manifest = null;
  const body = readFileSync(manifestPath);
  try { manifest = JSON.parse(body.toString("utf8")); } catch (e) { return { ok: false, detail: `MANIFEST.json is not valid JSON (${e.message})` }; }
  if (manifest.kind !== "valiant-evidence-pack") return { ok: false, detail: "MANIFEST.json is not a valiant evidence pack" };

  // 1. every listed file, byte for byte
  for (const f of manifest.files ?? []) {
    const p = join(dir, f.path);
    if (!existsSync(p)) return { ok: false, detail: `${f.path} is listed in the manifest but missing from the pack` };
    const got = sha(readFileSync(p));
    if (got !== f.sha256) return { ok: false, detail: `${f.path} does not match the manifest (sha256 ${got.slice(0, 12)} ≠ ${f.sha256.slice(0, 12)}) — it was changed after the pack was made` };
  }
  // 2. nothing added that the manifest does not name
  const listed = new Set([...(manifest.files ?? []).map((f) => f.path), "MANIFEST.json", "MANIFEST.sig", "HOW-TO-VERIFY.md"]);
  for (const name of readdirSync(dir)) {
    if (!listed.has(name) && !statSync(join(dir, name)).isDirectory()) {
      return { ok: false, detail: `${name} is in the pack but not in the manifest — the pack is not the pack that was made` };
    }
  }
  // 3. the signature, when there is one
  const sigPath = join(dir, "MANIFEST.sig");
  if (existsSync(sigPath)) {
    const pubPath = join(HERE, "..", "licence-public.pem");
    if (!existsSync(pubPath)) return { ok: false, detail: "the manifest is signed but this SDK build has no public key to check it with" };
    try {
      const ok = verifyBytes(null, body, readFileSync(pubPath, "utf8"), Buffer.from(readFileSync(sigPath, "utf8").trim(), "base64"));
      if (!ok) return { ok: false, detail: "MANIFEST.sig does not verify against the public key this SDK ships — the manifest was not signed by this issuer" };
    } catch (e) { return { ok: false, detail: `the signature could not be checked (${e.message})` }; }
  }
  return { ok: true, detail: `${manifest.files?.length ?? 0} file(s) verified${existsSync(sigPath) ? ", manifest signature valid" : ", unsigned (hashes only)"}` };
}
