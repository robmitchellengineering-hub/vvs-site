// hooks.mjs — put the gate in front of `git push`, and record the decision so a dead hook is caught.
//
// The hole this closes: `valiant gate` was a command nobody was required to run. The SDK repo has no CI (U-07 forbids
// GitHub-hosted minutes and no self-hosted runner exists), so between the work and `main` there was nothing — a PR was
// merged while the gate read "a contract is broken" (V-16, harness-mesh/SOP-VIOLATIONS.md).
//
// The receipts mechanism already existed (`valiant decisions`, hash-chained, UNEXERCISED). It had no hook to record from,
// so it could never fire. This installs the hook AND declares it, because a declared hook that stops firing is caught by
// the UNEXERCISED check — which is the difference between a hook and a hope.
import { readFileSync, writeFileSync, existsSync, mkdirSync, chmodSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";

export const MARKER = "# installed by valiant hooks --install";

/** Where a repo's hooks live, honouring a worktree (the hook must run in the tree it guards, not the shared clone). */
function hooksDir(repoRoot) {
  // A HOOK RUNNING US INHERITS GIT_DIR, GIT_WORK_TREE AND FRIENDS. With them set, `git rev-parse --git-path hooks` answers
  // for the OUTER repository — so `valiant hooks --install` could write into someone else's repo. Strip them and let cwd
  // decide, which is the only thing the caller actually chose.
  const env = { ...process.env };
  for (const k of ["GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_COMMON_DIR", "GIT_PREFIX", "GIT_OBJECT_DIRECTORY"]) delete env[k];
  const r = spawnSync("git", ["rev-parse", "--git-path", "hooks"], { cwd: repoRoot, encoding: "utf8", env });
  if (r.status !== 0) return null;
  const p = (r.stdout ?? "").trim();
  return p ? (p.startsWith("/") ? p : join(repoRoot, p)) : null;
}

/**
 * The pre-push body.
 *
 * FAST BY DEFAULT. A pre-push hook that costs minutes is a hook that gets `--no-verify`'d and then ignored, which is
 * worse than no hook — so this runs `verify` (under a second on a small repo, measured) and blocks on any non-zero.
 * `VALIANT_HOOK_MODE=gate` runs the whole thing, proof included, for anyone who wants that on every push.
 */
function prePushBody(cliPath) {
  const node = process.execPath;
  return `#!/bin/sh
${MARKER} — remove this line and the hook stops being managed by valiant
#
# Exit 0 only when every contract holds. 1 = a contract is broken, 2 = a contract could not be checked.
# Both block the push: "we could not look" is not a pass. Bypass with \`git push --no-verify\`, which leaves no record —
# deliberately visible rather than convenient.
if [ "\${VALIANT_HOOK_MODE:-verify}" = "gate" ]; then
  "${node}" "${cliPath}" gate
else
  "${node}" "${cliPath}" verify
fi
code=$?
if [ "$code" -eq 0 ]; then
  "${node}" "${cliPath}" decisions --record --hook pre-push:gate --verdict allow --reason "\${VALIANT_HOOK_MODE:-verify} held" >/dev/null 2>&1
else
  "${node}" "${cliPath}" decisions --record --hook pre-push:gate --verdict deny --reason "\${VALIANT_HOOK_MODE:-verify} exit $code" >/dev/null 2>&1
  echo ""
  echo "valiant: the check did not hold (exit $code) — the push is blocked."
  echo "  1 = a contract is broken · 2 = a contract could not be checked"
  echo "  this was: valiant \${VALIANT_HOOK_MODE:-verify}   (VALIANT_HOOK_MODE=gate runs the full proof)"
  exit 1
fi
`;
}

export function install(repoRoot, cliPath) {
  const dir = hooksDir(repoRoot);
  if (!dir) return { ok: false, why: "this is not a git repository, so there is nothing to hook" };
  const file = join(dir, "pre-push");
  let existing = null;
  try { existing = readFileSync(file, "utf8"); } catch { existing = null; }

  if (existing && !existing.includes(MARKER)) {
    return { ok: false, why: `${file} already exists and was not written by valiant — left alone (merge it by hand)` };
  }
  const already = existing !== null;
  try {
    mkdirSync(dir, { recursive: true });
    writeFileSync(file, prePushBody(cliPath));
    chmodSync(file, 0o755);
  } catch (e) {
    return { ok: false, why: `could not write ${file}: ${e.message}` };
  }
  return { ok: true, file, already };
}

export function status(repoRoot) {
  const dir = hooksDir(repoRoot);
  if (!dir) return { ok: false, installed: false, why: "not a git repository" };
  const file = join(dir, "pre-push");
  if (!existsSync(file)) return { ok: true, installed: false, file, why: "no pre-push hook — nothing runs the gate before a push" };
  let body = "";
  try { body = readFileSync(file, "utf8"); } catch { /* unreadable */ }
  const ours = body.includes(MARKER);
  return { ok: ours, installed: true, file, ours, why: ours ? "valiant's pre-push hook is installed" : "a pre-push hook exists but valiant did not write it" };
}
