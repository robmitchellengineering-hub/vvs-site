import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { join } from "node:path";

// The incident ledger (Valiant principle 4): failures become memory. Every HAZARD
// entry must name a detection RULE and the GUARD that now enforces it — a hazard
// with no guard is a rule that can silently stop catching. Only headings that carry
// a hazard id (H1, HM1, HV1, ...) are held to the RULE+GUARD contract; other `## `
// sections (e.g. "Still open") are notes, not hazards.
const HAZARD_ID = /^H[A-Z0-9]+$/i;

// Does the block MENTION the word at all (anywhere, any shape)? Used only to tell "you never wrote
// a guard" apart from "you wrote one and the contract cannot read it" — two different fixes, and
// reporting them as one wastes the author's time.
function mentions(block, word) {
  return new RegExp(`(^|[\\s*_-])${word}\\b`, "im").test(block);
}

/** Which half of the contract is missing, and whether it looks like a near-miss. */
function misses(block, ruleRe, guardRe) {
  const out = [];
  if (!ruleRe.test(block)) out.push(mentions(block, "RULE") ? "RULE written in a shape the contract does not read" : "no RULE");
  if (!guardRe.test(block)) out.push(mentions(block, "GUARD") ? "GUARD written in a shape the contract does not read" : "no GUARD");
  return out;
}

// ── REPLAY RECIPES AND THE HASH CHAIN ────────────────────────────────────────────────────────────────────────────────
// Plan item 1 (plan/BUILD-PLAN-enforcement.md). The ledger recorded RULE + GUARD — that something was proven, never how
// to re-prove it, so a row closed three months ago is trusted on the strength of a sentence. A REPLAY line carries the
// exact command; a CHAIN line carries the sha256 of the previous entry, so editing history stops being silent.

const LINE = (name) => new RegExp(`^[-*]*\\s*${name}:\\s*(.+)$`, "im");

/** The entry's own text with the CHAIN line removed — the thing the chain hashes. */
function canon(block) {
  return block.split("\n").map((l) => l.replace(/\r$/, "")).filter((l) => !/^[-*]*\s*CHAIN:/i.test(l)).join("\n").trim();
}

export function chainOf(blocks) {
  let prev = "";
  return blocks.map((b) => {
    const h = createHash("sha256").update(prev + "\u0000" + canon(b)).digest("hex");
    prev = h;
    return h;
  });
}

export function parseEntries(ledgerFile, text) {
  const sections = text.split(/^## /m).slice(1).map((block) => {
    const heading = block.split("\n")[0].trim();
    const id = heading.split(/\s+/)[0] || "";
    return { heading, id, isHazard: HAZARD_ID.test(id), block };
  });
  const hazards = sections.filter((s) => s.isHazard);
  const chain = chainOf(hazards.map((h) => h.block));
  return hazards.map((h, i) => ({
    id: h.id,
    heading: h.heading,
    replay: (LINE("REPLAY").exec(h.block) || [])[1]?.trim() ?? null,
    subject: (LINE("SUBJECT").exec(h.block) || [])[1]?.trim() ?? null,
    chainWritten: (LINE("CHAIN").exec(h.block) || [])[1]?.trim() ?? null,
    chainExpected: chain[i],
    block: h.block,
    file: ledgerFile,
  }));
}

/** Walk the chain. Names the FIRST break — a later one is a consequence, not a finding. */
export function verifyChain(entries) {
  const withChain = entries.filter((e) => e.chainWritten);
  if (withChain.length === 0) return { ok: true, adopted: false, detail: "no CHAIN lines — the ledger's history is not yet chained" };
  for (const e of entries) {
    if (!e.chainWritten) return { ok: false, at: e.id, detail: `${e.id} has no CHAIN line while later entries do — the chain is broken from here` };
    if (e.chainWritten !== e.chainExpected) {
      return { ok: false, at: e.id, detail: `${e.id} does not match the chain: this entry (or one above it) was edited after it was written` };
    }
  }
  return { ok: true, adopted: true, detail: `${entries.length} entries, chain intact` };
}

/** Re-run every REPLAY recipe. Four outcomes, because "it passed" hides three different situations. */
export function replayLedger(entries, repoRoot) {
  const out = [];
  for (const e of entries) {
    if (!e.replay) { out.push({ id: e.id, outcome: "UNREPLAYABLE", detail: "no REPLAY line — this claim cannot be re-checked, only believed" }); continue; }
    const r = spawnSync("sh", ["-c", e.replay], { cwd: repoRoot, encoding: "utf8", timeout: 600_000 });
    if (r.error || r.signal) { out.push({ id: e.id, outcome: "UNREPLAYABLE", detail: `the recipe could not be run (${r.error?.code ?? r.signal})` }); continue; }
    if ((r.status ?? 1) !== 0) { out.push({ id: e.id, outcome: "REFUTED", detail: `the recipe fails now (exit ${r.status}) — the claim no longer holds` }); continue; }
    if (e.subject) {
      let now = null;
      try { now = createHash("sha256").update(readFileSync(join(repoRoot, e.subject))).digest("hex"); } catch { /* missing */ }
      const recorded = (LINE("SUBJECT-SHA").exec(e.block) || [])[1]?.trim() ?? null;
      if (!recorded) out.push({ id: e.id, outcome: "OK", detail: "recipe passes (no SUBJECT-SHA recorded, so drift is not tracked)" });
      else if (now !== recorded) out.push({ id: e.id, outcome: "DRIFTED", detail: `recipe passes, but ${e.subject} is not the file the claim was proven against (${String(now).slice(0, 12)} ≠ ${recorded.slice(0, 12)})` });
      else out.push({ id: e.id, outcome: "OK", detail: "recipe passes against the same subject bytes" });
      continue;
    }
    out.push({ id: e.id, outcome: "OK", detail: "recipe passes now" });
  }
  return out;
}

export function checkLedger(repoRoot, ledgerFile) {
  if (ledgerFile == null) {
    return { ok: true, absent: true, detail: "absent (declared in config) — principle 4 not yet adopted" };
  }
  const path = join(repoRoot, ledgerFile);
  let text;
  try {
    text = readFileSync(path, "utf8");
  } catch (e) {
    return { ok: false, detail: `ledger ${ledgerFile} missing: ${e.message}` };
  }

  const sections = text.split(/^## /m).slice(1).map((block) => {
    const heading = block.split("\n")[0].trim();
    const id = heading.split(/\s+/)[0] || "";
    return { heading, id, isHazard: HAZARD_ID.test(id), block };
  });
  const hazards = sections.filter((s) => s.isHazard);
  const notes = sections.filter((s) => !s.isHazard);

  if (hazards.length === 0) {
    return { ok: false, detail: `no hazard entries in ${ledgerFile} (expected "## Hxx" headings)` };
  }
  // The contract is a line that BEGINS "RULE:" or "GUARD:" (a leading "- " or "* " is fine, any
  // case). Anything else is prose, however true it is. That is worth saying at the failure, because
  // a hazard that names its guard as "- GUARD (built, mutation-proven ...):" looks like compliance
  // to the person who wrote it and is invisible to this regex — measured 2026-10-26 on harness-mesh,
  // where three hazards "had no guard" and two of them did, in bold or behind a parenthesis. A
  // verification tool whose failure message does not teach the accepted shape sends the author
  // hunting for a guard they already wrote.
  const RULE = /^[-*]*\s*RULE:/im;
  const GUARD = /^[-*]*\s*GUARD:/im;
  const bad = hazards.filter((s) => !RULE.test(s.block) || !GUARD.test(s.block));
  if (bad.length > 0) {
    const detail = bad.map((s) => `${s.id} (${misses(s.block, RULE, GUARD).join(", ")})`).join("; ");
    return {
      ok: false,
      detail:
        `hazards missing RULE or GUARD: ${detail}. ` +
        `The contract is a line starting "RULE:" and a line starting "GUARD:" ` +
        `(a leading "- " or "* " is allowed). Bold markup ("**RULE:**") and a qualifier before the ` +
        `colon ("GUARD (built):") do NOT match — state the qualifier after the colon instead.`,
    };
  }
  const noteSuffix = notes.length ? `, ${notes.length} note(s)` : "";
  return { ok: true, detail: `${hazards.length} hazards, each with RULE + GUARD${noteSuffix}` };
}
