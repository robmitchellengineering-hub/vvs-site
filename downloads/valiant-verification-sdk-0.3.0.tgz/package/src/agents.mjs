// agents.mjs — enforcement where an AGENT works, not only where a human pushes.
//
// THE HOLE THIS FILLS. `valiant mcp` lets an agent ASK for the verdict; nothing makes it ask. An agent that never calls the
// tool reports "done" with the gate untouched, and the product's whole claim is that done means something. A tool an agent
// may ignore is documentation, not enforcement.
//
// Two hosts matter:
//   Claude Code  — `.claude/settings.json` hooks. A `Stop` hook runs when the agent tries to finish; a non-zero exit stops
//                  it and feeds the reason back. That is the moment "done" is attempted, so it is where the gate belongs.
//   DSH          — `~/.dsh/hooks/hooks.json`, `PreToolUse` on the shell, so a command that would claim completion is run
//                  through the gate first.
//
// Both files are edited surgically: existing entries are kept, entries that are already ours are not duplicated, and a
// malformed file is refused rather than overwritten.
import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { homedir } from "node:os";

export const MARKER = "installed by valiant enforce";

// THE HOOK MUST SCOPE ITSELF. A PreToolUse hook that runs `valiant gate` on EVERY tool call blocks everything: most calls
// happen in directories with no valiant.json, where the gate correctly exits 2 ("could not check"). So the hook asks the
// tool to decide: `enforce --hook` reads the event on stdin, and only a command that would CLAIM COMPLETION (a commit or a
// push) is gated. Everything else is allowed instantly.
const hookCommand = (cliPath, event) => event === "Stop"
  ? `"${process.execPath}" "${cliPath}" gate`
  : `"${process.execPath}" "${cliPath}" enforce --hook`;

/** The hook entry, in the shape both hosts use. */
const entry = (cliPath, event) => ({
  matcher: event === "Stop" ? "*" : "*",
  hooks: [{ type: "command", command: `${hookCommand(cliPath, event)} || exit 2   # ${MARKER}` }],
  _valiant: MARKER,
});

const isOurs = (e) => JSON.stringify(e).includes(MARKER);

/** Read a JSON file, or return a fresh object. A malformed file is an error, never silently replaced. */
function readJson(path) {
  if (!existsSync(path)) return { ok: true, data: {} };
  const raw = readFileSync(path, "utf8");
  if (!raw.trim()) return { ok: true, data: {} };
  try { return { ok: true, data: JSON.parse(raw) }; }
  catch (e) { return { ok: false, why: `${path} is not valid JSON (${e.message}) — fix it before installing` }; }
}

export function installClaude(repoRoot, cliPath) {
  const path = join(repoRoot, ".claude", "settings.json");
  const r = readJson(path);
  if (!r.ok) return { ok: false, why: r.why };
  const cfg = r.data;
  cfg.hooks = cfg.hooks ?? {};
  const stop = Array.isArray(cfg.hooks.Stop) ? cfg.hooks.Stop : [];
  if (stop.some(isOurs)) return { ok: true, path, already: true };
  cfg.hooks.Stop = [...stop, entry(cliPath, "Stop")];
  try {
    mkdirSync(dirname(path), { recursive: true });
    writeFileSync(path, `${JSON.stringify(cfg, null, 2)}\n`);
  } catch (e) { return { ok: false, why: `could not write ${path}: ${e.message}` }; }
  return { ok: true, path, already: false };
}

export function installDsh(cliPath, home = homedir()) {
  const path = join(home, ".dsh", "hooks", "hooks.json");
  const r = readJson(path);
  if (!r.ok) return { ok: false, why: r.why };
  const cfg = r.data;
  cfg.hooks = cfg.hooks ?? {};
  const pre = Array.isArray(cfg.hooks.PreToolUse) ? cfg.hooks.PreToolUse : [];
  if (pre.some(isOurs)) return { ok: true, path, already: true };
  cfg.hooks.PreToolUse = [...pre, entry(cliPath, "PreToolUse")];
  try {
    mkdirSync(dirname(path), { recursive: true });
    writeFileSync(path, `${JSON.stringify(cfg, null, 2)}\n`);
  } catch (e) { return { ok: false, why: `could not write ${path}: ${e.message}` }; }
  return { ok: true, path, already: false };
}

/** What is enforced where. Used by the docs and by `valiant enforce --status`. */
export function status(repoRoot, home = homedir()) {
  // The stance is shown FIRST, because "installed" and "enforcing" are different facts and a hook that is installed in advisory
  // mode blocks nothing.
  const claudePath = join(repoRoot, ".claude", "settings.json");
  const dshPath = join(home, ".dsh", "hooks", "hooks.json");
  const has = (p) => { const r = readJson(p); return r.ok && JSON.stringify(r.data).includes(MARKER); };
  const push = existsSync(join(repoRoot, ".git", "hooks", "pre-push")) &&
    readFileSync(join(repoRoot, ".git", "hooks", "pre-push"), "utf8").includes("installed by valiant hooks");
  return {
    push,
    claude: has(claudePath),
    dsh: has(dshPath),
    rows: [
      ["git push", push ? "enforced" : "not installed", "valiant hooks --install"],
      ["CI (GitHub/Jenkins/GitLab)", "enforced where the file is committed", "valiant ci-init <platform>"],
      ["Claude Code", has(claudePath) ? "enforced" : "advisory only — the agent may ignore it", "valiant enforce --install claude"],
      ["DSH harness", has(dshPath) ? "installed" : "not installed", "valiant enforce --install dsh"],
    ],
  };
}
