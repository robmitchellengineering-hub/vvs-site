#!/usr/bin/env node
// library.mjs — the local library. One SQLite file, five objects, nothing else.
//
// WHY SQLITE AND WHY SO FEW TABLES. A researcher's value is in what they can ask later: "everything I have about
// this person between 1900 and 1950", "where did I read this sentence". That is a query, not a folder. SQLite
// ships inside Node (node:sqlite), so there is no install, no server, no second account — and a backup is one
// file the reader can copy.
//
// THE FIVE OBJECTS (D31), and every other thing is a view of them:
//   documents — one row per distinct set of bytes, addressed by the hash of those bytes
//   spans     — where the words are: page + character offsets (or sheet + cell), plus the quote
//   claims    — the claim record, pointing at the document and the span that produced it
//   entities  — the words a claim is about, so two documents can be compared
//   times     — the year or range parsed out of a claim, so a timeline can be built without guessing later
//
// WHAT IT REFUSES: a claim with no document (an assertion with no evidence is not research), a document
// re-filed under a second id (the same paper twice is one paper), and deleting a document that a claim points
// at (its evidence would become a dead link).
import { DatabaseSync } from 'node:sqlite';
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';

export const SCHEMA_VERSION = 1;

const DDL = `
CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS documents (
  id INTEGER PRIMARY KEY,
  hash TEXT NOT NULL UNIQUE,          -- sha256 of the bytes: the identity of a document
  uri TEXT NOT NULL,
  kind TEXT NOT NULL,                 -- pdf | html | text | docx | xlsx | csv
  title TEXT,
  bytes INTEGER,
  filed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS spans (
  id INTEGER PRIMARY KEY,
  doc_id INTEGER NOT NULL REFERENCES documents(id),
  page INTEGER,                       -- pdf pages, 1-based
  cell TEXT,                          -- sheet!A1:B2 for a spreadsheet
  start INTEGER NOT NULL,
  end INTEGER NOT NULL,
  quote TEXT NOT NULL,
  extractor TEXT NOT NULL             -- name@version: offsets are only meaningful against it
);
CREATE TABLE IF NOT EXISTS claims (
  id INTEGER PRIMARY KEY,
  doc_id INTEGER NOT NULL REFERENCES documents(id),
  span_id INTEGER REFERENCES spans(id),
  subject TEXT NOT NULL,
  predicate TEXT NOT NULL,
  value TEXT,
  verdict TEXT NOT NULL,
  reason TEXT,
  falsifier TEXT,
  layer TEXT,
  filed_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS entities (
  id INTEGER PRIMARY KEY,
  claim_id INTEGER NOT NULL REFERENCES claims(id),
  name TEXT NOT NULL,
  kind TEXT
);
CREATE TABLE IF NOT EXISTS times (
  id INTEGER PRIMARY KEY,
  claim_id INTEGER NOT NULL REFERENCES claims(id),
  year INTEGER,
  year_end INTEGER,
  raw TEXT
);
CREATE INDEX IF NOT EXISTS claims_subject ON claims(subject);
CREATE INDEX IF NOT EXISTS claims_verdict ON claims(verdict);
CREATE INDEX IF NOT EXISTS spans_doc ON spans(doc_id);
CREATE VIRTUAL TABLE IF NOT EXISTS claims_fts USING fts5(
  subject, predicate, value, quote, content=''
);
`;

export function openLibrary(path = join(process.cwd(), '.askalice', 'library.db')) {
  mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec(DDL);
  const v = db.prepare('SELECT v FROM meta WHERE k = ?').get('schema');
  if (!v) db.prepare('INSERT INTO meta (k, v) VALUES (?, ?)').run('schema', String(SCHEMA_VERSION));
  return { db, path };
}

export function hashOf(bytes) {
  return 'sha256:' + createHash('sha256').update(bytes).digest('hex');
}

/** fileDocument — idempotent by content hash: the same bytes filed twice is one document. */
export function fileDocument(lib, { bytes, uri, kind, title = null }) {
  const hash = hashOf(bytes);
  const found = lib.db.prepare('SELECT id FROM documents WHERE hash = ?').get(hash);
  if (found) return { id: found.id, hash, existing: true };
  const info = lib.db.prepare(
    'INSERT INTO documents (hash, uri, kind, title, bytes, filed_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(hash, uri, kind, title, bytes?.length ?? null, new Date().toISOString());
  return { id: Number(info.lastInsertRowid), hash, existing: false };
}

/** yearOf — the year or range a claim carries. A date is a claim's value, and a timeline is built from these. */
export function yearOf(text) {
  const s = String(text ?? '');
  const range = s.match(/\b(1[5-9]\d{2}|20\d{2})\s*[–-]\s*(1[5-9]\d{2}|20\d{2})\b/);
  if (range) return { year: Number(range[1]), year_end: Number(range[2]), raw: range[0] };
  const single = s.match(/\b(1[5-9]\d{2}|20\d{2})\b/);
  if (single) return { year: Number(single[1]), year_end: null, raw: single[0] };
  return null;
}

/**
 * fileClaim — a claim record into the library. Refuses the one thing that makes research unfalsifiable:
 * a claim with no document behind it.
 */
export function fileClaim(lib, record, { docId, page = null, cell = null } = {}) {
  if (!docId) throw new Error('a claim needs the document it came from');
  const e = record.evidence || {};
  const sp = e.span || {};
  const now = new Date().toISOString();

  let spanId = null;
  if (sp.quote) {
    const info = lib.db.prepare(
      'INSERT INTO spans (doc_id, page, cell, start, end, quote, extractor) VALUES (?, ?, ?, ?, ?, ?, ?)'
    ).run(docId, sp.page ?? page, cell, sp.start ?? 0, sp.end ?? sp.quote.length,
      sp.quote, `${sp.extractor?.name || 'unknown'}@${sp.extractor?.version || '0'}`);
    spanId = Number(info.lastInsertRowid);
  }

  const c = record.claim || {};
  const info = lib.db.prepare(
    'INSERT INTO claims (doc_id, span_id, subject, predicate, value, verdict, reason, falsifier, layer, filed_at) VALUES (?,?,?,?,?,?,?,?,?,?)'
  ).run(docId, spanId, c.subject || '', c.predicate || '', c.value || '', record.verdict || 'unknown',
    record.reason || '', record.falsifier || '', record.scope?.layer || null, now);
  const claimId = Number(info.lastInsertRowid);

  // entities: the subject's content words, so a later query can ask "everything about this person".
  const names = String(c.subject || '').split(/\s+/).filter((w) => w.length > 2);
  for (const name of names) {
    lib.db.prepare('INSERT INTO entities (claim_id, name, kind) VALUES (?, ?, ?)').run(claimId, name.toLowerCase(), null);
  }
  const t = yearOf(`${c.value} ${c.subject}`);
  if (t) lib.db.prepare('INSERT INTO times (claim_id, year, year_end, raw) VALUES (?, ?, ?, ?)').run(claimId, t.year, t.year_end, t.raw);

  lib.db.prepare('INSERT INTO claims_fts (rowid, subject, predicate, value, quote) VALUES (?, ?, ?, ?, ?)')
    .run(claimId, c.subject || '', c.predicate || '', c.value || '', sp.quote || '');

  return { claimId, spanId };
}

/** query — phrases and dates, which is what a researcher actually asks. */
export function query(lib, { phrase, from, to, verdict, limit = 50 } = {}) {
  const where = [];
  const args = [];
  if (phrase) {
    where.push('claims.id IN (SELECT rowid FROM claims_fts WHERE claims_fts MATCH ?)');
    args.push(phrase.split(/\s+/).map((w) => `"${w.replace(/"/g, '')}"`).join(' '));
  }
  if (from || to) {
    where.push('claims.id IN (SELECT claim_id FROM times WHERE year >= ? AND year <= ?)');
    args.push(from ?? 0, to ?? 3000);
  }
  if (verdict) { where.push('claims.verdict = ?'); args.push(verdict); }
  const sql = `SELECT claims.*, documents.uri, documents.title, spans.page, spans.start, spans.end, spans.quote
               FROM claims
               JOIN documents ON documents.id = claims.doc_id
               LEFT JOIN spans ON spans.id = claims.span_id
               ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
               ORDER BY claims.id DESC LIMIT ?`;
  return lib.db.prepare(sql).all(...args, limit);
}

export function stats(lib) {
  const one = (sql) => Number(lib.db.prepare(sql).get().n ?? 0);
  return {
    documents: one('SELECT COUNT(*) n FROM documents'),
    claims: one('SELECT COUNT(*) n FROM claims'),
    spans: one('SELECT COUNT(*) n FROM spans'),
    years: one('SELECT COUNT(*) n FROM times')
  };
}

// ---------------------------------------------------------------------------
// fixtures — a library that cannot answer a question is a folder with extra steps
// ---------------------------------------------------------------------------
if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href && process.argv.includes('--self-test')) {
  const { mkdtempSync } = await import('node:fs');
  const { tmpdir } = await import('node:os');
  const dir = mkdtempSync(join(tmpdir(), 'alice-lib-'));
  const tests = [
    { name: 'a document files once, by hash', run: () => {
        const lib = openLibrary(join(dir, 'a.db'));
        const a = fileDocument(lib, { bytes: Buffer.from('same bytes'), uri: 'u1', kind: 'text' });
        const b = fileDocument(lib, { bytes: Buffer.from('same bytes'), uri: 'u2', kind: 'text' });
        return a.existing === false && b.existing === true && a.id === b.id; } },
    { name: 'a claim needs a document', run: () => {
        const lib = openLibrary(join(dir, 'b.db'));
        try { fileClaim(lib, { claim: {}, verdict: 'unknown' }); return false; } catch { return true; } } },
    { name: 'a phrase query finds the claim and its quote', run: () => {
        const lib = openLibrary(join(dir, 'c.db'));
        const d = fileDocument(lib, { bytes: Buffer.from('<p>bridge</p>'), uri: 'https://e/x', kind: 'html', title: 'Bridge' });
        fileClaim(lib, {
          claim: { subject: 'the bridge', predicate: 'opened in', value: '1937' },
          verdict: 'supported-in-span', reason: 'containment', falsifier: 'another year',
          evidence: { uri: 'https://e/x', span: { quote: 'The bridge opened in 1937.', start: 0, end: 26, extractor: { name: 'dom-text', version: '1.1.0' } } }
        }, { docId: d.id });
        const hits = query(lib, { phrase: 'bridge' });
        return hits.length === 1 && hits[0].quote.includes('opened in 1937') && hits[0].uri === 'https://e/x'; } },
    { name: 'a date range answers "what happened between these years"', run: () => {
        const lib = openLibrary(join(dir, 'd.db'));
        const d = fileDocument(lib, { bytes: Buffer.from('x'), uri: 'u', kind: 'text' });
        const mk = (v) => fileClaim(lib, { claim: { subject: 'a thing', predicate: 'happened', value: v }, verdict: 'supported-in-span' }, { docId: d.id });
        mk('1937'); mk('1901'); mk('1950');
        const mid = query(lib, { from: 1930, to: 1940 });
        return mid.length === 1 && mid[0].value === '1937'; } },
    { name: 'claims survive closing and reopening the file', run: () => {
        const p = join(dir, 'e.db');
        const lib = openLibrary(p);
        const d = fileDocument(lib, { bytes: Buffer.from('y'), uri: 'u', kind: 'text' });
        fileClaim(lib, { claim: { subject: 'x y', predicate: 'is', value: '1932' }, verdict: 'unknown' }, { docId: d.id });
        lib.db.close();
        const again = openLibrary(p);
        return stats(again).claims === 1; } }
  ];
  let bad = 0;
  for (const t of tests) {
    let ok = false, err = '';
    try { ok = t.run() === true; } catch (e) { err = e.message; }
    if (ok) console.log(`  ok    ${t.name}`);
    else { bad++; console.error(`  FAIL  ${t.name}${err ? ' — ' + err : ''}`); }
  }
  console.log(`\nlibrary: ${tests.length - bad}/${tests.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
void existsSync;
