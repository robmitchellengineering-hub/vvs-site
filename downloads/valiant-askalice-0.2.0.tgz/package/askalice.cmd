@echo off
REM askalice — the Windows shim. Double-clickability is not the goal; one word is.
REM PowerShell 5.1 and cmd.exe both land here, and %* forwards the arguments unchanged.
setlocal
node "%~dp0askalice.mjs" %*
exit /b %ERRORLEVEL%
