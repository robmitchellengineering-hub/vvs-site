#!/usr/bin/env node
// research.mjs — go and get the sources, then hand them to the checks.
//
// Rob: "the drag and drop input is for info you already have — the research section needs to go get the info in
// the first place and run it through the checks."
//
// ONE PROCESS, ONE MACHINE (D32). The fan-out is an in-process pool with a bounded concurrency and a per-source
// gap, not a fleet. The mesh, if ASKALICE_RIG=1 and it is present, only widens the pool (D33) — it is additive,
// invisible, and its absence changes nothing but speed.
//
// THREE THINGS THIS FILE IS CAREFUL ABOUT:
//   1. "no results" is not one fact. Every source reports how it answered: ok / empty / rate-limited / gated /
//      error. A 429 is UNKNOWN, never a failure and never a "nothing found".
//   2. the same work must not arrive twice. Dedupe by DOI first, then by URL, then by a normalised title.
//   3. a source that needs a key is a ROUTE, not a wall: it comes back `gated` with the reason, so the caller can
//      say what to do instead of shrugging.

const STOPWORDS = new Set(('the a an of and or in on at to for from by with is are was were be been being that this these those it its as if then than into over under has have had does do did not no opened open').split(' '));
/**
 * queryTerms — a question is not a search string. "Golden Gate Bridge opened 1937" asks an entity API for a
 * sentence; the words that carry meaning are the nouns and the number.
 */
export function queryTerms(q) {
  const words = String(q || '').toLowerCase().match(/[a-z0-9][a-z0-9'-]{2,}/g) || [];
  const kept = words.filter((w) => !STOPWORDS.has(w));
  return (kept.length ? kept : words).slice(0, 6).join(' ');
}

export const SOURCES = [
  {
    id: 'openalex', tier: 'free', kinds: ['work'], perMinute: 60,
    async search(q, f) {
      const r = await f(`https://api.openalex.org/works?search=${encodeURIComponent(q)}&per-page=5`);
      if (!r.ok) return { status: r.status };
      const j = await r.json();
      return { items: (j.results || []).map((w) => ({
        source: 'openalex', title: w.display_name, doi: (w.doi || '').replace(/^https?:\/\/doi\.org\//, '') || null,
        url: w.doi || w.id, year: w.publication_year ?? null, type: w.type ?? null
      })) };
    }
  },
  {
    id: 'crossref', tier: 'free', kinds: ['work'], perMinute: 50,
    async search(q, f) {
      const r = await f(`https://api.crossref.org/works?rows=5&query=${encodeURIComponent(q)}&select=DOI,title,issued,type,URL`);
      if (!r.ok) return { status: r.status };
      const j = await r.json();
      return { items: (j.message?.items || []).map((w) => ({
        source: 'crossref', title: (w.title || [])[0] || null, doi: w.DOI || null,
        url: w.URL || (w.DOI ? `https://doi.org/${w.DOI}` : null),
        year: w.issued?.['date-parts']?.[0]?.[0] ?? null, type: w.type ?? null
      })) };
    }
  },
  {
    id: 'europepmc', tier: 'free', kinds: ['work'], perMinute: 60,
    async search(q, f) {
      const r = await f(`https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=${encodeURIComponent(q)}&format=json&pageSize=5`);
      if (!r.ok) return { status: r.status };
      const j = await r.json();
      return { items: (j.resultList?.result || []).map((w) => ({
        source: 'europepmc', title: w.title, doi: w.doi || null,
        url: w.doi ? `https://doi.org/${w.doi}` : (w.pmid ? `https://europepmc.org/article/MED/${w.pmid}` : null),
        year: w.pubYear ? Number(w.pubYear) : null, type: w.pubType ?? null,
        openAccess: w.isOpenAccess === 'Y'
      })) };
    }
  },
  {
    id: 'arxiv', tier: 'free', kinds: ['preprint'], perMinute: 30,
    async search(q, f) {
      const r = await f(`https://export.arxiv.org/api/query?search_query=all:${encodeURIComponent(q)}&max_results=5`);
      if (!r.ok) return { status: r.status };
      const xml = await r.text();
      const items = [...xml.matchAll(/<entry>([\s\S]*?)<\/entry>/g)].map((m) => {
        const e = m[1];
        const t = (e.match(/<title>([\s\S]*?)<\/title>/) || [])[1] || '';
        const id = (e.match(/<id>([\s\S]*?)<\/id>/) || [])[1] || '';
        const pub = (e.match(/<published>(\d{4})/) || [])[1];
        return { source: 'arxiv', title: t.replace(/\s+/g, ' ').trim(), doi: null, url: id.trim(), year: pub ? Number(pub) : null, type: 'preprint' };
      });
      return { items };
    }
  },
  {
    id: 'doaj', tier: 'free', kinds: ['work'], perMinute: 30,
    async search(q, f) {
      const r = await f(`https://doaj.org/api/search/articles/${encodeURIComponent(q)}?pageSize=5`);
      if (!r.ok) return { status: r.status };
      const j = await r.json();
      return { items: (j.results || []).map((x) => {
        const b = x.bibjson || {};
        return { source: 'doaj', title: b.title || null, doi: (b.identifier || []).find((i) => i.type === 'doi')?.id || null,
          url: (b.link || [])[0]?.url || null, year: b.year ? Number(b.year) : null, type: 'article' };
      }) };
    }
  },
  {
    id: 'zenodo', tier: 'free', kinds: ['dataset', 'software'], perMinute: 30,
    async search(q, f) {
      const r = await f(`https://zenodo.org/api/records?q=${encodeURIComponent(q)}&size=5`);
      if (!r.ok) return { status: r.status };
      const j = await r.json();
      return { items: (j.hits?.hits || []).map((x) => ({
        source: 'zenodo', title: x.metadata?.title || null, doi: x.doi || null,
        url: x.links?.self_html || x.doi || null, year: x.metadata?.publication_date?.slice(0, 4) ? Number(x.metadata.publication_date.slice(0, 4)) : null,
        type: x.metadata?.resource_type?.type ?? null
      })) };
    }
  },
  {
    id: 'wikipedia', tier: 'free', kinds: ['tertiary'], perMinute: 60,
    async search(q, f) {
      const r = await f(`https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&format=json&srlimit=3`);
      if (!r.ok) return { status: r.status };
      const j = await r.json();
      return { items: (j.query?.search || []).map((x) => ({
        source: 'wikipedia', title: x.title, doi: null,
        url: `https://en.wikipedia.org/wiki/${encodeURIComponent(x.title.replace(/ /g, '_'))}`,
        year: null, type: 'tertiary'
      })) };
    }
  },
  {
    id: 'pubmed', tier: 'free', kinds: ['work'], perMinute: 50,
    async search(q, f) {
      const ids = await f(`https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term=${encodeURIComponent(q)}&retmode=json&retmax=5`);
      if (!ids.ok) return { status: ids.status };
      const idj = await ids.json();
      const list = idj.esearchresult?.idlist || [];
      if (!list.length) return { items: [] };
      const sum = await f(`https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id=${list.join(',')}&retmode=json`);
      if (!sum.ok) return { status: sum.status };
      const sj = await sum.json();
      return { items: list.map((id) => {
        const r = sj.result?.[id] || {};
        const doi = (r.articleids || []).find((a) => a.idtype === 'doi')?.value || null;
        return { source: 'pubmed', title: r.title || null, doi, url: doi ? `https://doi.org/${doi}` : `https://pubmed.ncbi.nlm.nih.gov/${id}/`,
          year: r.pubdate ? Number(String(r.pubdate).slice(0, 4)) || null : null, type: 'article' };
      }) };
    }
  },
  {
    id: 'openaire', tier: 'free', kinds: ['work'], perMinute: 30,
    async search(q, f) {
      const r = await f(`https://api.openaire.eu/search/publications?keywords=${encodeURIComponent(q)}&size=5&format=json`);
      if (!r.ok) return { status: r.status };
      const j = await r.json();
      const res = j.response?.results?.result || [];
      const arr = Array.isArray(res) ? res : [res];
      return { items: arr.map((x) => {
        const md = x.metadata?.['oaf:entity']?.['oaf:result'] || {};
        const title = md.title?.['$'] || md.title || null;
        const pid = md.pid?.['$'] || null;
        return { source: 'openaire', title: typeof title === 'string' ? title : null,
          doi: pid && String(pid).startsWith('10.') ? pid : null,
          url: pid && String(pid).startsWith('10.') ? `https://doi.org/${pid}` : (x.header?.dri?.$ || null),
          year: null, type: 'article' };
      }).filter((x) => x.title) };
    }
  },
  {
    id: 'figshare', tier: 'free', kinds: ['dataset', 'work'], perMinute: 30,
    async search(q, f) {
      const r = await f('https://api.figshare.com/v2/articles/search', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ search_for: q, page_size: 5 }) });
      if (!r.ok) return { status: r.status };
      const j = await r.json();
      return { items: (Array.isArray(j) ? j : []).map((x) => ({
        source: 'figshare', title: x.title || null, doi: x.doi || null,
        url: x.url_public_html || (x.doi ? `https://doi.org/${x.doi}` : null),
        year: x.published_date ? Number(String(x.published_date).slice(0, 4)) || null : null, type: x.defined_type_name ?? null
      })) };
    }
  },
  {
    id: 'digitalnz', tier: 'free', kinds: ['collection'], perMinute: 20,
    async search(q, f) {
      const r = await f(`https://api.digitalnz.org/v3/records.json?text=${encodeURIComponent(q)}&per_page=5`);
      if (!r.ok) return { status: r.status };
      const j = await r.json();
      return { items: (j.search?.results || []).map((x) => ({
        source: 'digitalnz', title: x.title || null, doi: null,
        url: x.landing_url || x.identifier || null,
        year: x.date ? Number(String(x.date).slice(0, 4)) || null : null, type: 'collection'
      })) };
    }
  },
  {
    id: 'wikidata', tier: 'free', kinds: ['entity'], perMinute: 60,
    async search(q, f) {
      const r = await f(`https://www.wikidata.org/w/api.php?action=wbsearchentities&search=${encodeURIComponent(q)}&language=en&format=json&limit=5`);
      if (!r.ok) return { status: r.status };
      const j = await r.json();
      return { items: (j.search || []).map((x) => ({
        source: 'wikidata', title: x.label || x.id, doi: null,
        url: x.concepturi || `https://www.wikidata.org/wiki/${x.id}`, year: null, type: 'entity'
      })) };
    }
  },
  {
    id: 'ror', tier: 'free', kinds: ['institution'], perMinute: 30,
    async search(q, f) {
      const r = await f(`https://api.ror.org/organizations?query=${encodeURIComponent(q)}`);
      if (!r.ok) return { status: r.status };
      const j = await r.json();
      return { items: (j.items || []).slice(0, 5).map((x) => ({
        source: 'ror', title: x.name || null, doi: null, url: x.id || null,
        year: x.established ? Number(x.established) || null : null, type: 'institution'
      })) };
    }
  },
  {
    id: 'orcid', tier: 'free', kinds: ['person'], perMinute: 30,
    async search(q, f) {
      const r = await f(`https://pub.orcid.org/v3.0/expanded-search/?q=${encodeURIComponent(q)}&rows=5`, { headers: { accept: 'application/json' } });
      if (!r.ok) return { status: r.status };
      const j = await r.json();
      return { items: (j['expanded-result'] || []).map((x) => ({
        source: 'orcid', title: [x['given-names'], x['family-names']].filter(Boolean).join(' ') || x['orcid-id'],
        doi: null, url: `https://orcid.org/${x['orcid-id']}`, year: null, type: 'person'
      })) };
    }
  },
  {
    id: 'trove', tier: 'keyed', kinds: ['collection', 'work'], perMinute: 20, needs: 'TROVE_API_KEY',
    async search(q, f, key) {
      if (!key) return { status: 'gated', reason: 'needs a Trove API key (free, one application)' };
      const r = await f(`https://api.trove.nla.gov.au/v3/result?q=${encodeURIComponent(q)}&category=all&n=5&encoding=json&apikey=${encodeURIComponent(key)}`);
      if (!r.ok) return { status: r.status };
      const j = await r.json();
      const items = [];
      for (const cat of j.category || []) for (const rec of cat.records?.article || cat.records?.work || []) {
        items.push({ source: 'trove', title: rec.heading || rec.title || null, doi: null, url: rec.identifier?.[0]?.value || rec.troveUrl || null, year: null, type: 'collection' });
      }
      return { items };
    }
  }
];

/** normalise — a title that differs only in punctuation or case is the same work. */
export function normaliseTitle(t) {
  return String(t || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

/** dedupe — DOI first (an identifier beats a guess), then URL, then the title. */
export function dedupe(items) {
  const seenDoi = new Map(), seenUrl = new Map(), seenTitle = new Map();
  const out = [];
  for (const it of items) {
    if (!it || (!it.title && !it.url)) continue;
    const doi = (it.doi || '').toLowerCase() || null;
    const url = (it.url || '').toLowerCase().replace(/\/$/, '') || null;
    const title = normaliseTitle(it.title);
    if (doi && seenDoi.has(doi)) { seenDoi.get(doi).alsoIn = [...(seenDoi.get(doi).alsoIn || []), it.source]; continue; }
    if (!doi && url && seenUrl.has(url)) { seenUrl.get(url).alsoIn = [...(seenUrl.get(url).alsoIn || []), it.source]; continue; }
    if (!doi && !url && title && seenTitle.has(title)) { seenTitle.get(title).alsoIn = [...(seenTitle.get(title).alsoIn || []), it.source]; continue; }
    if (doi) seenDoi.set(doi, it);
    if (url) seenUrl.set(url, it);
    if (title) seenTitle.set(title, it);
    out.push(it);
  }
  return out;
}

/**
 * bestOpenCopy — the paywall workaround, and a RESOLVER rather than a search: given a DOI, Unpaywall says whether
 * a legal open copy exists and where. It answers "can this claim be checked at all from a machine with no
 * subscription", which is the question a reader on a laptop actually has.
 */
export async function bestOpenCopy(doi, { fetchImpl = globalThis.fetch, email = process.env.UNPAYWALL_EMAIL || 'info@valiantmusic.com.au' } = {}) {
  if (!doi) return null;
  try {
    const r = await fetchImpl(`https://api.unpaywall.org/v2/${encodeURIComponent(doi)}?email=${encodeURIComponent(email)}`);
    if (!r.ok) return { status: r.status, oaUrl: null };
    const j = await r.json();
    const loc = j.best_oa_location;
    return loc ? { oaUrl: loc.url_for_pdf || loc.url, host: loc.host_type || null, version: loc.version || null, isOa: Boolean(j.is_oa) } : { oaUrl: null, isOa: Boolean(j.is_oa) };
  } catch (e) { return { status: 'error', oaUrl: null, reason: e.message }; }
}

/**
 * archivedCopy — the second resolver: when a page is gone, the Wayback Machine may still have it. A dead link is
 * not a dead end, and a verdict drawn from an archived copy says so.
 */
export async function archivedCopy(url, { fetchImpl = globalThis.fetch } = {}) {
  if (!url) return null;
  try {
    const r = await fetchImpl(`https://archive.org/wayback/available?url=${encodeURIComponent(url)}`);
    if (!r.ok) return { status: r.status, archived: null };
    const j = await r.json();
    const snap = j.archived_snapshots?.closest;
    return snap?.available ? { archived: snap.url, timestamp: snap.timestamp, status: 200 } : { archived: null };
  } catch (e) { return { status: 'error', archived: null, reason: e.message }; }
}

/**
 * research — ask every source, bounded, and report how each one answered.
 * Never throws on a source failure: a dead source is one line in the report, not a lost run.
 */
export async function research(query, opts = {}) {
  const {
    fetchImpl = globalThis.fetch, sources = SOURCES, concurrency = 4,
    keys = process.env, maxPerSource = 5, rig = process.env.ASKALICE_RIG === '1'
  } = opts;

  // D33: the rig only widens the pool. Unset means this line is the only trace of it, and it does nothing.
  const lanes = rig ? Math.max(concurrency, 8) : concurrency;

  const perSource = [];
  const all = [];
  let next = 0;

  const worker = async () => {
    while (next < sources.length) {
      const s = sources[next++];
      const key = s.needs ? keys[s.needs] : undefined;
      try {
        // ONE RETRY, and only on a thrown error: a pooled fan-out meets a reset connection now and then, and a
        // single silent failure in a research run is the difference between "found nothing" and "did not ask".
        let res;
        try { res = await s.search(queryTerms(query), fetchImpl, key); }
        catch (first) {
          try { res = await s.search(queryTerms(query), fetchImpl, key); }
          catch (second) { throw new Error(`${second.message}${second.cause?.code ? ' (' + second.cause.code + ')' : ''} after 2 attempts`); }
        }
        if (res.status === 'gated') { perSource.push({ id: s.id, tier: s.tier, status: 'gated', count: 0, reason: res.reason }); continue; }
        if (typeof res.status === 'number') {
          const status = res.status === 429 ? 'rate-limited' : res.status >= 400 && res.status < 500 ? 'refused' : 'error';
          perSource.push({ id: s.id, tier: s.tier, status, count: 0, reason: `HTTP ${res.status}` });
          continue;
        }
        const items = dedupe(res.items || []).slice(0, maxPerSource);
        perSource.push({ id: s.id, tier: s.tier, status: items.length ? 'ok' : 'empty', count: items.length });
        all.push(...items);
      } catch (e) {
        perSource.push({ id: s.id, tier: s.tier, status: 'error', count: 0, reason: e.message });
      }
    }
  };
  await Promise.all(Array.from({ length: Math.min(lanes, sources.length) }, worker));

  // RANK, don't just collect. A first live run asked for the Golden Gate Bridge and put "Multi-Qubit Golden Gates"
  // in front of the actual bridge chapters, because results arrived in completion order. Relevance to the query's
  // own words is a cheap, honest ordering: it never claims relevance it cannot show — the words are visible in the
  // title it scored.
  const qwords = String(query).toLowerCase().match(/[a-z0-9]{3,}/g) || [];
  const score = (it) => {
    const t = `${it.title || ''}`.toLowerCase();
    const hits = qwords.filter((w) => t.includes(w)).length;
    const typeBoost = it.type === 'tertiary' ? -0.5 : 0;   // a pointer is useful, but it is never the best answer
    return hits + typeBoost;
  };
  const findings = dedupe(all).map((it) => ({ ...it, score: score(it) })).sort((a, b) => b.score - a.score);
  perSource.sort((a, b) => (a.tier === b.tier ? a.id.localeCompare(b.id) : a.tier === 'free' ? -1 : 1));
  return {
    query,
    findings,
    perSource,
    asked: perSource.length,
    answered: perSource.filter((p) => p.status === 'ok' || p.status === 'empty').length,
    lanes
  };
}

// ---------------------------------------------------------------------------
// fixtures — every one offline: the fetch is injected, so a rate limit and a refusal are facts, not weather
// ---------------------------------------------------------------------------
if (process.argv[1] && import.meta.url === new URL('file://' + process.argv[1]).href && process.argv.includes('--self-test')) {
  const fakeSource = (id, status, items = []) => ({
    id, tier: 'free', kinds: ['work'], perMinute: 60,
    async search() {
      if (status === 429) return { status: 429 };
      if (status === 403) return { status: 403 };
      if (status === 'gated') return { status: 'gated', reason: 'needs a key' };
      if (status === 'throw') throw new Error('socket hang up');
      return { items };
    }
  });
  const tests = [
    { name: 'a keyword search returns deduped findings', run: async () => {
        const r = await research('x', { sources: [
          fakeSource('a', 200, [{ source: 'a', title: 'Same Work', doi: '10.1/x', url: 'https://doi.org/10.1/x' }]),
          fakeSource('b', 200, [{ source: 'b', title: 'Same work!', doi: '10.1/X', url: 'https://other' }])
        ] });
        return r.findings.length === 1 && r.perSource.filter((p) => p.status === 'ok').length === 2; } },
    { name: 'RED: a 429 is rate-limited, never "empty"', run: async () => {
        const r = await research('x', { sources: [fakeSource('r', 429)] });
        return r.perSource[0].status === 'rate-limited' && r.perSource[0].reason === 'HTTP 429'; } },
    { name: 'RED: a refusal is reported as refused, with its code', run: async () => {
        const r = await research('x', { sources: [fakeSource('d', 403)] });
        return r.perSource[0].status === 'refused' && /403/.test(r.perSource[0].reason); } },
    { name: 'RED: a source that throws does not lose the run', run: async () => {
        const r = await research('x', { sources: [fakeSource('t', 'throw'), fakeSource('ok', 200, [{ source: 'ok', title: 'T', url: 'u' }])] });
        return r.findings.length === 1 && r.perSource.some((p) => p.status === 'error'); } },
    { name: 'a keyed source with no key is gated with the route', run: async () => {
        const r = await research('x', { sources: [fakeSource('k', 'gated')] });
        return r.perSource[0].status === 'gated' && /key/.test(r.perSource[0].reason); } },
    { name: 'concurrency is bounded by the lanes', run: async () => {
        let live = 0, peak = 0;
        const slow = (id) => ({ id, tier: 'free', kinds: ['work'], perMinute: 60, async search() {
          live++; peak = Math.max(peak, live); await new Promise((r) => setTimeout(r, 5)); live--;
          return { items: [{ source: id, title: id, url: id }] };
        } });
        await research('x', { sources: [slow('1'), slow('2'), slow('3'), slow('4'), slow('5')], concurrency: 2 });
        return peak <= 2; } },
    { name: 'findings are ranked by the query\'s own words, and a tertiary pointer is never first', run: async () => {
        const r = await research('golden gate bridge', { sources: [fakeSource('a', 200, [
          { source: 'a', title: 'Multi-Qubit Golden Gates', url: 'u1' },
          { source: 'a', title: 'Golden Gate Bridge toll history', url: 'u2' },
          { source: 'a', title: 'Golden Gate Bridge', url: 'u3', type: 'tertiary' }
        ])] });
        const order = r.findings.map((f) => f.title);
        // the tertiary pointer must not be FIRST — it may legitimately rank second on its own words
        return order[0] === 'Golden Gate Bridge toll history' && order[0] !== 'Golden Gate Bridge'; } },
    { name: 'a DOI gets an open copy when one exists, and null when it does not', run: async () => {
        const yes = await bestOpenCopy('10.1/x', { fetchImpl: async () => ({ ok: true, json: async () => ({ is_oa: true, best_oa_location: { url_for_pdf: 'https://oa/x.pdf', host_type: 'repository', version: 'accepted' } }) }) });
        const no = await bestOpenCopy('10.1/y', { fetchImpl: async () => ({ ok: true, json: async () => ({ is_oa: false, best_oa_location: null }) }) });
        return yes.oaUrl === 'https://oa/x.pdf' && yes.version === 'accepted' && no.oaUrl === null; } },
    { name: 'a dead page finds an archived copy, and a live one does not need it', run: async () => {
        const got = await archivedCopy('https://gone/x', { fetchImpl: async () => ({ ok: true, json: async () => ({ archived_snapshots: { closest: { available: true, url: 'https://web.archive.org/web/2019/x', timestamp: '2019' } } }) }) });
        const none = await archivedCopy('https://gone/y', { fetchImpl: async () => ({ ok: true, json: async () => ({ archived_snapshots: {} }) }) });
        return got.archived === 'https://web.archive.org/web/2019/x' && none.archived === null; } },
    { name: 'the rig flag widens the pool and changes nothing else', run: async () => {
        const local = await research('x', { sources: [fakeSource('a', 200, [{ source: 'a', title: 'T', url: 'u' }])], rig: false });
        const rigged = await research('x', { sources: [fakeSource('a', 200, [{ source: 'a', title: 'T', url: 'u' }])], rig: true });
        return local.findings.length === rigged.findings.length && rigged.lanes > local.lanes; } }
  ];
  let bad = 0;
  for (const t of tests) {
    let ok = false, err = '';
    try { ok = (await t.run()) === true; } catch (e) { err = e.message; }
    if (ok) console.log(`  ok    ${t.name}`);
    else { bad++; console.error(`  FAIL  ${t.name}${err ? ' — ' + err : ''}`); }
  }
  console.log(`\nresearch: ${tests.length - bad}/${tests.length} fixtures behaved`);
  process.exit(bad ? 1 : 0);
}
