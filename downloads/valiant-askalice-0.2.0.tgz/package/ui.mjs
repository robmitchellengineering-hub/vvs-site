#!/usr/bin/env node
// ui.mjs — `askalice ui`: serve one page that runs the same checks the CLI runs.
//
// The page is a file (ui.html), not a string in here: the client's own templating collided with the server's,
// and a page a person edits should be a page, not a literal buried in a server.
import { createServer } from 'node:http';
import { readFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { extractText } from './extract.mjs';
import { isPdf, pdfPages } from './pdf.mjs';
import { checkFetched } from './check.mjs';
import { lineageOf, sourceKind } from './lineage.mjs';
import { citeFor, talkPageRequest } from './cite.mjs';
import { openLibrary, fileDocument, fileClaim, stats, query } from './library.mjs';
import { audit } from './audit.mjs';
import { home } from './morpheus.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const UA = { 'user-agent': 'askalice/0.1 (ui)' };
const PAGE = () => readFileSync(join(HERE, 'ui.html'), 'utf8');

async function loadSource(source) {
  if (/^https?:\/\//i.test(source)) {
    const r = await fetch(source, { headers: UA, redirect: 'follow' }).catch(() => null);
    if (!r || !r.ok) return { uri: source, httpStatus: r?.status ?? 0, kind: 'unreachable', reason: r?.status ? `HTTP ${r.status}` : 'no response' };
    const buf = Buffer.from(await r.arrayBuffer());
    if (isPdf(buf)) return { uri: source, httpStatus: r.status, body: buf, kind: 'pdf' };
    return { uri: source, httpStatus: r.status, body: buf.toString('utf8'), kind: 'html' };
  }
  if (!existsSync(source)) return { uri: source, httpStatus: 0, kind: 'missing', reason: 'no such file on this machine' };
  const buf = readFileSync(source);
  if (isPdf(buf)) return { uri: source, httpStatus: 200, body: buf, kind: 'pdf' };
  return { uri: source, httpStatus: 200, body: buf.toString('utf8'), kind: 'html' };
}

async function runOne(claim, src) {
  if (sourceKind(src.uri) === 'tertiary') {
    const walked = await lineageOf(claim, src.uri);
    if (!walked.deepest) {
      return { claim, verdict: 'unknown', reason: walked.reason === 'unsourced' ? 'no-span' : 'check-not-run',
        lineage: walked.chain, evidence: null, checked: null,
        falsifier: 'a real source the page cites, or an explicit denial in one' };
    }
    const r = await fetch(walked.deepest, { headers: UA, redirect: 'follow' }).catch(() => null);
    const buf = r && r.ok ? Buffer.from(await r.arrayBuffer()) : null;
    const body = buf && isPdf(buf) ? buf : (buf ? buf.toString('utf8') : '');
    return { ...checkFetched(claim, { uri: walked.deepest, httpStatus: r?.status ?? 0, body }), lineage: walked.chain };
  }
  return checkFetched(claim, { uri: src.uri, httpStatus: src.httpStatus, body: src.body });
}

const server = createServer(async (req, res) => {
  if (req.method === 'GET' && (req.url === '/' || req.url.startsWith('/?'))) {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    return res.end(PAGE());
  }
  if (req.method === 'GET' && req.url.startsWith('/api/query')) {
    // the library, asked a question — the same numbers a person would get from `askalice library`
    try {
      const u = new URL(req.url, 'http://x');
      const lib = openLibrary(join(home(), 'library.db'));
      const rows = query(lib, {
        phrase: u.searchParams.get('q') || undefined,
        from: u.searchParams.get('from') ? Number(u.searchParams.get('from')) : undefined,
        to: u.searchParams.get('to') ? Number(u.searchParams.get('to')) : undefined,
        verdict: u.searchParams.get('verdict') || undefined
      });
      lib.db.close();
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ rows }));
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/audit') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { draft, refs } = JSON.parse(body || '{}');
      if (!draft || !String(draft).trim()) throw new Error('paste a draft first');
      let parsed = {};
      if (typeof refs === 'string' && refs.trim()) {
        try { parsed = JSON.parse(refs); } catch { throw new Error('the reference list is not valid JSON — it should look like {"1":"https://…"}'); }
      } else if (refs && typeof refs === 'object') parsed = refs;
      const result = await audit(String(draft), { refs: parsed });
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify(result));
    } catch (e) {
      res.writeHead(422, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  if (req.method === 'POST' && req.url === '/api/check') {
    let body = '';
    for await (const c of req) body += c;
    try {
      const { source, claim } = JSON.parse(body || '{}');
      if (!source) throw new Error('a source is required');
      const src = await loadSource(source);
      if (src.kind === 'unreachable' || src.kind === 'missing') {
        res.writeHead(422, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ error: `Cannot read ${source} — ${src.reason}` }));
      }
      const records = [];
      const attach = (rec) => {
        // The citation is built here, from the record and the bytes that produced it, so the page never has to
        // know how a {{cite}} is assembled — and never has to invent a title.
        if (rec.evidence?.span?.quote) {
          try {
            const c = citeFor(rec, { body: src.body });
            rec.citation = c;
            rec.talk = talkPageRequest({ article: '<the article you are editing>', record: rec, cite: c });
          } catch { /* a citation we cannot build must not lose the record */ }
        }
        return rec;
      };
      if (claim) {
        const [subject, predicate, value] = claim.split('|').map((x) => (x ?? '').trim());
        records.push(attach(await runOne({ subject: subject || 'the claim', predicate: predicate || 'states', value: value || '' }, src)));
      } else {
        const { candidateClaims } = await import('./desk.mjs');
        const text = src.kind === 'pdf' ? pdfPages(src.body).pages.join(' ') : extractText(src.body);
        for (const c of candidateClaims(text).slice(0, 6)) records.push(attach(await runOne(c, src)));
      }
      // FILE IT. A check that is only shown is a check that is lost; the library is the point of the product.
      let filed = null;
      try {
        const lib = openLibrary(join(home(), 'library.db'));
        const doc = fileDocument(lib, { bytes: src.body, uri: src.uri, kind: src.kind, title: null });
        for (const r of records) fileClaim(lib, r, { docId: doc.id, page: r.evidence?.span?.page ?? null });
        filed = { documentId: doc.id, existing: doc.existing, ...stats(lib) };
        lib.db.close();
      } catch (e) { filed = { error: e.message }; }

      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ records, filed }));
    } catch (e) {
      res.writeHead(500, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }
  res.writeHead(404, { 'content-type': 'text/plain' });
  res.end('not found');
});

const port = Number(process.env.PORT || 4173);
server.listen(port, '127.0.0.1', () => {
  const url = `http://127.0.0.1:${port}/`;
  console.log(`askalice ui → ${url}`);
  if (process.argv.includes('--open')) {
    const cmd = process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]]
      : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
    import('node:child_process').then(({ spawn }) => { try { spawn(cmd[0], cmd[1], { detached: true, stdio: 'ignore' }).unref(); } catch { } });
  }
});
