// agents.mjs — enforcement where an AGENT works, not only where a human pushes.
//
// THE HOLE THIS FILLS. `valiant mcp` lets an agent ASK for the verdict; nothing makes it ask. An agent that never calls the
// tool reports "done" with the gate untouched, and the product's whole claim is that done means something. A tool an agent
// may ignore is documentation, not enforcement.
//
// Two hosts matter:
//   Claude Code  — `.claude/settings.json` hooks. A `Stop` hook runs when the agent tries to finish; a non-zero exit stops
//                  it and feeds the reason back. That is the moment "done" is attempted, so it is where the gate belongs.
//   DSH          — `~/.dsh/hooks/hooks.json`, `PreToolUse` on the shell, so a command that would claim completion is run
//                  through the gate first.
//
// Both files are edited surgically: existing entries are kept, entries that are already ours are not duplicated, and a
// malformed file is refused rather than overwritten.
import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { homedir } from "node:os";

export const MARKER = "installed by valiant enforce";

// THE HOOK MUST SCOPE ITSELF. A PreToolUse hook that runs `valiant gate` on EVERY tool call blocks everything: most calls
// happen in directories with no valiant.json, where the gate correctly exits 2 ("could not check"). So the hook asks the
// tool to decide: `enforce --hook` reads the event on stdin, and only a command that would CLAIM COMPLETION (a commit or a
// push) is gated. Everything else is allowed instantly.
// NO `|| exit 2`, AND NO BAKED-IN PATH. The first version ended with `|| exit 2`, which meant a missing checkout turned EVERY tool
// call in every session into a failure — a way-in risk, not enforcement — and it also masked the engine's own exit code, so "gate
// red" and "hook broken" looked identical. The command now resolves the CLI the same way the pre-push hook does and lets the engine
// decide: 0 allow, 2 block, and a clear sentence if the CLI cannot be found.
const hookCommand = (cliPath, event) => {
  // The Stop hook runs the gate, so it TELLS the gate that it is a hook — otherwise its blocks record nothing and a block without a
  // reason is the thing this project refuses.
  // THE ASSIGNMENT MUST PRECEDE THE COMMAND. `$V VALIANT_HOOK=… gate` passes the assignment as an ARGUMENT to the CLI, which then sees a
  // command word it does not know — measured: the Stop hook blocked but recorded nothing, which is exactly the gap this was meant to close.
  const runner = event === "Stop" ? "gate" : "enforce --hook";
  const prefix = event === "Stop" ? "VALIANT_HOOK=claude:stop " : "";
  // WINDOWS RUNS THIS THROUGH cmd, WHERE `if [ -z "$V" ]` IS NOT A COMMAND AT ALL. The same property is kept — the CLI is
  // named with its interpreter, so nothing is resolved from PATH by accident — but the syntax is cmd's. A moved checkout
  // fails loudly here (exit 2, "could not check"), which is the behaviour the POSIX branch also has.
  if (process.platform === "win32") {
    const cmdPrefix = event === "Stop" ? "set VALIANT_HOOK=claude:stop&& " : "";
    // THE HOST BLOCKS ON EXIT 2. cmd supports ||, so the mapping is the same as the POSIX branch: any failure becomes 2,
    // which is "could not check", and the gate's own exit code has already been printed by the engine.
    // `rem` SWALLOWS THE REST OF THE LINE, `&` included, so a marker written that way turns the hook into a no-op that
    // exits 0 (measured). A quoted `set` holds the same marker, runs in cmd and in a batch file, and leaves the exit code
    // to the command that follows. `if errorlevel 1` is cmd's reliable test after it.
    return `set "VALIANT_HOOK_MARKER=${MARKER}" & ${cmdPrefix}"${process.execPath}" "${cliPath}" ${runner} & if errorlevel 1 exit /b 2`;
  }
  return [
    'V="${VALIANT_BIN:-}"; ',
    `if [ -z "$V" ]; then if [ -f "${cliPath}" ]; then V="${process.execPath} ${cliPath}"; elif command -v valiant >/dev/null 2>&1; then V="$(command -v valiant)"; fi; fi; `,
    'if [ -z "$V" ]; then echo "valiant: the hook cannot find the CLI (checkout moved, and no valiant on PATH)" >&2; exit 2; fi; ',
    // THE HOST BLOCKS ON EXIT 2, NOT ON "NON-ZERO". Claude Code treats 2 as "block and hand the agent the reason"; a 1 is an error
    // it may not act on. So any failure is mapped to 2 — but the gate's OWN exit code is printed by the engine first, so "broken" and
    // "could not check" stay distinguishable to a human. (A test caught this: removing the mapping made a broken repo exit 1, which
    // is not a block.)
    `${prefix}$V ${runner}; code=$?; if [ $code -ne 0 ]; then exit 2; fi; exit 0`,
  ].join("");
};

/** The hook entry, in the shape both hosts use. */
const entry = (cliPath, event) => {
  // THE MARKER MUST BE A COMMENT IN THE HOST'S OWN SYNTAX. "# ..." is a POSIX comment; cmd reads it as an argument, and
  // appended to a command it also changes the last word — which made "does it end by running the gate" false on Windows.
  // `rem ... &` is cmd's comment and still lets the command's exit code stand. `_valiant` keeps isOurs() working either way.
  // WINDOWS CARRIES THE MARKER INSIDE hookCommand (a quoted `set`), because a leading `rem` swallows the rest of the
  // line and turns the hook into a no-op. POSIX appends a comment.
  const command = process.platform === "win32"
    ? hookCommand(cliPath, event)
    : `${hookCommand(cliPath, event)}   # ${MARKER}`;
  return { matcher: "*", hooks: [{ type: "command", command }], _valiant: MARKER };
};

const isOurs = (e) => JSON.stringify(e).includes(MARKER);

// THE OPERATOR'S OWN ESTATE RULES. Not shipped in the SDK: a customer must not get the robmesh's rules.
// They live at ~/.valiant/local-hooks.json and are installed beside the gate hook, so one estate can fire
// its own PreToolUse SOPs (route-to-mesh, no-sleep-poll, no-blanket-git-add, …) through the same mechanism.
const LOCAL_MARKER = "installed by valiant local-hook";
const isLocal = (e) => JSON.stringify(e).includes(LOCAL_MARKER);

/** Read the operator's local hook pack, or an empty list when it is absent. */
function readLocalHooks(home) {
  const path = join(home, ".valiant", "local-hooks.json");
  const r = readJson(path);
  if (!r.ok) return { ok: false, why: r.why };
  const hooks = Array.isArray(r.data.hooks) ? r.data.hooks : [];
  const out = [];
  for (const h of hooks) {
    const id = typeof h?.id === "string" ? h.id.trim() : "";
    const command = typeof h?.command === "string" ? h.command.trim() : "";
    if (!id || !command) return { ok: false, why: `${path}: each hook needs an "id" and a "command"` };
    out.push({ id, command });
  }
  return { ok: true, hooks: out, path };
}

const localEntry = (id, command) => ({
  matcher: "*",
  hooks: [{ type: "command", command: `${command}   # ${LOCAL_MARKER} ${id}` }],
});

/** Read a JSON file, or return a fresh object. A malformed file is an error, never silently replaced. */
function readJson(path) {
  if (!existsSync(path)) return { ok: true, data: {} };
  const raw = readFileSync(path, "utf8");
  if (!raw.trim()) return { ok: true, data: {} };
  try { return { ok: true, data: JSON.parse(raw) }; }
  catch (e) { return { ok: false, why: `${path} is not valid JSON (${e.message}) — fix it before installing` }; }
}

export function installClaude(repoRoot, cliPath) {
  const path = join(repoRoot, ".claude", "settings.json");
  const r = readJson(path);
  if (!r.ok) return { ok: false, why: r.why };
  const cfg = r.data;
  cfg.hooks = cfg.hooks ?? {};
  const stop = Array.isArray(cfg.hooks.Stop) ? cfg.hooks.Stop : [];
  // UPGRADE, NOT SKIP. `stop.some(isOurs)` ended the install whenever our marker existed, so a hook written by an older build was never
  // replaced — the machine kept running the bug the new build fixed. Same fault as the DSH installer next door.
  // WINDOWS GETS A LAUNCHER, NOT A SHELL STRING. A command stored in JSON is re-parsed by cmd, and between the JSON, the
  // host and cmd the quoting of a path like "C:\\Program Files\\nodejs\\node.exe" survives only by luck: measured three
  // times — a `rem` that swallowed the line, a `||` that bound to the wrong command, and a command that came back
  // "not recognized". A .cmd file the host invokes is one token, and its own lines are a real batch file.
  const entryFor = () => {
    const e = entry(cliPath, "Stop");
    if (process.platform === "win32") {
      const bat = join(dirname(path), "valiant-stop.cmd");
      const body = `@echo off\r\nrem ${MARKER}\r\n"${process.execPath}" "${cliPath}" gate\r\nif errorlevel 1 exit /b 2\r\n`;
      try { mkdirSync(dirname(bat), { recursive: true }); writeFileSync(bat, body); e.hooks[0].command = `"${bat}"`; } catch { /* keep the inline command as the fallback */ }
    }
    return e;
  };
  const at = stop.findIndex(isOurs);
  if (at !== -1) {
    const want = entryFor();
    const have = stop[at]?.hooks?.[0]?.command ?? "";
    if (have === want.hooks[0].command) return { ok: true, path, already: true };
    stop[at] = want;
    cfg.hooks.Stop = stop;
    try { writeFileSync(path, `${JSON.stringify(cfg, null, 2)}\n`); } catch (e) { return { ok: false, why: `could not rewrite ${path}: ${e.message}` }; }
    return { ok: true, path, upgraded: true };
  }
  cfg.hooks.Stop = [...stop, entryFor()];
  try {
    mkdirSync(dirname(path), { recursive: true });
    writeFileSync(path, `${JSON.stringify(cfg, null, 2)}\n`);
  } catch (e) { return { ok: false, why: `could not write ${path}: ${e.message}` }; }
  return { ok: true, path, already: false };
}

export function installDsh(cliPath, home = homedir()) {
  const path = join(home, ".dsh", "hooks", "hooks.json");
  const r = readJson(path);
  if (!r.ok) return { ok: false, why: r.why };
  const cfg = r.data;
  cfg.hooks = cfg.hooks ?? {};
  let pre = Array.isArray(cfg.hooks.PreToolUse) ? cfg.hooks.PreToolUse : [];

  // THE GATE HOOK — upsert in place. Seeing our marker used to end the install, so a hook written by an older
  // build was never replaced; if ours is present but its command differs, rewrite it.
  const ours = pre.findIndex(isOurs);
  const want = entry(cliPath, "PreToolUse");
  const gateWasRight = ours !== -1 && (pre[ours]?.hooks?.[0]?.command ?? "") === want.hooks[0].command;
  if (ours !== -1) pre[ours] = want; else pre.push(want);

  // THE LOCAL HOOK PACK — the operator's own estate rules. Replace the whole set with the current file, so a
  // removed rule is removed and an edited command is updated, never accumulated forever.
  const lr = readLocalHooks(home);
  if (!lr.ok) return { ok: false, why: lr.why };
  pre = pre.filter((e) => !isLocal(e));
  for (const h of lr.hooks) pre.push(localEntry(h.id, h.command));

  cfg.hooks.PreToolUse = pre;
  try {
    mkdirSync(dirname(path), { recursive: true });
    writeFileSync(path, `${JSON.stringify(cfg, null, 2)}\n`);
  } catch (e) { return { ok: false, why: `could not write ${path}: ${e.message}` }; }
  return { ok: true, path, already: gateWasRight, local: lr.hooks.length };
}

/** What is enforced where. Used by the docs and by `valiant enforce --status`. */
export function status(repoRoot, home = homedir()) {
  // The stance is shown FIRST, because "installed" and "enforcing" are different facts and a hook that is installed in advisory
  // mode blocks nothing.
  const claudePath = join(repoRoot, ".claude", "settings.json");
  const dshPath = join(home, ".dsh", "hooks", "hooks.json");
  const has = (p) => { const r = readJson(p); return r.ok && JSON.stringify(r.data).includes(MARKER); };
  const push = existsSync(join(repoRoot, ".git", "hooks", "pre-push")) &&
    readFileSync(join(repoRoot, ".git", "hooks", "pre-push"), "utf8").includes("installed by valiant hooks");
  return {
    push,
    claude: has(claudePath),
    dsh: has(dshPath),
    rows: [
      ["git push", push ? "enforced" : "not installed", "valiant hooks --install"],
      ["CI (GitHub/Jenkins/GitLab)", "enforced where the file is committed", "valiant ci-init <platform>"],
      ["Claude Code", has(claudePath) ? "enforced" : "advisory only — the agent may ignore it", "valiant enforce --install claude"],
      ["DSH harness", has(dshPath) ? "installed" : "not installed", "valiant enforce --install dsh"],
    ],
  };
}
