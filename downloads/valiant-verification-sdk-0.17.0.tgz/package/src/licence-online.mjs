// licence-online.mjs — the licence is confirmed online, and a verdict is trusted for 24 hours.
//
// Rob, 2026-11-02: "licence verification needs to be done online"; then "24 hr cache". Those two together are a specific set of
// rules, and every one of them is checked here:
//
//   check succeeds            → that verdict is stored and believed for 24 hours
//   check fails (revoked)     → REFUSED now, cache or no cache: a revocation must not wait for a cache to expire
//   check cannot run          → the cached verdict is used IF it is younger than 24 hours; otherwise the licence is "cannot
//                               check", which is red — an unreachable server is not a licence
//   cache is for another jti  → ignored, never reused across licences
//
// The cache is keyed by jti so a re-issued licence never inherits the previous one's health.
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

export const DEFAULT_URL = "https://api.morpheus.nz/api/functions/licenceCheck";
export const CACHE_HOURS = 24;

const DIR = () => join(process.env.HOME || homedir(), ".valiant");
const CACHE = () => join(DIR(), "licence-check.json");

export function readCache() {
  try { return JSON.parse(readFileSync(CACHE(), "utf8")); } catch { return null; }
}

function writeCache(row) {
  try {
    mkdirSync(DIR(), { recursive: true, mode: 0o700 });
    writeFileSync(CACHE(), `${JSON.stringify(row, null, 2)}\n`, { mode: 0o600 });
  } catch { /* a cache we cannot write is a cache we do not have */ }
}

const ageHours = (row) => (row?.at ? (Date.now() - Date.parse(row.at)) / 3_600_000 : Infinity);

/** Ask the issuer. Returns {ok:true, valid, revoked, why} or {ok:false, why} when the answer never arrived. */
export async function ask(licence, { url = process.env.VALIANT_LICENCE_URL || DEFAULT_URL, timeoutMs = 6000 } = {}) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ licence }),
      signal: ac.signal,
    });
    if (!res.ok) return { ok: false, why: `the licence server returned HTTP ${res.status}` };
    const body = await res.json();
    return { ok: true, valid: body.valid === true, revoked: body.revoked === true, why: body.why ?? null, jti: body.jti ?? null, exp: body.exp ?? null };
  } catch (e) {
    return { ok: false, why: `could not reach the licence server (${e.name === "AbortError" ? "timed out" : e.message})` };
  } finally { clearTimeout(timer); }
}

/**
 * The decision the gate acts on.
 * @returns {{ok: boolean, source: "server"|"cache", why?: string, revoked?: boolean, staleHours?: number}}
 */
export async function evaluateOnline(licence, { jti, url, timeoutMs, now = Date.now() } = {}) {
  const cached = readCache();
  const mine = cached && jti && cached.jti === jti ? cached : null;

  const r = await ask(licence, { url, timeoutMs });
  if (r.ok) {
    // A REFUSAL IS NEVER CACHED AS TRUST: a revoked licence must stop now, not when the cache turns over.
    if (r.revoked || !r.valid) {
      writeCache({ at: new Date(now).toISOString(), jti: jti ?? null, valid: false, revoked: !!r.revoked, why: r.why ?? null });
      return { ok: false, source: "server", revoked: !!r.revoked, why: r.why ?? "the licence server says this licence is not valid" };
    }
    writeCache({ at: new Date(now).toISOString(), jti: jti ?? null, valid: true, revoked: false, exp: r.exp ?? null });
    return { ok: true, source: "server" };
  }

  // THE SERVER COULD NOT ANSWER. Believe a recent verdict, refuse a stale one, and say which happened.
  const age = ageHours(mine);
  if (mine && age <= CACHE_HOURS) {
    if (mine.revoked || mine.valid === false) return { ok: false, source: "cache", revoked: !!mine.revoked, why: mine.why ?? "revoked (cached verdict)" };
    return { ok: true, source: "cache", staleHours: Math.floor(age) };
  }
  return { ok: false, source: "none", why: `${r.why}, and no verdict from the last ${CACHE_HOURS} hours to fall back on` };
}
