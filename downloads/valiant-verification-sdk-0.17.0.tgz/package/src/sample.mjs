// sample.mjs — pick a seeded sample of published proofs and re-execute them.
//
// A repo whose guards are proved by its own runner publishes mutations.json. That is SELF-ATTESTED: the file
// could have been typed by hand. No amount of reading it can tell a real row from a fabricated one, so the
// mitigation is the one the registry already names — re-run a seeded sample and publish which k were checked.
import { execFileSync } from "node:child_process";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { isAbsolute, join } from "node:path";

export function sampleProofs({ dir, k = 3, seed = Number(new Date().toISOString().slice(0, 10).replace(/-/g, "")), prover = "node scripts/mutate-guards.mjs" }) {
  const proofsPath = join(dir, "mutations.json");
  if (!existsSync(proofsPath)) return { ok: false, code: 2, reason: "no mutations.json — there is nothing published to sample" };
  const doc = JSON.parse(readFileSync(proofsPath, "utf8"));
  const published = (doc.proofs ?? []).filter((p) => p.result === "red");
  if (!published.length) return { ok: false, code: 2, reason: "mutations.json holds no red proof to sample" };

  // A seeded LCG: the same seed picks the same guards, so the sample can be re-run by anyone reading the record.
  let state = seed >>> 0;
  const next = () => (state = (state * 1103515245 + 12345) >>> 0) / 4294967296;
  const guards = [...new Set(published.map((p) => p.guard))].sort();
  const chosen = [];
  const pool = [...guards];
  while (chosen.length < Math.min(k, guards.length)) chosen.push(pool.splice(Math.floor(next() * pool.length), 1)[0]);

  const results = [];
  for (const guard of chosen) {
    let code = 0, output = "";
    // NO SHELL. A prover is a command, not a shell line: "node ./prover.js" and "sh ./prover.sh" both split into argv,
    // and running the words directly means the platform's shell cannot silently change what was proved (on Windows the
    // old hardcoded /bin/sh did not exist, so every prover "failed" and the sampler reported a proof it never ran).
    try {
      const argv = (String(prover).match(/"[^"]*"|'[^']*'|\S+/g) ?? []).map((w) => w.replace(/^["']|["']$/g, ""));
      if (!argv.length) throw new Error("empty prover command");
      output = execFileSync(argv[0], [...argv.slice(1), guard], { cwd: dir, encoding: "utf8", timeout: 900000 });
    }
    catch (e) {
      code = e.status ?? 1;
      output = `${e.stdout ?? ""}${e.stderr ?? ""}`;
      // A prover that cannot be STARTED (missing command, wrong path) otherwise looks exactly like a proof that failed.
      if (process.env.VALIANT_DEBUG) console.error(`sampler: could not run prover ${JSON.stringify(prover)} for ${guard}: ${e.message}`);
    }
    const caught = (output.match(/caught\s+\S+/g) ?? []).length;
    results.push({ guard, exit: code, caught, reproduced: code === 0 && caught > 0 });
  }
  const record = {
    note: "A random SAMPLE of published mutation proofs, re-executed. Same seed + same repo = same sample.",
    seed, k: chosen.length, of: guards.length, prover,
    commit: (() => { try { return execFileSync("git", ["rev-parse", "HEAD"], { cwd: dir, encoding: "utf8" }).trim(); } catch { return null; } })(),
    at: new Date().toISOString(),
    sampled: results,
    reproduced: results.filter((r) => r.reproduced).length,
    failed: results.filter((r) => !r.reproduced).map((r) => r.guard),
  };
  const dest = join(dir, "sampled-proofs.json");
  writeFileSync(dest, `${JSON.stringify(record, null, 2)}\n`);
  return { ok: record.failed.length === 0, code: record.failed.length ? 1 : 0, record, dest };
}
