// ship.mjs — get a node's observations OFF the node, and merge them into the corpus.
//
// WHY. `valiant outcomes` records every (diff, verdict) pair a machine has seen — this Mac alone has over six thousand, of
// which several hundred are `survived` and `always-red`: the times a check did NOT catch what it claimed. That is the
// material a corpus is made of, and it never leaves the machine it was produced on. Until it does, more nodes prove more
// things and learn nothing collectively.
//
// THE TRUST RULE. A shard is not believed because it arrives. It carries a content hash so a truncated or edited shard is
// refused, and every row is marked `proven: false` on arrival: what a node OBSERVED is a lead, not a rule. A lead becomes
// a rule only when the same class is proven here, by re-execution, with the recipe it came with.
import { readFileSync, writeFileSync, existsSync, mkdirSync, appendFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { homedir, hostname, platform, arch } from "node:os";
import { join } from "node:path";

export const SHARD_VERSION = 1;
const DIR = () => join(process.env.HOME || homedir(), ".valiant");
const OUTCOMES = () => join(DIR(), "outcomes.jsonl");
const STORE = () => join(DIR(), "corpus-absorbs.jsonl");

/** A stable id for a recipe: the sabotage and the check, not the guard's name. Two repos naming the same guard
 *  differently are the same class. */
export function recipeKey(row) {
  const d = row?.diff ?? {};
  const check = Array.isArray(row?.check) ? row.check.join("\u0000") : String(row?.check ?? "");
  return createHash("sha256").update([d.file ?? "", d.find ?? "", d.replace ?? "", check].join("\u0000")).digest("hex").slice(0, 16);
}

const nodeId = () => createHash("sha256").update(`${hostname()}|${platform()}|${arch()}`).digest("hex").slice(0, 16);

const hashPairs = (pairs) => createHash("sha256").update(JSON.stringify(pairs)).digest("hex");

const readRows = () => {
  if (!existsSync(OUTCOMES())) return [];
  return readFileSync(OUTCOMES(), "utf8").split("\n").filter(Boolean).map((l) => {
    try { return JSON.parse(l); } catch { return null; }
  }).filter(Boolean);
};

/**
 * Build a shard: deduped by recipe, keeping the worst verdict seen for each (a `survived` outranks a `caught`, because the
 * question the corpus asks is "where did the check fail to catch", and an average would hide it).
 */
export function buildShard({ since = null, max = 5000, exclude = [] } = {}) {
  const skip = new Set(exclude.map((e) => String(e)));
  const rows = readRows().filter((r) => r.kind === "guard" && r.diff?.file
    && (since ? String(r.at ?? "") >= since : true)
    // A TOOL TESTING ITSELF IS NOT CORPUS MATERIAL. This machine's own suite produces hundreds of fixture guards; shipping
    // them would teach the corpus about `subject.txt` instead of about real repos.
    && !(r.repoName && skip.has(r.repoName)));
  const byKey = new Map();
  for (const r of rows) {
    const key = recipeKey(r);
    const prev = byKey.get(key);
    if (!prev) { byKey.set(key, { key, row: r, count: 1, verdicts: { [r.verdict]: 1 } }); continue; }
    prev.count++;
    prev.verdicts[r.verdict] = (prev.verdicts[r.verdict] ?? 0) + 1;
    // keep the row whose verdict is the most informative
    const rank = (v) => ({ survived: 5, "always-red": 4, unstable: 3, "cannot-run": 2, stale: 1, caught: 0 }[v] ?? 0);
    if (rank(r.verdict) > rank(prev.row.verdict)) prev.row = r;
  }
  const pairs = [...byKey.values()].slice(0, max).map(({ key, row, count, verdicts }) => ({
    key,
    guard: row.guard ?? null,
    diff: { file: row.diff?.file ?? null, find: row.diff?.find ?? null, replace: row.diff?.replace ?? "" },
    check: Array.isArray(row.check) ? row.check : null,
    verdict: row.verdict ?? "error",
    verdicts,
    seen: count,
    firstSeen: row.at ?? null,
    // A lead, not a rule: it was observed on another machine and has not been proven here.
    proven: false,
  }));
  return {
    version: SHARD_VERSION,
    kind: "valiant-outcomes",
    node: nodeId(),
    host: hostname(),
    platform: `${platform()}/${arch()}`,
    exportedAt: new Date().toISOString(),
    count: pairs.length,
    rowsRead: rows.length,
    pairs,
    hash: hashPairs(pairs),
  };
}

export function writeShard(path, shard) {
  writeFileSync(path, `${JSON.stringify(shard, null, 2)}\n`);
  return path;
}

/** Validate a shard: shape, hash, and that every row carries enough to be re-run later. */
export function validateShard(doc) {
  if (!doc || doc.kind !== "valiant-outcomes") return { ok: false, why: "not a valiant outcomes shard" };
  if (doc.version !== SHARD_VERSION) return { ok: false, why: `shard version ${doc.version} is not ${SHARD_VERSION} — update the tool` };
  if (!Array.isArray(doc.pairs)) return { ok: false, why: "no pairs array" };
  if (hashPairs(doc.pairs) !== doc.hash) return { ok: false, why: "the shard's hash does not match its contents — it was edited or truncated" };
  const bad = doc.pairs.filter((p) => !p.key || !p.diff?.file);
  if (bad.length) return { ok: false, why: `${bad.length} row(s) name no file, so they cannot be re-run later` };
  return { ok: true };
}

/** Merge into the local store. Dedupes by recipe key; a row already known keeps its first provenance and gains a sighting. */
export function absorb(shardPath) {
  let doc = null;
  try { doc = JSON.parse(readFileSync(shardPath, "utf8")); } catch (e) { return { ok: false, why: `cannot read ${shardPath}: ${e.message}` }; }
  const v = validateShard(doc);
  if (!v.ok) return { ok: false, why: v.why };

  const known = new Map();
  if (existsSync(STORE())) {
    for (const line of readFileSync(STORE(), "utf8").split("\n").filter(Boolean)) {
      try { const r = JSON.parse(line); known.set(r.key, r); } catch { /* skip */ }
    }
  }
  let added = 0;
  let seen = 0;
  mkdirSync(DIR(), { recursive: true });
  const touched = [];
  for (const p of doc.pairs) {
    const prev = known.get(p.key);
    if (prev) {
      // THE STORE IS NOT APPEND-ONLY. `seen` used to be computed here and thrown away: the row on disk kept its original
      // sighting count and node list, so a class seen on five machines still looked like one, and promotion could never
      // reach its threshold. Updates are collected and written back below.
      prev.sightings = (prev.sightings ?? 1) + 1;
      prev.nodes = [...new Set([...(prev.nodes ?? [prev.node]), doc.node])];
      touched.push(prev);
      seen++;
      continue;
    }
    const row = {
      key: p.key, node: doc.node, host: doc.host, platform: doc.platform,
      guard: p.guard, diff: p.diff, check: p.check, verdict: p.verdict,
      verdicts: p.verdicts ?? null, seen: p.seen ?? 1, firstSeen: p.firstSeen ?? null,
      absorbedAt: new Date().toISOString(), proven: false, sightings: 1, nodes: [doc.node],
    };
    appendFileSync(STORE(), `${JSON.stringify(row)}\n`);
    known.set(row.key, row);
    added++;
  }
  // rewrite the file with the rows that changed, atomically enough for one process at a time
  if (touched.length) {
    const changed = new Map(touched.map((r) => [r.key, r]));
    const out = [];
    const file = STORE();
    const existing = existsSync(file) ? readFileSync(file, "utf8").split("\n").filter(Boolean) : [];
    for (const line of existing) {
      let r = null;
      try { r = JSON.parse(line); } catch { continue; }
      out.push(changed.get(r.key) ?? r);
    }
    writeFileSync(file, out.map((r) => JSON.stringify(r)).join("\n") + "\n");
  }
  return { ok: true, added, seen, total: known.size, node: doc.node, host: doc.host };
}

export function storeSummary() {
  if (!existsSync(STORE())) return { rows: [], total: 0, unproven: 0, byVerdict: {} };
  const rows = readFileSync(STORE(), "utf8").split("\n").filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  const byVerdict = {};
  for (const r of rows) byVerdict[r.verdict] = (byVerdict[r.verdict] ?? 0) + 1;
  return { rows, total: rows.length, unproven: rows.filter((r) => !r.proven).length, byVerdict, nodes: [...new Set(rows.map((r) => r.node))].length };
}

// ── from lead to rule ────────────────────────────────────────────────────────────────────────────────────────────────
//
// A lead is another node's observation. It becomes a RULE only when this machine re-runs the recipe itself: the shard's
// word is not evidence, which is the whole difference between a corpus and a rumour. So the chain is:
//
//   absorb  → the lead is stored, proven: false
//   prove   → the recipe is re-executed HERE, in a repo that carries the file; the verdict recorded
//   promote → only proven rows may become rules, and only with the repo they were proven against

const readStore = () => {
  const p = STORE();
  if (!existsSync(p)) return [];
  return readFileSync(p, "utf8").split("\n").filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
};
const writeStore = (rows) => writeFileSync(STORE(), rows.map((r) => JSON.stringify(r)).join("\n") + "\n");

/** Re-execute one lead's recipe in a repo that contains the file it names. */
export async function prove(key, repoRoot) {
  const { runMutation } = await import("./mutate.mjs");
  const rows = readStore();
  const row = rows.find((r) => r.key === key || r.key?.startsWith(key));
  if (!row) return { ok: false, why: `no lead with key ${key} — run: valiant corpus leads` };
  if (!row.diff?.file) return { ok: false, why: "this lead names no file, so it can never be re-run" };
  if (!Array.isArray(row.check) || !row.check.length) return { ok: false, why: "this lead carries no check, so there is nothing to re-run" };
  if (!existsSync(join(repoRoot, row.diff.file))) return { ok: false, why: `${row.diff.file} is not in ${repoRoot} — prove it where the file lives` };

  const guard = { name: row.guard ?? "lead", file: row.diff.file, find: row.diff.find, replace: row.diff.replace, check: row.check };
  const verdict = runMutation(guard, repoRoot);
  // The lead's own verdict is what the other node saw. What matters here is whether the recipe behaves the same way HERE.
  row.proven = true;
  row.provenAt = new Date().toISOString();
  row.proofVerdict = verdict?.result ?? "error";
  row.proofDetail = String(verdict?.detail ?? "").slice(0, 200);
  row.proofRepo = createHash("sha256").update(String(repoRoot)).digest("hex").slice(0, 12);
  writeStore(rows);
  return { ok: true, row, verdict };
}

/** Which leads are ready to become rules: proven, and seen on at least `minNodes` machines. */
export function candidates({ minNodes = 2 } = {}) {
  return readStore().filter((r) => r.proven === true && (r.nodes?.length ?? 1) >= minNodes);
}

/** Promote proven leads to rules. Without --apply it only reports, because promotion is the irreversible half. */
export function promote({ minNodes = 2, apply = false } = {}) {
  const all = readStore();
  const ready = candidates({ minNodes });
  const leads = all.filter((r) => r.proven !== true);
  // proven here, but seen on too few machines: neither ready nor a lead, and saying so stops the count looking wrong
  const single = all.filter((r) => r.proven === true && (r.nodes?.length ?? 1) < minNodes);
  if (!apply) return { ok: true, ready, leads, single, applied: 0 };
  const file = join(DIR(), "corpus-promoted.jsonl");
  let applied = 0;
  for (const r of ready) {
    appendFileSync(file, `${JSON.stringify({ ...r, promotedAt: new Date().toISOString() })}\n`);
    applied++;
  }
  return { ok: true, ready, leads, single, applied, file };
}
