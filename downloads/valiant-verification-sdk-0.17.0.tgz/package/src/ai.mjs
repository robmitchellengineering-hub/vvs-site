// Morpheus AI client — the only file that knows how the SDK talks to a Morpheus account.
//
// WHY THE DEVICE FLOW AND NOT A TOKEN FIELD. The SDK already proves its identity offline with a
// licence; AI is a different credential, and it must bill the operator's OWN Morpheus credits (D29,
// D30). The device flow is the shape Morpheus built for exactly this: ask for a short code, approve
// it in the browser while logged into your own account, and receive a `dvc_` token that resolves
// server-side to that person — so the one AI call the Unambiguator makes bills their credits through
// the same runAiAction path every other client uses. No password, no JWT pasted into a config file.
//
// This is used ONLY by `valiant disambiguate --ai` (D37, slice 2) — the single metered call whose
// whole job is to GUESS what each vague term refers to and produce the fluent rewrite. Everything
// else in the Unambiguator is mechanical and free, and `--ai` stays off by default.
import { readFileSync, writeFileSync, mkdirSync, chmodSync, existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

export const DEFAULT_API = "https://api.morpheus.nz";

export function apiBase() {
  return (process.env.VALIANT_API || DEFAULT_API).replace(/\/+$/, "");
}

/** home — the SDK's own state dir, shared with the licence. */
export function home() {
  return join(process.env.HOME || homedir(), ".valiant");
}

export function tokenPath() {
  return join(home(), "ai-token");
}

export function readToken() {
  try {
    const t = readFileSync(tokenPath(), "utf8").trim();
    return t.startsWith("dvc_") || t.length > 20 ? t : null;
  } catch { return null; }
}

export function writeToken(token) {
  mkdirSync(home(), { recursive: true });
  writeFileSync(tokenPath(), token.trim() + "\n", { mode: 0o600 });
  try { chmodSync(tokenPath(), 0o600); } catch { /* windows ignores this; the file is under the user profile */ }
  return { path: tokenPath(), length: token.trim().length };
}

export function redact(token) {
  if (!token) return "(none)";
  const t = String(token);
  return t.slice(0, 4) + "…" + t.slice(-2);
}

async function post(path, body, { fetchImpl, token } = {}) {
  const f = fetchImpl ?? globalThis.fetch;
  const headers = { "content-type": "application/json", "user-agent": "valiant-sdk/0.1" };
  if (token) headers.authorization = `Bearer ${token}`;
  const res = await f(apiBase() + path, { method: "POST", headers, body: JSON.stringify(body ?? {}) });
  let json = null;
  try { json = await res.json(); } catch { /* an empty or html body is not a crash */ }
  return { status: res.status, ok: res.ok, json };
}

export async function deviceStart({ fetchImpl } = {}) {
  const r = await post("/api/auth/device/start", { client_label: "valiant disambiguator", scopes: ["ai_action"] }, { fetchImpl });
  if (!r.ok || !r.json?.user_code) {
    return { ok: false, status: r.status, reason: r.status === 404 ? "this Morpheus deployment has no device flow" : `start answered HTTP ${r.status}` };
  }
  return { ok: true, ...r.json };
}

export async function devicePoll(deviceCode, { fetchImpl } = {}) {
  const r = await post("/api/auth/device/poll", { device_code: deviceCode }, { fetchImpl });
  const j = r.json ?? {};
  const status = j.status || (r.ok ? "pending" : "error");
  return { ok: r.ok, status, token: j.token || j.device_token || null, user: j.user || null, reason: j.error || j.message || null, http: r.status };
}

/** login — the whole device flow, with the waiting injected so it can be tested without sleeping. */
export async function login({ fetchImpl, onShow, sleep = (ms) => new Promise((r) => setTimeout(r, ms)), maxWaitMs = 600000 } = {}) {
  const start = await deviceStart({ fetchImpl });
  if (!start.ok) return { ok: false, reason: start.reason };
  // onShow gets a SANITISED view: device_code is the secret half of the pair and has no business in a terminal.
  if (onShow) onShow({ user_code: start.user_code, verification_uri: start.verification_uri, verification_uri_complete: start.verification_uri_complete });
  const interval = Math.max(1, Number(start.interval) || 5) * 1000;
  const deadline = Date.now() + Math.min(maxWaitMs, (Number(start.expires_in) || 600) * 1000);
  while (Date.now() < deadline) {
    const p = await devicePoll(start.device_code, { fetchImpl });
    // The token is RETURNED, not written: the caller owns persistence, so `login` has no disk
    // side-effect and can be tested without clobbering a real stored token.
    if (p.token) return { ok: true, token: p.token, user: p.user };
    if (p.status === "denied") return { ok: false, reason: "the request was denied in the browser" };
    if (p.status === "expired") return { ok: false, reason: "the code expired before it was approved" };
    if (p.status === "error") return { ok: false, reason: p.reason || "the poll failed" };
    await sleep(interval);
  }
  return { ok: false, reason: "timed out waiting for approval" };
}

/** recordUsage — what the last AI call consumed, kept on this machine. */
export function recordUsage(json, { at = new Date().toISOString() } = {}) {
  const u = json?.usage;
  if (!u) return null;
  const row = { at, model: json.model ?? null, provider: json.provider ?? null, ...u };
  try {
    mkdirSync(home(), { recursive: true });
    writeFileSync(join(home(), "ai-usage.json"), JSON.stringify(row) + "\n", { mode: 0o600 });
  } catch { /* a machine that cannot write still gets the number back */ }
  return row;
}

export function lastUsage() {
  try { return JSON.parse(readFileSync(join(home(), "ai-usage.json"), "utf8")); } catch { return null; }
}

/** aiCall — the scoped AI function a device token may call (ai_action → runAiAction). */
export async function aiCall(payload, { fetchImpl, token } = {}) {
  const t = token ?? readToken();
  if (!t) return { ok: false, status: 0, reason: "no-token" };
  const r = await post("/api/functions/runAiAction", payload, { fetchImpl, token: t });
  if (r.status === 401 || r.status === 403) return { ok: false, status: r.status, reason: "token-rejected" };
  const usage = r.ok ? recordUsage(r.json) : null;
  return { ok: r.ok, status: r.status, json: r.json, usage };
}

/** disambiguateAI — the one call the Unambiguator makes: task `disambiguate`. */
export async function disambiguateAI(instruction, ambiguities, opts = {}) {
  return aiCall({ task: "disambiguate", instruction, ambiguities }, opts);
}
