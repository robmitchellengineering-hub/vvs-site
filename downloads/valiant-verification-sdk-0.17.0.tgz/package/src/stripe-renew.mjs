// stripe-renew.mjs — mint a short licence when Stripe says the subscription is paid, and mint NOTHING when it is not.
//
// Rob, 2026-10-27: "confirm that Stripe billing mechanism for ongoing monthly payments, if those payments stop i need
// the sdk to stop."
//
// The SDK verifies licences OFFLINE — no server, no network call — which is a feature: it works on a CI box behind a
// proxy or an airgapped machine. So liveness cannot be "ask Stripe at run time". It is expressed as TIME: the licence
// is short (default 7 days, the broker-token shape Rob chose 2026-10-27) and only a paid subscription earns a renewal. Stop paying, and the last licence runs out;
// `valiant gate` then refuses with "licence expired N day(s) ago" — the behaviour already proven on this machine.
//
// This module is the paid → renewed half: it verifies a Stripe webhook signature, decides whether the event means
// "still paying", and mints. It performs no network I/O, so it is testable without Stripe and cannot fail open.
import { createHmac, createPrivateKey, sign, timingSafeEqual } from "node:crypto";
import { appendFileSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

const b64url = (b) => Buffer.from(b).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

/**
 * Stripe's scheme: header `t=<unix>,v1=<hex hmac>` where the MAC is HMAC-SHA256(secret, `${t}.${rawBody}`).
 * A stale timestamp is refused: an old, validly signed event replayed later must not renew anything.
 */
export function verifyStripeSignature({ payload, header, secret, toleranceSeconds = 300, now = Date.now() }) {
  if (!header || !secret) return { ok: false, why: "missing signature header or signing secret" };
  const parts = Object.fromEntries(String(header).split(",").map((kv) => kv.split("=", 2)).map(([k, v]) => [k?.trim(), v?.trim()]));
  const t = Number(parts.t);
  const v1 = parts.v1;
  if (!Number.isFinite(t) || !v1) return { ok: false, why: "the signature header is not in Stripe's t=…,v1=… shape" };
  if (Math.abs(now / 1000 - t) > toleranceSeconds) return { ok: false, why: `the event is ${Math.round(Math.abs(now / 1000 - t))}s old — a replayed event must not renew a licence` };
  const expected = createHmac("sha256", secret).update(`${parts.t}.${payload}`).digest("hex");
  const a = Buffer.from(expected, "utf8");
  const b = Buffer.from(String(v1), "utf8");
  if (a.length !== b.length || !timingSafeEqual(a, b)) return { ok: false, why: "the signature does not match the payload — the event did not come from Stripe, or the secret is wrong" };
  return { ok: true };
}

/** Which Stripe events keep a licence alive, which grant GRACE, and which must NOT renew. Named explicitly, not defaulted. */
export const RENEWING = new Set(["invoice.paid", "invoice.payment_succeeded", "customer.subscription.updated", "customer.subscription.created"]);
/**
 * A FAILED PAYMENT IS NOT AN INSTANT CUT-OFF. Rob, 2026-10-30: "if someones payment fails they dont instantly loose service
 * they have 7 days to pay before it shuts down". So the failed payment mints a deliberate, bounded grace licence — a card
 * change is not an outage — and when that expires, nothing more is minted.
 */
export const GRACE_TRIGGER = "invoice.payment_failed";
export const STOPPING = new Set(["customer.subscription.deleted", "customer.subscription.paused", "charge.refunded"]);

export function decide(event) {
  const type = event?.type;
  if (RENEWING.has(type)) return { renew: true, why: type };
  if (type === GRACE_TRIGGER) return { renew: true, grace: true, days: GRACE_DAYS, why: `${type} — the payment failed, so a ${GRACE_DAYS}-day grace licence is minted; the customer has that long to fix it` };
  if (STOPPING.has(type)) return { renew: false, stop: true, why: `${type} — the subscription is not being paid; no licence is minted and the last one is left to expire` };
  return { renew: false, why: `${type ?? "(no type)"} is not a billing event this service acts on` };
}

/** Mint claims for a paid subscription. Seats come from the Stripe quantity, so the licence matches what was bought. */
// MONTHLY, BECAUSE THAT IS WHAT IS PAID FOR. Rob, 2026-10-30: "should be monthly as thats what the payments are". A
// subscription bills monthly, so the licence it mints lasts a month: a customer is never asked to renew a licence they have
// already paid for, and the control for non-payment is the expiry date the payment itself set.
export const LICENCE_DAYS = 30;
/** The grace a failed payment buys: long enough for a card change, short enough to matter. */
export const GRACE_DAYS = 7;
/** A licence covers one developer machine AND this many CI runners per seat: five seats, five runners (Rob, 2026-11-02). */
export const RUNNERS_PER_SEAT = 1;

export function claimsFor(event, { days = LICENCE_DAYS, grace = false, revocations = [], now = Date.now() } = {}) {
  const obj = event?.data?.object ?? {};
  const account = obj.customer ?? obj.customer_email ?? obj.subscription ?? null;
  if (!account) return { ok: false, why: "the event names no customer, so a licence cannot be tied to an account" };
  const quantity = obj.lines?.data?.[0]?.quantity ?? obj.quantity ?? obj.items?.data?.[0]?.quantity ?? 1;
  // WHICH TIER WAS BOUGHT. The checkout records `package` in Stripe metadata, and without reading it an enterprise
  // purchase minted a plain `solo` licence — so the $49 tier delivered exactly what the $25 tier did, and the licence
  // could not show what was bought.
  //
  // ENTERPRISE IS PER SEAT TOO (Rob, 2026-10-28: "the enterprise version is per seat too"). `PACKAGES.sdk_ent` is
  // `perSeat: true`, so an enterprise licence carries the seats bought exactly like standard: the tier buys SSO, priority
  // support and an SLA, NOT extra machines. An earlier version of this code made enterprise uncapped, which contradicted
  // the price it is sold at.
  const pkg = obj.metadata?.package ?? obj.metadata?.tier ?? null;
  const enterprise = pkg === "sdk_ent" || pkg === "enterprise" || obj.metadata?.plan === "enterprise";
  const t = Math.floor(now / 1000);
  return {
    ok: true,
    claims: {
      v: 1,
      sub: String(account),
      plan: enterprise ? "enterprise" : quantity > 1 ? "team" : "solo",
      // ONE MACHINE PER SEAT, ON EVERY PLAN. The tier changes the price and what comes with it, never the seat rule.
      seats: Number(quantity) || 1,
      // AND CI RUNNERS TO MATCH (Rob, 2026-11-02): "if you buy 5 seats thats 5 CI runners". Stated in the licence, so a buyer
      // can see what they got without reading this file.
      runners: Math.max(1, (Number(quantity) || 1) * RUNNERS_PER_SEAT),
      jti: `lic_${t.toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
      iat: t,
      exp: t + Math.round(days * 86_400),
      src: "stripe",
      // A grace licence is labelled, so a support conversation can tell "we granted you a week" from "you paid".
      ...(grace ? { grace: true } : {}),
      // THE LICENCE IS ALSO THE REVOCATION CARRIER (Rob, 2026-10-30). This spread was MISSING while the parameter was
      // accepted, so `claimsFor(ev, { revocations: […] })` silently minted a licence without the list — the carrier existed
      // and carried nothing. Found by measuring three licences and noticing they were all the same 270 bytes.
      ...(Array.isArray(revocations) && revocations.length ? { revocations } : {}),
      event: event.id ?? null,
    },
  };
}

/** Sign exactly as tools/mint-licence.mjs does, so a renewed licence is indistinguishable to the verifier. */
export function mintLicence(claims, keyPem) {
  const key = createPrivateKey(keyPem);
  const payload = Buffer.from(JSON.stringify(claims));
  const payloadPart = b64url(payload);
  const signature = sign(null, payload, key);
  return `vvs1.${payloadPart}.${b64url(signature)}`;
}

/**
 * DELIVERY. A renewed licence has to reach the customer's machine, or the renewal did nothing. There is no email and no
 * portal in this SDK, so the handler writes the file the operator sends, and records the issue in the register. Wiring
 * Stripe to mail it is a deployment decision (Morpheus has mail; this repo does not).
 */
export function deliver({ licence, claims, outDir }) {
  try {
    mkdirSync(outDir, { recursive: true });
    const file = join(outDir, `${claims.sub.replace(/[^A-Za-z0-9_.-]/g, "_")}-${claims.jti}.licence`);
    writeFileSync(file, `${licence}\n`, { mode: 0o600 });
    return { ok: true, file };
  } catch (e) { return { ok: false, why: e.message }; }
}

export function recordIssue({ claims, outDir }) {
  try {
    mkdirSync(outDir, { recursive: true });
    const p = join(outDir, "issued.jsonl");
    appendFileSync(p, `${JSON.stringify({ at: new Date().toISOString(), jti: claims.jti, sub: claims.sub, plan: claims.plan, seats: claims.seats, exp: claims.exp, src: claims.src ?? "manual" })}\n`);
    return { ok: true, file: p };
  } catch (e) { return { ok: false, why: e.message }; }
}

export function issuerKey() {
  return readFileSync(join(process.env.HOME || homedir(), ".valiant", "issuer-key.pem"), "utf8");
}

/**
 * The whole handler, with no HTTP in it: verify → decide → mint (or not). Returns what a webhook should send back.
 * On a stopping event it returns `renewed: false` and no licence — and that is the requirement, not an error.
 */
export function handleWebhook({ payload, signatureHeader, secret, days = LICENCE_DAYS, keyPem = null, now = Date.now() }) {
  const sig = verifyStripeSignature({ payload, header: signatureHeader, secret, now });
  if (!sig.ok) return { status: 400, ok: false, why: sig.why };
  let event = null;
  try { event = JSON.parse(payload); } catch (e) { return { status: 400, ok: false, why: `the payload is not JSON (${e.message})` }; }
  const d = decide(event);
  if (!d.renew) return { status: 200, ok: true, renewed: false, why: d.why, stopped: !!d.stop, event: event.type };
  // A GRACE MINT USES ITS OWN TERM. `days` is the paid term; a failed payment must not inherit it, or a card decline would
  // buy another month.
  const term = d.grace ? d.days : days;
  const c = claimsFor(event, { days: term, grace: !!d.grace, now });
  if (!c.ok) return { status: 200, ok: true, renewed: false, why: c.why, event: event.type };
  if (!keyPem) return { status: 200, ok: true, renewed: true, claims: c.claims, licence: null, why: "no issuer key here — claims minted, signing skipped" };
  return { status: 200, ok: true, renewed: true, claims: c.claims, licence: mintLicence(c.claims, keyPem), event: event.type };
}

/**
 * THE CUSTOMER GETS THE RENEWAL (Rob, 2026-10-27). The handler builds the message; sending it is the host's job, because
 * this SDK has no SMTP and should not grow one — morpheus.nz already has a mailer for exactly this.
 *
 * Stripe puts the address on the customer (`customer_email` on an invoice, `email` on a customer object). If the event
 * carries neither, the message is not built and the operator has to look — never guess an address.
 */
export function customerEmail(event) {
  const o = event?.data?.object ?? {};
  return o.customer_email ?? o.receipt_email ?? o.customer_details?.email ?? o.email ?? null;
}

export function renewalMail({ event, licence, claims }) {
  const to = customerEmail(event);
  if (!to) return { ok: false, why: "the Stripe event carries no customer email — the licence was minted but nobody can be told" };
  const days = Math.max(1, Math.round((claims.exp - claims.iat) / 86_400));
  const expires = new Date(claims.exp * 1000).toISOString().slice(0, 10);
  const text = [
    "Your Valiant licence has been renewed.",
    "",
    `Account:   ${claims.sub}`,
    `Plan:      ${claims.plan}${claims.seats ? ` (${claims.seats} seat${claims.seats === 1 ? "" : "s"})` : ""}`,
    `Licence:   ${claims.jti}`,
    `Valid for: ${days} days — until ${expires}`,
    "",
    "Install it on each machine:",
    "",
    `  valiant licence --file ${claims.jti}.licence`,
    "",
    "Then check it with:  valiant licence --status",
    "",
    "The file is attached. It verifies offline, with no account and no network call.",
    "",
    "This licence is short-lived on purpose: it renews while your subscription is paid, and stops when it is not.",
  ].join("\n");
  return {
    ok: true,
    mail: {
      to,
      subject: `Valiant licence renewed — valid until ${expires}`,
      text,
      attachments: [{ filename: `${claims.jti}.licence`, content: `${licence}\n` }],
    },
  };
}
