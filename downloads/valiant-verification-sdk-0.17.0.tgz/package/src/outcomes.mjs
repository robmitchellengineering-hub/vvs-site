// outcomes.mjs — the verifier's own record of (diff, verdict) pairs.
//
// Rob, 2026-10-27: "Do consider logging verifier outcomes as (diff, verdict) pairs — cheap now, the only thing that
// makes any future training possible."
//
// Every other artefact this tool writes is about the repo under test: mutations.json says a proof is red, the ledger
// says a claim was proven. None of them record what the VERIFIER saw — the exact sabotage it applied and what the check
// did with it — so the tool cannot improve from its own history, and nobody can train on it later.
//
// A record is deliberately small and deliberately paired:
//   diff    the sabotage: {file, find, replace} — the exact bytes it changed
//   verdict caught | survived | always-red | stale | unstable | cannot-run | error
//   trials  how many runs in each phase, so a sample is reproducible
//   check   the command, because a diff without the check that judged it is half a pair
//
// PRIVACY, because a check command can carry a secret: the repo PATH is hashed, never stored; a record can be turned off
// entirely with VALIANT_NO_OUTCOMES=1; and nothing leaves the machine. `valiant outcomes` reads the file back, so the
// user owns the record as much as the tool does.
import { appendFileSync, existsSync, mkdirSync, readFileSync, renameSync, statSync } from "node:fs";
import { createHash } from "node:crypto";
import { consent, repOptOut, observationFor, enqueue } from "./consent.mjs";
import { homedir } from "node:os";
import { join } from "node:path";

const DIR = () => join(process.env.HOME || homedir(), ".valiant");
const FILE = () => join(DIR(), "outcomes.jsonl");
const MAX_BYTES = 32 * 1024 * 1024;   // rotate rather than grow without bound

const enabled = () => process.env.VALIANT_NO_OUTCOMES !== "1";

function fingerprint(repoRoot) {
  // The path is a place, not evidence; hashing it keeps the record portable and the machine private.
  return createHash("sha256").update(String(repoRoot)).digest("hex").slice(0, 12);
}

export function recordOutcome({ repoRoot, guard, result, trials = null, extra = {} }) {
  if (!enabled()) return;
  try {
    mkdirSync(DIR(), { recursive: true });
    const file = FILE();
    try { if (statSync(file).size > MAX_BYTES) renameSync(file, `${file}.1`); } catch { /* first write */ }
    const row = {
      at: new Date().toISOString(),
      kind: "guard",
      repo: fingerprint(repoRoot),
      // THE NAME, NOT THE PATH. A machine that runs a tool's own test suite fills the log with fixture guards
      // (`subject.txt`, `HERO`), which is noise in a corpus. The name lets a shard exclude it; the path would leak where
      // the repo lives, which is not evidence.
      repoName: (() => { try { return String(repoRoot).split(/[\\/]/).filter(Boolean).pop() ?? null; } catch { return null; } })(),
      guard: guard?.name ?? null,
      diff: { file: guard?.file ?? null, find: guard?.find ?? null, replace: guard?.replace ?? "" },
      check: guard?.check ?? guard?.fixture ?? null,
      verdict: result?.result ?? "error",
      detail: typeof result?.detail === "string" ? result.detail.slice(0, 300) : null,
      trials,
      ...extra,
    };
    appendFileSync(file, `${JSON.stringify(row)}\n`);
    // THE CORPUS IS COLLECTED BY DEFAULT (Rob, 2026-11-02), and what is collected is METADATA: a salted recipe hash, the
    // verdict, the trial count and the shape of the check — never the file, the find, the replace or the check itself. Queued
    // locally and flushed by whoever has a collector configured, so a machine offline still gates.
    try {
      const c = consent();
      if (c.enabled && !repOptOut(repoRoot)) {
        const obs = observationFor(row, { installId: c.installId });
        if (obs) enqueue(obs);
      }
    } catch { /* collection must never break the thing it observes */ }
  } catch { /* logging must never break the thing it observes */ }
}

/** Also record the composite outcomes, so the record covers the verdicts a customer reads, not only the guard engine. */
export function recordVerdict({ repoRoot, command, exitCode, summary, extra = {} }) {
  if (!enabled()) return;
  try {
    mkdirSync(DIR(), { recursive: true });
    appendFileSync(FILE(), `${JSON.stringify({
      at: new Date().toISOString(), kind: "verdict", repo: fingerprint(repoRoot),
      command, exitCode, summary: summary ? String(summary).slice(0, 200) : null, ...extra,
    })}\n`);
  } catch { /* best effort */ }
}

export function readOutcomes() {
  const file = FILE();
  if (!existsSync(file)) return { file, rows: [], counts: {} };
  let rows = [];
  try {
    rows = readFileSync(file, "utf8").split("\n").filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  } catch { return { file, rows: [], counts: {} }; }
  const counts = {};
  for (const r of rows) {
    const k = r.kind === "verdict" ? `verdict:${r.command}:${r.exitCode}` : `guard:${r.verdict}`;
    counts[k] = (counts[k] ?? 0) + 1;
  }
  return { file, rows, counts };
}

/** The (diff, verdict) pairs alone — the shape a training set takes. */
export function pairs() {
  return readOutcomes().rows
    .filter((r) => r.kind === "guard" && r.diff?.find)
    .map((r) => ({ diff: r.diff, check: r.check, verdict: r.verdict, trials: r.trials, at: r.at }));
}
