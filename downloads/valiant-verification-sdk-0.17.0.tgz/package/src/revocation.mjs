// revocation.mjs — a revoked licence is not an instant cut-off, and it is not ignored either.
//
// Rob, 2026-10-30: "Block after grace". The reason for the middle phase is asymmetric risk: a REVOCATION CAN BE WRONG —
// support revokes the wrong account, a key rotation goes sideways, a customer's licence was duplicated onto their old
// laptop — and cutting a paying customer's delivery off instantly turns our mistake into their outage. A leaked licence
// surviving two days is the smaller harm.
//
//   first seen  → GRACE: the gate runs, prints what happened, records the decision, and carries on
//   +48 hours   → BLOCK: the gate exits 2, which is red, and is never a pass
//
// The list is local (`~/.valiant/revoked.txt`, one jti per line). The SDK never phones home to ask whether a licence is
// still valid — that is the property that makes it usable on the machines it exists for.
import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

export const GRACE_HOURS = 48;

const DIR = () => join(process.env.HOME || homedir(), ".valiant");
const LIST = () => join(DIR(), "revoked.txt");
const SEEN = () => join(DIR(), "revocations-seen.json");

/** The revoked ids this machine has been told about. */
export function revokedSet() {
  try {
    return new Set(readFileSync(LIST(), "utf8").split("\n").map((l) => l.trim()).filter((l) => l && !l.startsWith("#")));
  } catch {
    return new Set();
  }
}

/** When each revoked id was FIRST seen here — the clock the grace runs on. */
export function seenMap() {
  try { return JSON.parse(readFileSync(SEEN(), "utf8")).seen ?? {}; } catch { return {}; }
}

/**
 * Record the revoked ids this machine can see, returning the first-seen time for `jti`. The first time an id is noticed is
 * the only moment grace can start: keying it to the licence's issue date or to now would make grace either eternal or zero.
 */
export function noteRevocations(jtis, now = Date.now()) {
  const map = seenMap();
  let changed = false;
  for (const jti of jtis) if (!map[jti]) { map[jti] = new Date(now).toISOString(); changed = true; }
  if (changed) {
    try {
      mkdirSync(DIR(), { recursive: true });
      writeFileSync(SEEN(), `${JSON.stringify({ seen: map }, null, 2)}\n`);
    } catch { /* a machine we cannot write to still gets the conservative answer below */ }
  }
  return map;
}

/**
 * Decide what a revoked licence does here.
 *   { state: "not-revoked" }                  — nothing to do
 *   { state: "grace",  until, hoursLeft }     — run, warn, record
 *   { state: "blocked", since }               — exit 2
 */
export function revocationState(jti, { now = Date.now(), graceHours = GRACE_HOURS } = {}) {
  if (!jti) return { state: "not-revoked" };
  const revoked = revokedSet();
  if (!revoked.has(jti)) return { state: "not-revoked" };
  const map = noteRevocations([...revoked], now);
  const since = Date.parse(map[jti] ?? "") || now;
  const until = since + graceHours * 3_600_000;
  if (now < until) return { state: "grace", since: new Date(since).toISOString(), until: new Date(until).toISOString(), hoursLeft: Math.max(1, Math.ceil((until - now) / 3_600_000)) };
  return { state: "blocked", since: new Date(since).toISOString() };
}

// A gate evaluates the licence more than once (verify, then the mutation phase). A warning printed twice reads as a fault,
// so a human sees it once per process.
const alreadySaid = new Set();

/**
 * One line for a human, or null when there is nothing to say.
 * @param {boolean} [once] suppress the repeat when the same licence is checked again in this process
 */
export function revocationNotice(jti, opts = {}) {
  const r = revocationState(jti, opts);
  if (r.state === "not-revoked") return null;
  if (opts.once) { if (alreadySaid.has(`${jti}:${r.state}`)) return null; alreadySaid.add(`${jti}:${r.state}`); }
  if (r.state === "grace") return `this licence (${jti}) has been REVOKED. It keeps working for ${r.hoursLeft} more hour(s), until ${r.until}, so a wrong revocation is not an outage — after that every gate stops.`;
  return `this licence (${jti}) was REVOKED on ${r.since} and the grace has run out.`;
}

// ── distribution ─────────────────────────────────────────────────────────────────────────────────────────────────────
//
// A revocation list nobody receives is not a control. Two carriers, both offline-safe:
//
//   1. THE LICENCE ITSELF. Every renewal can carry `revocations: [jti…]` as a signed claim, so a paying customer's machine
//      learns the list for free at renewal — no endpoint, no network call from the SDK, no infrastructure to run.
//   2. `licence --sync <url|file>` for immediate action, cached locally with its issue date, so a stale cache is VISIBLE
//      rather than silently trusted. A list older than the one already held is refused: a rollback would resurrect a
//      revoked licence.

const META = () => join(DIR(), "revocations-meta.json");

/** Add ids to the local list. Nothing is removed, so a sync cannot un-revoke something. */
export function mergeRevocations(jtis, { now = Date.now() } = {}) {
  const clean = [...new Set((jtis ?? []).map((j) => String(j ?? "").trim()).filter(Boolean))];
  if (!clean.length) return { added: 0, total: revokedSet().size };
  const already = revokedSet();
  const fresh = clean.filter((j) => !already.has(j));
  if (fresh.length) {
    try {
      mkdirSync(DIR(), { recursive: true, mode: 0o700 });
      const existing = existsSync(LIST()) ? readFileSync(LIST(), "utf8") : "";
      const body = existing.endsWith("\n") || !existing ? existing : `${existing}\n`;
      writeFileSync(LIST(), `${body}${fresh.join("\n")}\n`, { mode: 0o600 });
    } catch (e) {
      return { added: 0, total: already.size, error: `could not write ${LIST()} (${e.code ?? e.message})` };
    }
  }
  noteRevocations([...already, ...fresh], now);
  return { added: fresh.length, total: revokedSet().size };
}

/** The issue date of the list this machine holds, so staleness can be shown rather than assumed. */
/**
 * SHOULD THE GATE REFRESH THE LIST NOW? A revocation that only arrives when someone remembers to run `--sync` is a revocation that arrives
 * when someone remembers. The gate asks this once per run and refreshes best-effort; the cache is what makes that safe offline.
 * Six hours: a withdrawal reaches a machine well inside the 48-hour grace the product promises, without a network call on every command.
 */
export const REFRESH_HOURS = 6;
export function needsRefresh({ now = Date.now(), hours = REFRESH_HOURS } = {}) {
  const m = meta();
  if (!m.fetchedAt) return true;
  const age = now - Date.parse(m.fetchedAt);
  return !Number.isFinite(age) || age > hours * 3_600_000;
}

/** The ids the last fetch brought in, so the gate can apply the grace rule to them without a network. */
export function cachedRevocations() {
  try {
    if (!existsSync(LIST())) return [];
    return readFileSync(LIST(), "utf8").split("\n").map((l) => l.trim()).filter(Boolean);
  } catch { return []; }
}

export function meta() {
  try { return JSON.parse(readFileSync(META(), "utf8")); } catch { return { issuedAt: null, from: null, count: revokedSet().size }; }
}

/**
 * Absorb the `revocations` claim from a licence that verified. This is carrier 1: a renewal email is also a revocation
 * update, which is why it needs no endpoint and no phone-home.
 */
export function absorbLicenceClaims(claims) {
  const list = Array.isArray(claims?.revocations) ? claims.revocations : [];
  if (!list.length) return { added: 0, total: revokedSet().size, source: "licence" };
  const r = mergeRevocations(list);
  try {
    mkdirSync(DIR(), { recursive: true, mode: 0o700 });
    writeFileSync(META(), `${JSON.stringify({ issuedAt: claims.iat ?? null, from: `licence ${claims.jti ?? "(no jti)"}`, count: r.total }, null, 2)}\n`, { mode: 0o600 });
  } catch { /* a cache we cannot date is still a list we honour */ }
  return { ...r, source: "licence" };
}

/**
 * Carrier 2: fetch a signed revocation list and merge it. `source` is a URL, a file path, or the token itself.
 * Returns what changed, or why it was refused — never a silent no-op.
 */
// THE ISSUER'S OWN ENDPOINT IS THE DEFAULT. It replaced a file published from the issuing Mac, so `valiant licence --sync` with no
// argument now asks the issuer directly — no URL to remember, no copy to keep current.
export const DEFAULT_SYNC_URL = "https://api.morpheus.nz/api/functions/revocations";

export async function syncRevocations(source = DEFAULT_SYNC_URL, { publicKeyPem, now = Date.now(), verifyLicence } = {}) {
  if (!verifyLicence) return { ok: false, why: "no verifier available" };
  let text = String(source ?? "").trim();
  const looksLikeToken = text.startsWith("vvs1.");
  if (!looksLikeToken) {
    if (/^https?:\/\//i.test(text)) {
      try {
        const res = await fetch(text, { redirect: "follow" });
        if (!res.ok) return { ok: false, why: `${text} returned HTTP ${res.status}` };
        const raw = (await res.text()).trim();
        // The issuer's endpoint answers JSON ({ok, list}); a plain file is the raw token. Both arrive here.
        if (raw.startsWith("{")) {
          let body = null;
          try { body = JSON.parse(raw); } catch { return { ok: false, why: "the issuer returned JSON that does not parse" }; }
          if (!body.ok || typeof body.list !== "string") {
            return { ok: false, why: body.error ?? "the issuer returned no signed list" };
          }
          text = body.list.trim();
        } else {
          text = raw;
        }
      } catch (e) {
        return { ok: false, why: `could not fetch ${text} (${e.message})` };
      }
    } else {
      try { text = readFileSync(text, "utf8").trim(); } catch (e) { return { ok: false, why: `could not read ${text} (${e.code ?? e.message})` }; }
    }
  }
  const v = verifyLicence(text, { publicKeyPem, now: Math.floor(now / 1000) });
  if (!v.ok) return { ok: false, why: `the list did not verify: ${v.reason}` };
  if (v.claims?.kind !== "revocations") return { ok: false, why: "that token is a licence, not a revocation list — pass the list the issuer publishes" };
  const list = Array.isArray(v.claims.revocations) ? v.claims.revocations : [];
  const before = meta();
  if (before.issuedAt && v.claims.iat && Number(v.claims.iat) < Number(before.issuedAt)) {
    // A rollback would resurrect revoked licences, which is exactly what an attacker with an old list would want.
    return { ok: false, why: `this list is older (${new Date(v.claims.iat * 1000).toISOString()}) than the one already held (${new Date(before.issuedAt * 1000).toISOString()}) — refusing to roll back` };
  }
  const r = mergeRevocations(list, { now });
  if (r.error) return { ok: false, why: r.error };
  try {
    mkdirSync(DIR(), { recursive: true, mode: 0o700 });
    writeFileSync(META(), `${JSON.stringify({ issuedAt: v.claims.iat ?? null, from: /^https?:/i.test(String(source)) ? "url" : "file", count: r.total, fetchedAt: new Date(now).toISOString() }, null, 2)}\n`, { mode: 0o600 });
  } catch { /* best effort */ }
  return { ok: true, added: r.added, total: r.total, issuedAt: v.claims.iat ?? null };
}

/**
 * Mint the standalone list `--sync` fetches. Same envelope as a licence, same key, `kind: "revocations"` — so it verifies
 * with the code that already ships and needs nothing new at the customer's end.
 *
 * A list is PUBLIC: it is a signed statement that certain ids are withdrawn, and publishing it leaks nothing but the ids.
 * It is still signed, because an unsigned list is a wish — anyone could hand a customer a list with their own id on it.
 */
export function mintRevocationList({ jtis = [], keyPem, kid = null, days = 90, now = Date.now(), mint }) {
  if (!keyPem) return { ok: false, why: "no issuer key — a list without a signature is a wish" };
  if (!mint) return { ok: false, why: "no signing function available" };
  const ids = [...new Set((jtis ?? []).map((j) => String(j ?? "").trim()).filter(Boolean))];
  const iat = Math.floor(now / 1000);
  const claims = { v: 1, kind: "revocations", iat, exp: iat + Math.max(1, days) * 86_400, revocations: ids };
  if (kid) claims.kid = kid;
  try { return { ok: true, token: mint(claims, keyPem), claims, count: ids.length }; }
  catch (e) { return { ok: false, why: `could not sign the list (${e.message})` }; }
}
