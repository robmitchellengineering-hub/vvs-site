// receipts.mjs — one record per hook decision, hash-chained, with the command hashed and never stored.
//
// Plan item 3 (plan/BUILD-PLAN-enforcement.md). The gap it names is ours: the hooks print a message and exit non-zero,
// and nothing is recorded, so "the hook blocked it" is a claim about a message nobody kept. A decision that leaves no
// trace cannot be audited, and a hook that silently stopped firing looks exactly like a hook with nothing to do.
//
// Shaped after APort (Apache-2.0): identity → authorisation → audit, with a signed decision per tool call. Exported as
// an in-toto statement so a receipt is readable by supply-chain tooling rather than being our own JSON shape.
//
// PRIVACY: hooks see secrets, so the COMMAND IS HASHED, never stored. The reason is free text and is truncated.
import { appendFileSync, existsSync, mkdirSync, readFileSync, renameSync, statSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { homedir } from "node:os";
import { join } from "node:path";

const DIR = () => join(process.env.HOME || homedir(), ".valiant");
export const FILE = () => join(DIR(), "decisions.jsonl");
const MAX_BYTES = 32 * 1024 * 1024;

const sha = (s) => createHash("sha256").update(String(s)).digest("hex");

function lastHash(file) {
  try {
    const lines = readFileSync(file, "utf8").split("\n").filter(Boolean);
    return lines.length ? (JSON.parse(lines[lines.length - 1]).chain ?? "") : "";
  } catch { return ""; }
}

/**
 * Record one decision. FAIL-SAFE BY CONSTRUCTION: it returns a result and never throws, because a hook that crashes
 * because logging failed breaks the thing it protects.
 */
export function recordDecision({ hook, tool = null, command = null, verdict, reason = "" }) {
  try {
    mkdirSync(DIR(), { recursive: true });
    const file = FILE();
    try { if (statSync(file).size > MAX_BYTES) renameSync(file, `${file}.1`); } catch { /* first write */ }
    const prev = lastHash(file);
    const body = {
      at: new Date().toISOString(),
      hook: String(hook ?? "unknown"),
      tool,
      // HASHED, never stored: a hook sees the command line, and the command line can carry a secret.
      commandSha256: command == null ? null : sha(command),
      verdict: verdict === "deny" ? "deny" : verdict === "warn" ? "warn" : "allow",
      reason: String(reason).slice(0, 200),
      prev,
    };
    const chain = sha(prev + "\u0000" + JSON.stringify(body));
    appendFileSync(file, `${JSON.stringify({ ...body, chain })}\n`);
    return { ok: true, chain };
  } catch (e) {
    return { ok: false, why: e.message };   // never throw
  }
}

export function readDecisions() {
  const file = FILE();
  if (!existsSync(file)) return [];
  try { return readFileSync(file, "utf8").split("\n").filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean); }
  catch { return []; }
}

/** Walk the chain; the FIRST break is the finding (anything after it is a consequence). */
export function verifyDecisions(rows = readDecisions()) {
  let prev = "";
  for (const [i, r] of rows.entries()) {
    const expect = sha(prev + "\u0000" + JSON.stringify({ at: r.at, hook: r.hook, tool: r.tool, commandSha256: r.commandSha256, verdict: r.verdict, reason: r.reason, prev: r.prev }));
    if (r.prev !== prev) return { ok: false, at: i, detail: `record ${i + 1} (${r.hook}) follows a different record than the one on disk — a line was removed or reordered` };
    if (r.chain !== expect) return { ok: false, at: i, detail: `record ${i + 1} (${r.hook}) does not match its own chain value — it was edited` };
    prev = r.chain;
  }
  return { ok: true, count: rows.length };
}

export function summarise(rows = readDecisions()) {
  const by = {};
  for (const r of rows) {
    by[r.hook] ??= { allow: 0, deny: 0, warn: 0, lastDeny: null, last: null };
    by[r.hook][r.verdict] = (by[r.hook][r.verdict] ?? 0) + 1;
    if (r.verdict === "deny") by[r.hook].lastDeny = { at: r.at, reason: r.reason };
    by[r.hook].last = r.at;
  }
  return by;
}

/**
 * A hook with no decision in N days is either redundant or broken, and both are worth knowing. This is the gate that
 * makes "the hook is installed" different from "the hook is doing anything".
 */
export function unexercised(declared, days, rows = readDecisions()) {
  const cutoff = Date.now() - days * 86_400_000;
  const seen = new Set(rows.filter((r) => Date.parse(r.at) >= cutoff).map((r) => r.hook));
  return (declared ?? []).filter((h) => !seen.has(h));
}

/** An in-toto statement, so a receipt travels with build provenance instead of being our own shape. */
export function toInToto(rows = readDecisions()) {
  const body = rows.map((r) => ({ at: r.at, hook: r.hook, tool: r.tool, verdict: r.verdict, reason: r.reason, chain: r.chain }));
  return {
    _type: "https://in-toto.io/Statement/v1",
    subject: [{ name: "valiant-decisions", digest: { sha256: sha(JSON.stringify(body)) } }],
    predicateType: "https://valiant.dev/decision-log/v1",
    predicate: { count: rows.length, decisions: body },
  };
}

export function writeInToto(path, rows = readDecisions()) {
  writeFileSync(path, `${JSON.stringify(toInToto(rows), null, 2)}\n`);
  return path;
}
