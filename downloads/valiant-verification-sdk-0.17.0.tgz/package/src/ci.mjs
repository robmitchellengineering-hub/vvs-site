// ci.mjs — WHERE THE GATE RUNS, decided from the machine it is standing on.
//
// The product's own CI step used to be a static file: `ci-init github` copied a template that pinned a 0.2.0 tarball
// and assumed `ubuntu-latest`. That is wrong in all three places a customer actually installs:
//
//   1. a STRANGER on a laptop has no runners — they want GitHub-hosted runners on their own account's free minutes;
//   2. a SOLO OPERATOR with a few machines wants the gate on the machines they own, not on a paid minute;
//   3. an ENTERPRISE already has runners registered on their own VMs — installing another is the last thing they want.
//
// So this module DETECTS (git host, OS, architecture, existing CI files, existing runners) and then PLANS one of four
// lanes. It writes files; it never registers a runner, never executes a token, and never prints a credential.
import { existsSync, readFileSync, readdirSync, mkdirSync, writeFileSync, statSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { join, dirname, basename } from "node:path";

// GitHub enforces a MINIMUM runner version to register at all (2.338.2 on 2026-11-03; 2.329.0 failed). A pin below it fails with
// "RUNNER UPDATE REQUIRED" and a 404 that reads like an auth error — that is how this constant was found stale.
export const RUNNER_VERSION = "2.338.2";

const OS_ALIASES = { darwin: "macos", mac: "macos", macos: "macos", win32: "windows", windows: "windows", linux: "linux" };
const ARCH_ALIASES = { x64: "x64", x86_64: "x64", amd64: "x64", arm64: "arm64", aarch64: "arm64" };

export function normalizeOs(v) {
  const k = String(v || "").toLowerCase();
  if (!OS_ALIASES[k]) return null;
  return OS_ALIASES[k];
}
export function normalizeArch(v) {
  const k = String(v || "").toLowerCase();
  if (!ARCH_ALIASES[k]) return null;
  return ARCH_ALIASES[k];
}
export function hostOs() { return normalizeOs(process.platform) || "linux"; }
export function hostArch() { return normalizeArch(process.arch) || "x64"; }

function sh(cmd, args, cwd) {
  try { return { ok: true, out: execFileSync(cmd, args, { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim() }; }
  catch { return { ok: false, out: "" }; }
}

/** Parse `git remote get-url origin` into a host/owner/repo. No network. */
export function parseRemote(url) {
  if (!url) return null;
  let u = String(url).trim();
  let m = u.match(/^https?:\/\/(?:[^@/]+@)?([^/]+)\/(.+?)(?:\.git)?\/?$/);
  if (!m) m = u.match(/^(?:ssh:\/\/)?(?:[^@]+@)?([^/:]+)[:/](.+?)(?:\.git)?\/?$/);
  if (!m) return null;
  const host = m[1].toLowerCase();
  const path = m[2].replace(/\.git$/, "");
  const parts = path.split("/").filter(Boolean);
  if (parts.length < 2) return null;
  return { host, owner: parts[0], repo: parts.slice(1).join("/"), slug: `${parts[0]}/${parts.slice(1).join("/")}` };
}

/** Everything decided from the local machine, read-only. */
export function detectEnv(cwd = process.cwd()) {
  const remote = sh("git", ["remote", "get-url", "origin"], cwd);
  const branch = sh("git", ["rev-parse", "--abbrev-ref", "HEAD"], cwd);
  const parsed = remote.ok ? parseRemote(remote.out) : null;
  const files = {
    githubWorkflows: existsSync(join(cwd, ".github", "workflows")),
    jenkins: existsSync(join(cwd, "Jenkinsfile")),
    gitlab: existsSync(join(cwd, ".gitlab-ci.yml")),
    azure: existsSync(join(cwd, "azure-pipelines.yml")),
    buildkite: existsSync(join(cwd, ".buildkite")),
  };
  const gh = sh("gh", ["auth", "status", "--json", "hosts"], cwd);
  let ghAuthed = false;
  if (gh.ok) {
    try { const j = JSON.parse(gh.out); ghAuthed = Object.values(j.hosts || {}).some((h) => (h.state || "").includes("success")); } catch { /* older gh */ }
  }
  return {
    cwd,
    git: remote.ok,
    remote: parsed,
    branch: branch.ok ? branch.out : null,
    os: hostOs(),
    arch: hostArch(),
    files,
    ghInstalled: sh("gh", ["--version"], cwd).ok,
    ghAuthed,
    node: process.versions.node,
  };
}

/** The one lane that fits. Pure: takes the detected environment, returns a decision with its reason. */
export function decideLane(env, opts = {}) {
  const labels = (opts.existing || []).filter(Boolean);
  if (labels.length) return { lane: "github-existing", reason: `you named existing runner labels (${labels.join(", ")}) — nothing will be installed` };
  if (opts.fleet) return { lane: "github-fleet", reason: "a fleet manifest was given — one matrix job over the machines in it" };
  if (opts.selfHosted) return { lane: "github-self-hosted", reason: "you asked for this machine to run the gate — GitHub-hosted minutes are not used" };
  if (env.files.jenkins && !env.remote) return { lane: "jenkins", reason: "this repo has a Jenkinsfile and no GitHub remote" };
  if (env.files.gitlab && env.remote && env.remote.host.includes("gitlab")) return { lane: "gitlab", reason: "the remote is GitLab" };
  if (env.remote && env.remote.host === "github.com") return { lane: "github-hosted", reason: "GitHub remote and no runner named — the account's own Actions minutes, which are free on public repos" };
  if (env.files.jenkins) return { lane: "jenkins", reason: "a Jenkinsfile is present" };
  if (env.files.gitlab) return { lane: "gitlab", reason: "a .gitlab-ci.yml is present" };
  return { lane: null, reason: "no GitHub remote and no CI file — cannot tell where the gate would run; pass a platform or --existing <labels>" };
}

/** Keep only nodes that have a runner registered under their own label. Pure, so the rule is testable. */
export function filterFleetByRegistered(nodes, registeredLabels) {
  const have = new Set(registeredLabels || []);
  const keep = [], missing = [];
  for (const n of nodes || []) {
    if (have.has(nodeLabel(n.name))) keep.push(n); else missing.push(n.name);
  }
  return { keep, missing };
}

export function nodeLabel(name) {
  return "node-" + String(name || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function labelsFor(os, arch, extra = []) {
  return ["self-hosted", "valiant", os, arch, ...extra].filter(Boolean);
}

/** The install command for the SDK, with a version that CANNOT drift from package.json. */
export function installCommand({ version, tarball, install }) {
  if (install) return install;
  const tgz = tarball || `valiant-verification-sdk-${version}.tgz`;
  return `npm install -g ./${tgz}`;
}

function gateSteps({ lane, licenceSecret = "VALIANT_LICENCE", install, os, selfRepo = false }) {
  // Self-hosted nodes carry their own licence (ESTATE.md: one licence per seat). An empty secret must NOT overwrite it
  // with an empty file — that turns a working node into "could not check" and gets blamed on the product.
  // NODE, NOT SHELL. A Windows runner's default shell is PowerShell 5.1, where `||`, `command -v` and `printf` are
  // parse errors — the first Windows job died on exactly that. Every step below is a node one-liner, which behaves the
  // same in PowerShell and bash.
  const licenceStep = [
    "      - name: Licence (only when this runner has none)",
    "        if: env.VALIANT_LICENCE != ''",
    `        run: node -e "const fs=require('fs'),p=require('path');const d=p.join(process.env.HOME||process.env.USERPROFILE,'.valiant');fs.mkdirSync(d,{recursive:true});fs.writeFileSync(p.join(d,'licence'),process.env.VALIANT_LICENCE||'');"`,
    "        env:",
    `          VALIANT_LICENCE: \${{ secrets.${licenceSecret} }}`,
  ];
  const nodeCheck = lane === "github-hosted"
    ? ["      - uses: actions/setup-node@v4", "        with:", "          node-version: '20'"]
    : ["      # the runner must already have Node >= 18; this fails the job rather than guessing",
       "      - name: Node floor", "        run: |", "          node -e \"process.exit(+process.versions.node.split('.')[0] < 18 ? 2 : 0)\""];
  return [
    "      - uses: actions/checkout@v4",
    "",
    ...nodeCheck,
    "",
    "      # The licensed SDK. A path or a private registry the customer controls — never a public registry.",
    "      # On a self-hosted node that already has it, the install is skipped rather than repeated.",
    "      - name: Install Valiant",
    `        run: ${lane === "github-hosted" ? install : `node -e "const{spawnSync}=require('child_process');if(spawnSync('valiant',['--version'],{stdio:'ignore',shell:true}).status===0){console.log('valiant already present');process.exit(0)}const r=spawnSync('npm',['install','-g','${install.replace(/^npm install -g /, "")}'],{encoding:'utf8',shell:true});process.stdout.write(r.stdout||'');process.stderr.write(r.stderr||'');process.exit(r.status??1)"`}`,
    "",
    ...(lane === "github-hosted" ? licenceStep : licenceStep),
    "",
    // THE REPO THAT SHIPS THE CLI GATES ITS OWN TREE. `valiant gate` resolves the CLI from PATH, so the SDK's own checkout
    // was verified by whatever version was installed globally — on 2026-11-03 that was a build from before the Windows
    // fixes, and four gates failed in CI while the same tree passed when run directly.
    "      # THE EVERYDAY VERDICT. The guards are what catch what they need to catch on a change; this step must be",
    "      # fast enough to run on every push, and it is: 36 gates, no mutation re-runs.",
    `      - name: The gates (everyday)`,
    `        run: ${selfRepo ? "node bin/valiant.mjs verify" : "valiant verify"}`,
    "",
    "      # THE PROOF, WHEN A HUMAN ASKS OR A RELEASE IS CUT. Every published mutation re-executed — the expensive,",
    "      # thorough check that should gate a deploy, not a typo fix. A deadline, because a job that never ends blocks",
    "      # every job behind it (a cancelled run does not always kill the gate a self-hosted runner started; measured:",
    "      # three orphans in one evening, one held a node for an hour), with a hard cap above it as the backstop.",
    "      - name: The proof (pre-deploy)",
    `        if: \${{ github.event_name == 'workflow_dispatch' || startsWith(github.ref, 'refs/tags/v') }}`,
    `        run: ${selfRepo ? "node bin/valiant.mjs gate" : "valiant gate"} --timeout 45`,
    "        timeout-minutes: 60",
  ].join("\n");
}

export function renderWorkflow(plan, { version, tarball, install, ownerRepo, licenceSecret = "VALIANT_LICENCE", fleetNodes = [], labels = [], os = "linux", arch = "x64", selfRepo = false }) {
  const cmd = installCommand({ version, tarball, install });
  const head = [
    `# Valiant — the verdict step. Written by \`valiant ci-init\` for the ${plan.lane} lane.`,
    `# Why this lane: ${plan.reason}`,
    "#",
    "# 0 every contract holds · 1 a contract is broken · 2 a contract could not be checked — all three non-green.",
    "# It never reports success from a step allowed to fail, and it needs no network at verify time.",
    "name: valiant",
    // EVERYDAY IS THE GATES; THE PROOF IS PRE-DEPLOY. A change is judged by the 36 guards on every push (seconds to
    // minutes) and the full mutation proof — 40 full gate runs — only when a human asks for it or a release tag is cut.
    // Measured 2026-11-03: the proof was 30-60 minutes per node, and it ran on every push, twice (push and pull_request).
    "on:",
    "  push:",
    "    branches: [\"**\"]",
    "    tags: [\"v*\"]",
    "  pull_request:",
    "  workflow_dispatch:",
    "",
    "jobs:",
    "  gate:",
  ];
  if (plan.lane === "github-fleet") {
    return [
      ...head,
      "    strategy:",
      "      fail-fast: false",
      "      matrix:",
      "        include:",
      ...fleetNodes.flatMap((n) => [
        `          - name: ${n.name}`,
        `            labels: [${labelsFor(n.os, n.arch, [nodeLabel(n.name), ...(n.labels || [])]).join(", ")}]`,
      ]),
      "    # one job per machine: a red gate on any node fails the workflow, and no node is a hidden fallback",
      "    runs-on: ${{ matrix.labels }}",
      "    steps:",
      gateSteps({ lane: "github-self-hosted", licenceSecret, install: cmd, os, selfRepo }),
      "",
    ].join("\n");
  }
  const runsOn = plan.lane === "github-hosted"
    ? "ubuntu-latest"
    : `[${labels.join(", ")}]`;
  return [
    ...head,
    `    runs-on: ${runsOn}`,
    "    env:",
    `      VALIANT_LICENCE: \${{ secrets.${licenceSecret} }}`,
    "    steps:",
    gateSteps({ lane: plan.lane, licenceSecret, install: cmd, os, selfRepo }),
    "",
  ].join("\n");
}

export function renderGitlab({ version, tarball, install }) {
  const cmd = installCommand({ version, tarball, install });
  return [
    "# Valiant — the verdict job. Written by `valiant ci-init`.",
    "# It sets no allow_failure, so a red gate cannot be a green pipeline; exit 2 fails too.",
    "# Prefer a masked/protected variable for the signed licence file (it is a credential, not a public key).",
    "valiant:",
    "  stage: test",
    "  image: node:20",
    "  variables:",
    "    VALIANT_LICENCE: $VALIANT_LICENCE",
    "  script:",
    `    - ${cmd}`,
    "    - mkdir -p \"$HOME/.valiant\"",
    "    - test -z \"$VALIANT_LICENCE\" || printf '%s' \"$VALIANT_LICENCE\" > \"$HOME/.valiant/licence\"",
    "    - valiant gate",
    "",
  ].join("\n");
}

export function renderJenkins({ version, tarball, install }) {
  const cmd = installCommand({ version, tarball, install });
  return [
    "// Valiant — the verdict stage. Written by `valiant ci-init`.",
    "// No catchError, no returnStatus: a non-zero exit (including 2, could not check) fails the build.",
    "pipeline {",
    "  agent any",
    "  environment {",
    "    VALIANT_LICENCE = credentials('valiant-licence')",
    "  }",
    "  stages {",
    "    stage('valiant gate') {",
    "      steps {",
    `        sh '${cmd}'`,
    "        sh 'test -z \"$VALIANT_LICENCE\" || printf \\'%s\\' \"$VALIANT_LICENCE\" > \"$HOME/.valiant/licence\"'",
    "        sh 'valiant gate'",
    "      }",
    "    }",
    "  }",
    "}",
    "",
  ].join("\n");
}

const RUNNER_ASSET = {
  macos: { arch: { arm64: "osx-arm64", x64: "osx-x64" }, ext: "tar.gz", shell: "sh" },
  linux: { arch: { arm64: "linux-arm64", x64: "linux-x64" }, ext: "tar.gz", shell: "sh" },
  windows: { arch: { arm64: "win-arm64", x64: "win-x64" }, ext: "zip", shell: "ps1" },
};

/** A registration script for THIS machine. It fetches a one-hour registration token with gh at run time; no token is
 *  ever written into the file. */
export function renderRunnerScript({ name, os, arch, ownerRepo, labels }) {
  const meta = RUNNER_ASSET[os] || RUNNER_ASSET.linux;
  const asset = `actions-runner-${meta.arch[arch] || meta.arch.x64}-${RUNNER_VERSION}.${meta.ext}`;
  const url = `https://github.com/actions/runner/releases/download/v${RUNNER_VERSION}/${asset}`;
  const lab = labelsFor(os, arch, labels).join(",");
  if (os === "windows") {
    return [
      `# Register ${name} as a GitHub Actions runner for ${ownerRepo}. Generated by valiant ci-init.`,
      `# Needs: git, node >= 18, an authenticated gh (gh auth login), and admin on the repo.`,
      `$ErrorActionPreference = "Stop"`,
      `$repo = "${ownerRepo}"`,
      `$labels = "${lab}"`,
      `$name = if ($env:RUNNER_NAME) { $env:RUNNER_NAME } else { "${name}" }`,
      `$token = gh api -X POST "repos/$repo/actions/runners/registration-token" --jq .token`,
      `if (-not $token) { throw "no registration token - is gh authenticated with admin on $repo?" }`,
      `$dir = "$env:USERPROFILE\\actions-runner-$name"`,
      `New-Item -ItemType Directory -Force -Path $dir | Out-Null`,
      `Set-Location $dir`,
      `if (-not (Test-Path ".\\config.cmd")) {`,
      `  Invoke-WebRequest -Uri "${url}" -OutFile runner.zip`,
      `  Expand-Archive runner.zip -DestinationPath . -Force`,
      `}`,
      `.\\config.cmd --url "https://github.com/$repo" --token $token --name $name --labels $labels --unattended --replace`,
      `.\\svc.cmd install`,
      `.\\svc.cmd start`,
      "",
    ].join("\n");
  }
  return [
    `#!/usr/bin/env bash`,
    `# Register ${name} as a GitHub Actions runner for ${ownerRepo}. Generated by valiant ci-init.`,
    `# Needs: git, node >= 18, an authenticated gh (gh auth login), and admin on the repo.`,
    `set -euo pipefail`,
    `repo="${ownerRepo}"`,
    `labels="${lab}"`,
    `name="\${RUNNER_NAME:-${name}}"`,
    `token="$(gh api -X POST "repos/$repo/actions/runners/registration-token" --jq .token)"`,
    `[ -n "$token" ] || { echo "no registration token - is gh authenticated with admin on $repo?" >&2; exit 2; }`,
    `dir="$HOME/actions-runner-$name"`,
    `mkdir -p "$dir" && cd "$dir"`,
    `if [ ! -x ./config.sh ]; then curl -fsSL -o runner.tgz "${url}" && tar xzf runner.tgz; fi`,
    `./config.sh --url "https://github.com/$repo" --token "$token" --name "$name" --labels "$labels" --unattended --replace`,
    `# installs a launchd (macOS) or systemd (Linux) service so the runner survives a reboot`,
    `if [ "$(uname -s)" = "Linux" ]; then sudo ./svc.sh install && sudo ./svc.sh start; else ./svc.sh install && ./svc.sh start; fi`,
    `echo "runner '$name' registered with labels: $labels"`,
    "",
  ].join("\n");
}

/** Read harness-mesh node cards (nodes/*.json) into a fleet manifest. The mesh is not required by the product —
 *  this is the adapter that lets an estate that already has machines describe them in one file. */
export function meshToFleet(dir, { exclude = [], roles = null } = {}) {
  if (!existsSync(dir)) throw new Error(`mesh nodes directory not found: ${dir}`);
  const skip = new Set(exclude);
  const nodes = [];
  for (const f of readdirSync(dir)) {
    if (!f.endsWith(".json")) continue;
    let card;
    try { card = JSON.parse(readFileSync(join(dir, f), "utf8")); } catch { continue; }
    const name = card.host || basename(f, ".json");
    if (skip.has(name) || skip.has(f.replace(/\.json$/, ""))) continue;
    if (roles && roles.length && card.role && !roles.includes(card.role)) continue;
    const os = normalizeOs(card.platform);
    const arch = normalizeArch(card.arch);
    if (!os || !arch) continue; // a phone or a registered-but-not-a-computer node is not a CI runner
    nodes.push({ name, os, arch, role: card.role || null });
  }
  return { nodes };
}

/** The account path: create one, connect one, or use a token. Never creates an account (ToS + captcha), never stores. */
export function accountSteps(env, ownerRepo) {
  const out = [];
  if (!env.ghInstalled) {
    out.push({ step: 1, do: "Install the GitHub CLI (or use a token in GH_TOKEN)", url: "https://cli.github.com/" });
  }
  if (!env.ghAuthed) {
    out.push({ step: out.length + 1, do: "Connect your GitHub account (device code, no password typed here)", cmd: "gh auth login --hostname github.com --web --git-protocol ssh" });
    out.push({ step: out.length + 1, do: "No account yet? Create one in the browser, then run the line above", url: "https://github.com/signup" });
  }
  if (ownerRepo && env.ghAuthed) {
    out.push({ step: out.length + 1, do: "Check this account can administer the repo (needed only to REGISTER a self-hosted runner)", cmd: `gh api repos/${ownerRepo} --jq .permissions.admin` });
  }
  out.push({ step: out.length + 1, do: "Free minutes: GitHub-hosted runners are free on public repos; private repos draw on the account's included minutes", url: "https://docs.github.com/en/billing/managing-billing-for-your-products/about-billing-for-github-actions" });
  return out;
}

/** Ask GitHub what runners exist — only when a token can answer. Absence is reported UNVERIFIED, never green. */
export function checkRunners(env, ownerRepo, wanted) {
  if (!ownerRepo) return { verified: false, why: "no GitHub remote" };
  let res;
  try {
    res = execFileSync("gh", ["api", `repos/${ownerRepo}/actions/runners`, "--jq", ".runners[].labels[].name"], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] });
  } catch (e) {
    const msg = String(e.stderr || e.message || "");
    return { verified: false, why: /403|404/.test(msg) ? "this token cannot read the repo's runners (needs admin)" : "gh could not reach the API" };
  }
  const have = new Set(res.split("\n").map((s) => s.trim()).filter(Boolean));
  const missing = wanted.filter((l) => !have.has(l));
  return { verified: true, labels: [...have], missing };
}

/** The plan object is the whole decision, and it is testable without touching disk. */
export function planCi(env, opts = {}) {
  const lane = decideLane(env, opts);
  const os = normalizeOs(opts.os) || env.os;
  const arch = normalizeArch(opts.arch) || env.arch;
  const labels = opts.lane === "github-existing" || (opts.existing && opts.existing.length)
    ? opts.existing
    : labelsFor(os, arch, opts.labels || []);
  const fleet = opts.fleet || null;
  return {
    ...lane,
    os, arch,
    labels,
    ownerRepo: env.remote ? env.remote.slug : null,
    fleet,
    account: accountSteps(env, env.remote ? env.remote.slug : null),
  };
}
