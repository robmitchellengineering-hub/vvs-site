// sops.mjs — the guaranteed baseline, and the customer's own SOPs beside it.
//
// THE MODEL, in one paragraph. An install ships `sops/baseline.json`: our rules, immutable, hash-pinned, each
// one backed by a check the SDK ships so it holds on any machine. The customer then writes `sops/local.json`
// with their own SOPs. A local rule may ADD to the baseline and may carry its own command check; it may never
// override a baseline rule, disable one, or shadow one by id — a conflict is refused with the rule named. A
// local rule with no check is allowed but counted as `accepted-unenforced` on every run, because a rule
// nothing enforces is an opinion and the count is what stops "we adopted the SOPs" from hiding it.
import { createHash, verify as cryptoVerify } from "node:crypto";
import { fileURLToPath } from "node:url";
import { dirname } from "node:path";
import { createRequire } from "node:module";
const require_ = createRequire(import.meta.url);
const require_child = () => require_("node:child_process");
const require_fs = () => require_("node:fs");
const require_path = () => require_("node:path");
const require_os = () => require_("node:os");
import { existsSync, readFileSync, realpathSync, lstatSync, symlinkSync } from "node:fs";
import { sep } from "node:path";
import { join } from "node:path";
import { runCheck } from "./spawn.mjs";

const SOPS = "sops";

export function loadSops(repoRoot, cfg = {}) {
  const pkg = dirname(fileURLToPath(import.meta.url));
  const basePath = join(pkg, "..", "baseline", "baseline.json");
  const sigPath = join(pkg, "..", "baseline", "baseline.sig");
  if (!existsSync(basePath)) return null;
  const baseline = JSON.parse(readFileSync(basePath, "utf8"));
  // The customer's rules come from valiant.json. A legacy `sops/local.json` (installs before this) is still read, so
  // an existing repo keeps working; `valiant sops init` migrates it into the config.
  if (cfg.sopRules !== undefined && !Array.isArray(cfg.sopRules)) {
    // A rule written as a bare object used to vanish, and the gate stayed green with "0 enforced, 0 counted" — the one
    // thing the model says must never happen (independent review #14, F5).
    return { baseline, local: { rules: [] }, basePath, sigPath, repoRoot, legacy: null, invalid: 'valiant.json "sopRules" must be an ARRAY of rules — a single rule object is refused, not silently ignored' };
  }
  let rules = Array.isArray(cfg.sopRules) ? cfg.sopRules : [];
  let legacy = null;
  const legacyPath = join(repoRoot, SOPS, "local.json");
  if (!rules.length && existsSync(legacyPath)) {
    try { rules = JSON.parse(readFileSync(legacyPath, "utf8")).rules ?? []; legacy = legacyPath; }
    catch { /* a broken legacy file is reported by sops check, not by a crash here */ }
  }
  return { baseline, local: { rules }, basePath, sigPath, repoRoot, legacy };
}

/** The baseline is ours. If the bytes changed, that is a finding, not a preference. */
// THE EXPECTED DIGEST LIVES IN CODE, not in a file beside the data. Replacing baseline.json + .sig + .sha256 together
// with an older release's self-consistent triple passed B4, because the pin and the data were both editable
// (independent review #10, F4.1). A constant here can only change by editing the program.
export const BASELINE_SHA = "233be12949a4e905f97a9c0feae366cffe53f3e3b52b9e148392f73d1d27be7b";

export function baselineIntact(sops) {
  // The baseline now ships INSIDE the package and is verified against the public key in the same package. There is no
  // copy in the customer's tree to edit, delete or replay — the checksum-in-the-repo attack (review #6 F3, #5 F8) has
  // nothing to stand on.
  const sigPath = sops.sigPath;
  if (!existsSync(sigPath)) {
    return { ok: false, reason: "the installed baseline is missing its signature — reinstall the SDK" };
  }
  const body = readFileSync(sops.basePath);
  const shipped = join(dirname(fileURLToPath(import.meta.url)), "..", "licence-public.pem");
  if (!existsSync(shipped)) return { ok: false, reason: "the SDK cannot find licence-public.pem, so the baseline cannot be verified" };
  const ok = (() => {
    try { return cryptoVerify(null, body, readFileSync(shipped, "utf8"), Buffer.from(readFileSync(sigPath, "utf8").trim(), "base64")); }
    catch { return false; }
  })();
  const sha = createHash("sha256").update(body).digest("hex");
  // "SIGNED AT SOME POINT" IS NOT "THE BASELINE THIS BUILD INSTALLS". An older signed baseline replayed over a
  // newer one passed B4, so a rule added in a later version could be replayed away (independent review #5, F8).

  // We ship a sha256 as well; if it is present it must agree, or shipping it is decoration.
  if (sha !== BASELINE_SHA) {
    return { ok: false, reason: `the installed baseline is not the one this build ships (${sha.slice(0, 12)} ≠ ${BASELINE_SHA.slice(0, 12)}) — an edit, or an older release's baseline replayed over this one` };
  }
  // THE SIGNATURE RESULT IS THE ANSWER. It was computed and then discarded here, so an edited baseline passed B4.
  if (!ok) return { ok: false, reason: "the baseline's signature does not verify against this SDK's key — baseline.json has been edited" };
  return { ok, sha };
}

/**
 * Conflicts are refusals, not merges. A customer's rule may add; it may not subtract, shadow or weaken.
 * Returns { conflicts: [...], enforced: [...], unenforced: [...] }.
 */
export function resolveRules(sops) {
  const asRules = (x) => (Array.isArray(x) ? x : []);
  const baselineIds = new Set(asRules(sops.baseline.rules).map((r) => r.id));
  const conflicts = [];
  const seen = new Set();
  for (const [i, r] of asRules(sops.local.rules).entries()) {
    const where = `sops/local.json rules[${i}]${r.id ? ` (${r.id})` : ""}`;
    if (!r.id) { conflicts.push({ rule: where, why: "a rule with no id cannot be referenced, counted or audited" }); continue; }
    if (seen.has(r.id)) { conflicts.push({ rule: where, why: `duplicate id "${r.id}"` }); continue; }
    seen.add(r.id);
    if (baselineIds.has(r.id)) { conflicts.push({ rule: where, id: r.id, why: `id "${r.id}" is a baseline rule — a local rule cannot shadow one` }); continue; }
    if (r.disables) { conflicts.push({ rule: where, why: `tries to disable "${r.disables}" — a baseline rule cannot be disabled from below` }); continue; }
    if (r.weakens) { conflicts.push({ rule: where, why: `declares itself a weakening of "${r.weakens}" — that is a conflict, not adoption` }); continue; }
  }
  const enforced = [], unenforced = [];
  for (const r of asRules(sops.local.rules)) {
    if (conflicts.some((c) => c.rule.includes(r.id))) continue;
    const hasCheck = Array.isArray(r.check) && r.check.length > 0;
    // To be ENFORCED a rule must be able to fail: a check plus a declared sabotage the SDK can apply and watch it
    // go red (`{ file, find, replace }`). Without that, it is a claim — counted, never called enforced.
    // SHAPE IS NOT ENFORCEMENT. A rule with `sabotage: {file: "does-not-exist.txt", find: "never"}` was counted as
    // enforced because the keys were present. The sabotage must point at a real file and a string that occurs
    // exactly once, and the check must be shown clean-then-red (applied below, not here).
    const sab = r.sabotage;
    const twoWay = hasCheck && sab && typeof sab.file === "string" && typeof sab.find === "string"
      && !sab.file.replace(/^\.\//, "").startsWith("sops/")
      && !sab.file.includes("..") && existsSync(join(sops.repoRoot, sab.file))
      && (() => {
        // A DIRECTORY (or an unreadable file) used to throw EISDIR straight out of the checker (review #6, F6).
        try {
          const target = join(sops.repoRoot, sab.file);
          if (!lstatSync(target).isFile()) return false;
          return readFileSync(target, "utf8").split(sab.find).length - 1 === 1;
        } catch { return false; }
      })();
    (twoWay ? enforced : unenforced).push(r);
  }
  return { conflicts, enforced, unenforced };
}

/** The SDK's own baseline checks. Each is structural, needs no network, and fails loudly. */
/**
 * A local rule is enforced only if BOTH hold: its check passes on the clean tree, and fails once the rule's own
 * sabotage is applied. Runs in a throwaway copy so the repo is never touched.
 */
export function proveLocalRule(rule, repoRoot) {
  try {
    return proveLocalRuleInner(rule, repoRoot);
  } catch (e) {
    return { ok: false, why: `the rule could not be proven (${e.message})` };
  }
}

function proveLocalRuleInner(rule, repoRoot) {
  const { spawnSync } = require_child();
  const { cpSync, mkdtempSync, rmSync, writeFileSync, readFileSync: rd } = require_fs();
  const { join: j } = require_path();
  const { tmpdir } = require_os();
  // ONE COPY, MUTATED IN PLACE — the shape the mutation engine uses. Two copies anywhere on disk can be compared by
  // the check, and two were: a rule was "enforced" by a check that hashed its tree against a sibling copy and
  // implemented nothing about the rule (independent review #12, F5).
  const tmp = mkdtempSync(j(tmpdir(), "sops-rule-"));
  try { writeFileSync(j(tmp, ".valiant-owner"), String(process.pid)); } catch { /* best effort */ }
  for (const sig of ["SIGINT", "SIGTERM", "SIGHUP"]) process.once(sig, () => { try { rmSync(tmp, { recursive: true, force: true }); } catch { /* best effort */ } process.exit(130); });
  const copy = j(tmp, "repo");
  const run = () => runCheck(rule.check, rule.check.slice(1), { cwd: copy });
  try {
    cpSync(repoRoot, copy, { recursive: true, filter: (p2) => !/[\\/](\.git|node_modules|\.venv|target|dist|build|__pycache__|sops)$/.test(p2) });
    // DEPENDENCIES ARE CLONED, NEVER LINKED: linking let a rule's check write the real node_modules while the rule was
    // certified (F6); and without copy-on-write a real copy is the only honest fallback (F7).
    for (const d of ["node_modules", ".venv"]) {
      const src = j(repoRoot, d);
      if (!existsSync(src) || existsSync(j(copy, d))) continue;
      const cloned = spawnSync("cp", ["-c", "-R", src, j(copy, d)], { encoding: "utf8" });
      if (cloned.status !== 0) {
        const plain = spawnSync("cp", ["-R", src, j(copy, d)], { encoding: "utf8" });
        if (plain.status !== 0) return { ok: false, why: "its dependencies could not be copied into a throwaway tree, so its check cannot run without risking the real ones" };
      }
    }

    const clean = run();
    if (clean.error || clean.status !== 0) {
      return { ok: false, why: `its check does not pass on the unsabotaged copy (${clean.error?.code ?? `exit ${clean.status}`})` };
    }

    const target = j(copy, rule.sabotage.file);
    let real = null;
    try { real = realpathSync(target); } catch { return { ok: false, why: `its sabotage target is not in the copy (${rule.sabotage.file})` }; }
    const root = realpathSync(copy);
    if (!real.startsWith(root + sep)) return { ok: false, why: "its sabotage resolves outside the repo" };
    if (lstatSync(target).isSymbolicLink()) return { ok: false, why: "its sabotage target is a symlink" };
    const original = rd(target);   // BYTES, so a binary subject survives the undo (review #14, F4)
    const findBuf = Buffer.from(rule.sabotage.find, "utf8");
    const at = original.indexOf(findBuf);
    if (at < 0 || original.indexOf(findBuf, at + 1) >= 0) return { ok: false, why: `its sabotage find text does not occur exactly once in ${rule.sabotage.file}` };
    // A FUNCTION REPLACEMENT: `String.replace` expands `$&`/`$$`, so the sabotage applied was not the one declared
    // (review #14, F3).
    writeFileSync(target, Buffer.concat([original.subarray(0, at), Buffer.from(rule.sabotage.replace ?? "", "utf8"), original.subarray(at + findBuf.length)]));
    const trials = 2 + Math.floor(Math.random() * 2);
    for (let t = 0; t < trials; t++) {
      const d = run();
      if (d.error) return { ok: false, why: `its check could not run under the sabotage (${d.error.code ?? d.error.message})` };
      if ((d.status ?? 0) === 0) return { ok: false, why: "STILL PASSES with its sabotage applied — the check cannot detect what the rule claims" };
    }
    writeFileSync(target, original);
    for (let t = 0; t < trials; t++) {
      const r = run();
      if (r.error) return { ok: false, why: `its check could not run after the undo (${r.error.code ?? r.error.message})` };
      if ((r.status ?? 0) !== 0) return { ok: false, why: "its check stayed red after the sabotage was undone (or is not repeatable) — it is not detecting the sabotage" };
    }
    return { ok: true, why: `passes clean, fails ${trials}x under its own sabotage, and passes ${trials}x once it is undone` };
  } finally {
    try { rmSync(tmp, { recursive: true, force: true }); } catch { /* best effort */ }
  }
}

export const BASELINE_CHECKS = {
  "sdk:gates-ran": (ctx) => {
    // B1 used to be green on DECLARED gates: a config whose only gate was `exit 1` passed it. The rule says a
    // verdict is never green without having RUN a check, so it runs them.
    const n = (ctx.cfg?.gates ?? []).length;
    if (!n) return { ok: false, detail: "the config declares no gate, so any verdict would be about nothing" };
    const r = ctx.runGates();
    return r.ok ? { ok: true, detail: `${r.passed}/${r.total} gate(s) ran and passed` } : { ok: false, detail: r.detail };
  },
  "sdk:evidence-subject": (ctx) => {
    const proofs = ctx.proofs ?? [];
    const red = proofs.filter((p) => p.result === "red");
    if (!red.length) return { ok: false, detail: "no red proof is published, so there is no evidence to name anything" };
    // One definition, shared with the external-prover rule — a second copy would drift (it already did).
    const { proofSubject } = ctx.evidence;
    const bogus = red.filter((p) => !proofSubject(ctx.repoRoot, p).ok);
    return bogus.length === 0
      ? { ok: true, detail: `${red.length} proof(s), each naming a file inside this repo` }
      : { ok: false, detail: `${bogus.length} proof(s) name no file inside this repo: ${bogus.slice(0, 3).map((p) => p.guard).join(", ")}` };
  },
  "sdk:guard-twoway": async (ctx) => {
    // A ROW IN A FILE IS NOT A GUARD THAT WENT RED. Two honest kinds of evidence, and the difference matters:
    //   external  — the repo's own runner produced it, so a seeded sample is RE-EXECUTED by this SDK;
    //   first-party — `valiant mutate` produced it in a run whose checks the SDK itself watched go clean then red
    //                 (an always-red check is refused), so the record names a run that happened.
    // Neither is proof against an owner who controls their own checks; both are re-checkable by a reviewer.
    const proofs = (ctx.proofs ?? []).filter((p) => p.result === "red");
    if (!proofs.length) return { ok: false, detail: "no red proof is published, so no guard has been seen to fail" };
    // A proof that carries its own recipe can be re-run by THIS SDK, whichever way it was produced. That is the
    // strongest evidence available, and it is why `prover` no longer decides what counts.
    const withRecipe = proofs.filter((p) => p.file && typeof p.find === "string" && p.replace !== undefined && Array.isArray(p.check) && p.check.length);
    if (withRecipe.length) {
      // THE GATE ALREADY RE-RAN EVERY ONE OF THESE, SECONDS AGO. `gate` proves every guard in its mutate segment and then
      // spawns `sops check`, which used to re-execute a sample of the proofs it had just watched go red — the same work,
      // twice, for a proof produced by this very invocation. When the gate says so (and only then), the record is checked
      // for shape and age rather than re-run: every proof must be red, carry its recipe, and name a file that exists.
      if (ctx.fresh?.proof === true) {
        const bad = withRecipe.filter((p) => !(p.file && ctx.evidence?.proofSubject?.(ctx.repoRoot, p)?.ok !== false));
        if (bad.length) return { ok: false, detail: `${bad.length} proof(s) name no file in this repo` };
        return { ok: true, detail: `${withRecipe.length} proof(s) proved by the mutate segment of this gate run` };
      }
      const ev = await ctx.verifyEvidence();
      return ev.ok ? { ok: true, detail: ev.detail } : { ok: false, detail: ev.reason };
    }
    // No recipe: fall back to the guards this repo DECLARES, which the SDK runs itself.
    const declared = (ctx.cfg?.guards ?? []);
    if (!declared.length) {
      return { ok: false, detail: "no proof carries a re-execution recipe (file, find, replace, check) and no guards are declared, so nothing can be re-run" };
    }
    const run = ctx.runMutations(declared.slice(0, 3));
    const notCaught = run.filter((r) => r.result !== "caught");
    return notCaught.length === 0
      ? { ok: true, detail: `${run.length} declared guard(s) re-run now and each went red` }
      : { ok: false, detail: `${notCaught.length} guard(s) did not go red when re-run: ${notCaught.map((r) => `${r.name} (${r.result})`).join(", ")}` };
  },
  "sdk:baseline-hash": (ctx) => {
    const r = baselineIntact(ctx.sops);
    return r.ok ? { ok: true, detail: `baseline sha256 ${r.sha.slice(0, 12)}` } : { ok: false, detail: r.reason };
  },
  "sdk:unenforced-counted": (ctx) => ({ ok: true, detail: `${ctx.unenforced.length} rule(s) counted but unenforced (no check, or no sabotage) — printed on every run` }),
  "sdk:evidence-written": (ctx) => {
    const p = join(ctx.repoRoot, "mutations.json");
    return existsSync(p) ? { ok: true, detail: "mutations.json is on disk; a stranger can re-check it" } : { ok: false, detail: "no mutations.json — the run left nothing behind" };
  },
};
