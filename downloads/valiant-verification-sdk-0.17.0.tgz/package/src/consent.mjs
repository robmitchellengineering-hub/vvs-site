// consent.mjs — the corpus is collected by DEFAULT, and the payload is metadata only.
//
// Rob, 2026-11-02: "how to get corpus results back from customers i want that to be the default we collect that info thats the
// main part of the product if its a big enterprise deal and they wont let us they can opt out but otherwise collect corpus info
// by default".
//
// WHAT LEAVES A MACHINE, AND WHAT NEVER DOES. A recipe is `{file, find, replace, check}` — that is SOURCE CODE. Nothing here
// sends it. What is sent is the shape of the observation: a hash of the recipe (so the same class of failure is recognisable
// across customers), the verdict, how many times it was seen, the trial count, and a hash of the licence id. That is enough to
// learn "checks of this shape survive sabotage" and not enough to reconstruct anybody's code.
//
// A hash is not nothing — it is a stable fingerprint of a code fragment, and a weak one could be attacked by guessing. So the
// hash is over the recipe's identity, not its text, and the salt is the install id, which never leaves the machine in a form
// that can be joined across customers.
import { createHash, randomUUID } from "node:crypto";
import { readFileSync, writeFileSync, existsSync, mkdirSync, appendFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

const DIR = () => join(process.env.HOME || homedir(), ".valiant");
const CONSENT = () => join(DIR(), "consent.json");
const QUEUE = () => join(DIR(), "corpus-queue.jsonl");
export const MAX_QUEUE = 500;

export function consent({ env = process.env } = {}) {
  if (env.VALIANT_NO_CORPUS === "1") return { enabled: false, why: "VALIANT_NO_CORPUS=1", installId: null };
  let state = null;
  try { state = JSON.parse(readFileSync(CONSENT(), "utf8")); } catch { /* first run */ }
  if (!state) {
    // FIRST RUN: on, and recorded so the choice is visible rather than implied.
    state = { corpus: true, installId: randomUUID(), since: new Date().toISOString(), note: "default: metadata only, never source" };
    try { mkdirSync(DIR(), { recursive: true, mode: 0o700 }); writeFileSync(CONSENT(), `${JSON.stringify(state, null, 2)}\n`, { mode: 0o600 }); } catch { /* read-only home */ }
  }
  if (state.corpus === false) return { enabled: false, why: "opted out on this machine", installId: state.installId };
  return { enabled: true, why: "default", installId: state.installId };
}

/** A repository may opt out on its own — an enterprise deal that will not allow collection says so in its config. */
/** Turn collection back on: the refusal is withdrawn, the install id is kept. */
export function enable() {
  try {
    let state = {};
    try { state = JSON.parse(readFileSync(CONSENT(), "utf8")); } catch { /* first run */ }
    mkdirSync(DIR(), { recursive: true, mode: 0o700 });
    writeFileSync(CONSENT(), `${JSON.stringify({ ...state, corpus: true, installId: state.installId ?? randomUUID(), enabledAt: new Date().toISOString() }, null, 2)}\n`, { mode: 0o600 });
    return { ok: true, path: CONSENT() };
  } catch (e) { return { ok: false, why: `could not write ${CONSENT()} (${e.code ?? e.message})` }; }
}

export function repOptOut(repoRoot) {
  try { return JSON.parse(readFileSync(join(repoRoot, "valiant.json"), "utf8"))?.corpus === false; } catch { return false; }
}

export function optOut({ why = "customer opted out" } = {}) {
  try {
    let state = {};
    try { state = JSON.parse(readFileSync(CONSENT(), "utf8")); } catch { /* first run */ }
    mkdirSync(DIR(), { recursive: true, mode: 0o700 });
    writeFileSync(CONSENT(), `${JSON.stringify({ ...state, corpus: false, installId: state.installId ?? randomUUID(), optedOutAt: new Date().toISOString(), note: why }, null, 2)}\n`, { mode: 0o600 });
    return { ok: true, path: CONSENT() };
  } catch (e) { return { ok: false, why: `could not write ${CONSENT()} (${e.code ?? e.message})` }; }
}

/** The observation: no source, no paths, no hostname. */
export function observationFor(row, { installId }) {
  if (!row || row.kind !== "guard") return null;
  const d = row.diff ?? {};
  const check = Array.isArray(row.check) ? row.check.join("\u0000") : String(row.check ?? "");
  // salted identity: the same recipe from the same install hashes the same; two customers cannot be joined by it.
  const recipe = createHash("sha256").update(`${installId}\u0000${d.file}\u0000${d.find}\u0000${d.replace}\u0000${check}`).digest("hex").slice(0, 32);
  return {
    v: 1,
    recipe,
    verdict: row.verdict ?? "error",
    trials: Number.isInteger(row.trials) ? row.trials : null,
    // the SHAPE of the check, never its text: knowing a check is a shell pipeline is useful and harmless.
    checkKind: Array.isArray(row.check) ? String(row.check[0] ?? "").slice(0, 20) : null,
    repo: row.repo ?? null,
    license: row.license ? createHash("sha256").update(String(row.license)).digest("hex").slice(0, 12) : null,
    at: row.at ?? new Date().toISOString(),
  };
}

export function enqueue(obs) {
  if (!obs) return { queued: false, why: "nothing to record" };
  try {
    mkdirSync(DIR(), { recursive: true, mode: 0o700 });
    let existing = existsSync(QUEUE()) ? readFileSync(QUEUE(), "utf8").split("\n").filter(Boolean) : [];
    let dropped = 0;
    if (existing.length >= MAX_QUEUE) {
      // A FULL QUEUE DROPS THE OLDEST, NEVER THE NEWEST. Refusing new evidence to protect stale evidence is backwards: the recent
      // observation is the one that describes what the tool is doing now.
      dropped = existing.length - Math.floor(MAX_QUEUE * 0.8);
      existing = existing.slice(dropped);
      writeFileSync(QUEUE(), existing.map((l) => l).join("\n") + "\n", { mode: 0o600 });
    }
    appendFileSync(QUEUE(), `${JSON.stringify(obs)}\n`, { mode: 0o600 });
    return { queued: true, depth: existing.length + 1, dropped };
  } catch (e) { return { queued: false, why: `could not queue (${e.code ?? e.message})` }; }
}

export function queueDepth() {
  try { return readFileSync(QUEUE(), "utf8").split("\n").filter(Boolean).length; } catch { return 0; }
}

/** Send what is queued. Best effort by design: a machine offline must still be able to gate. */
// THE COLLECTOR, BY DEFAULT. Without a baked-in URL every customer's observations queue forever and the corpus never grows — which
// is the failure this whole mechanism exists to avoid. Overridable for a self-hosted collector or a test.
export const DEFAULT_COLLECTOR = "https://api.morpheus.nz/api/functions/corpusIngest";

/**
 * Send a small batch in the background, best effort. Called at the end of a gate run so collection happens without anyone
 * remembering — the missing half of "collected by default": a queue nobody drains is a local file, not a corpus.
 */
export async function maybeFlush({ installId, batch = 100, budgetMs = 8000 } = {}) {
  if (process.env.VALIANT_NO_CORPUS === "1") return { ok: true, sent: 0, why: "opted out" };
  if (queueDepth() === 0) return { ok: true, sent: 0, why: "nothing queued" };
  // DRAIN IT, DO NOT POST ONE PAGE AND LEAVE. On 2026-11-01, 421 observations sat in the queue for eleven hours because a single
  // 100-row POST timed out and nothing retried — and a 200-row batch times out consistently against the deployed collector while
  // 20 rows go through. So: keep sending while there is a queue and time left, and when the collector is slow ASK FOR LESS rather
  // than give up. A queue nobody drains is a local file, not a corpus.
  const started = Date.now();
  let sent = 0;
  let size = Math.max(1, Math.min(batch, 100));
  let lastWhy = null;
  while (queueDepth() > 0 && Date.now() - started < budgetMs) {
    const left = budgetMs - (Date.now() - started);
    const r = await flush({ installId, limit: size, timeoutMs: Math.max(1500, Math.min(6000, left)) });
    if (r.sent) { sent += r.sent; lastWhy = null; continue; }
    lastWhy = r.why ?? "send failed";
    if (size <= 10) break;              // small batches failing too: the collector is down, not overloaded
    size = Math.max(10, Math.floor(size / 2));
  }
  const remaining = queueDepth();
  return { ok: lastWhy === null, sent, remaining, ...(lastWhy ? { why: lastWhy } : {}) };
}

export async function flush({ url = process.env.VALIANT_CORPUS_URL || DEFAULT_COLLECTOR, installId, limit = 200, timeoutMs = 4000 } = {}) {
  if (!url) return { ok: false, why: "no VALIANT_CORPUS_URL configured" };
  // NEVER SEND AN ANONYMOUS ROW WHEN WE KNOW WHO WE ARE. A flush called without an install id stored 421 rows with install_id NULL —
  // they arrived and cannot be attributed, which is a corpus that cannot answer "how is this install doing". Fall back to the
  // machine's own consent record instead of trusting every caller to pass it.
  if (!installId) { try { installId = consent().installId ?? null; } catch { /* no consent record: send anonymous rather than nothing */ } }
  let rows = [];
  try { rows = readFileSync(QUEUE(), "utf8").split("\n").filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean); } catch { return { ok: true, sent: 0, note: "nothing queued" }; }
  if (!rows.length) return { ok: true, sent: 0 };
  const batch = rows.slice(0, limit);
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), timeoutMs);
  try {
    const res = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ install: installId ?? null, observations: batch }), signal: ac.signal });
    if (!res.ok) return { ok: false, why: `collector returned HTTP ${res.status}`, kept: batch.length };
    // write back only what did not go
    const rest = rows.slice(batch.length);
    writeFileSync(QUEUE(), rest.map((r) => JSON.stringify(r)).join("\n") + (rest.length ? "\n" : ""), { mode: 0o600 });
    return { ok: true, sent: batch.length, remaining: rest.length };
  } catch (e) {
    return { ok: false, why: `could not reach the collector (${e.name === "AbortError" ? "timed out" : e.message})`, kept: batch.length };
  } finally { clearTimeout(timer); }
}
