// contract.mjs — declare what a successful run must PRODUCE, and check the record against it.
//
// Plan item 4, from chainloop's workflow-contract pattern (Apache-2.0). The gap it names is ours, with a recorded
// incident: V-02 — a job printed "5 of 5 runs failed", exited 0, and was recorded `suspect`. The state machine judged
// the exit code, and nobody had declared what a successful run must produce. A checker was added for the symptom
// (`verify-job-claims`); the cause is that a run had no contract.
//
// Shape in valiant.json:
//   "contract": {
//     "exit": 0,
//     "artifacts": ["dist/report.json"],
//     "assertions": [{ "mustNotMatch": "([0-9]+) of \\1 .*failed", "why": "..." }]
//   }
//
// A record is what a run left behind: { exitCode, stdout, stderr, artifacts: {path: size} } or a mesh result.json.
import { existsSync, statSync } from "node:fs";
import { join } from "node:path";

/** The default contradiction: a run that SAYS it failed and exits 0. This is V-02, and it is a defect, not a suspect. */
const DEFAULT_ASSERTIONS = [
  { mustNotMatch: "\\b([0-9]+) of \\1 (?:runs?|tests?|checks?|jobs?) failed\\b", why: "the output reports failures while the run exited 0" },
  { mustNotMatch: "\\b(fatal|panic|unhandled error|traceback)\\b.*", why: "the output reports a fatal error while the run exited 0" },
];

const matches = (text, pattern) => {
  // `\1` backreferences work in a real RegExp, not in a string — compile it, case-insensitively.
  try { const m = new RegExp(pattern, "i").exec(String(text ?? "")); return m ? m[0] : null; } catch { return null; }
};

export function checkContract(contract, record) {
  if (!contract) return { ok: true, absent: true, findings: [], detail: "no contract declared — a run's success is whatever its exit code says" };
  const findings = [];
  const wantExit = contract.exit ?? 0;
  if (record.exitCode !== wantExit) {
    findings.push({ what: "exit", detail: `the run exited ${record.exitCode}, the contract requires ${wantExit}` });
  }
  const base = record.repoRoot ?? ".";
  for (const a of contract.artifacts ?? []) {
    const p = join(base, a);
    if (!existsSync(p)) { findings.push({ what: "artifact", detail: `the run was to produce ${a} — it does not exist` }); continue; }
    let size = 0;
    try { size = statSync(p).size; } catch { /* unreadable */ }
    if (size === 0) findings.push({ what: "artifact", detail: `${a} exists but is empty — a declared artefact with no content is not evidence` });
  }
  if (Array.isArray(contract.proofs)) {
    for (const pr of contract.proofs) {
      if (!pr?.command) { findings.push({ what: "proof", detail: "a proof in the contract has no command" }); continue; }
      findings.push({ what: "proof", detail: `proof "${pr.command}" is declared but not executed by this checker — declare it as a gate instead` });
    }
  }
  const text = `${record.stdout ?? ""}\n${record.stderr ?? ""}`;
  for (const a of [...DEFAULT_ASSERTIONS, ...(contract.assertions ?? [])]) {
    if (!a?.mustNotMatch) continue;
    const hit = matches(text, a.mustNotMatch);
    if (hit) findings.push({ what: "claim", detail: `${a.why ?? "the output contradicts the exit code"} — matched ${JSON.stringify(hit.slice(0, 80))}` });
  }
  return { ok: findings.length === 0, findings, detail: findings.length === 0 ? "the record matches the contract" : `${findings.length} finding(s)` };
}
