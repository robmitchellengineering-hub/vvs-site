// The Unambiguator (D37) — the mechanical core.
//
// No AI, no dependencies. The whole job is four pure steps:
//   detect → bullets → mechanical rewrite → re-scan → verdict.
//
// Slice 2 (an AI rewrite that GUESSES `resolved_to` so the user only ticks) plugs into
// the same `bullets` shape without changing any of this. The value of the mechanical
// layer is exactly what it can do without a model: it names every dangling referent, and
// it re-checks the rewrite so "unambiguous" is a measured fact, not a sentence.
//
// Clarity and continuity (Rob's words): no dangling "it" / "that" / "bits and bobs".
// Every referent is named, and every resolution is a recorded yes/no verdict (VVS rule 5).

// ── Detection vocabulary ────────────────────────────────────────────────────────────────
// Three classes are reliably mechanical today. "missing-parameter", "contradiction" and
// "two-or-more candidates" (plan rules 4–6) are NOT claimed yet — a detector that guesses
// those is the class of false-positive this feature must not ship. Add them behind their
// own mutation tests, not here.

const PRONOUN_RE = /\b(it|its|this|that|these|those|they|them)\b/gi;
const VAGUE_RE = /\b(stuff|things|something|anything|whatever|bits and bobs|a bit|etc|and so on|sort of|kind of)\b/gi;
// "that part" / "this part" are deliberately absent: the demonstrative "this"/"that" is already
// caught by PRONOUN_RE, so adding the phrase would flag one ambiguity twice. "the bits" carries a
// lookahead so the idiom "bits and bobs" is caught once, by VAGUE_RE, not twice.
const UNNAMED_RE = /\b(the thing|the other bits|the rest|the bits(?!\s+and\s+bobs))\b/gi;

// An antecedent is a noun phrase earlier in the SAME instruction that a pronoun can point at.
// Two signals, both conservative and documented:
//   * a definite noun phrase — "the <word…>" ("the customer list")
//   * a proper noun — a capitalized token ("Pacland", "Morpheus"), but not the first word.
const DEFINITE_RE = /\bthe\s+[a-z][a-z-]*(?:\s+[a-z][a-z-]*){0,3}\b/g;
const PROPER_RE = /\b[A-Z][a-zA-Z]{1,}\b/g;

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function definiteAntecedents(text) {
  return [...text.matchAll(DEFINITE_RE)].map((m) => m.index);
}

function properAntecedents(text) {
  // A capitalized token counts as an antecedent only when it is not the first word —
  // sentence-initial capitals are grammar, not names.
  return [...text.matchAll(PROPER_RE)].map((m) => m.index).filter((i) => i > 0);
}

function hasAntecedentBefore(text, index) {
  if (definiteAntecedents(text).some((i) => i < index)) return true;
  if (properAntecedents(text).some((i) => i < index)) return true;
  return false;
}

/** Find every ambiguity in the text. Stable ids, deduped per referent. */
export function detect(text) {
  const out = [];
  const seen = new Set();
  const push = (referent, kind, question) => {
    const key = `${kind}:${referent.toLowerCase()}`;
    if (seen.has(key)) return;
    seen.add(key);
    out.push({ id: `b${out.length + 1}`, referent, kind, question, resolved_to: null, answer: null, override: null });
  };

  for (const m of text.matchAll(PRONOUN_RE)) {
    const word = m[0];
    // A pronoun whose referent is already named in the instruction is NOT dangling.
    if (!hasAntecedentBefore(text, m.index)) {
      push(word, "dangling-pronoun", `what does "${word}" refer to?`);
    }
  }
  for (const m of text.matchAll(VAGUE_RE)) {
    push(m[0], "vague-quantifier", `"${m[0]}" — specify what, and how much`);
  }
  for (const m of text.matchAll(UNNAMED_RE)) {
    push(m[0], "unnamed-object", `"${m[0]}" — name it`);
  }
  return out;
}

/** The resolution that actually applies for one bullet, honouring the override. */
export function effectiveResolution(b) {
  if (b.answer === true) return b.resolved_to;
  if (b.answer === false) return b.override;
  return null;
}

/** Replace one word, preserving the case of its first letter. */
function replaceWord(text, word, replacement) {
  const re = new RegExp(`\\b${escapeRegex(word)}\\b`, "gi");
  return text.replace(re, (match) => {
    if (match[0] === match[0].toUpperCase() && replacement) {
      return replacement[0].toUpperCase() + replacement.slice(1);
    }
    return replacement;
  });
}

/** Mechanical substitution: every resolved bullet's referent is replaced by its resolution. */
export function rewrite(text, bullets) {
  let out = text;
  for (const b of bullets) {
    const r = effectiveResolution(b);
    if (r == null) continue;
    out = replaceWord(out, b.referent, r);
  }
  return out;
}

/** The one entry point. `bullets` may carry the user's ticks/overrides keyed by id or referent.
 * `aiRewrite` (slice 2) is the fluent rewrite from the one AI call; when present it is used verbatim,
 * and the re-scan still runs over it — so an AI rewrite that left a referent dangling is refused. */
export function disambiguate(text, { bullets = [], aiRewrite = null } = {}) {
  const t = (text ?? "").trim();
  if (t === "") {
    return { input: t, rewrite: t, bullets: [], verdict: "rejected", unresolved: [], detail: "no instruction to disambiguate" };
  }
  const detected = detect(t);
  if (detected.length === 0) {
    return { input: t, rewrite: t, bullets: [], verdict: "unambiguous", unresolved: [], detail: "no ambiguity detected" };
  }
  const merged = detected.map((d) => {
    const matches = bullets.filter((b) =>
      (b.id && b.id === d.id) || (b.referent && b.referent.toLowerCase() === d.referent.toLowerCase())
    );
    // An explicit tick (answer true/false) beats an AI guess (answer null) for the same referent —
    // override-by-default: a "no" tick, or a --resolve, replaces the guess rather than being shadowed by it.
    const u = matches.find((b) => b.answer != null) ?? matches[0];
    return {
      ...d,
      resolved_to: u?.resolved_to ?? null,
      answer: u?.answer ?? null,
      override: u?.override ?? null,
    };
  });
  const rewritten = typeof aiRewrite === "string" && aiRewrite.trim() ? aiRewrite : rewrite(t, merged);
  // THE RE-SCAN. The rewrite must be re-checked, not trusted: a resolution that leaves another
  // dangling referent behind (or is itself empty) must keep the verdict honest.
  const survivors = detect(rewritten);
  const allResolved = merged.every((b) => effectiveResolution(b) != null);
  const verdict = survivors.length === 0 && allResolved ? "unambiguous" : "needs-ticks";
  return {
    input: t,
    rewrite: rewritten,
    bullets: merged,
    verdict,
    unresolved: survivors,
    detail: verdict === "unambiguous"
      ? `${merged.length} ambiguity(ies) resolved, re-scan clean`
      : survivors.length
        ? `${survivors.length} referent(s) still unresolved after the rewrite`
        : `${merged.filter((b) => effectiveResolution(b) == null).length} bullet(s) still unticked`,
  };
}
