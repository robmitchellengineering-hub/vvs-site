// spawn.mjs — running a repo's own check, on any platform.
//
// THE WINDOWS DEFECT THIS EXISTS FOR. On Windows `npm` is `npm.cmd`, and Node's spawnSync cannot execute a `.cmd` without a
// shell: it fails with ENOENT. So `valiant mutate` reported CANNOT-RUN for every `npm run test` check on Windows — the
// proof could not even start — and the tool looked broken on a platform it claims to support.
//
// `shell: true` fixes it and changes quoting rules, so it is used ONLY on Windows, where the alternative is not running the
// command at all. On POSIX nothing changes.
import { spawnSync } from "node:child_process";

const WINDOWS = process.platform === "win32";

/** Quote one argument for cmd.exe. Only used on Windows, where the shell is doing the parsing. */
const quote = (a) => {
  const s = String(a);
  if (s === "") return '""';
  // cmd.exe metacharacters and spaces both need the wrapper; inside it, double quotes are doubled.
  if (!/[\s"&|<>^()]/.test(s)) return s;
  return `"${s.replace(/"/g, '""')}"`;
};

/** spawnSync a check (or a gate) in a repo, on any platform. */
export function runCheck(cmd, args, opts = {}) {
  if (!Array.isArray(cmd) || !cmd.length) return { error: new Error("no command"), status: null };
  const base = { cwd: opts.cwd, encoding: "utf8", timeout: opts.timeout };
  if (!WINDOWS) return spawnSync(cmd[0], args, base);
  const line = [cmd[0], ...args].map(quote).join(" ");
  return spawnSync(line, { ...base, shell: true });
}
