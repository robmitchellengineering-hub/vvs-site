import { spawnSync } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

/**
 * Prove one gate can fail.
 *
 * THE FOUR LEGS, and every one of them is required. An independent review (2026-11-02) found this harness could report "caught" for a gate that was
 * ALREADY RED, a gate whose binary does not exist, and a gate that was killed by the timeout — because `r.status ?? 1` turns "did not run" into
 * "went red", and nothing ever ran the gate before sabotaging it. A proof with no baseline is not a proof.
 *
 *   1. the gate runs GREEN on the untouched tree            — or it is "error", and the sabotage proves nothing
 *   2. the sabotage is applied (exactly one match)          — or it is "stale"
 *   3. the gate goes red, BY EXIT 1 (or a declared expectExit)
 *   4. the file is restored, BYTE FOR BYTE, and the gate runs green again
 */
export function proveGate(gate, repoRoot) {
  const s = gate.sabotage ?? {};
  const file = s.file ?? gate.subject;
  const name = gate.name;
  if (!file || typeof s.find !== "string" || s.replace === undefined || s.find === "") {
    return { name, kind: "gate", result: "unproven", detail: "no sabotage declared, so nothing shows it can fail" };
  }
  const abs = join(repoRoot, file);
  let original;
  try {
    original = readFileSync(abs, "utf8");
  } catch (e) {
    return { name, kind: "gate", result: "error", detail: `${file} could not be read (${e.message})` };
  }
  const hits = original.split(s.find).length - 1;
  if (hits !== 1) {
    return { name, kind: "gate", result: "stale", detail: `the sabotage matches ${file} ${hits} time(s), so it proves nothing about the current file` };
  }

  const runGate = () => spawnSync(gate.cmd[0], gate.cmd.slice(1), { cwd: repoRoot, encoding: "utf8", timeout: 600000 });

  // LEG 1 — THE BASELINE. Without it, a gate that is already red, missing, or hung records "caught" for every sabotage in the catalogue.
  const base = runGate();
  if (base.error || base.signal) {
    return { name, kind: "gate", result: "error", detail: `the gate could not run (${base.error?.message ?? base.signal}), so nothing can be proved about it` };
  }
  if ((base.status ?? 1) !== 0) {
    return { name, kind: "gate", result: "error", detail: `the gate is already red (exit ${base.status}) before any sabotage — fix it first, or the proof is meaningless` };
  }

  let outcome;
  try {
    // LEG 2 — the sabotage
    writeFileSync(abs, original.replace(s.find, s.replace));
    const r = runGate();
    // "DID NOT RUN" IS NOT "WENT RED". A missing binary, a spawn failure or a timeout is an error, not a caught sabotage: r.status is null for all
    // three, and defaulting it to 1 is how a gate whose command does not exist could be "proved" 36 times.
    if (r.error || r.signal) {
      outcome = { name, kind: "gate", result: "error", detail: `the gate did not run under the sabotage (${r.error?.message ?? r.signal})` };
    } else if (r.status === 0) {
      outcome = { name, kind: "gate", result: "survived", detail: `the gate still passed with ${file} sabotaged — it does not protect what it names` };
    } else if (r.status === (gate.expectExit ?? 1)) {
      outcome = { name, kind: "gate", result: "caught", detail: `exit ${r.status} with ${file} sabotaged`, file, find: s.find, replace: s.replace, check: gate.cmd };
    } else {
      // exit 2 is this tool's own "cannot check", and any other code is not the failure the sabotage was meant to produce
      outcome = { name, kind: "gate", result: "error", detail: `the gate exited ${r.status} (not ${gate.expectExit ?? 1}) under the sabotage — that is not the failure it was meant to produce` };
    }
  } catch (e) {
    outcome = { name, kind: "gate", result: "error", detail: `the sabotage could not be applied (${e.message})` };
  } finally {
    // LEG 4 — RESTORE, AND PROVE IT. The old code attempted the write and swallowed any failure, so a half-restored tree looked like a clean one.
    // That is how a sabotage leaked into a commit on 2026-11-02.
    try {
      writeFileSync(abs, original);
      const after = readFileSync(abs, "utf8");
      if (after !== original) outcome = { name, kind: "gate", result: "error", detail: `${file} was NOT restored byte-for-byte — restore it before committing` };
    } catch (e) {
      outcome = { name, kind: "gate", result: "error", detail: `${file} could not be restored (${e.message}) — restore it before committing` };
    }
  }
  return outcome;
}

/**
 * Gates with no sabotage at all — counted, never silently accepted. A sabotage that names no find/replace is not a proof either, so it counts as
 * unproven here: `sabotage: {}` used to satisfy a ceiling of zero while proving nothing (an independent review, 2026-11-02).
 */
export function unprovenGates(cfg) {
  return (cfg?.gates ?? []).filter((g) => !g.sabotage || typeof g.sabotage.find !== "string" || g.sabotage.find === "");
}
