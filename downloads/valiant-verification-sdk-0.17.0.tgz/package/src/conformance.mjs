/**
 * Conformance — grade SOMEONE ELSE'S certificate against the claim format.
 *
 * v2 ("scope and watch"), 2026-10-30. The first version required a **falsifier**. That is a physics-shaped
 * requirement and it does not port to human systems: an organisation can be defeated by an unbounded family
 * of events, so "name the falsifying observation" is either impossible or theatre. The scalable replacement
 * is two fields:
 *
 *   SCOPE — the conditions the claim depends on (finite, enumerable, checkable)
 *   WATCH — the signal that shows a scope condition has moved, who owns it, and how often they look
 *
 * A claim whose failure modes are not enumerable is still conformant, provided its WATCH states a rate.
 * That is the honest position: you cannot be exhaustive in an open system, you can be timely.
 */

export const REQUIRED_GATE_FIELDS = ["name", "result", "evidence", "producer", "scope", "watch", "remedy"];
export const GRADES = ["VERIFIED", "QUALIFIED", "RESTRICTED", "REFUSED"];
const GRADE_RANK = { VERIFIED: 0, QUALIFIED: 1, RESTRICTED: 2, REFUSED: 3 };
const PLACEHOLDER = /^(|n\/?a|none|tbd|todo|-+)$/i;
// a rate is what makes a watch finite in an open system
const RATE = /\b(per|each|every|daily|weekly|monthly|quarterly|annual|annually|hourly|batch|run|shift|release|sample|sampled|continuous|on\s+entry|%)\b/i;
// legacy v1 field, kept only to migrate: a falsifier is a scope condition expressed as a negative
const LEGACY = "falsifier";

function str(v) {
  return typeof v === "string" ? v.trim() : "";
}

/** Read a watch that may be an object {signal, owner, rate} or a single sentence containing a rate. */
export function readWatch(watch) {
  if (watch && typeof watch === "object" && !Array.isArray(watch)) {
    return { signal: str(watch.signal), owner: str(watch.owner), rate: str(watch.rate) };
  }
  const s = str(watch);
  const m = s.match(RATE);
  return { signal: s, owner: "", rate: m ? m[0] : "" };
}

export function checkGate(gate, index) {
  const where = `gate[${index}]${gate && gate.name ? ` (${gate.name})` : ""}`;
  const out = [];
  if (!gate || typeof gate !== "object") return [`${where}: not an object`];

  for (const field of REQUIRED_GATE_FIELDS) {
    if (field === "watch") continue;
    if (PLACEHOLDER.test(str(gate[field]))) out.push(`${where}: missing or placeholder \`${field}\``);
  }

  const watch = readWatch(gate.watch);
  if (PLACEHOLDER.test(watch.signal)) out.push(`${where}: missing \`watch\` — the signal that shows a scope condition moved`);
  if (!watch.rate) {
    out.push(`${where}: \`watch\` has no rate — in an open system you cannot be exhaustive, you can be timely; say how often you look`);
  }
  if (gate.watch && typeof gate.watch === "object" && PLACEHOLDER.test(watch.owner)) {
    out.push(`${where}: \`watch.owner\` is empty — a signal nobody owns is not a watch`);
  }

  if (gate[LEGACY] !== undefined) {
    out.push(`${where}: legacy \`falsifier\` field — express it as \`scope\` (the condition) plus \`watch\` (the signal, owner and rate)`);
  }

  const result = str(gate.result);
  const scope = str(gate.scope);
  if (result && scope && result.toLowerCase() === scope.toLowerCase()) {
    out.push(`${where}: scope repeats the result — a condition cannot be the claim it bounds`);
  }
  if (gate.grade !== undefined && !GRADES.includes(gate.grade)) {
    out.push(`${where}: grade \`${gate.grade}\` is not one of ${GRADES.join(", ")}`);
  }
  return out;
}

/** The overall grade is the WORST gate grade, never an average. */
export function conformance(cert) {
  const findings = [];
  if (!cert || typeof cert !== "object") return { conformant: false, findings: ["certificate is not an object"], grade: "REFUSED" };
  for (const field of ["subject", "sector", "issuer", "issued"]) {
    if (PLACEHOLDER.test(str(cert[field]))) findings.push(`certificate: missing or placeholder \`${field}\``);
  }
  const gates = Array.isArray(cert.gates) ? cert.gates : [];
  if (gates.length === 0) findings.push("certificate: no gates — a certificate with nothing to check certifies nothing");
  gates.forEach((g, i) => findings.push(...checkGate(g, i)));

  const gateGrades = gates.map((g) => g && g.grade).filter((g) => GRADES.includes(g));
  const worst = gateGrades.length ? gateGrades.reduce((a, b) => (GRADE_RANK[a] >= GRADE_RANK[b] ? a : b)) : null;
  if (worst && cert.grade && GRADES.includes(cert.grade) && GRADE_RANK[cert.grade] < GRADE_RANK[worst]) {
    findings.push(`certificate: grade \`${cert.grade}\` is better than its worst gate \`${worst}\` — the grade is the worst finding, not the average`);
  }
  return { conformant: findings.length === 0, findings, grade: findings.length ? "REFUSED" : (worst || "UNGRADED"), gates_checked: gates.length, format: "scope-and-watch@2" };
}

/** A certificate that violates every rule, used to prove the suite can go red. */
export function adversarialCertificate() {
  return {
    subject: "adversarial fixture", sector: "", issuer: "conformance-suite", issued: "2026-10-30", grade: "VERIFIED",
    gates: [
      { name: "scope repeats the result", result: "the number is 0.53", evidence: "a run", producer: "a script", scope: "the number is 0.53", watch: "we would notice", remedy: "" },
      { name: "no watch at all", result: "everything is fine", evidence: "a run", producer: "a script", scope: "as long as nothing changes", watch: "", remedy: "none" },
      { name: "a watch with no rate", result: "a check passed", evidence: "a run", producer: "a script", scope: "same operator", watch: { signal: "drift", owner: "QA", rate: "" }, remedy: "fix it", grade: "REFUSED" },
      { name: "still using the v1 field", result: "legacy", evidence: "a run", producer: "a script", scope: "s", watch: { signal: "x", owner: "y", rate: "monthly" }, remedy: "r", falsifier: "if this fails" },
    ],
  };
}
