// review.mjs — principle 3 with a mechanism instead of a sentence: "the reviewer must not grade its own work".
//
// THE GAP. `tools/release.mjs` refused a release without "an independent review", and decided that by looking for a `## ` heading and the word
// "independent" anywhere in REVIEWS.md. A one-line entry saying "reviewed independently" satisfied it. Of the five principles the product sells, this
// was the only one with nothing behind it — the one place a customer had to believe rather than check.
//
// THE MECHANISM. A review record names BOTH models: the one that wrote the change and the one that reviewed it. The gate refuses a record where they
// match, where the verdict is not `pass`, or where the scope names no commit. That does not prove a different model was used — nothing here can — but
// it makes the claim say what it means, and refuses the specific failure of a worker grading itself.
//
// WHAT IT IS NOT. A signature on a model's identity. An agent that types the wrong name is not caught, exactly as a human who signs a review they did
// not read is not caught. The record makes the claim explicit and re-checkable; it does not make lying impossible, and pretending otherwise would be
// the overstatement this file exists to remove.
import { readFileSync, writeFileSync, existsSync, appendFileSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';

export const REVIEWS = 'REVIEWS.md';

/** Parse every structured review block: `## …` whose body carries the four fields. */
export function parseReviews(text) {
  const out = [];
  for (const block of String(text).split(/^## /m).slice(1)) {
    const field = (name) => {
      const m = new RegExp(`^[-*\\s]*${name}\\s*:\\s*(.+)$`, 'im').exec(block);
      return m ? m[1].trim() : null;
    };
    const heading = block.split('\n')[0].trim();
    out.push({
      heading,
      reviewerModel: field('reviewer-model'),
      authorModel: field('author-model'),
      scope: field('scope'),
      verdict: field('verdict'),
      body: block,
    });
  }
  return out.filter((r) => r.reviewerModel || r.authorModel || r.scope || r.verdict);
}

/**
 * Decide whether a review record may back a release.
 * @returns {{ok: boolean, detail: string, review?: object}}
 */
export function checkReview(repoRoot, { requireScopeInGit = true } = {}) {
  const p = join(repoRoot, REVIEWS);
  if (!existsSync(p)) return { ok: false, detail: `${REVIEWS} is missing — a release with no review is a release nobody tried to break` };
  let text = '';
  try { text = readFileSync(p, 'utf8'); } catch (e) { return { ok: false, detail: `${REVIEWS} could not be read (${e.message})` }; }
  const reviews = parseReviews(text);
  if (!reviews.length) {
    return { ok: false, detail: `no structured review in ${REVIEWS} — a heading and the word "independent" is not a review. Record one: valiant review --record --reviewer <model> --author <model> --scope <commit>` };
  }
  const r = reviews[reviews.length - 1];
  if (!r.reviewerModel) return { ok: false, detail: `${REVIEWS}: the latest review names no reviewer-model` };
  if (!r.authorModel) return { ok: false, detail: `${REVIEWS}: the latest review names no author-model — a reviewer cannot be judged independent of an unnamed author` };
  if (r.reviewerModel.toLowerCase() === r.authorModel.toLowerCase()) {
    return { ok: false, detail: `the review was written by ${r.reviewerModel}, the same model that wrote the change — a worker grading its own work is the failure this principle names` };
  }
  if (!/^pass\b/i.test(r.verdict ?? '')) {
    return { ok: false, detail: `the review verdict is "${r.verdict ?? "missing"}", not pass — a release needs a review that says it looked and found nothing blocking` };
  }
  if (requireScopeInGit) {
    if (!r.scope) return { ok: false, detail: `${REVIEWS}: the review names no scope, so nobody can tell what was reviewed` };
    const isHash = /^[0-9a-f]{7,40}$/i.test(r.scope);
    const git = spawnSync('git', ['-C', repoRoot, 'rev-parse', '--verify', '--quiet', `${r.scope}^{commit}`], { encoding: 'utf8' });
    // A SCOPE THAT NAMES NOTHING REAL IS NOT A SCOPE. An earlier version accepted this and said so in the verdict; the file header and the release
    // gate both claimed it was refused, so the honest fix is to refuse it. An independent review found the contradiction on 2026-11-02.
    if (!isHash) {
      return { ok: false, detail: `the review's scope "${r.scope}" names no commit, so nobody can tell what was reviewed — record it with --scope <commit>` };
    }
    if (isHash && (git.status ?? 1) !== 0) return { ok: false, detail: `the review's scope ${r.scope} is not a commit in this repository` };
    // THE SCOPE MUST BE IN THE RELEASE'S HISTORY, not merely some commit in the repo — a review of an abandoned
    // branch tip must not unlock a pack it never saw (release review NEW-3). It is an ANCESTOR of HEAD, not HEAD
    // itself, because recording the review commits REVIEWS.md and moves HEAD one step past the reviewed commit.
    const anc = spawnSync('git', ['-C', repoRoot, 'merge-base', '--is-ancestor', r.scope, 'HEAD'], { encoding: 'utf8' });
    if (anc.status !== 0) {
      const head = spawnSync('git', ['-C', repoRoot, 'rev-parse', '--short', 'HEAD'], { encoding: 'utf8' }).stdout.trim();
      return { ok: false, detail: `the review's scope ${r.scope} is not an ancestor of HEAD (${head}) — record it against a commit in the release history` };
    }
  }
  return { ok: true, review: r, detail: `${r.reviewerModel} reviewed the work of ${r.authorModel} — different models, verdict ${r.verdict}` };
}

/** Append a structured record. The prose stays above it; the fields are what a gate reads. */
export function recordReview(repoRoot, { reviewerModel, authorModel, scope, verdict = 'pass', notes = '', findings = [] }) {
  if (!reviewerModel || !authorModel) throw new Error('a review records both models: --reviewer <model> and --author <model>');
  if (!scope) throw new Error('a review records what it reviewed: --scope <commit> (a review of "everything" cannot be re-checked later)');
  const when = new Date().toISOString().slice(0, 10);
  const lines = [
    '',
    `## ${when} — review by ${reviewerModel}`,
    '',
    `- reviewer-model: ${reviewerModel}`,
    `- author-model: ${authorModel}`,
    `- scope: ${scope}`,
    `- verdict: ${verdict}`,
    '',
    `Written by a different model than the change, which is the whole of principle 3: a worker may not grade its own work.`,
    '',
  ];
  if (notes) lines.push(notes, '');
  if (findings.length) {
    lines.push('Findings:', '');
    for (const f of findings) lines.push(`- ${f}`);
    lines.push('');
  }
  const p = join(repoRoot, REVIEWS);
  if (!existsSync(p)) writeFileSync(p, '# Reviews\n');
  appendFileSync(p, lines.join('\n'));
  return { ok: true, line: `${reviewerModel} reviewed ${authorModel}` };
}
