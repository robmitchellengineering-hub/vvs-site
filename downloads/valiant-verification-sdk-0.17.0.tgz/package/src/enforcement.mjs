// enforcement.mjs — enforce | warn | observe, and a gate that notices when "warn" has quietly become the new normal.
//
// Plan item 5, borrowed from APort (Apache-2.0): adoption should not need a big-bang flip, so a gate can run in
// `warn` (record what it WOULD have blocked, allow) or `observe` (record, always allow). The failure mode that makes
// this dangerous is the obvious one: a warn mode nobody turns off is a silent disable, and silence is how gating rots.
//
// So the mode is never just an environment variable. The first time a non-enforce mode is used it is stamped, and
// `valiant decisions` reports how long it has been that way — a warn mode older than the configured limit is RED.
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

const DIR = () => join(process.env.HOME || homedir(), ".valiant");
const FILE = () => join(DIR(), "enforcement.json");
const MODES = ["enforce", "warn", "observe"];

export function mode() {
  const m = String(process.env.VALIANT_ENFORCEMENT ?? "enforce").toLowerCase();
  return MODES.includes(m) ? m : "enforce";   // an unknown value must not silently weaken anything
}

/** Stamp the first day a non-enforce mode was used; clear it when enforce comes back. Never throws. */
export function noteMode(m = mode()) {
  try {
    if (m === "enforce") {
      if (existsSync(FILE())) rmSync(FILE(), { force: true });
      return { mode: m, since: null };
    }
    let cur = null;
    try { cur = JSON.parse(readFileSync(FILE(), "utf8")); } catch { /* first use */ }
    if (cur && cur.mode === m && cur.since) return cur;
    const row = { mode: m, since: new Date().toISOString() };
    mkdirSync(DIR(), { recursive: true });
    writeFileSync(FILE(), `${JSON.stringify(row, null, 2)}\n`);
    return row;
  } catch { return { mode: m, since: null }; }
}

/** How long has a non-enforce mode been in force? A warn mode with no end date is a disable nobody decided. */
export function aged(maxDays = 7) {
  let row = null;
  try { row = JSON.parse(readFileSync(FILE(), "utf8")); } catch { return { ok: true, mode: "enforce", days: 0 }; }
  const days = (Date.now() - Date.parse(row.since)) / 86_400_000;
  return { ok: days <= maxDays, mode: row.mode, since: row.since, days: Math.floor(days), maxDays };
}

/** In warn/observe a failing verdict still has to be RECORDED, or the mode becomes "we never looked". */
export const allows = (m = mode()) => m !== "enforce";


// ── THE TOGGLE (Rob, 2026-11-02): "able to be toggled on and off from enforced to advisory"
//
// The modes above are the rollout vocabulary (enforce/warn/observe, set per process by an environment variable, with an ageing
// alarm). The toggle is a STANCE for the machine, set once and read by every installed hook without reinstalling it:
//
//   enforced → the gate's exit code blocks the agent
//   advisory  → the gate runs and speaks, and nothing is blocked
//
// They are not two systems: `advisory` is this machine's default for `warn`, and an explicit VALIANT_ENFORCEMENT still wins, so
// a CI job can force enforcement over a developer's advisory stance.
const STANCE = ["enforced", "advisory"];
const STANCE_FILE = () => join(process.env.HOME || homedir(), ".valiant", "stance.json");

/** The machine's stance: "enforced" unless someone turned it down. */
export function readStance() {
  try {
    const s = JSON.parse(readFileSync(STANCE_FILE(), "utf8"));
    return STANCE.includes(s.stance) ? s.stance : "enforced";
  } catch { return "enforced"; }
}

export function writeStance(stance, { why = null } = {}) {
  if (!STANCE.includes(stance)) return { ok: false, why: `stance must be one of ${STANCE.join(", ")}` };
  try {
    mkdirSync(DIR(), { recursive: true, mode: 0o700 });
    writeFileSync(STANCE_FILE(), `${JSON.stringify({ stance, setAt: new Date().toISOString(), why }, null, 2)}\n`, { mode: 0o600 });
    return { ok: true, stance, path: STANCE_FILE() };
  } catch (e) { return { ok: false, why: `could not write ${STANCE_FILE()} (${e.code ?? e.message})` }; }
}

/** A repository may opt out of blocking without changing the machine. */
export function repoStance(repoRoot) {
  try {
    const m = JSON.parse(readFileSync(join(repoRoot, "valiant.json"), "utf8"))?.enforcement?.stance;
    return STANCE.includes(m) ? m : null;
  } catch { return null; }
}

/**
 * What a hook should do HERE, right now: an explicit VALIANT_ENFORCEMENT beats the repo, which beats the machine.
 */
export function effectiveStance(repoRoot, { env = process.env } = {}) {
  const forced = String(env.VALIANT_ENFORCEMENT ?? "").toLowerCase();
  if (forced === "enforce") return { stance: "enforced", source: "VALIANT_ENFORCEMENT" };
  if (forced === "warn" || forced === "observe") return { stance: "advisory", source: "VALIANT_ENFORCEMENT" };
  const repo = repoRoot ? repoStance(repoRoot) : null;
  if (repo) return { stance: repo, source: "valiant.json" };
  return { stance: readStance(), source: STANCE_FILE() };
}
