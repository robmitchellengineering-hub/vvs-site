// ui.mjs — the VVS SDK control panel: a local, zero-dependency dashboard.
//
// `valiant ui` serves this on localhost. It mirrors, exactly, the surface an agent has over MCP:
//   run   → gate / verify / ledger / outcomes / licence
//   toggle→ enforcement mode (enforce / advisory / off)
//
// The readout DRIVES the run: `verify` streams each gate as it lands, so a gate is something you
// watch tick green or red, not a terminal line you read after it is over. No framework, no
// dependency, no network — Node's own `http` module and one inline page.
import { createServer } from "node:http";
import { readFileSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { homedir } from "node:os";
import { fileURLToPath } from "node:url";
import { spawn, spawnSync } from "node:child_process";
import { disambiguate } from "./disambiguate.mjs";

// ---------------------------------------------------------------------------
// the dashboard (one inline page — brand colours, a live "scope", run + toggle)
// ---------------------------------------------------------------------------
const DASHBOARD = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>VVS SDK — control panel</title>
<style>
  :root{--navy:#142e53;--navy2:#1c4a74;--teal:#1a9d8f;--teal2:#2fb8a6;--ink:#14212e;--muted:#5b6b7a;--line:#dde7ee;--bg:#f5f8fa;--card:#ffffff;--good:#2fb8a6;--bad:#e05656;--warn:#e0a13e;}
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;min-height:100vh}
  header{display:flex;align-items:center;gap:14px;padding:16px 26px;background:var(--card);border-bottom:1px solid var(--line);position:sticky;top:0}
  header img.badge{height:38px;width:auto}
  .brand{font-weight:800;letter-spacing:.08em;color:var(--navy);font-size:15px}
  .brand small{display:block;font-weight:600;letter-spacing:.04em;color:var(--muted);font-size:11px;margin-top:2px}
  main{max-width:980px;margin:0 auto;padding:26px}
  .row{display:flex;gap:18px;flex-wrap:wrap;align-items:stretch}
  .card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px 20px;flex:1;min-width:260px;box-shadow:0 1px 3px rgba(14,40,70,.05)}
  .card h2{font-size:12px;letter-spacing:.18em;text-transform:uppercase;color:var(--teal);margin:0 0 12px;font-weight:800}
  .scope{background:#0b1626;border:1px solid #1c3350;border-radius:14px;padding:16px 18px;margin-top:18px;min-height:320px;position:relative;overflow:hidden;font-family:"SF Mono",Consolas,Menlo,monospace;color:#d6e2ee}
  .scope .head{display:flex;justify-content:space-between;align-items:center;color:#8ba3bc;font-size:12px;margin-bottom:12px}
  .pulse{display:inline-block;width:9px;height:9px;border-radius:50%;background:var(--warn);margin-right:7px;vertical-align:middle}
  .pulse.live{background:var(--teal2);animation:blink 1s infinite}
  @keyframes blink{0%,100%{opacity:1}50%{opacity:.25}}
  .gate{display:flex;align-items:center;gap:10px;padding:7px 8px;border-bottom:1px solid #13253a;animation:fade .25s ease;font-size:13px;color:#d6e2ee}
  @keyframes fade{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}
  .gate .n{color:#4a6480;min-width:24px;text-align:right;font-size:11px}
  .gate .name{flex:1;color:#d6e2ee}
  .gate .st{font-weight:700;font-size:11px;letter-spacing:.06em}
  .gate.ok .st{color:var(--good)}
  .gate.bad .st{color:var(--bad)}
  .gate.warn .st{color:var(--warn)}
  .verdict{display:flex;align-items:center;gap:14px;margin-top:14px;padding-top:14px;border-top:1px solid #1c3350}
  .stamp{font-size:20px;font-weight:800;letter-spacing:.08em;padding:6px 16px;border-radius:8px}
  .stamp.pass{color:#04231d;background:var(--good)}
  .stamp.fail{color:#2a0a0a;background:var(--bad)}
  .stamp.warn{color:#2a1c04;background:var(--warn)}
  .btn{border:none;border-radius:9px;padding:10px 16px;font-weight:700;font-size:14px;cursor:pointer;background:var(--navy);color:#fff;border:1px solid var(--navy)}
  .btn:hover{opacity:.92}
  .btn.primary{background:var(--teal);border-color:var(--teal);color:#fff}
  .btn.primary:disabled{opacity:.5;cursor:default}
  .seg{display:inline-flex;border:1px solid var(--line);border-radius:9px;overflow:hidden}
  .seg button{background:transparent;border:none;color:var(--muted);padding:8px 14px;font-weight:600;font-size:13px;cursor:pointer}
  .seg button.on{background:var(--teal);color:#fff}
  .kv{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--line);font-size:13px}
  .kv b{color:var(--muted);font-weight:600}
  a{color:var(--teal)}
</style>
</head>
<body>
<header>
  <img class="badge" src="/badge.png" alt="Valiant Verification Systems">
  <div class="brand">VALIANT VERIFICATION SYSTEMS <small>SDK — control panel</small></div>
</header>
<main>
  <div class="row">
    <div class="card">
      <h2>Run</h2>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn primary" data-run="verify">Run verify</button>
        <button class="btn" data-run="gate">Gate</button>
        <button class="btn" data-run="ledger">Ledger</button>
        <button class="btn" data-run="outcomes">Outcomes</button>
      </div>
    </div>
    <div class="card">
      <h2>Enforcement</h2>
      <div class="seg" id="mode">
        <button data-mode="enforced">enforced</button>
        <button data-mode="advisory">advisory</button>
      </div>
      <p style="color:#8ba3bc;font-size:12px;margin:10px 0 0">What the hooks do when an agent tries to finish: block it, or warn and let it through.</p>
    </div>
    <div class="card">
      <h2>Licence</h2>
      <div id="licence" style="font-size:13px">…</div>
      <div id="licence-cta" style="margin-top:10px;display:none">
        <a class="btn primary" href="https://morpheus.nz/licences" target="_blank" rel="noopener" style="padding:7px 12px;font-size:12px;display:inline-block;text-decoration:none">Get the 14-day trial</a>
        <input id="licence-token" placeholder="paste the token (vvs1.…)" style="width:100%;margin-top:8px;background:var(--card);border:1px solid var(--line);border-radius:8px;color:var(--ink);padding:8px;font:inherit;font-size:13px">
        <button class="btn" id="licence-activate" style="margin-top:8px;padding:7px 12px;font-size:12px">Activate</button>
      </div>
    </div>
    <div class="card">
      <h2>First run — add a repository</h2>
      <p style="color:#8ba3bc;font-size:12px;margin:0 0 10px">Point the SDK at a project. It writes one file (valiant.json), proposes a guard, proves it can fail, and runs the gate.</p>
      <input id="setup-dir" placeholder="/path/to/your/project" style="width:100%;background:var(--card);border:1px solid var(--line);border-radius:8px;color:var(--ink);padding:8px;font:inherit;font-size:13px">
      <button class="btn primary" id="setup-run" style="margin-top:8px">Run setup</button>
      <div id="setup-result" style="margin-top:10px;font-size:13px"></div>
    </div>
  </div>

  <div class="card" style="margin-top:18px;flex:1 0 100%">
    <h2>Unambiguator</h2>
    <p style="color:#8ba3bc;font-size:12px;margin:0 0 10px">Paste an instruction. Every dangling "it / that / those" is named with a question — tick each resolution and watch the rewrite sharpen.</p>
    <textarea id="amb-text" rows="3" style="width:100%;background:var(--card);border:1px solid var(--line);border-radius:9px;color:var(--ink);padding:10px;font:inherit;font-size:13px">It said it works, and that needs review.</textarea>
    <button class="btn primary" id="amb-run" style="margin-top:10px">Disambiguate</button>
    <div id="amb-result" style="margin-top:14px"></div>
  </div>

  <div class="card" style="margin-top:18px;flex:1 0 100%">
    <h2>AI Control</h2>
    <p style="color:#8ba3bc;font-size:12px;margin:0 0 10px">Every action the agent takes is logged here. Tick yes/no — the number is the verdict (0 under control · 1 a control broke · 2 could not check).</p>
    <div id="ctl-summary" style="font-size:15px;margin-bottom:10px">…</div>
    <div id="ctl-actions" style="max-height:280px;overflow:auto"></div>
  </div>

  <div class="scope" id="scope">
    <div class="head"><span><span class="pulse" id="pulse"></span><span id="status">idle</span></span><span id="count"></span></div>
    <div id="gates"></div>
    <div class="verdict" id="verdict" style="display:none"><span class="stamp" id="stamp"></span><span id="verdicttext" style="color:#9fb4ca;font-size:13px"></span></div>
  </div>
</main>
<script>
const $ = (s) => document.querySelector(s);
let mode = "off";

async function loadState(){
  const r = await fetch("/api/state").then(r=>r.json());
  mode = r.stance;
  for(const b of document.querySelectorAll("#mode button")){
    b.classList.toggle("on", b.dataset.mode === r.stance);
  }
  const l = r.licence;
  $("#licence").innerHTML = l.ok
    ? '<div class="kv"><b>status</b><span style="color:var(--good)">OK</span></div>' +
      '<div class="kv"><b>plan</b><span>'+(l.plan||"—")+'</span></div>' +
      '<div class="kv"><b>seats</b><span>'+(l.seats===0?"unlimited":l.seats)+'</span></div>' +
      '<div class="kv"><b>expires</b><span>'+(l.expires||"—")+'</span></div>'
    : '<div class="kv"><b>status</b><span style="color:var(--warn)">'+(l.reason||"no licence")+'</span></div>';
  const cta = document.getElementById("licence-cta");
  if (cta) cta.style.display = l.ok ? "none" : "block";
}
async function activateLicence(){
  const token = document.getElementById("licence-token").value.trim();
  if(!token) return;
  const r = await fetch("/api/licence/activate", {method:"POST", headers:{"content-type":"application/json"}, body:JSON.stringify({token})}).then(r=>r.json());
  if(r.ok){ document.getElementById("licence-token").value=""; loadState(); }
  else alert("licence not accepted: " + (r.why||"unknown"));
}
async function runSetup(){
  const dir = document.getElementById("setup-dir").value.trim();
  const el = document.getElementById("setup-result");
  el.innerHTML = '<span style="color:var(--warn)">running setup…</span>';
  const r = await fetch("/api/setup", {method:"POST", headers:{"content-type":"application/json"}, body:JSON.stringify({dir})}).then(r=>r.json());
  el.innerHTML = r.ok
    ? '<span style="color:var(--good)">setup ran — verification + enforcement are ON (push gate + agent gate installed)</span>'
    : '<span style="color:var(--bad)">' + (r.why||"setup failed") + '</span>';
}
document.getElementById("licence-activate").onclick = activateLicence;
document.getElementById("setup-run").onclick = runSetup;
async function setMode(m){
  await fetch("/api/toggle", {method:"POST", headers:{"content-type":"application/json"}, body:JSON.stringify({stance:m})});
  mode = m;
  for(const b of document.querySelectorAll("#mode button")) b.classList.toggle("on", b.dataset.mode === m);
}
document.querySelectorAll("#mode button").forEach(b=>b.onclick=()=>setMode(b.dataset.mode));

function clearScope(){
  $("#gates").innerHTML = ""; $("#verdict").style.display = "none"; $("#count").textContent = "";
}
async function run(tool){
  clearScope();
  $("#status").textContent = "running " + tool + "…"; $("#pulse").classList.add("live");
  document.querySelectorAll("[data-run]").forEach(b=>b.disabled = true);
  const es = new EventSource("/api/run?tool=" + tool);
  let n = 0;
  es.addEventListener("gate", (e)=>{
    const g = JSON.parse(e.data); n++;
    const el = document.createElement("div");
    el.className = "gate " + (g.ok ? "ok" : (g.cannotCheck ? "warn" : "bad"));
    const st = g.ok ? "PASS" : (g.cannotCheck ? "CANT" : "FAIL");
    el.innerHTML = '<span class="n">'+n+'</span><span class="name">'+g.name+'</span><span class="st">'+st+'</span>';
    $("#gates").appendChild(el);
    $("#count").textContent = n + " gate" + (n===1?"":"s");
    el.scrollIntoView({behavior:"smooth", block:"nearest"});
  });
  es.addEventListener("done", (e)=>{
    const d = JSON.parse(e.data);
    es.close();
    $("#pulse").classList.remove("live");
    $("#status").textContent = d.ok ? "done" : "done — see red below";
    $("#count").textContent = d.pass + " / " + d.total + " passed";
    $("#verdict").style.display = "flex";
    const stamp = $("#stamp");
    stamp.className = "stamp " + (d.ok ? "pass" : (d.exit===2 ? "warn" : "fail"));
    stamp.textContent = d.ok ? "VERIFIED" : (d.exit===2 ? "COULD NOT CHECK" : "FAILED");
    $("#verdicttext").textContent = d.summary || "";
    document.querySelectorAll("[data-run]").forEach(b=>b.disabled = false);
  });
  es.onerror = ()=>{ es.close(); $("#pulse").classList.remove("live"); $("#status").textContent = "stream ended";
    document.querySelectorAll("[data-run]").forEach(b=>b.disabled = false); };
}
document.querySelectorAll("[data-run]").forEach(b=>b.onclick=()=>run(b.dataset.run));
function esc(s){ return String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
let amb = { text: "", bullets: [] };
async function ambRun(){
  amb = { text: $("#amb-text").value, bullets: [] };
  const r = await fetch("/api/disambiguate", {method:"POST", headers:{"content-type":"application/json"}, body:JSON.stringify({text: amb.text})}).then(r=>r.json());
  amb.bullets = r.bullets;
  ambRender(r);
}
function ambRender(r){
  let html = "";
  if (!r.bullets.length) html = '<div style="color:var(--good)">nothing ambiguous — ' + esc(r.detail) + '</div>';
  else r.bullets.forEach((b,i)=>{
    html += '<div class="gate" style="align-items:flex-start">' +
      '<input type="checkbox" data-amb="'+i+'" '+(b.answer===true?"checked":"")+' style="margin-top:3px">' +
      '<div style="flex:1"><b>'+esc(b.referent)+'</b> <span style="color:#4a6480;font-size:11px">('+esc(b.kind)+')</span><br><span style="color:#8ba3bc;font-size:12px">'+esc(b.question)+'</span></div>' +
      '<input type="text" data-ambtxt="'+i+'" value="'+esc(b.resolved_to||b.override||"")+'" placeholder="replace with…" style="background:#0a1522;border:1px solid #23456a;border-radius:6px;color:#d6e2ee;padding:4px 8px;width:170px;font-size:12px">' +
      '</div>';
  });
  html += '<div style="margin-top:12px;color:#d6e2ee;font-size:14px"><b>rewrite:</b> <span style="color:#fff">'+esc(r.rewrite)+'</span></div>' +
    '<div style="margin-top:6px;color:#9fb4ca;font-size:12px">verdict: <b style="color:'+(r.verdict==="unambiguous"?"var(--good)":"var(--warn)")+'">'+esc(r.verdict)+'</b></div>';
  $("#amb-result").innerHTML = '<div style="background:#0b1626;border:1px solid #1c3350;border-radius:12px;padding:14px;color:#d6e2ee">' + html + '</div>';
  document.querySelectorAll("[data-amb]").forEach(cb=>cb.onchange=ambTick);
  document.querySelectorAll("[data-ambtxt]").forEach(inp=>inp.oninput=ambTick);
}
async function ambTick(){
  const bullets = [];
  document.querySelectorAll("#amb-result .gate").forEach((row,i)=>{
    const cb = row.querySelector("[data-amb]"); const tx = row.querySelector("[data-ambtxt]");
    bullets.push({ id: amb.bullets[i]?.id, referent: amb.bullets[i]?.referent, answer: cb.checked, resolved_to: tx.value.trim() || null });
  });
  const r = await fetch("/api/disambiguate", {method:"POST", headers:{"content-type":"application/json"}, body:JSON.stringify({text: amb.text, bullets})}).then(r=>r.json());
  ambRender(r);
}
$("#amb-run").onclick = ambRun;
async function ctlLoad(){ ctlRender(await fetch("/api/control").then(r=>r.json())); }
function ctlRender(r){
  const col = r.number === 0 ? "var(--good)" : r.number === 1 ? "var(--bad)" : "var(--warn)";
  $("#ctl-summary").innerHTML = '<b style="color:'+col+';font-size:22px">'+r.number+'</b> <span style="color:var(--muted);font-size:13px">'+esc(r.summary)+'</span>';
  let html = "";
  (r.actions||[]).forEach(a=>{
    const st = a.approved === true ? "✓" : a.approved === false ? "✗" : "…";
    const c = a.approved === true ? "var(--good)" : a.approved === false ? "var(--bad)" : "var(--warn)";
    html += '<div class="gate" style="align-items:center">' +
      '<span class="st" style="color:'+c+';min-width:18px;font-size:15px">'+st+'</span>' +
      '<span class="name" style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(a.action)+'</span>' +
      '<button class="btn" data-ctl-yes="'+a.line+'" style="padding:4px 10px;font-size:12px">yes</button>' +
      '<button class="btn" data-ctl-no="'+a.line+'" style="padding:4px 10px;font-size:12px">no</button>' +
      '</div>';
  });
  if (!(r.actions||[]).length) html = '<div style="color:var(--muted);font-size:13px">no actions recorded yet — the ledger is empty</div>';
  $("#ctl-actions").innerHTML = html;
  document.querySelectorAll("[data-ctl-yes]").forEach(b=>b.onclick=()=>ctlTick(b.dataset.ctlYes, true));
  document.querySelectorAll("[data-ctl-no]").forEach(b=>b.onclick=()=>ctlTick(b.dataset.ctlNo, false));
}
async function ctlTick(line, approve){
  ctlRender(await fetch("/api/control/tick", {method:"POST", headers:{"content-type":"application/json"}, body:JSON.stringify({line:Number(line), approve})}).then(r=>r.json()));
}
ctlLoad();
loadState();
// ?run=verify (or gate/ledger/outcomes) auto-triggers a run on load, so the readout is alive immediately.
const _q = new URLSearchParams(location.search).get("run");
if (_q) run(_q);
</script>
</body>
</html>`;

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------
function json(res, code, obj) { res.writeHead(code, { "content-type": "application/json" }); res.end(JSON.stringify(obj)); }

/** licence status, offline — same shape the dashboard renders. */
async function licenceState() {
  const { verifyLicence, describeLicence } = await import("./licence.mjs");
  const p = join(process.env.HOME || homedir(), ".valiant", "licence");
  if (!existsSync(p)) return { ok: false, reason: "no licence on this machine" };
  // Resolve the public key the same way the licence command does: the shipped licence-public.pem, then an explicit env override.
  const pub = join(dirname(fileURLToPath(import.meta.url)), "..", "licence-public.pem");
  const publicKeyPem = (existsSync(pub) ? readFileSync(pub, "utf8").trim() : "") || (process.env.VALIANT_LICENCE_KEY || "").trim();
  if (!publicKeyPem) return { ok: false, reason: "no licence public key to verify against" };
  const v = verifyLicence(readFileSync(p, "utf8").trim(), { publicKeyPem });
  if (!v.ok) return { ok: false, reason: v.reason };
  const d = describeLicence(v.claims);
  return { ok: true, plan: d.plan ?? v.claims.plan, seats: v.claims.seats, expires: new Date(v.claims.exp * 1000).toISOString().slice(0, 10) };
}

// ---------------------------------------------------------------------------
// the run — stream each gate as it lands (the "alive" readout)
// ---------------------------------------------------------------------------
async function runGatesStreaming(res, { tool }) {
  const { loadConfig } = await import("./config.mjs");
  const { runGate } = await import("./gates.mjs");
  const repoRoot = process.cwd();

  res.writeHead(200, {
    "content-type": "text/event-stream",
    "cache-control": "no-cache",
    connection: "keep-alive",
  });
  const emit = (event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  let gates = [];
  let exit = 0;
  let summary = "";

  if (tool === "verify" || tool === "gate") {
    let cfg;
    try { cfg = loadConfig(join(repoRoot, "valiant.json")); }
    catch (e) { emit("done", { ok: false, exit: 2, pass: 0, total: 0, summary: e.message }); return res.end(); }
    gates = cfg.gates ?? [];
  } else if (tool === "ledger") {
    const { runLedger } = await import("./ledger.mjs").catch(() => ({}));
    emit("gate", { name: "ledger", ok: runLedger ? true : false, cannotCheck: !runLedger, detail: "" });
    emit("done", { ok: !!runLedger, exit: runLedger ? 0 : 2, pass: runLedger ? 1 : 0, total: 1, summary: "ledger" });
    return res.end();
  } else if (tool === "outcomes") {
    const p = join(repoRoot, "mutations.json");
    let n = 0;
    if (existsSync(p)) { try { n = (JSON.parse(readFileSync(p, "utf8")).proofs ?? []).length; } catch {} }
    emit("gate", { name: "outcomes", ok: true, detail: "" });
    emit("done", { ok: true, exit: 0, pass: 1, total: 1, summary: `${n} recorded proof(s) in mutations.json` });
    return res.end();
  } else {
    emit("done", { ok: false, exit: 2, pass: 0, total: 0, summary: `unknown tool ${tool}` });
    return res.end();
  }

  let pass = 0, bad = 0;
  for (let i = 0; i < gates.length; i++) {
    const r = runGate(gates[i], repoRoot);
    if (r.ok) pass++; else { bad++; if (r.cannotCheck) exit = 2; else if (exit === 0) exit = 1; }
    emit("gate", { name: r.name, ok: r.ok, cannotCheck: !!r.cannotCheck, detail: r.detail });
    await sleep(25); // let the ticking read as a run, not a paste
  }
  if (exit === 0) exit = bad === 0 ? 0 : 1;
  summary = tool === "gate" ? `${pass}/${gates.length} gates hold` : `${pass}/${gates.length} gates passed`;
  emit("done", { ok: exit === 0, exit, pass, total: gates.length, summary });
  res.end();
}

// ---------------------------------------------------------------------------
// server
// ---------------------------------------------------------------------------
export function serve({ port = 8787 } = {}) {
  const server = createServer(async (req, res) => {
    const url = new URL(req.url, "http://localhost");
    if (req.method === "GET" && url.pathname === "/") {
      res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
      return res.end(DASHBOARD);
    }
    if (req.method === "GET" && url.pathname === "/badge.png") {
      try {
        const png = readFileSync(join(dirname(fileURLToPath(import.meta.url)), "..", "badge.png"));
        res.writeHead(200, { "content-type": "image/png", "cache-control": "max-age=3600" });
        return res.end(png);
      } catch { res.writeHead(404); return res.end(); }
    }
    if (req.method === "GET" && url.pathname === "/api/state") {
      const { readStance } = await import("./enforcement.mjs");
      const licence = await licenceState();
      return json(res, 200, { stance: readStance(), licence });
    }
    if (req.method === "POST" && url.pathname === "/api/toggle") {
      let body = ""; req.on("data", (c) => (body += c)); req.on("end", async () => {
        try {
          const { stance } = JSON.parse(body);
          const { writeStance } = await import("./enforcement.mjs");
          const r = writeStance(stance);
          return json(res, r.ok ? 200 : 400, r);
        } catch { return json(res, 400, { ok: false }); }
      });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/licence/activate") {
      let body = ""; req.on("data", (c) => (body += c)); req.on("end", () => {
        try {
          const { token } = JSON.parse(body);
          if (!token) return json(res, 400, { ok: false, why: "no token pasted" });
          const r = spawnSync("valiant", ["licence", token], { encoding: "utf8", timeout: 20000 });
          if (r.status !== 0) return json(res, 400, { ok: false, why: (r.stderr || r.stdout || "licence activation failed").trim() });
          return json(res, 200, { ok: true, msg: (r.stdout || "").trim() });
        } catch (e) { return json(res, 400, { ok: false, why: e.message }); }
      });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/setup") {
      let body = ""; req.on("data", (c) => (body += c)); req.on("end", () => {
        try {
          const { dir } = JSON.parse(body);
          const cwd = dir ? String(dir) : process.cwd();
          const r = spawnSync("valiant", ["setup"], { cwd, encoding: "utf8", timeout: 120000 });
          if (r.status !== 0) return json(res, 400, { ok: false, why: (r.stderr || r.stdout || "setup failed").trim() });
          return json(res, 200, { ok: true, msg: (r.stdout || "").trim() });
        } catch (e) { return json(res, 400, { ok: false, why: e.message }); }
      });
      return;
    }
    if (req.method === "POST" && url.pathname === "/api/disambiguate") {
      let body = ""; req.on("data", (c) => (body += c)); req.on("end", () => {
        try {
          const { text, bullets } = JSON.parse(body);
          const r = disambiguate(String(text ?? ""), { bullets: Array.isArray(bullets) ? bullets : [] });
          return json(res, 200, r);
        } catch (e) { return json(res, 400, { ok: false, why: e.message }); }
      });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/control") {
      const { checkControl, readActions } = await import("./control.mjs");
      const r = checkControl(process.cwd());
      return json(res, 200, { ...r, actions: readActions(process.cwd()) });
    }
    if (req.method === "POST" && url.pathname === "/api/control/tick") {
      let body = ""; req.on("data", (c) => (body += c)); req.on("end", async () => {
        try {
          const { line, approve } = JSON.parse(body);
          const { tick, checkControl, readActions } = await import("./control.mjs");
          const t = tick(process.cwd(), Number(line), approve === true);
          if (!t.ok) return json(res, 400, t);
          const r = checkControl(process.cwd());
          return json(res, 200, { ...r, actions: readActions(process.cwd()) });
        } catch (e) { return json(res, 400, { ok: false, why: e.message }); }
      });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/run") {
      return runGatesStreaming(res, { tool: url.searchParams.get("tool") || "verify" });
    }
    res.writeHead(404); res.end("not found");
  });

  server.listen(port, () => {
    const url = `http://localhost:${port}`;
    console.log(`valiant ui: ${url}  (control panel — Ctrl-C to stop)`);
    // Open the browser automatically so the panel comes up without a copy-paste.
    try {
      const cmd = process.platform === "darwin" ? "open" : process.platform === "win32" ? "cmd" : "xdg-open";
      const args = process.platform === "win32" ? ["/c", "start", "", url] : [url];
      spawn(cmd, args, { detached: true, stdio: "ignore" }).unref();
    } catch { /* no open helper is fine — the URL is printed */ }
  });
  return server;
}
