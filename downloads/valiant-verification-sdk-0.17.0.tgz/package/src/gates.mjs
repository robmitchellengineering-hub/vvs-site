import { spawnSync } from "node:child_process";
import { runCheck } from "./spawn.mjs";
import { provenanceFor } from "./provenance.mjs";

// The named-gate contract (Valiant principle 1): a gate is run BY NAME, and a gate
// that is missing, cannot-check (exit 2), or passes with no evidence is a FAIL —
// never a silent pass (H17).
/**
 * A POLICY TEST is a gate whose own rule is exercised: the same check is run against inputs that must pass and inputs
 * that must fail, and a rule with no failing case is rejected by the TOOL, not by a reviewer.
 *
 * Plan item 2, borrowed in pattern from cfn-guard (Apache-2.0): "a rule that has never been shown to fail is not a
 * rule". It is the same argument as mutation testing, applied to policy instead of code — and no engine, because our
 * gates are commands rather than rules over documents.
 *
 * Shape:  { "name": "no-secrets", "type": "policy-tests", "cmd": ["./policy"], "cases": [
 *           { "input": "fixtures/clean.json", "expect": "pass" },
 *           { "input": "fixtures/leaky.json", "expect": "fail" } ] }
 * The case's input is appended to the command, so a policy script takes one argument.
 */
/**
 * EVERY WAY A GATE CAN FAIL, in one list, because the site published "7 distinct ways" and the code implements at least 8 — a number that lives
 * nowhere cannot be checked. Each entry names the verdict and the sentence a reader sees.
 */
// EVERY ENTRY NAMES THE LINE THAT EMITS IT. The first version of this list invented two modes ("missing", "not-run") that no code produced and
// omitted two that it did — an independent review counted them on 2026-11-02. A list that says where each verdict comes from cannot drift like that.
export const GATE_FAILURE_MODES = [
  { code: "did-not-run", detail: "the check could not be started at all (spawn error, missing binary)", remediation: "verify the check command in valiant.json is installed and runnable in a fresh checkout" },       // runGate(): catch on spawn
  { code: "exit-1", detail: "the check ran and failed", remediation: "read the shown output and fix what it names" },                                                     // runGate(): non-zero status
  { code: "exit-2", detail: "cannot check (exit 2) — never a silent pass", remediation: "read the detail — the check could not be completed here; treat it as red" },                                  // runGate(): status 2
  { code: "signal", detail: "killed by signal", remediation: "the check was killed — re-run with a longer timeout or more memory" },                                                             // runGate(): signal
  { code: "no-output", detail: "exit 0 with no output — suspect, a pass must produce evidence", remediation: "make the check print evidence on success — a pass must produce output" },              // runGate(): empty both streams
  { code: "empty-stdout", detail: "exit 0 with empty stdout — suspect unless expectStderr is declared", remediation: "declare expectStderr if stderr is the evidence, or print the result to stdout" },      // runGate(): empty stdout
  { code: "unexpected-stderr", detail: "exit 0 with unexpected stderr — suspect unless expectStderr allows it", remediation: "declare expectStderr to allow it, or make the check stay quiet on success" }, // runGate(): stderr present
  { code: "no-fail-case", detail: "a policy gate whose cases contain no expectation of failure", remediation: "add a case that must fail — a policy with no failing case has not been shown to reject anything" },             // runPolicyTests()
];

// The remediation for a failure code, looked up once so a result carries the fix, never a dead end.
const rem = (code) => (GATE_FAILURE_MODES.find((m) => m.code === code) || {}).remediation ?? null;

export function runPolicyTests(gate, repoRoot) {
  const { name, cmd, cases = [], limitations = [] } = gate;
  const lims = Array.isArray(limitations) ? limitations : [];
  const baseProv = provenanceFor(cmd, null, repoRoot);
  const fails = cases.filter((c) => c.expect === "fail").length;
  if (fails === 0) {   // → the "no-fail-case" failure mode listed above
    // THE POINT OF THE GATE TYPE. A policy whose only evidence is inputs it accepts has not been shown to be able to
    // reject anything, which is the failure this whole product exists to catch.
    return { name, ok: false, code: "no-fail-case", confidence: "derived", coverage: "unknown", authority: "local-execution", remediation: rem("no-fail-case"), limitations: lims, provenance: baseProv, detail: "no case expects failure — a policy that has never been shown to reject something is not a policy" };
  }
  const out = [];
  let bad = 0;
  let stdoutBytes = 0;
  let stderrBytes = 0;
  for (const c of cases) {
    const res = runCheck(cmd, [...cmd.slice(1), c.input], { cwd: repoRoot });
    if (res.error) {
      // The tool could not spawn AT ALL — this is "did not run", not "ran and failed" (release review finding 4).
      // The normal-gate path already says did-not-run/unknown/unknown for the identical condition; keep them in step.
      return { name, ok: false, code: "did-not-run", confidence: "unknown", coverage: "unknown", authority: "local-execution", remediation: rem("did-not-run"), limitations: lims, provenance: baseProv, cannotCheck: true, detail: `did not run: ${res.error.message}`, cases: out };
    }
    const status = res.status;
    // A "fail" case is satisfied only when the tool RAN and rejected (non-zero, not exit 2 "cannot check", not a
    // signal). Exit 2 is "could not check", not "rejected" — counting it as a rejection let a crash satisfy the
    // "never shown to fail" rule (release review N7).
    const ok = c.expect === "pass" ? status === 0 : status !== null && status !== 0 && status !== 2;
    if (!ok) bad++;
    stdoutBytes += res.stdout ? Buffer.byteLength(res.stdout) : 0;
    stderrBytes += res.stderr ? Buffer.byteLength(res.stderr) : 0;
    out.push({ input: c.input, expect: c.expect, exit: status, ok });
  }
  // Provenance for a policy gate: the binary identity is per-gate; runs and byte counts are aggregated across
  // cases so a passing gate cannot read as "never spawned" (release review finding 3). Per-case exits stay in cases[].
  const prov = { ...baseProv, runs: cases.length, stdout_bytes: stdoutBytes, stderr_bytes: stderrBytes };
  const detail = bad === 0
    ? `${cases.length} case(s): ${cases.length - fails} pass-fixture(s) accepted, ${fails} fail-fixture(s) rejected`
    : `${bad} of ${cases.length} case(s) did not behave: ` + out.filter((o) => !o.ok).map((o) => `${o.input} expected ${o.expect}, got exit ${o.exit}`).join("; ");
  return { name, ok: bad === 0, code: bad === 0 ? null : "exit-1", confidence: "derived", coverage: "complete", authority: "local-execution", remediation: bad === 0 ? null : rem("exit-1"), limitations: lims, provenance: prov, detail, cases: out };
}

export function runGate(gate, repoRoot) {
  if (gate?.type === "policy-tests") return runPolicyTests(gate, repoRoot);
  const { name, cmd, expectStderr = false, quiet: wantQuiet = false, limitations = [] } = gate;
  // A CUSTOMER MAY NOT BUY SILENCE. `quiet` is honoured directly — but config.mjs refuses `quiet: true` from a
  // valiant.json, so the only gates that reach here with quiet are the SDK's own shipped corpus guards.
  const quiet = wantQuiet;
  const res = runCheck(cmd, cmd.slice(1), { cwd: repoRoot });
  const lims = Array.isArray(limitations) ? limitations : [];
  const prov = provenanceFor(cmd, res, repoRoot);

  if (res.error) {
    // A missing/unstartable binary is "could not check" (exit 2), not "a contract is broken" (exit 1) — the same
    // answer the policy-tests path gives, so the two cannot disagree about the identical condition (release review N3).
    return { name, ok: false, code: "did-not-run", confidence: "unknown", coverage: "unknown", authority: "local-execution", remediation: rem("did-not-run"), limitations: lims, provenance: prov, cannotCheck: true, detail: `did not run: ${res.error.message}` };
  }
  const status = res.status;
  const out = (res.stdout || "").trim();
  // NOISE IS NOT EVIDENCE. npm's update notice goes to stderr, so the first run on a clean machine read
  // as "exit 0 with unexpected stderr — suspect" and the second passed with nothing changed. A gate that
  // flips colour because a package manager mentioned a new version teaches people to ignore it.
  const NOISE = /^(npm (notice|warn)|\s*$)/i;
  const err = (res.stderr || "").split("\n").filter((l) => !NOISE.test(l)).join("\n").trim();

  if (status === null) return { name, ok: false, code: "signal", confidence: "unknown", coverage: "unknown", authority: "local-execution", remediation: rem("signal"), limitations: lims, provenance: prov, detail: "killed by signal" };
  if (status === 2) return { name, ok: false, code: "exit-2", confidence: "unknown", coverage: "unknown", authority: "local-execution", remediation: rem("exit-2"), limitations: lims, provenance: prov, cannotCheck: true, detail: "cannot check (exit 2) — never a silent pass" };
  if (status !== 0) {
    return { name, ok: false, code: "exit-1", confidence: "observed", coverage: "complete", authority: "local-execution", remediation: rem("exit-1"), limitations: lims, provenance: prov, detail: `exit ${status}`, show: (err || out).slice(0, 200) };
  }

  if (!quiet) {
    const hasOut = out.length > 0;
    const hasErr = err.length > 0;
    if (!hasOut && !hasErr) {
      return { name, ok: false, code: "no-output", confidence: "observed", coverage: "complete", authority: "local-execution", remediation: rem("no-output"), limitations: lims, provenance: prov, detail: "exit 0 with no output — suspect (a pass must produce evidence)" };
    }
    if (!hasOut && hasErr && !expectStderr) {
      return { name, ok: false, code: "empty-stdout", confidence: "observed", coverage: "complete", authority: "local-execution", remediation: rem("empty-stdout"), limitations: lims, provenance: prov, detail: "exit 0 with empty stdout — suspect (declare expectStderr if stderr is the evidence)" };
    }
    if (hasOut && hasErr && !expectStderr) {
      return { name, ok: false, code: "unexpected-stderr", confidence: "observed", coverage: "complete", authority: "local-execution", remediation: rem("unexpected-stderr"), limitations: lims, provenance: prov, detail: "exit 0 with unexpected stderr — suspect (declare expectStderr to allow it)" };
    }
  }
  // A quiet gate that passes with no output stays silent BY DECLARED CONTRACT, not because it observed
  // nothing — but the record must say so, or 0 bytes reads as missing evidence (release review finding 8).
  const quietNoOutput = quiet && out.length === 0 && err.length === 0;
  return { name, ok: true, code: null, confidence: "observed", coverage: "complete", authority: "local-execution", remediation: null, limitations: quietNoOutput ? [...lims, "quiet gate — silence on pass is the declared contract, not missing evidence"] : lims, provenance: prov, detail: "exit 0", show: (out || err).slice(0, 200) };
}

export function runAllGates(gates, repoRoot) {
  return gates.map((g) => runGate(g, repoRoot));
}
