// evidence.mjs — one definition of "this proof is real", used by both the gate and the SOP baseline.
//
// The failure this closes (independent review #3, 2026-10-26): a hand-typed `mutations.json` satisfied the whole
// baseline and the external prover. `{"proofs":[{"guard":"package.json","result":"red"}]}` printed
// "every contract holds" and no guard was ever run. Every check here RUNS something:
//
//   1. each red proof names a subject that is a real file INSIDE this repo (not `../..`, not a comment);
//   2. a seeded sample of those proofs is RE-EXECUTED through the repo's own prover;
//   3. the record of that re-run is the SDK's, not the customer's — a typed sampled-proofs.json is ignored.
import { existsSync, readFileSync, statSync } from "node:fs";
import { join, normalize, relative, isAbsolute } from "node:path";
import { sampleProofs } from "./sample.mjs";

/** A proof's subject must be a file inside the repo. One definition, so the two callers cannot drift. */
export function proofSubject(repoRoot, proof) {
  const raw = proof?.file ?? proof?.guard;
  if (typeof raw !== "string" || !raw) return { ok: false, why: "no subject" };
  if (isAbsolute(raw)) return { ok: false, why: "absolute path" };
  const p = normalize(join(repoRoot, raw));
  const rel = relative(repoRoot, p);
  if (rel === "") return { ok: false, why: "the repo root is not a subject" };
  if (rel.startsWith("..") || isAbsolute(rel)) return { ok: false, why: "outside the repo" };
  if (!existsSync(p)) return { ok: false, why: "no such file" };
  // A directory exists too, and "." resolved to the repo root — `{"guard":"."}` passed as evidence.
  try { if (!statSync(p).isFile()) return { ok: false, why: "not a file" }; } catch { return { ok: false, why: "unreadable" }; }
  return { ok: true, path: rel };
}

export function readProofs(repoRoot) {
  const p = join(repoRoot, "mutations.json");
  if (!existsSync(p)) return null;
  try { return JSON.parse(readFileSync(p, "utf8")); } catch { return null; }
}

/**
 * Re-execute a seeded sample and require it to reproduce, with the record validated rather than trusted:
 * `sampled.length === k`, every entry reproduced, and the commit the sample ran against is HEAD.
 */
export async function verifyExternalEvidence({ repoRoot, k = 3, prover = "node scripts/mutate-guards.mjs", cache, seed = Number(new Date().toISOString().slice(0, 10).replace(/-/g, "")) }) {
  const doc = readProofs(repoRoot);
  if (!doc) return { ok: false, reason: "no readable mutations.json" };
  const red = (doc.proofs ?? []).filter((p) => p.result === "red");
  if (!red.length) return { ok: false, reason: "mutations.json holds no red proof" };

  const bad = red.map((p) => ({ p, s: proofSubject(repoRoot, p) })).filter((x) => !x.s.ok);
  if (bad.length) {
    return { ok: false, reason: `${bad.length} proof(s) name no file inside this repo: ${bad.slice(0, 3).map((x) => x.p.guard ?? x.p.file).join(", ")}` };
  }

  // A proof must carry its own re-execution recipe: the SDK applies the sabotage and watches the check fail.
  const recipe = red.filter((p) => p.file && typeof p.find === "string" && p.replace !== undefined && Array.isArray(p.check) && p.check.length);
  if (recipe.length !== red.length) {
    return {
      ok: false,
      reason: `${red.length - recipe.length} proof(s) do not carry their own re-execution recipe (file, find, replace, check) — `
        + "a proof the SDK cannot re-run itself is a claim, not evidence. Emit those four fields from your prover.",
    };
  }

  if (cache?.evidence) return cache.evidence;

  // THE SDK RUNS THE MUTATION ITSELF. It used to shell out to the repo's `proverCmd` and grep its stdout for the
  // word "caught", so a three-line script printing that word was accepted as a re-execution (independent review #5,
  // F2). Now a seeded sample of the proofs is applied by the SDK's own engine and each check must go from pass to
  // fail. The repo's prover is not consulted for verification at all.
  // Sample EXACTLY min(k, n) WITHOUT shrinking the pool as we go: splicing inside the loop re-ran n-1 rows, and the
  // rows it skipped were never executed — so a fabricated row survived by not being chosen (review #6, F2).
  let state = seed >>> 0;
  const next = () => (state = (state * 1103515245 + 12345) >>> 0) / 4294967296;
  // EVERY RED PROOF IS RE-RUN. Sampling meant a fabricated row survived whenever the seed did not pick it, while the
  // verdict still counted it (independent review #7, F2). `k` is a floor for how many must exist, not a cap.
  const sample = recipe;

  const { runAllMutations } = await import("./mutate.mjs");
  const guards = sample.map((p, n) => ({ name: `${p.guard ?? p.file}#${n}`, file: p.file, find: p.find, replace: p.replace, check: p.check }));
  const results = runAllMutations(guards, repoRoot);
  const notRed = results.filter((r) => r.result !== "caught");
  const result = notRed.length === 0
    ? { ok: true, detail: `${sample.length} proof(s), every one re-run by the SDK and each went red` }
    : { ok: false, reason: `the SDK re-ran ${sample.length} proof(s) and ${notRed.length} did not go red: ${notRed.map((b) => `${b.name} (${b.result})`).join(", ")}` };
  if (cache) cache.evidence = result;
  return result;
}
