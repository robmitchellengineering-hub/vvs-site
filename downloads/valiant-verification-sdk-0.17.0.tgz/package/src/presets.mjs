// presets.mjs — find the check a repo already has, for stacks that are not Node.
//
// PLAN-vvs-integrations.md, "layer 1: detect". Six languages cover ~80% of new repositories (GitHub Octoverse 2025) and
// `init` could only see `package.json`, so "install and work" was true for Node and nothing else.
//
// THE RULE EVERY PRESET MUST OBEY: detect what is THERE, never invent a command. A preset that guesses `pytest` in a
// repo with no tests gives the customer a gate that fails on their first run for a reason they did not cause — the exact
// failure the tool exists to catch. When nothing is found, `init` refuses and writes nothing.
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";

const has = (root, ...paths) => paths.every((p) => existsSync(join(root, p)));
const any = (root, paths) => paths.find((p) => existsSync(join(root, p))) ?? null;
const isFile = (root, p) => { try { return statSync(join(root, p)).isFile(); } catch { return false; } };
const read = (root, p) => { try { return readFileSync(join(root, p), "utf8"); } catch { return ""; } };

/** A Makefile target counts only if the file really declares it. */
const makeTarget = (root, target) => {
  if (!isFile(root, "Makefile")) return false;
  return new RegExp(`^${target}\\s*:`, "m").test(read(root, "Makefile"));
};

export const PRESETS = [
  {
    id: "python",
    stack: "Python",
    detect(root) {
      // A test framework must be visible: a bare pyproject.toml is a package, not a test suite.
      const cfg = ["pyproject.toml", "pytest.ini", "tox.ini", "setup.cfg"].filter((f) => isFile(root, f));
      const pytestConfigured = cfg.some((f) => /pytest|\[tool\.pytest|\[tool:pytest/i.test(read(root, f)));
      const tests = any(root, ["tests", "test", "spec"]);
      if (cfg.includes("tox.ini") && /\[testenv/i.test(read(root, "tox.ini"))) return { name: "tox", cmd: ["tox"] };
      if (pytestConfigured || (cfg.length && tests)) return { name: "pytest", cmd: ["python3", "-m", "pytest", "-q"] };
      if (tests && isFile(root, "requirements.txt")) return { name: "pytest", cmd: ["python3", "-m", "pytest", "-q"] };
      return null;
    },
  },
  {
    id: "maven",
    stack: "Java (Maven)",
    detect(root) {
      if (!isFile(root, "pom.xml")) return null;
      return { name: "mvn-test", cmd: ["mvn", "-q", "-B", "test"] };
    },
  },
  {
    id: "gradle",
    stack: "JVM (Gradle)",
    detect(root) {
      const build = any(root, ["build.gradle", "build.gradle.kts"]);
      if (!build) return null;
      // The wrapper is the version the project pins; using the system gradle would test a different toolchain.
      return isFile(root, "gradlew") ? { name: "gradle-test", cmd: ["./gradlew", "test"] } : { name: "gradle-test", cmd: ["gradle", "test"] };
    },
  },
  {
    id: "dotnet",
    stack: ".NET",
    detect(root) {
      // A GLOB NEEDS A READDIR. `any(root, ["*.sln", "*.csproj"])` tested for a file literally named "*.csproj", so .NET
      // was never detected — and the preset suite passed because it had no .NET case. Found by running it against a real
      // .csproj (2026-10-29).
      let entries = [];
      // A MISSING IMPORT MUST NOT LOOK LIKE "NO MATCH". `readdirSync` was undefined here, the catch turned the
      // ReferenceError into "nothing found", and .NET was silently undetectable. A missing directory is a fact; a
      // programming error is not, so only the directory case is caught.
      try { entries = readdirSync(root); }
      catch (e) { if (e.code !== "ENOENT" && e.code !== "ENOTDIR") throw e; entries = []; }
      const proj = entries.find((f) => /\.(sln|csproj)$/i.test(f));
      if (!proj) return null;
      return { name: "dotnet-test", cmd: ["dotnet", "test"] };
    },
  },
  {
    id: "go",
    stack: "Go",
    detect(root) {
      if (!isFile(root, "go.mod")) return null;
      return { name: "go-test", cmd: ["go", "test", "./..."] };
    },
  },
  {
    id: "rust",
    stack: "Rust",
    detect(root) {
      if (!isFile(root, "Cargo.toml")) return null;
      return { name: "cargo-test", cmd: ["cargo", "test", "--quiet"] };
    },
  },
  {
    id: "php",
    stack: "PHP",
    detect(root) {
      if (!isFile(root, "composer.json")) return null;
      if (isFile(root, "vendor/bin/phpunit")) return { name: "phpunit", cmd: ["vendor/bin/phpunit"] };
      let scripts = {};
      try { scripts = JSON.parse(read(root, "composer.json")).scripts ?? {}; } catch { scripts = {}; }
      if (typeof scripts.test === "string") return { name: "composer-test", cmd: ["composer", "test"] };
      return null;
    },
  },
  {
    id: "ruby",
    stack: "Ruby",
    detect(root) {
      if (!any(root, ["Gemfile", "Rakefile"])) return null;
      if (existsSync(join(root, "spec"))) return { name: "rspec", cmd: ["bundle", "exec", "rspec"] };
      if (makeTarget(root, "test") || isFile(root, "Rakefile")) return { name: "rake-test", cmd: ["bundle", "exec", "rake", "test"] };
      return null;
    },
  },
  {
    id: "make",
    stack: "Make",
    detect(root) {
      if (!makeTarget(root, "test")) return null;
      return { name: "make-test", cmd: ["make", "test"] };
    },
  },
];

/** Every preset that can be shown to exist. Empty means "refuse", never "guess". */
export function detectPresets(repoRoot) {
  const found = [];
  for (const p of PRESETS) {
    let hit = null;
    try { hit = p.detect(repoRoot); } catch { hit = null; }
    if (hit) found.push({ id: p.id, stack: p.stack, ...hit });
  }
  return found;
}
