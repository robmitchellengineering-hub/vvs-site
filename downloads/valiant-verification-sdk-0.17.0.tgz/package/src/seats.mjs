// seats.mjs — what a licence is allowed to run on: the buyer's machine, and their CI runner.
//
// Rob, 2026-11-02: "a single licence should allow you to build with vvs qa" — one licence covers ONE developer machine and ONE
// CI runner. Without that, a solo buyer whose workflow runs `valiant gate` on a GitHub runner is refused by the seat check on
// their own paid code, which reads as the product being broken rather than per-seat pricing.
//
// The rule is honest about what it can see: a runner is recognised by the environment CI sets, so a machine that looks like a
// runner spends the runner allowance and a laptop spends a seat. If the environment says nothing, the machine is a laptop —
// the conservative reading, because guessing "runner" would hand out free seats.

import { createHash } from "node:crypto";
import os from "node:os";

/** Runners per seat. Rob, 2026-11-02: "if you buy 5 seats thats 5 CI runners" — the allowance scales with what was bought. */
export const RUNNERS_PER_SEAT = 1;

/** How many runners a licence allows: its own claim, else one per seat (an older licence keeps the same deal). */
export function runnerAllowance(claims) {
  if (Number.isInteger(claims?.runners)) return claims.runners;
  const seats = claims?.seats ?? (claims?.plan === "enterprise" ? 0 : 1);
  if (seats === 0) return 1;   // uncapped seats: one runner, stated, rather than an unbounded free tier
  return Math.max(1, seats * RUNNERS_PER_SEAT);
}

const CI_ENV = [
  "GITHUB_ACTIONS", "GITLAB_CI", "CIRCLECI", "BUILDKITE", "JENKINS_URL", "TF_BUILD", "TEAMCITY_VERSION",
  "DRONE", "TRAVIS", "CODEBUILD_BUILD_ID", "BITBUCKET_BUILD_NUMBER", "NETLIFY", "VERCEL",
];

/** Is this process running on a CI runner? Returns the evidence, so a refusal can be argued with. */
export function runnerEvidence(env = process.env) {
  for (const name of CI_ENV) if (env[name]) return { runner: true, why: name };
  // Generic CI=true is last: it is set by things that are not build runners (some editors, some test harnesses).
  if (String(env.CI ?? "").toLowerCase() === "true") return { runner: true, why: "CI" };
  return { runner: false, why: null };
}

/** A stable id for this machine, so a seat is a place and not a process. */
export function machineId() {
  return createHash("sha256").update(`${os.hostname()}|${os.platform()}|${os.arch()}`).digest("hex").slice(0, 16);
}

/**
 * Decide whether this machine may use this licence, and record it when allowed.
 *
 * @returns {{ok: boolean, issue?: string, kind?: "runner"|"machine", machines?: number, runners?: number, justAdded?: boolean}}
 */
export function claimSeat(claims, reg, { id, host, platform, arch, env = process.env, now = () => new Date().toISOString() }) {
  const seats = claims?.seats ?? (claims?.plan === "enterprise" ? 0 : 1);
  // THE ALLOWANCE SCALES WITH SEATS. Five seats means five machines and five runners; a licence minted before `runners` existed
  // gets one per seat too, because refusing an existing customer for a rule they never agreed to would be a change of terms.
  const runners = runnerAllowance(claims);
  const key = String(claims?.jti ?? "unknown");
  const det = runnerEvidence(env);
  const kind = det.runner ? "runner" : "machine";

  reg.licences = reg.licences ?? {};
  const entry = reg.licences[key];
  // TWO SHAPES LIVE IN THE REGISTER. Older entries are an array of id STRINGS; this version writes `{id, kind}` objects. The
  // first version of this function mapped every array through the legacy branch, which turned an existing `{id, kind}` record
  // into `{id: {id, kind}, kind: "machine"}` — so a machine already counted looked new and was refused its own seat.
  const used = !entry ? []
    : Array.isArray(entry) ? entry.map((m) => (typeof m === "string" ? { id: m, kind: "machine" } : { id: m.id, kind: m.kind ?? "machine" }))
    : entry;

  if (used.some((u) => u.id === id)) {
    return { ok: true, kind, machines: used.filter((u) => u.kind === "machine").length, runners: used.filter((u) => u.kind === "runner").length };
  }

  const machinesUsed = used.filter((u) => u.kind === "machine").length;
  const runnersUsed = used.filter((u) => u.kind === "runner").length;
  const room = kind === "runner" ? (runners === 0 || runnersUsed < runners) : (seats === 0 || machinesUsed < seats);

  if (!room) {
    const which = kind === "runner"
      ? `already used on ${runnersUsed} runner(s) — a licence covers ${runners}`
      : `already used on ${machinesUsed} machine(s) — a licence covers ${seats}`;
    return {
      ok: false, kind, machines: machinesUsed, runners: runnersUsed,
      issue: `  this licence is ${seats} seat(s) + ${runners} CI runner(s), and it is ${which}.\n`
        + `  release one by removing its entry from seats.json, or renew with more seats.`,
    };
  }

  reg.licences[key] = [...used, { id, kind }];
  reg.machines = reg.machines ?? {};
  reg.machines[id] = { host, platform, arch, kind, at: now(), ...(det.why ? { evidence: det.why } : {}) };
  return { ok: true, kind, machines: machinesUsed + (kind === "machine" ? 1 : 0), runners: runnersUsed + (kind === "runner" ? 1 : 0), justAdded: true };
}
