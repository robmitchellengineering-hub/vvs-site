// mcp.mjs — Valiant as an MCP server, so an agent asks for the verdict instead of inferring one.
//
// Rob, 2026-10-27: "anthropic is about to go public ... we need integration directly there too." The measured case is in
// PLANS/PLAN-vvs-integrations.md: 28% of organisations already reach their CI/CD tool through MCP or agent skills, and a
// verification product is exactly what an agent should be required to ask rather than summarise.
//
// The point of this server is the SHAPE of what it returns: an exit code and the four contract results. An agent that is
// told "do not report done until valiant says done" can comply only if the answer is machine-readable. Prose from a
// model describing a green gate is the failure this whole tool exists to catch.
//
// Transport: JSON-RPC 2.0 over stdio, one JSON object per line (MCP's stdio framing). No dependencies.
import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));
const CLI = join(HERE, "..", "bin", "valiant.mjs");

export const PROTOCOL_VERSION = "2024-11-05";

/** One tool per question an agent actually asks. Each runs the real CLI and returns its exit code. */
export const TOOLS = [
  {
    name: "valiant_gate",
    description: "The whole verdict for a repo: gates by name, ledger, guards proved, SOP baseline. Returns the exit code (0 every contract holds · 1 a contract is broken · 2 a contract could not be checked) and each contract's result. Call this before reporting work as done.",
    inputSchema: { type: "object", properties: { repo: { type: "string", description: "Repo path (default: the server's working directory)" } }, additionalProperties: false },
  },
  {
    name: "valiant_verify",
    description: "Run every declared gate by name and report which passed. Narrower than valiant_gate: no proof, no SOP baseline.",
    inputSchema: { type: "object", properties: { repo: { type: "string" } }, additionalProperties: false },
  },
  {
    name: "valiant_ledger",
    description: "Check the hazard ledger (every entry needs RULE + GUARD), verify its hash chain, and re-run every REPLAY recipe. Returns who cannot be re-checked (UNREPLAYABLE), who drifted, and who is refused (REFUTED).",
    inputSchema: { type: "object", properties: { repo: { type: "string" }, replay: { type: "boolean", description: "Also re-run the REPLAY recipes" } }, additionalProperties: false },
  },
  {
    name: "valiant_outcomes",
    description: "The verifier's own record: (diff, verdict) pairs — the sabotage applied and what the guard did with it. Useful for asking 'has this guard ever actually caught anything?'",
    inputSchema: { type: "object", properties: { repo: { type: "string" }, limit: { type: "number" } }, additionalProperties: false },
  },
  {
    name: "valiant_licence_status",
    description: "Whether this machine holds a valid licence, with plan, seats and expiry. Never blocks on the network.",
    inputSchema: { type: "object", properties: {}, additionalProperties: false },
  },
];

const runCli = (args, cwd) => {
  const r = spawnSync(process.execPath, [CLI, ...args], { cwd, encoding: "utf8", timeout: 600_000 });
  return {
    exitCode: r.error ? null : r.status,
    stdout: (r.stdout ?? "").trim(),
    stderr: (r.stderr ?? "").trim(),
    error: r.error ? r.error.message : null,
    timedOut: r.signal === "SIGTERM",
  };
};

/** The verdict as data. `holds` is the only field an agent should branch on; the rest explains it. */
const summarise = (cmd, args, cwd) => {
  // THE COMMAND GOES IN THE ARGV. Passing only the flags ran `valiant` with no command, which prints help and exits 0
  // — a green verdict for having done nothing, from the tool that exists to catch exactly that.
  const r = runCli([cmd, ...args], cwd);
  const contracts = r.stdout.split("\n")
    .map((l) => /^\s*(PASS|FAIL|ABSENT)\s+(.+?)(?:\s+\(exit (\d+)\))?$/.exec(l.trim()))
    .filter(Boolean)
    .map((m) => ({ status: m[1], contract: m[2], exit: m[3] ? Number(m[3]) : null }));
  return {
    command: [cmd, ...args].join(" "),
    exitCode: r.exitCode,
    holds: r.exitCode === 0,
    canCheck: r.exitCode !== 2,
    contracts,
    detail: r.stdout.split("\n").filter(Boolean).slice(-3).join("\n"),
    stderr: r.stderr || null,
    error: r.error,
  };
};

export function callTool(name, args = {}, env = {}) {
  const cwd = args.repo || env.VALIANT_MCP_CWD || process.cwd();
  switch (name) {
    case "valiant_gate": return summarise("gate", [], cwd);
    case "valiant_verify": return summarise("verify", [], cwd);
    case "valiant_ledger": return summarise("ledger", [...(args.replay ? ["--replay"] : []), "--verify"], cwd);
    case "valiant_outcomes": {
      const r = runCli(["outcomes", "--pairs"], cwd);
      const pairs = r.stdout.split("\n").filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
      const limit = Number(args.limit ?? 20);
      return { command: "outcomes --pairs", exitCode: r.exitCode, count: pairs.length, pairs: pairs.slice(-limit), error: r.error, stderr: r.stderr || null };
    }
    case "valiant_licence_status": {
      const r = runCli(["licence", "--status"], cwd);
      return { command: "licence --status", exitCode: r.exitCode, holds: r.exitCode === 0, detail: r.stdout, stderr: r.stderr || null, error: r.error };
    }
    default: return null;
  }
}

/** One request in, one response out. Kept separate from stdio so the tests can drive it directly. */
export function handle(request, env = {}) {
  const { id = null, method, params = {} } = request ?? {};
  const reply = (result) => ({ jsonrpc: "2.0", id, result });
  const fail = (code, message) => ({ jsonrpc: "2.0", id, error: { code, message } });

  try {
    if (method === "initialize") {
      return reply({
        protocolVersion: PROTOCOL_VERSION,
        capabilities: { tools: {} },
        serverInfo: { name: "valiant", version: readVersion() },
        instructions: "Valiant verifies that a repo's checks actually run and can fail. Before reporting work as done, call valiant_gate and report its exit code: 0 every contract holds, 1 broken, 2 could not check. Do not describe a gate as passing unless exitCode is 0.",
      });
    }
    if (method === "notifications/initialized") return null;   // a notification: no response
    if (method === "tools/list") return reply({ tools: TOOLS });
    if (method === "tools/call") {
      const name = params?.name;
      if (!TOOLS.some((t) => t.name === name)) return fail(-32602, `unknown tool: ${name}`);
      const result = callTool(name, params?.arguments ?? {}, env);
      return reply({ content: [{ type: "text", text: JSON.stringify(result, null, 2) }], isError: result?.exitCode !== 0 });
    }
    if (method === "ping") return reply({});
    return fail(-32601, `method not found: ${method}`);
  } catch (e) {
    // A TOOL MUST NEVER CRASH THE SERVER. An agent that loses its verdict channel is worse off than one that gets an error.
    return { jsonrpc: "2.0", id, error: { code: -32603, message: `valiant mcp: ${e.message}` } };
  }
}

function readVersion() {
  try { return JSON.parse(readFileSync(join(HERE, "..", "package.json"), "utf8")).version ?? "0.0.0"; } catch { return "0.0.0"; }
}

/** stdio loop: one JSON object per line, in and out. */
export function serve({ input = process.stdin, output = process.stdout, env = process.env } = {}) {
  let buffer = "";
  input.setEncoding("utf8");
  input.on("data", (chunk) => {
    buffer += chunk;
    let nl;
    while ((nl = buffer.indexOf("\n")) >= 0) {
      const line = buffer.slice(0, nl).trim();
      buffer = buffer.slice(nl + 1);
      if (!line) continue;
      let req = null;
      try { req = JSON.parse(line); } catch {
        output.write(`${JSON.stringify({ jsonrpc: "2.0", id: null, error: { code: -32700, message: "parse error" } })}\n`);
        continue;
      }
      const res = handle(req, env);
      if (res) output.write(`${JSON.stringify(res)}\n`);
    }
  });
  input.on("end", () => process.exit(0));
}
