// provenance.mjs — measure WHICH check tool actually ran, so a result carries the tool's identity
// rather than trusting a version string. TRUST.md rung 2: "the tool version and the binary hash are
// in the record." The executable is sha256-sampled prelaunch; a version string is deliberately NOT
// captured here because it is the thing being replaced by the measured hash (REA's own argument).
//
// This never throws: a run must not break because provenance could not be measured. An unresolved
// tool is recorded as `resolved_path: null`, which is honest absence, not a fabricated identity.
import { createHash } from "node:crypto";
import { readFileSync, statSync } from "node:fs";
import { join, isAbsolute, delimiter } from "node:path";

const WINDOWS = process.platform === "win32";

// POSIX execvp SKIPS a PATH entry it cannot execute and runs the next one; a regular file with no
// execute bit is not a candidate. Windows has no execute bit, so isFile() is the whole test there.
const executable = (st) => st.isFile() && (WINDOWS || (st.mode & 0o111) !== 0);

/** Resolve a command word to the executable the OS would run, mirroring PATH and Windows extensions. */
export function resolveBinary(cmd0, cwd) {
  if (!cmd0 || typeof cmd0 !== "string") return null;
  if (cmd0.includes("/") || cmd0.includes("\\")) {
    const p = isAbsolute(cmd0) ? cmd0 : join(cwd, cmd0);
    try { const st = statSync(p); return executable(st) ? p : null; } catch { return null; }
  }
  const exts = WINDOWS ? ["", ".exe", ".cmd", ".bat"] : [""];
  for (const dir of (process.env.PATH || "").split(delimiter)) {
    if (!dir) continue;
    for (const ext of exts) {
      // A RELATIVE PATH entry (".") resolves against the cwd the command runs in, not process.cwd() —
      // resolveBinary must mirror that, or --config makes it hash a different file than the one that ran (release review N1).
      const p = isAbsolute(dir) ? join(dir, cmd0 + ext) : join(cwd, dir, cmd0 + ext);
      try { if (executable(statSync(p))) return p; } catch { /* keep looking */ }
    }
  }
  return null;
}

const sha256File = (p) => {
  try { return createHash("sha256").update(readFileSync(p)).digest("hex"); }
  catch { return null; }
};

/**
 * Per-tool provenance for one gate run: the resolved executable and its measured hash, plus the exit
 * and output byte counts. `res` is the spawnSync result (may be null for a multi-case policy gate,
 * whose per-case exits live in the cases array).
 */
export function provenanceFor(cmd, res, cwd) {
  const tool = Array.isArray(cmd) && cmd.length ? cmd[0] : null;
  const resolved_path = resolveBinary(tool, cwd);
  // The interpreter is not the judge. `executable_sha256` names the runtime (node); a swapped judge script is
  // invisible unless the script files themselves are hashed too (release review NEW-1). Hash every cmd argument
  // that resolves to a file under cwd.
  const files = [];
  for (const arg of Array.isArray(cmd) ? cmd.slice(1) : []) {
    if (typeof arg !== "string") continue;
    const p = isAbsolute(arg) ? arg : join(cwd, arg);
    try { if (statSync(p).isFile()) files.push({ path: arg, sha256: sha256File(p) }); } catch { /* not a file */ }
  }
  return {
    tool,
    command: Array.isArray(cmd) ? [...cmd] : null,
    resolved_path,
    executable_sha256: resolved_path ? sha256File(resolved_path) : null,
    files: files.length ? files : null,
    exit: { code: res?.status ?? null, signal: res?.signal ?? null },
    stdout_bytes: res?.stdout ? Buffer.byteLength(res.stdout) : 0,
    stderr_bytes: res?.stderr ? Buffer.byteLength(res.stderr) : 0,
  };
}
