// ci-cli.mjs — the `valiant ci-init` command: parse, plan, write, and say what to do next.
//
// It keeps the old surface (`ci-init github|jenkins|gitlab`) and adds the three that were missing: run on this machine,
// run on labels an enterprise already has, and run as a fleet over a list of machines. Nothing here registers a runner;
// it writes the workflow and (for self-hosted lanes) a registration script a human runs.
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join, dirname } from "node:path";
import {
  detectEnv, planCi, meshToFleet, renderWorkflow, renderGitlab, renderJenkins,
  renderRunnerScript, checkRunners, normalizeOs, nodeLabel, filterFleetByRegistered,
} from "./ci.mjs";

const PLATFORMS = ["github", "gitlab", "jenkins", "auto"];
const flagValue = (args, name) => {
  const i = args.indexOf(name);
  return i >= 0 ? args[i + 1] : undefined;
};
const csv = (v) => String(v || "").split(",").map((s) => s.trim()).filter(Boolean);

function write(path, content, { force }) {
  if (existsSync(path) && !force) return { wrote: false, path };
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, content);
  return { wrote: true, path };
}

export function runCiInit(argv, cwd = process.cwd(), pkgPath) {
  const args = [...argv];
  const VALUED = new Set(["--os", "--arch", "--existing", "--fleet", "--mesh", "--labels", "--tarball", "--install", "--licence-secret", "--exclude", "--role"]);
  let positional = "auto";
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith("-")) { if (VALUED.has(args[i])) i++; continue; }
    positional = args[i];
    break;
  }
  const platform = positional.toLowerCase();
  if (!PLATFORMS.includes(platform)) {
    console.error(`valiant ci-init: choose a platform — github | jenkins | gitlab   (got "${platform}")`);
    return 2;
  }
  if (platform !== "github" && platform !== "auto" && ["--fleet", "--existing", "--mesh", "--self-hosted", "--check"].some((f) => args.includes(f))) {
    console.error("valiant ci-init: --fleet/--existing/--mesh/--self-hosted/--check are GitHub Actions lanes; drop the platform or use `github`");
    return 2;
  }

  const pkg = JSON.parse(readFileSync(pkgPath, "utf8"));
  const env = detectEnv(cwd);
  const opts = {
    existing: csv(flagValue(args, "--existing")),
    selfHosted: args.includes("--self-hosted"),
    fleet: null,
  };

  // A fleet can be a file, or the mesh's own node cards.
  const meshDir = flagValue(args, "--mesh");
  if (meshDir) opts.fleet = meshToFleet(meshDir, { exclude: csv(flagValue(args, "--exclude")), roles: csv(flagValue(args, "--role")) });
  const fleetFile = flagValue(args, "--fleet");
  if (fleetFile) opts.fleet = JSON.parse(readFileSync(fleetFile, "utf8"));

  const os = normalizeOs(flagValue(args, "--os")) || env.os;
  const arch = flagValue(args, "--arch") || env.arch;
  const plan = planCi(env, { ...opts, os, arch });
  let lane = platform === "auto" ? plan.lane : platform === "github" ? plan.lane : platform;
  if (platform === "github" && !plan.lane) lane = opts.existing.length ? "github-existing" : opts.selfHosted ? "github-self-hosted" : "github-hosted";
  if (!lane) {
    console.error(`valiant ci-init: ${plan.reason}`);
    console.error("  name where it should run:  valiant ci-init --existing <runner,labels>");
    console.error("  or run it on this machine:  valiant ci-init --self-hosted");
    console.error("  or name the machines:       valiant ci-init --mesh <harness-mesh/nodes>");
    return 2;
  }

  // --existing without a platform is the enterprise lane even when a remote is absent.
  if (platform === "github" && opts.existing.length && plan.lane !== "github-existing") lane = "github-existing";
  if (platform === "gitlab") plan.reason = "you asked for GitLab — one job, no allow_failure";
  if (platform === "jenkins") plan.reason = "you asked for Jenkins — one stage, no catchError";

  const labels = lane === "github-existing" ? opts.existing : plan.labels;
  if (lane !== "github-hosted" && !["gitlab", "jenkins"].includes(lane) && !labels.length) {
    console.error("valiant ci-init: a self-hosted lane needs labels — pass --existing <a,b> or --self-hosted");
    return 2;
  }

  // A MATRIX WITH A ROW FOR A MACHINE THAT HAS NO RUNNER DOES NOT FAIL — IT HANGS. Eight node cards and two real
  // runners meant six jobs queued for a day and every pull request read as pending forever. So the fleet is generated
  // from what GitHub actually has, and the cards it left out are named rather than silently dropped.
  if ((lane === "github-fleet" || lane === "github-self-hosted") && opts.fleet && plan.ownerRepo && !args.includes("--include-unregistered")) {
    const reg = checkRunners(env, plan.ownerRepo, []);
    if (reg.verified) {
      const { keep, missing } = filterFleetByRegistered(opts.fleet.nodes, reg.labels || []);
      if (missing.length) console.error(`  note: ${missing.length} machine(s) have no registered runner and were left out: ${missing.join(", ")}`);
      if (!keep.length) {
        console.error("ci-init: no machine in the fleet has a registered runner — register one, or pass --include-unregistered to write the matrix anyway");
        return 2;
      }
      opts.fleet = { ...opts.fleet, nodes: keep };
    } else {
      console.error(`  UNVERIFIED: ${reg.why} — the matrix includes every machine in the manifest (it will queue where no runner exists)`);
    }
  }

  const renderOpts = {
    version: pkg.version,
    tarball: flagValue(args, "--tarball"),
    install: flagValue(args, "--install"),
    ownerRepo: plan.ownerRepo,
    licenceSecret: flagValue(args, "--licence-secret") || "VALIANT_LICENCE",
    fleetNodes: opts.fleet ? opts.fleet.nodes : [],
    labels,
    os,
    arch,
    selfRepo: existsSync(join(cwd, "bin", "valiant.mjs")),
  };

  let rel, content;
  if (lane === "gitlab") { rel = ".gitlab-ci.yml"; content = renderGitlab(renderOpts); }
  else if (lane === "jenkins") { rel = "Jenkinsfile"; content = renderJenkins(renderOpts); }
  else { rel = join(".github", "workflows", "valiant.yml"); content = renderWorkflow({ ...plan, lane, reason: plan.reason }, renderOpts); }

  if (args.includes("--print")) {
    console.log(content);
    return 0;
  }

  const force = args.includes("--force");
  const target = join(cwd, rel);
  // A workflow written for one lane must not be silently kept while another lane's runner scripts are installed:
  // that produces a fleet with a hosted workflow, which is exactly the "green that proves nothing" this product exists
  // to catch. Differ + no --force is a refusal with the reason, not a half-write.
  if (existsSync(target) && !force) {
    const prev = readFileSync(target, "utf8");
    const m = prev.match(/ci-init` for the ([\w-]+) lane/);
    if (m && m[1] !== lane) {
      console.error(`ci-init: ${rel} already exists for the ${m[1]} lane; this run is ${lane}.`);
      console.error("  pass --force to replace it, or --print to review the new one first");
      return 2;
    }
    console.log(`ci-init: ${lane} — ${plan.reason}`);
    console.log(`  left alone (already exists; pass --force to replace): ${target}`);
    return 0;
  }
  const res = write(target, content, { force });

  // Self-hosted lanes also get the registration script(s), because the workflow alone cannot register a machine.
  const runnerFiles = [];
  if (lane === "github-self-hosted" || lane === "github-fleet") {
    const nodes = lane === "github-fleet" ? opts.fleet.nodes : [{ name: "this-machine", os, arch }];
    for (const n of nodes) {
      const ext = n.os === "windows" ? "ps1" : "sh";
      const p = join("ci", "runners", `${n.name}.${ext}`);
      const pin = lane === "github-fleet" ? [nodeLabel(n.name)] : [];
      const body = renderRunnerScript({ name: n.name, os: n.os, arch: n.arch, ownerRepo: plan.ownerRepo || "OWNER/REPO", labels: [...pin, ...(n.labels || [])] });
      runnerFiles.push(write(join(cwd, p), body, { force }));
    }
    write(join(cwd, "ci", "valiant-ci.json"), JSON.stringify({
      lane, os, arch, labels, nodes: opts.fleet ? opts.fleet.nodes : undefined,
      sdkVersion: pkg.version, generated: new Date().toISOString().slice(0, 10),
      note: "generated by valiant ci-init — the workflow is the source of truth; this file is for `ci-init --check`",
    }, null, 2) + "\n", { force: true });
  }

  if (args.includes("--json")) {
    console.log(JSON.stringify({ lane, reason: plan.reason, file: res, runnerFiles, labels, ownerRepo: plan.ownerRepo }, null, 2));
  } else {
    console.log(`ci-init: ${lane} — ${plan.reason}`);
    console.log(`  ${res.wrote ? "wrote" : "left alone (already exists; pass --force to replace)"}: ${res.path}`);
    for (const r of runnerFiles) console.log(`  ${r.wrote ? "wrote" : "left alone"}: ${r.path}`);
    if (lane === "github-hosted") {
      console.log("  hosted runners: the repo's own Actions minutes — free on public repos, included minutes on private ones");
    }
    if (lane === "github-self-hosted" || lane === "github-fleet") {
      console.log("  the runner script fetches a one-hour registration token with gh at run time; no token is stored");
      for (const r of runnerFiles) console.log(`  run it on that machine: ${r.path}`);
      console.log("  a self-hosted node without the secret keeps its own licence; an empty secret never overwrites it");
    }
    if (lane === "github-existing") {
      console.log(`  runs on labels: ${labels.join(", ")} — nothing was installed`);
    }
  }

  if (opts.fleet && !args.includes("--json")) {
    console.log("  fleet:");
    for (const n of opts.fleet.nodes) console.log(`    ${n.name.padEnd(20)} ${n.os}/${n.arch}`);
  }

  if (!args.includes("--json")) {
    console.log("\n  account:");
    for (const s of plan.account) console.log(`    ${s.step}. ${s.do}${s.cmd ? `\n       ${s.cmd}` : ""}${s.url ? `\n       ${s.url}` : ""}`);
  }

  if (args.includes("--check")) {
    const wanted = lane === "github-hosted" ? [] : labels;
    const r = checkRunners(env, plan.ownerRepo, wanted);
    if (!r.verified) {
      console.error(`  UNVERIFIED: ${r.why} — runner labels are NOT confirmed (absent evidence is not a pass)`);
      return 2;
    }
    console.log(`  runner labels seen: ${r.labels.join(", ") || "(none)"}`);
    if (r.missing.length) { console.error(`  MISSING: ${r.missing.join(", ")}`); return 2; }
    console.log("  every label the workflow names exists");
  }
  return 0;
}
