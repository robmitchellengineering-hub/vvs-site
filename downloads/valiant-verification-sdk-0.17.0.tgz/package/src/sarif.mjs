// sarif.mjs — the verdict in a format a security dashboard already reads.
//
// PLAN-vvs-integrations.md, layer 3. A red gate that only exists in CI logs is invisible to the person who owns the
// finding. SARIF 2.1.0 is what GitHub's code-scanning tab and Azure DevOps consume, so a failed gate can appear next to
// the code it is about — with no service of ours in the middle and no dependency added.
//
// Level mapping is deliberate:
//   exit 1 (a contract is broken)       → "error"    — something is wrong and can be fixed
//   exit 2 (could not check)            → "warning"  — nothing is wrong yet, but nothing was proved either
//   anything else that is not 0         → "note"     — signalled, not graded
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url));

export const SARIF_SCHEMA = "https://json.schemastore.org/sarif-2.1.0.json";
export const SARIF_VERSION = "2.1.0";

const level = (code) => (code === 1 ? "error" : code === 2 ? "warning" : "note");

function version() {
  try { return JSON.parse(readFileSync(join(HERE, "..", "package.json"), "utf8")).version ?? "0.0.0"; } catch { return "0.0.0"; }
}

/**
 * One result per gate that did not pass, at the location of the config that declared it — because a gate's "file" is the
 * config, and pointing at a line we did not read would be a guess dressed as a location.
 */
export function toSarif({ results = [], configPath = "valiant.json", command = "verify", skipped = [], infoUri = "https://github.com/robmitchellengineering-hub/valiant-verification-sdk" } = {}) {
  const failures = results.filter((r) => !r.ok);
  const rules = [...new Set(failures.map((r) => r.name))].map((name) => ({
    id: `valiant/${name}`,
    name,
    shortDescription: { text: `The "${name}" gate must pass` },
    help: { text: `Run \`valiant ${command}\` to see this gate's output. A gate that could not run (exit 2) is not a pass.` },
  }));
  // A releaseOnly gate is legitimately OUT of the everyday scope, but the SARIF consumer must not read
  // "executionSuccessful: true" as "nothing was skipped" — the skip is named, not silent.
  const notifications = skipped.length ? [{
    level: "note",
    message: { text: `${skipped.length} releaseOnly gate(s) skipped by this ${command}: ${skipped.join(", ")} — run \`valiant gate\` to check them` },
  }] : [];
  return {
    $schema: SARIF_SCHEMA,
    version: SARIF_VERSION,
    runs: [{
      tool: {
        driver: {
          name: "valiant",
          version: version(),
          informationUri: infoUri,
          rules,
        },
      },
      invocations: [{ executionSuccessful: failures.length === 0, command, toolExecutionNotifications: notifications }],
      results: failures.map((r) => ({
        ruleId: `valiant/${r.name}`,
        level: level(r.cannotCheck ? 2 : typeof r.exit === "number" ? r.exit : 1),
        message: { text: `${r.name}: ${r.detail ?? "did not pass"}` },
        locations: [{
          physicalLocation: {
            artifactLocation: { uri: configPath.replace(/\\/g, "/") },
          },
        }],
      })),
    }],
  };
}

export function printSarif(doc, write = (s) => process.stdout.write(s)) {
  write(`${JSON.stringify(doc, null, 2)}\n`);
}
