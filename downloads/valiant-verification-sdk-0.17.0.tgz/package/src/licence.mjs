// Licence verification — offline, signature-based, no phone-home.
//
// WHY OFFLINE. A paid verification tool that needs a network round trip to start is unusable on the
// machines this thing is FOR: CI runners, air-gapped build boxes, a customer's laptop on a train. It
// also puts Morpheus's uptime in the path of somebody else's build. So the licence carries its own
// proof: a small JSON payload, Ed25519-signed by Morpheus, verified here with a public key. Nothing
// is sent, nothing is stored beyond the key itself.
//
// WHAT THIS CANNOT DO, stated plainly: it cannot un-issue. Offline verification has no idea whether a
// licence was refunded five minutes ago. That gap is closed by SHORT EXPIRY + renewal rather than by
// a check-in — the same shape Morpheus's own broker tokens use (7-day tokens, re-minted before they
// expire). A caller may also pass a `revoked` set (kid list) for the case where a key is known bad.
//
// THE FORMAT, which is the contract the server mints to:
//
//     vvs1.<base64url(payload JSON)>.<base64url(ed25519 signature)>
//
// payload: { "v": 1, "sub": "<morpheus account id>", "plan": "solo"|"team", "seats": 1, "iat": <unix>,
//            "exp": <unix>, "kid": "<key id>", "jti": "<licence id>" }
//
// `kid` names which signing key made it, so a key rotation does not invalidate everything at once.
import { createPublicKey, verify as cryptoVerify } from "node:crypto";

const PREFIX = "vvs1";
const PLANS = ["solo", "team", "enterprise"];

// WHAT A TIER MEANS. Seats are the only real difference today, and that is stated rather than implied:
// every plan gets the whole tool, because a licence that unlocks a partial product teaches a customer
// that the product is partial. ENTERPRISE is unlimited seats (`seats: 0` means "no seat count").
const PLAN_SEATS = { solo: 1, team: 5, enterprise: 0 };

/** base64url without padding, either way round. */
function b64urlToBuf(s) {
  return Buffer.from(s.replace(/-/g, "+").replace(/_/g, "/"), "base64");
}

/**
 * Verify a licence string.
 *
 * @param {string} licence  the vvs1.… string the customer pasted
 * @param {object} opts
 * @param {string} opts.publicKeyPem  PEM Ed25519 public key (or a map keyed by `kid` for rotation)
 * @param {number} [opts.now]         unix seconds; injectable so tests are not clock-dependent
 * @param {number} [opts.graceDays]   how long an expired licence still works (default 0 — expiry is expiry)
 * @param {Set<string>} [opts.revoked] licence ids (jti) known bad
 * @returns {{ok: boolean, reason?: string, claims?: object}}
 */
export function verifyLicence(licence, { publicKeyPem, now = Math.floor(Date.now() / 1000), graceDays = 0, revoked } = {}) {
  if (typeof licence !== "string" || !licence.trim()) return { ok: false, reason: "no licence given" };
  const parts = licence.trim().split(".");
  if (parts.length !== 3) return { ok: false, reason: "not a licence: expected vvs1.<payload>.<signature>" };
  const [prefix, payloadPart, sigPart] = parts;
  if (prefix !== PREFIX) return { ok: false, reason: `unknown licence version "${prefix}" (this build reads ${PREFIX})` };

  let claims;
  try {
    claims = JSON.parse(b64urlToBuf(payloadPart).toString("utf8"));
  } catch {
    return { ok: false, reason: "the payload is not readable JSON — the key was probably truncated when copied" };
  }
  if (claims?.v !== 1) return { ok: false, reason: `unsupported payload version ${JSON.stringify(claims?.v)}` };
  // TWO TOKEN TYPES, ONE SIGNATURE. A revocation list is the second: same vvs1 envelope, same key, no plan and no account,
  // because it grants nothing — it only withdraws. It is checked as strictly (version, expiry, signature, a real array) and
  // cannot be mistaken for a licence: `kind` decides which checks apply, and a licence must never carry `kind`.
  const isRevocationList = claims.kind === "revocations";
  if (isRevocationList) {
    if (!Array.isArray(claims.revocations)) return { ok: false, reason: "a revocation list has no revocations array" };
    if (!Number.isInteger(claims.exp)) return { ok: false, reason: "a revocation list has no expiry" };
  } else {
    if (!PLANS.includes(claims.plan)) return { ok: false, reason: `unknown plan ${JSON.stringify(claims.plan)}` };
    if (typeof claims.sub !== "string" || !claims.sub) return { ok: false, reason: "licence names no account" };
    if (!Number.isInteger(claims.exp)) return { ok: false, reason: "licence has no expiry" };
  }

  if (revoked && claims.jti && revoked.has(claims.jti)) {
    return { ok: false, reason: `licence ${claims.jti} has been revoked` };
  }

  // Resolve the key: a single PEM, or { kid: pem } for rotation. A licence naming a kid we do not
  // have is a DIFFERENT failure from a bad signature, and saying which one saves the customer a
  // support round trip.
  let pem = publicKeyPem;
  if (pem && typeof pem === "object") {
    if (!claims.kid) return { ok: false, reason: "this build has several signing keys but the licence names no key id (kid)" };
    pem = pem[claims.kid];
    if (!pem) return { ok: false, reason: `licence was signed with key "${claims.kid}", which this build does not carry — update the tool` };
  }
  if (!pem) return { ok: false, reason: "no public key to verify against (this build is misconfigured)" };

  // The signature covers the payload BYTES AS RECEIVED, not a re-serialisation — so a server that
  // changes its JSON key order does not silently invalidate every outstanding licence.
  let okSignature = false;
  try {
    okSignature = cryptoVerify(null, b64urlToBuf(payloadPart), createPublicKey(pem), b64urlToBuf(sigPart));
  } catch (e) {
    return { ok: false, reason: `could not check the signature: ${e.message}` };
  }
  if (!okSignature) return { ok: false, reason: "the signature does not match this licence — it was edited, or it came from another issuer" };

  const graceSeconds = Math.max(0, graceDays) * 86400;
  if (now > claims.exp + graceSeconds) {
    const days = Math.round((now - claims.exp) / 86400);
    return { ok: false, reason: `licence expired ${days} day(s) ago — renew it at morpheus.nz`, claims };
  }

  return { ok: true, claims };
}

/** Human-readable line for the CLI. Never prints the licence itself. */
export function describeLicence(claims) {
  const exp = new Date(claims.exp * 1000).toISOString().slice(0, 10);
  const seats = claims.seats ?? PLAN_SEATS[claims.plan] ?? 1;
  const seatText = seats === 0 ? "unlimited seats" : `${seats} seat(s)`;
  return `${claims.plan} plan · account ${String(claims.sub).slice(0, 8)}… · ${seatText} · expires ${exp}`;
}

export { PLANS, PLAN_SEATS, PREFIX };
