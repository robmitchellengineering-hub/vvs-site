#!/usr/bin/env node
// Reference guard — invariant 23: "a refresh preserves what it cannot derive".
//
// A tool that regenerates state and replaces what it does not own deletes knowledge silently: the run says "updated", and the hand-added field,
// the note, the union of two sources is gone. The rule: carry forward what you cannot derive, and UNION what you cannot fully observe.
//
// THE CONTRACT. `conventions.refresh` names a command and a fixture directory. The guard runs the command against a COPY of the fixture, then
// asserts that a field the fixture marks as not-owned survives. The marker is `.valiant-preserve.json` inside the fixture:
//   { "file": "state.json", "keys": ["note", "handAdded"] }
// That is a declaration the repo owns — not a guess about its data model.
//
// WHAT IT DOES NOT DO. It does not know which fields a tool SHOULD derive; it checks only what the repo says must survive.
import { readFileSync, existsSync, cpSync, rmSync, mkdtempSync } from "node:fs";
import { join, resolve } from "node:path";
import { spawnSync } from "node:child_process";
import { tmpdir } from "node:os";
import { readConventions, CONVENTIONS, unenforced } from "../../src/conventions.mjs";

const root = resolve(process.argv[2] || ".");
const cfgPath = join(root, "valiant.json");
if (!existsSync(cfgPath)) { console.log("  ok   no valiant.json: nothing is adopted here"); process.exit(0); }
const cfg = JSON.parse(readFileSync(cfgPath, "utf8"));
const c = CONVENTIONS.find((x) => x.key === "refresh");
const { declared, problems } = readConventions(cfg, root);
const mine = problems.filter((p) => p.key === "refresh");
if (mine.length) { console.error(`  ${mine.map((m) => m.why).join("; ")}`); process.exit(1); }
if (declared.refresh === undefined) { console.log("  " + unenforced(c)); process.exit(0); }

const { command, fixture } = declared.refresh;
if (!fixture) { console.log("  " + unenforced({ ...c, what: 'needs "fixture": a directory the guard may run the command against' })); process.exit(0); }
const fixtureDir = join(root, fixture);
const marker = join(fixtureDir, ".valiant-preserve.json");
if (!existsSync(marker)) {
  console.error(`  conventions.refresh names fixture ${fixture} but it has no .valiant-preserve.json — the guard cannot tell what must survive`);
  process.exit(1);
}
const spec = JSON.parse(readFileSync(marker, "utf8"));
const work = mkdtempSync(join(tmpdir(), "refresh-"));
try {
  cpSync(fixtureDir, join(work, "f"), { recursive: true });
  const before = JSON.parse(readFileSync(join(work, "f", spec.file), "utf8"));
  const r = spawnSync(command[0], command.slice(1), { cwd: join(work, "f"), encoding: "utf8" });
  if ((r.status ?? 1) !== 0) {
    console.error(`  the declared refresh command exited ${r.status}: ${(r.stderr || r.stdout || "").split("\n")[0].slice(0, 120)}`);
    process.exit(1);
  }
  const after = JSON.parse(readFileSync(join(work, "f", spec.file), "utf8"));
  const lost = (spec.keys ?? []).filter((k) => before[k] !== undefined && after[k] === undefined);
  if (lost.length) {
    console.error(`  the refresh DELETED ${lost.join(", ")} from ${spec.file} — it cannot derive those, so it must carry them forward`);
    process.exit(1);
  }
  console.log(`  ok   the refresh ran and preserved ${(spec.keys ?? []).length} field(s) it cannot derive`);
  process.exit(0);
} finally { rmSync(work, { recursive: true, force: true }); }
