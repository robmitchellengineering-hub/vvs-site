#!/usr/bin/env node
// Reference guard — invariant 17: "a check that never ran is not a pass."
//
// A required CI step that may fail without failing the build (continue-on-error, allow_failure, `|| true`, `set +e`,
// `if: always()` on the only test step) reports a green that means nothing. This guard reads the CI configuration and
// names each such line.
// Usage: node ci-can-skip.mjs [dir]   (exit 0 = no required step can be swallowed, 1 = one can)
import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';

const root = resolve(process.argv[2] || '.');
const CANDIDATES = ['.github/workflows', '.gitlab-ci.yml', '.circleci', 'azure-pipelines.yml', '.buildkite'];
const files = [];
const collect = (p) => {
  if (!existsSync(p)) return;
  let s = null;
  try { s = statSync(p); } catch { return; }
  if (s.isDirectory()) { for (const e of readdirSync(p)) collect(join(p, e)); return; }
  if (/\.(yml|yaml)$/.test(p)) files.push(p);
};
for (const c of CANDIDATES) collect(join(root, c));
if (files.length === 0) { console.log('ci-can-skip: no CI configuration found — nothing to check'); process.exit(0); }

// Each pattern is a way a step reports success without its result mattering.
const RULES = [
  [/continue-on-error:\s*true/i, 'continue-on-error: true'],
  [/allow_failure:\s*true/i, 'allow_failure: true'],
  [/\|\|\s*true/, '"|| true" swallows the exit code'],
  [/^\s*set\s+\+e\b/m, '"set +e" lets a later failure pass the step'],
  [/if:\s*always\(\)/i, '"if: always()" runs regardless of the result'],
  [/--no-verify\b/, '--no-verify skips the hooks that would have caught it'],
];
let bad = 0;
for (const f of files) {
  const lines = readFileSync(f, 'utf8').split('\n');
  lines.forEach((line, i) => {
    for (const [re, why] of RULES) {
      if (re.test(line)) {
        console.log(`  FAIL ${relative(root, f)}:${i + 1} — ${why}`);
        bad++;
      }
    }
  });
}
if (!bad) console.log(`  ok   ${files.length} CI file(s): no step can be swallowed`);
process.exit(bad ? 1 : 0);
