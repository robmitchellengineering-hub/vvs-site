#!/usr/bin/env node
// Reference guard — invariant 14: "a declaration outlives its block."
//
// `const` inside a block is scoped to it. Code that reads it after the closing brace is either a bug that only shows
// under some paths, or a declaration that belongs one level out. This is a deliberately small, dependency-free
// approximation: it tracks brace depth, records declarations made at depth > 0, and reports a use of that name after
// its block has closed.
// Usage: node declaration-scope.mjs [dir]   (exit 0 = no outliving declaration, 1 = one found)
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';

const root = resolve(process.argv[2] || '.');
const SKIP = new Set(['node_modules', '.git', 'dist', 'build', '.venv', '__pycache__', 'target']);
const files = [];
(function walk(dir) {
  let entries = [];
  try { entries = readdirSync(dir); } catch { return; }
  for (const e of entries) {
    if (SKIP.has(e)) continue;
    const p = join(dir, e);
    let s = null;
    try { s = statSync(p); } catch { continue; }
    if (s.isDirectory()) { walk(p); continue; }
    if (/\.[cm]?[jt]sx?$/.test(e) && !/\.min\./.test(e)) files.push(p);
  }
})(root);

/**
 * Blank out everything that is not code, keeping each line's length so offsets stay meaningful:
 * comments, single- and double-quoted strings, and template literals (which may span lines).
 * Braces inside a string or a template are not structure, and counting them made this guard report
 * declarations that were never in a deeper block — measured against this very repository's own source.
 */
function codeOnly(lines) {
  const out = [];
  let inTemplate = false;
  let inBlockComment = false;
  for (const raw of lines) {
    let line = "";
    for (let i = 0; i < raw.length; i++) {
      const ch = raw[i];
      const next = raw[i + 1];
      if (inBlockComment) { if (ch === "*" && next === "/") { inBlockComment = false; i++; } line += " "; continue; }
      if (inTemplate) {
        if (ch === "\\") { line += "  "; i++; continue; }
        if (ch === "`") { inTemplate = false; line += " "; continue; }
        line += " "; continue;
      }
      if (ch === "/" && next === "/") { line += " ".repeat(raw.length - i); break; }
      if (ch === "/" && next === "*") { inBlockComment = true; line += "  "; i++; continue; }
      if (ch === "`") { inTemplate = true; line += " "; continue; }
      if (ch === "'" || ch === '"') {
        const quote = ch; line += " ";
        for (i++; i < raw.length; i++) { if (raw[i] === "\\") { line += "  "; i++; continue; } if (raw[i] === quote) break; line += " "; }
        line += " "; continue;
      }
      line += ch;
    }
    out.push(line);
  }
  return out;
}

let bad = 0;
for (const f of files) {
  const rawLines = readFileSync(f, 'utf8').split('\n');
  const src = codeOnly(rawLines);
  const stack = [];                      // {names:Set, depth}
  let depth = 0;
  const reported = new Set();
  src.forEach((line, i) => {
    const open = (line.match(/\{/g) || []).length;
    const close = (line.match(/\}/g) || []).length;
    // A DECLARATION IN A PARAMETER LIST OR A DESTRUCTURING PATTERN IS NOT A BLOCK-LOCAL `const`. The first version reported
    // `({ key, row }) => …` as "key outlives its block" — a false positive, and a guard that cries wolf is a guard that gets
    // switched off. Only a plain `const x =` / `let x =` statement counts.
    const decl = /^\s*(?:const|let)\s+([A-Za-z_$][\w$]*)\s*=/.exec(line);
    const isPattern = /\(\s*\{|^\s*(?:const|let)\s*\{/.test(line);
    if (decl && depth > 0 && !isPattern) stack.push({ names: new Set([decl[1]]), depth });
    // A use of a name declared in a block that has already closed.
    for (const entry of [...stack]) {
      if (depth < entry.depth) {
        for (const name of entry.names) {
          const re = new RegExp(`\\b${name}\\b`);
          // A RE-DECLARATION OR A SHADOWED USE IS NOT THE BUG. If the name is also declared at file scope, a later use may be that
          // binding; if the line destructures or declares it again, the use is a different variable with the same spelling.
          // AN ARROW PARAMETER IS A NEW BINDING, and this tracker does not model arrow scopes. `(r) => …` re-using a name from an
          // enclosing block is normal code, not a bug — so a line carrying `=>` is not evidence of an outliving use.
          const arrow = /=>/.test(line);
          const shadowed = arrow
            || new RegExp(`(?:const|let|var)\\s+${name}\\b|\\b${name}\\s*[:,}]|\\{[^}]*\\b${name}\\b[^}]*\\}`).test(line);
          if (!shadowed && re.test(line) && !reported.has(`${name}:${i}`)) {
            console.log(`  FAIL ${relative(root, f)}:${i + 1} — "${name}" was declared inside a block (depth ${entry.depth}) and is used after it closed`);
            reported.add(`${name}:${i}`);
            bad++;
          }
        }
        stack.splice(stack.indexOf(entry), 1);
      }
    }
    depth += open - close;
    if (depth < 0) depth = 0;
  });
}
if (!bad) console.log(`  ok   ${files.length} source file(s): no declaration outlives its block`);
process.exit(bad ? 1 : 0);
