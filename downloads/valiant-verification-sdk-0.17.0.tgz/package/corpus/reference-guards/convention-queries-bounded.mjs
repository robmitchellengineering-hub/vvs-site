#!/usr/bin/env node
// Reference guard — invariants 9 and 7: "a silent zero is a bug" and "schema drift degrades gracefully".
//
// A query that returns nothing because the table is empty and a query that returns nothing because a column vanished look identical to the
// caller. The rule: a query is bounded and sampled, and a schema mismatch degrades instead of taking the feature down.
//
// WHAT THIS CHECKS. Each module declared as `conventions.queries` must (a) bound what it reads — LIMIT / limit / top / take — and (b) show it
// handles a missing column or a failed query, by a catch or a fallback, rather than letting the throw escape.
import { readFileSync, existsSync } from "node:fs";
import { join, resolve } from "node:path";
import { readConventions, CONVENTIONS, unenforced } from "../../src/conventions.mjs";

const root = resolve(process.argv[2] || ".");
const cfgPath = join(root, "valiant.json");
if (!existsSync(cfgPath)) { console.log("  ok   no valiant.json: nothing is adopted here"); process.exit(0); }
const cfg = JSON.parse(readFileSync(cfgPath, "utf8"));
const c = CONVENTIONS.find((x) => x.key === "queries");
const { declared, problems } = readConventions(cfg, root);
const mine = problems.filter((p) => p.key === "queries");
if (mine.length) { console.error(`  ${mine.map((m) => m.why).join("; ")}`); process.exit(1); }
if (declared.queries === undefined) { console.log("  " + unenforced(c)); process.exit(0); }

const BOUND = /\b(LIMIT|limit|take|slice\(|top)\b/i;
const DEGRADE = /(catch\s*\(|try\s*\{|fallback|defaultTo|\?\?|\|\|)/;
const bad = [];
for (const rel of declared.queries) {
  const f = join(root, rel);
  if (!existsSync(f)) { bad.push(`${rel}: declared but missing`); continue; }
  const src = readFileSync(f, "utf8");
  if (!BOUND.test(src)) bad.push(`${rel}: reads without a bound — an unbounded read is how a silent zero and a slow outage are the same event`);
  if (!DEGRADE.test(src)) bad.push(`${rel}: no fallback or catch — a missing column would take the feature down instead of degrading`);
}
if (bad.length) { console.error("  queries that cannot tell empty from broken:"); for (const b of bad) console.error(`    ${b}`); process.exit(1); }
console.log(`  ok   ${declared.queries.length} query module(s) bound their reads and degrade on drift`);
process.exit(0);
