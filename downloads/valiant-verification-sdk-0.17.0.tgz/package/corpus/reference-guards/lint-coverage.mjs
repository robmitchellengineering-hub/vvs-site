#!/usr/bin/env node
// Reference guard — invariant 18 (the mechanical half): "lint coverage".
//
// THE INCIDENT SHAPE. A repo has a linter, runs it on every gate, and reports green — while a whole directory is excluded. The green
// looks like coverage and is a statement about the files that were looked at. The rule's checkable half: every source file must be inside
// the set the rule set actually covers, and the lint script must be wired to something that runs it.
//
// WHAT THIS CHECKS.
//   1. no source file sits under a path excluded by `.eslintignore`, `.prettierignore`, or the `ignores` array of an eslint flat config;
//   2. if a lint script exists, something calls it — a gate in valiant.json or a CI workflow step. A lint script nothing runs is the same
//      silence as no lint script.
//
// WHAT IT DOES NOT DO. It does not run the linter and cannot tell whether the rules are any good; and the render half of invariant 18
// (a user-visible change is verified by rendering it) is a browser check, not a text check — stated, not implied.
//
// Usage: node lint-coverage.mjs [dir]   (exit 0 = no source file is excluded and the lint script is wired, 1 = a hole)
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';

const root = resolve(process.argv[2] || '.');
const read = (p) => { try { return readFileSync(p, 'utf8'); } catch { return null; } };
const SKIP = new Set(['node_modules', '.git', 'dist', 'build', 'target', '.venv', '__pycache__', '.playwright']);
const SOURCE = ['.js', '.mjs', '.cjs', '.jsx', '.ts', '.tsx'];

const sources = [];
(function walk(dir) {
  let entries = [];
  try { entries = readdirSync(dir); } catch { return; }
  for (const e of entries) {
    if (SKIP.has(e)) continue;
    const p = join(dir, e);
    let s = null;
    try { s = statSync(p); } catch { continue; }
    if (s.isDirectory()) { walk(p); continue; }
    if (SOURCE.some((x) => e.endsWith(x)) && !/\.min\./.test(e)) sources.push(p);
  }
})(root);

// 1. the excluded set
const ignores = [];
for (const name of ['.eslintignore', '.prettierignore']) {
  const t = read(join(root, name));
  if (t) for (const line of t.split('\n')) { const v = line.trim(); if (v && !v.startsWith('#')) ignores.push(v.replace(/^\.\//, '')); }
}
for (const name of ['eslint.config.js', 'eslint.config.mjs', 'eslint.config.cjs']) {
  const t = read(join(root, name));
  if (!t) continue;
  const m = /ignores\s*:\s*\[([^\]]*)\]/.exec(t);
  if (m) for (const part of m[1].split(',')) { const v = part.trim().replace(/^['"`]|['"`]$/g, ''); if (v) ignores.push(v); }
}

const problems = [];
for (const ig of ignores) {
  const base = ig.replace(/\*+$/, '').replace(/\/$/, '');
  if (!base) continue;
  const covered = sources.filter((f) => relative(root, f).startsWith(base));
  if (covered.length) problems.push(`${covered.length} source file(s) sit under an excluded path "${ig}" — the lint run never looks at them (e.g. ${relative(root, covered[0])})`);
}

// 2. is the lint script wired to anything?
const pkg = (() => { const t = read(join(root, 'package.json')); try { return t ? JSON.parse(t) : null; } catch { return null; } })();
const lintNames = Object.entries(pkg?.scripts ?? {}).filter(([, cmd]) => /\b(eslint|prettier|biome|standard|xo)\b/.test(String(cmd))).map(([n]) => n);
if (lintNames.length) {
  const wired = [];
  const cfg = (() => { const t = read(join(root, 'valiant.json')); try { return t ? JSON.parse(t) : null; } catch { return null; } })();
  for (const g of cfg?.gates ?? []) wired.push([].concat(g.cmd ?? []).join(' '));
  for (const dir of ['.github/workflows']) {
    const p = join(root, dir);
    let entries = [];
    try { entries = readdirSync(p); } catch { continue; }
    for (const f of entries) { const t = read(join(p, f)); if (t) wired.push(t); }
  }
  const called = wired.some((w) => lintNames.some((n) => new RegExp(`(npm|pnpm|yarn|bun)\\s+(run\\s+)?${n}\\b`).test(w)));
  if (!called) problems.push(`a lint script exists (${lintNames.join(', ')}) but no gate or CI step runs it`);
}

if (problems.length) {
  console.error('  lint coverage has a hole:');
  for (const p of problems.slice(0, 20)) console.error(`    ${p}`);
  process.exit(1);
}
const hasLint = lintNames.length > 0 || ignores.length > 0;
console.log(hasLint
  ? `  ok   ${sources.length} source file(s), none under an excluded path; lint is wired`
  : `  ok   no linter configured in this repo, so there is nothing excluded (looked for: .eslintignore, .prettierignore, eslint flat config, lint scripts)`);
process.exit(0);
