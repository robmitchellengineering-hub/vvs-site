#!/usr/bin/env node
// Reference guard — invariant 31: "a parser is not a type-checker".
//
// THE INCIDENT SHAPE. A formatter or a linter parses every file, so a green lint run feels like proof the code is sound. It says nothing
// about whether the types line up: `tsc` and a linter answer different questions, and a repo can ship a lint script while the type-check
// script exists but nothing ever calls it.
//
// WHAT THIS CHECKS. If a repo has TypeScript (a tsconfig, or typescript in the dependencies), then:
//   1. a script that runs `tsc` exists (a `typecheck`, `check:types`, `tsc` or `build:types` script, or `build` invoking tsc), and
//   2. something actually runs it — a gate command in valiant.json, a CI workflow step, or a hook.
// A type-check script that nothing calls is the same silence as not having one.
//
// WHAT IT DOES NOT DO. It does not run tsc (that is the gate's job — this guard proves the wiring exists), and a repo with no TypeScript
// is told so explicitly rather than passing silently.
//
// Usage: node typecheck-is-real.mjs [dir]   (exit 0 = wired, 1 = TypeScript present and unwired)
import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';

const root = resolve(process.argv[2] || '.');
const read = (p) => { try { return readFileSync(p, 'utf8'); } catch { return null; } };
const json = (p) => { const t = read(p); if (!t) return null; try { return JSON.parse(t); } catch { return null; } };

const hasTsconfig = ['tsconfig.json', 'tsconfig.base.json', 'jsconfig.json'].some((f) => existsSync(join(root, f)));
const pkg = json(join(root, 'package.json'));
const deps = { ...(pkg?.dependencies ?? {}), ...(pkg?.devDependencies ?? {}) };
const hasTypescript = 'typescript' in deps;

if (!hasTsconfig && !hasTypescript) {
  console.log('  ok   no TypeScript in this repo, so there is no type contract to wire (this is not a silent pass: it was looked for)');
  process.exit(0);
}

// 1. a script that actually runs tsc
const scripts = pkg?.scripts ?? {};
const runsTsc = Object.entries(scripts).filter(([, cmd]) => /\btsc\b/.test(String(cmd)));
if (!runsTsc.length) {
  console.error('  TypeScript is present, but no package.json script runs `tsc` — a linter parsing the files is not a type-check.');
  console.error(`  scripts found: ${Object.keys(scripts).join(', ') || 'none'}`);
  process.exit(1);
}

// 2. something calls it: a gate, a CI step, or a documented hook
const wired = [];
const cfg = json(join(root, 'valiant.json'));
for (const g of cfg?.gates ?? []) wired.push(`valiant.json gate "${g.name}": ${[].concat(g.cmd ?? []).join(' ')}`);
for (const dir of ['.github/workflows', '.gitlab-ci.yml']) {
  const p = join(root, dir);
  if (dir.endsWith('.yml')) { const t = read(p); if (t) wired.push(`.gitlab-ci.yml`); continue; }
  let entries = [];
  try { entries = readdirSync(p); } catch { continue; }
  for (const f of entries) { const t = read(join(p, f)); if (t) wired.push(`.github/workflows/${f}\n${t}`); }
}
const names = runsTsc.map(([n]) => n);
const called = wired.some((w) => names.some((n) => new RegExp(`(npm|pnpm|yarn|bun)\\s+(run\\s+)?${n}\\b`).test(w) || w.includes(`tsc`)));
if (!called) {
  console.error(`  a type-check script exists (${names.join(', ')}) but nothing runs it — no gate, no CI step.`);
  console.error('  This is the exact silence the invariant names: the check exists and is never asked.');
  process.exit(1);
}
console.log(`  ok   TypeScript is wired: ${names.join(', ')} runs tsc and something calls it`);
process.exit(0);
