#!/usr/bin/env node
// pipeline-masks-status.mjs — invariant 29: a pipeline must not mask the status it exists to report.
//
// THE INCIDENT. A verification job printed "PASS: clippy and the tests" while BOTH had failed, because the
// command ended with a test run piped into `tail -30` — and a pipeline returns the status of its LAST element,
// which is tail. The exit code was never wrong; it was never consulted.
//
// WHY A GUARD AND NOT A RULE. "Don't pipe a check into a filter" is a rule people agree with and then break,
// because the pipeline looks tidier and the failure is invisible until it matters. This reads the files where
// it happens — shell scripts, Makefiles, CI workflows, package.json scripts — and fails on the pattern.
//
// WHAT IT DOES NOT FLAG, deliberately: a pipeline already inside `set -o pipefail`, anything using PIPESTATUS,
// and a pipe whose non-zero status is handled explicitly. A guard that cries wolf gets switched off.
//
//   node pipeline-masks-status.mjs [repoRoot]     exit 0 clean · 1 masking pipelines found
import { readFileSync, existsSync, readdirSync } from "node:fs";
import { join, relative } from "node:path";

const ROOT = process.argv[2] || process.cwd();
const SKIP_DIRS = new Set([".git", "node_modules", "dist", "build", ".next", "vendor", "target", ".venv"]);
const SHELL_EXT = /\.(sh|bash|zsh)$/i;
const MASKING = /\|\s*(tail|head|grep|awk|sed|cut|sort|uniq|wc|tr)\b/;
const PROTECTED = /set\s+-[a-z]*o\s+pipefail|set\s+-[a-z]*e[a-z]*|PIPESTATUS|\|\|\s*(true|:|exit 0|echo )/;

function* walk(dir) {
  let entries;
  try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of entries) {
    if (e.isDirectory()) {
      if (!SKIP_DIRS.has(e.name)) yield* walk(join(dir, e.name));
      continue;
    }
    if (!e.isFile()) continue;
    const p = join(dir, e.name);
    const rel = relative(ROOT, p);
    const isShell = SHELL_EXT.test(e.name);
    const isCi = /(^|\/)\.github\/workflows\/[^/]+\.ya?ml$/.test(rel) || /(^|\/)(Makefile|makefile)$/.test(rel);
    if (isShell || isCi) yield { p, rel, kind: isShell ? "shell" : "ci" };
  }
}

const findings = [];
let scanned = 0;

for (const { p, rel, kind } of walk(ROOT)) {
  let text;
  try { text = readFileSync(p, "utf8"); } catch { continue; }
  scanned++;
  const lines = text.split("\n");
  // A shell file that declares pipefail is safe for its whole body.
  const fileProtected = kind === "shell" && /set\s+-[a-z]*o\s+pipefail|set\s+-[a-z]*e[a-z]*/.test(text);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.trim().startsWith("#")) continue;
    if (!MASKING.test(line)) continue;
    if (fileProtected || PROTECTED.test(line)) continue;
    findings.push({ rel, line: i + 1, text: line.trim().slice(0, 110) });
  }
}

// package.json scripts are the other place people pipe a check into a filter.
const pkgPath = join(ROOT, "package.json");
if (existsSync(pkgPath)) {
  try {
    const scripts = JSON.parse(readFileSync(pkgPath, "utf8")).scripts || {};
    for (const [name, cmd] of Object.entries(scripts)) {
      if (MASKING.test(cmd) && !PROTECTED.test(cmd)) {
        findings.push({ rel: "package.json", line: 0, text: `"${name}": ${cmd}`.slice(0, 110) });
      }
    }
  } catch { /* an unreadable package.json is another guard's problem */ }
}

console.log(`\n  scanned ${scanned} shell/CI file(s) under ${ROOT}\n`);
if (findings.length === 0) {
  console.log("  PASS   no pipeline masks the status it reports\n");
  process.exit(0);
}
for (const f of findings) {
  console.log(`  FAIL   ${f.rel}${f.line ? `:${f.line}` : ""}  ${f.text}`);
}
console.error(`\npipeline-masks-status: ${findings.length} pipeline(s) return the filter's status, not the check's.`);
console.error("Fix: `set -o pipefail` at the top of the script, or capture the status before piping.");
process.exit(1);
