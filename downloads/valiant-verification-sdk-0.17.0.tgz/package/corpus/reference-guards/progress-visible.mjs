#!/usr/bin/env node
// Reference guard — invariant 28: "a stalled process is distinguishable from a slow one".
//
// THE INCIDENT SHAPE. A worker runs for forty minutes with no output. Is it working or wedged? Nobody can tell, so the answer is a guess:
// wait longer (and if it is wedged, lose the time) or kill it (and if it is working, lose the work). The rule: long-running work exposes
// LAST-PROGRESS TIME, so "still going" and "wedged" become different observations instead of the same word.
//
// WHAT THIS CHECKS. A file that runs a loop open-endedly — `while (true)`, `for (;;)`, `setInterval(` — or whose name says it is a
// long-runner (worker, daemon, watch, poll, runner, loop) must write progress evidence: a heartbeat, a progress/last-progress value, a
// status file, or an explicit touch. Test files are skipped, because a loop fixture is a fixture and not a daemon.
//
// WHAT IT DOES NOT DO. It cannot tell whether the heartbeat is written often enough, and it cannot see a loop that recurses instead of
// iterating. It also cannot judge a script that runs long only for large inputs — the naming and the open-ended loop are the signals
// available in a tree, and that limit is stated rather than hidden.
//
// Usage: node progress-visible.mjs [dir]   (exit 0 = every long-runner reports progress, 1 = a silent one)
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';

const root = resolve(process.argv[2] || '.');
const SKIP = new Set(['node_modules', '.git', 'dist', 'build', 'target', '.venv', '__pycache__', '.vv', '.playwright']);
const SKIP_PATHS = [/reference-guards[\\/]/, /selftest-|\\.test\\.|__fixtures__/, /\\.md$/];
const EXTS = ['.mjs', '.js', '.cjs', '.ts', '.sh', '.ps1'];
const LONG_NAME = /(worker|daemon|watch|poll|runner|loop|scheduler|consumer)/i;
const OPEN_LOOP = /(while\s*\(\s*(true|1)\s*\)|for\s*\(\s*;\s*;\s*\)|setInterval\s*\()/;
const PROGRESS = /(heartbeat|last[_-]?progress|progress[_-]?at|progressAt|status\.json|touch\s*\(|writeFileSync\([^)]*progress)/i;

const problems = [];
let checked = 0;
function walk(dir) {
  let entries = [];
  try { entries = readdirSync(dir); } catch { return; }
  for (const e of entries) {
    if (SKIP.has(e)) continue;
    const p = join(dir, e);
    if (SKIP_PATHS.some((re) => re.test(p))) continue;
    let s = null;
    try { s = statSync(p); } catch { continue; }
    if (s.isDirectory()) { walk(p); continue; }
    if (!EXTS.some((x) => e.endsWith(x))) continue;
    let src = '';
    try { src = readFileSync(p, 'utf8'); } catch { continue; }
    const longByName = LONG_NAME.test(e);
    const longByShape = OPEN_LOOP.test(src);
    if (!longByName && !longByShape) continue;
    checked++;
    if (!PROGRESS.test(src)) {
      const why = longByName && longByShape ? 'its name says long-runner and it loops open-endedly'
        : longByName ? 'its name says long-runner' : 'it loops open-endedly';
      problems.push(`${relative(root, p)}: ${why}, but it never reports progress — a stall would look exactly like slow work`);
    }
  }
}
walk(root);

if (problems.length) {
  console.error('  long-running work with no last-progress signal:');
  for (const p of problems.slice(0, 20)) console.error(`    ${p}`);
  process.exit(1);
}
console.log(`  ok   ${checked} long-running file(s) checked; every one exposes progress`);
process.exit(0);
