#!/usr/bin/env node
// Reference guard — invariant 36: "stable context first, volatile last".
//
// Context is a cache asset: stable bytes first, volatile state later, and say nothing when the answer is the default. A builder that puts
// `now()` in the middle of the instruction block invalidates the cache for every request, and the cost is invisible until the bill arrives.
//
// WHAT THIS CHECKS. The module declared as `conventions.context` must mark its parts, and no part marked `stable: true` may contain a volatile
// marker (a clock, a random value, an environment read, the working directory, a git call). If the module declares an ORDER, a volatile part
// may not appear before a stable one.
//
// WHAT IT DOES NOT DO. It reads the source; it does not run the builder (that is #35/#22 territory), so a builder that computes volatility at
// run time is out of its reach — stated, not hidden.
import { readFileSync, existsSync } from "node:fs";
import { join, resolve } from "node:path";
import { readConventions, CONVENTIONS, unenforced } from "../../src/conventions.mjs";

const root = resolve(process.argv[2] || ".");
const cfgPath = join(root, "valiant.json");
if (!existsSync(cfgPath)) { console.log("  ok   no valiant.json: nothing is adopted here"); process.exit(0); }
const cfg = JSON.parse(readFileSync(cfgPath, "utf8"));
const c = CONVENTIONS.find((x) => x.key === "context");
const { declared, problems } = readConventions(cfg, root);
const mine = problems.filter((p) => p.key === "context");
if (mine.length) { console.error(`  ${mine.map((m) => m.why).join("; ")}`); process.exit(1); }
if (declared.context === undefined) { console.log("  " + unenforced(c)); process.exit(0); }

const file = join(root, declared.context);
if (!existsSync(file)) { console.error(`  conventions.context names ${declared.context}, which does not exist`); process.exit(1); }
const src = readFileSync(file, "utf8");
const VOLATILE = /(Date\.now|new Date\(|Math\.random|randomUUID|process\.env|process\.cwd|execSync|spawnSync)/;

// Every object literal that marks itself stable, with the text up to its closing brace.
const blocks = [...src.matchAll(/stable\s*:\s*true[^}]*\}/g)].map((m) => m[0]);
const bad = blocks.filter((b) => VOLATILE.test(b));
if (bad.length) {
  console.error(`  ${declared.context}: ${bad.length} part(s) marked stable:true contain a volatile value (${VOLATILE.exec(bad[0])?.[1]}):`);
  console.error(`    ${bad[0].replace(/\s+/g, " ").slice(0, 140)}`);
  console.error("  A stable block that changes between calls is not stable, and it defeats the cache it is meant to protect.");
  process.exit(1);
}

// Ordering, when the module declares one: the first volatile part may not precede the last stable one.
const marks = [...src.matchAll(/stable\s*:\s*(true|false)/g)].map((m) => m[1] === "true");
const lastStable = marks.lastIndexOf(true);
const firstVolatile = marks.indexOf(false);
if (lastStable !== -1 && firstVolatile !== -1 && firstVolatile < lastStable) {
  console.error(`  ${declared.context}: a volatile part is declared at position ${firstVolatile} but a stable part follows at ${lastStable} — stable must come first`);
  process.exit(1);
}
console.log(`  ok   ${declared.context}: ${blocks.length} stable part(s), none volatile, stable before volatile`);
process.exit(0);
