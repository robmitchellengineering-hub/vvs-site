#!/usr/bin/env node
// Reference guard — invariant 40: "a UI change is verified by looking at it".
//
// A build proves a page mounts. A snapshot proves a string matched. Neither proves the page renders: layout, clipping, an empty state, a button
// that is off-screen. The rule: a change that touches UI carries a screenshot someone could look at.
//
// WHAT THIS CHECKS. With `conventions.ui` declared (`roots` + `screenshots`), any UI file that changed must have a screenshot in the screenshots
// directory. "Changed" is decided by the repo's own VCS when available (git diff against HEAD, plus untracked files under a root); with no VCS the
// guard says it cannot tell and does not pretend a change did not happen.
//
// WHAT IT DOES NOT DO. It cannot judge whether the screenshot shows a correct page — that is a reviewer's job, and the guard's job is to make sure
// there is something to look at.
import { readFileSync, existsSync, readdirSync, statSync } from "node:fs";
import { join, resolve, relative } from "node:path";
import { spawnSync } from "node:child_process";
import { readConventions, CONVENTIONS, unenforced } from "../../src/conventions.mjs";

const root = resolve(process.argv[2] || ".");
const cfgPath = join(root, "valiant.json");
if (!existsSync(cfgPath)) { console.log("  ok   no valiant.json: nothing is adopted here"); process.exit(0); }
const cfg = JSON.parse(readFileSync(cfgPath, "utf8"));
const c = CONVENTIONS.find((x) => x.key === "ui");
const { declared, problems } = readConventions(cfg, root);
const mine = problems.filter((p) => p.key === "ui");
if (mine.length) { console.error(`  ${mine.map((m) => m.why).join("; ")}`); process.exit(1); }
if (declared.ui === undefined) { console.log("  " + unenforced(c)); process.exit(0); }

const { roots, screenshots } = declared.ui;
const UI = /\.(jsx|tsx|vue|svelte|html|css|scss)$/i;
const walk = (dir, out = []) => {
  let entries = [];
  try { entries = readdirSync(dir); } catch { return out; }
  for (const e of entries) {
    if (e === "node_modules" || e === ".git") continue;
    const p = join(dir, e);
    let s = null; try { s = statSync(p); } catch { continue; }
    if (s.isDirectory()) walk(p, out); else if (UI.test(e)) out.push(p);
  }
  return out;
};
const changedIn = (files) => {
  const git = spawnSync("git", ["-C", root, "rev-parse", "--is-inside-work-tree"], { encoding: "utf8" });
  if ((git.status ?? 1) !== 0) return null;                       // no VCS: cannot tell what changed
  const diff = spawnSync("git", ["-C", root, "status", "--porcelain", "--untracked-files=all"], { encoding: "utf8" });
  const touched = new Set((diff.stdout || "").split("\n").filter(Boolean).map((l) => l.slice(3).trim()));
  return files.filter((f) => touched.has(relative(root, f)));
};

const uiFiles = roots.flatMap((r) => walk(join(root, r)));
const changed = changedIn(uiFiles);
if (changed === null) { console.log("  " + unenforced({ ...c, what: "needs a VCS to know which UI files changed — run this inside the repo's git worktree" })); process.exit(0); }
if (!changed.length) { console.log(`  ok   no UI file changed (${uiFiles.length} under ${roots.join(", ")})`); process.exit(0); }

const shotDir = join(root, screenshots);
const shots = existsSync(shotDir) ? readdirSync(shotDir).filter((f) => /\.(png|jpe?g|webp)$/i.test(f)) : [];
if (!shots.length) {
  console.error(`  ${changed.length} UI file(s) changed but ${screenshots} holds no image:`);
  for (const f of changed.slice(0, 5)) console.error(`    ${relative(root, f)}`);
  console.error(`  A passing build proves the page mounts, not that it renders. Screenshot the change into ${screenshots}/ and look at it.`);
  process.exit(1);
}
console.log(`  ok   ${changed.length} UI file(s) changed and ${shots.length} screenshot(s) are there to look at`);
process.exit(0);
