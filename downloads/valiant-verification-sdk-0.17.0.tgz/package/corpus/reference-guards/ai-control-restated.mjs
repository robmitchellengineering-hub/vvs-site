#!/usr/bin/env node
// ai-control-restated.mjs — reference guard (AI control standard).
//
// THE ASKED-VS-MEANT GAP (Aza Raskin's "alien intelligence"): an AI optimises what you
// literally wrote, not what you meant. This guard closes the gap mechanically — before an
// agent acts it must record what it *means* (`restated`), so the human can catch the
// misreading BEFORE the action, not after. Every action line must carry a non-empty `restated`.
//
// Convention: ai-actions.jsonl, one NDJSON line per action, with a `restated` field.
// Exit 0 = every action restated (or nothing recorded) · 1 = an unrestated action exists.
import { readFileSync, existsSync } from "node:fs";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

const LEDGER = "ai-actions.jsonl";

export function check(dir) {
  const p = join(resolve(dir), LEDGER);
  if (!existsSync(p)) return { ok: true, detail: "no action ledger — nothing recorded" };
  const lines = readFileSync(p, "utf8").split("\n").filter((l) => l.trim());
  const bad = [];
  lines.forEach((l, i) => {
    let a;
    try { a = JSON.parse(l); } catch { return; }
    if (typeof a.restated !== "string" || !a.restated.trim()) bad.push(`line ${i + 1}: "${String(a.action ?? "").slice(0, 40)}" was never restated — the asked-vs-meant gap was not checked`);
  });
  return { ok: bad.length === 0, detail: bad.length ? bad.join(" · ") : `${lines.length} action(s), all restated` };
}

const IS_MAIN = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;
if (IS_MAIN) {
  if (process.argv.includes("--self-test")) {
    const { mkdtempSync, writeFileSync, rmSync } = await import("node:fs");
    const { tmpdir } = await import("node:os");
    let fail = 0;
    const good = mkdtempSync(join(tmpdir(), "ars-")); writeFileSync(join(good, LEDGER), '{"action":"write a","restated":"I will write file a and nothing else"}\n');
    if (!check(good).ok) { console.error("FAIL: a fully-restated ledger should pass"); fail++; }
    const bad = mkdtempSync(join(tmpdir(), "ars-")); writeFileSync(join(bad, LEDGER), '{"action":"write a","restated":""}\n');
    if (check(bad).ok) { console.error("FAIL: a missing restatement must go red"); fail++; }
    rmSync(good, { recursive: true, force: true }); rmSync(bad, { recursive: true, force: true });
    console.log(`ai-control-restated: ${fail === 0 ? "PASS" : "FAIL"} self-test`);
    process.exit(fail ? 1 : 0);
  }
  const r = check(process.argv[2] || ".");
  if (r.ok) process.exit(0);
  console.error(`ai-control-restated: ${r.detail}`);
  process.exit(1);
}
