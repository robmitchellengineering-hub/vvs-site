#!/usr/bin/env node
// Reference guard — invariant 12: "data isolation is a decision."
//
// A query against a table that HAS a tenant column, with no tenant predicate, reads every tenant's rows. This guard
// reads SQL and Prisma-style calls and reports the ones that touch a tenant table without naming the tenant column.
//
// Configuration (default ./tenant-tables.json):
//   { "tables": [ { "name": "documents", "tenant": "org_id" } ] }
// Usage: node tenant-predicate.mjs [dir]   (exit 0 = every tenant query is scoped, 1 = one is not)
import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';

const root = resolve(process.argv[2] || '.');
const cfgPath = process.env.TENANT_CFG || join(root, 'tenant-tables.json');
if (!existsSync(cfgPath)) { console.log('tenant-predicate: no tenant-tables.json — nothing declared'); process.exit(0); }
let cfg;
try { cfg = JSON.parse(readFileSync(cfgPath, 'utf8')); } catch (e) { console.log(`  CANNOT-CHECK ${e.message}`); process.exit(2); }
const tables = Array.isArray(cfg.tables) ? cfg.tables : [];
if (!tables.length) { console.log('  CANNOT-CHECK no tables declared — an empty list is not a pass'); process.exit(2); }

const SKIP = new Set(['node_modules', '.git', 'dist', 'build', '.venv', '__pycache__', 'target', 'migrations']);
const files = [];
(function walk(dir) {
  let entries = [];
  try { entries = readdirSync(dir); } catch { return; }
  for (const e of entries) {
    if (SKIP.has(e)) continue;
    const p = join(dir, e);
    let s = null;
    try { s = statSync(p); } catch { continue; }
    if (s.isDirectory()) { walk(p); continue; }
    if (/\.(mjs|cjs|js|ts|tsx|sql|prisma)$/.test(e)) files.push(p);
  }
})(root);

let bad = 0;
for (const f of files) {
  const lines = readFileSync(f, 'utf8').split('\n');
  for (const t of tables) {
    const ref = new RegExp(`\\b(from|into|update|join|model)\\s+["'\`]?${t.name}\\b|\\b${t.name}\\s*\\.\\s*(findMany|findFirst|findUnique|updateMany|deleteMany|count)\\b`, 'i');
    lines.forEach((line, i) => {
      if (!ref.test(line)) return;
      // The predicate may be on the same line or the next two (a Prisma call is often formatted over several).
      const window = lines.slice(i, i + 3).join(' ');
      if (new RegExp(`\\b${t.tenant}\\b`, 'i').test(window)) return;
      if (/\/\/\s*no-tenant|isolation-exempt/i.test(line)) return;
      console.log(`  FAIL ${relative(root, f)}:${i + 1} — reads "${t.name}" with no ${t.tenant} predicate`);
      bad++;
    });
  }
}
if (!bad) console.log(`  ok   ${files.length} file(s): every query against a tenant table is scoped`);
process.exit(bad ? 1 : 0);
