#!/usr/bin/env node
// Reference guard — invariant 3: "bound the model's output".
//
// THE INCIDENT SHAPE. A call that can produce long output without an explicit budget gets the provider's default, which is often far
// below what the answer needed — so the reply is silently cut, the caller treats a truncated document as a complete one, and the defect
// looks like the model being wrong rather than the request being unbounded. The rule: set a budget, and treat truncation as an ERROR.
//
// WHAT THIS CHECKS.
//   1. every file that calls a model API declares a budget (`max_tokens`, `max_completion_tokens`, `max_output_tokens`, `num_predict`);
//   2. if the file inspects a finish/stop reason, the "hit the cap" branch is handled — a `length` / `max_tokens` value must appear,
//      because that is the branch that turns a silent cut into a stated failure.
//
// WHAT IT DOES NOT DO. It cannot tell whether the NUMBER is big enough for the task — only that a number was chosen deliberately. A
// budget of 10 would pass this guard and still truncate; that is a judgement a reviewer makes, and this guard does not pretend otherwise.
//
// Skips its own source and tests that assert the rule, because a fixture must contain the fault it demonstrates.
//
// Usage: node model-call-budget.mjs [dir]   (exit 0 = every model call is bounded, 1 = an unbounded call)
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';

const root = resolve(process.argv[2] || '.');
const SKIP = new Set(['node_modules', '.git', 'dist', 'build', 'target', '.venv', '__pycache__', '.vv', '.playwright']);
const SKIP_PATHS = [/reference-guards[\\/]/, /selftest-|\\.test\\.|__fixtures__/, /\\.md$/];
const EXTS = ['.mjs', '.js', '.cjs', '.ts', '.tsx'];
const LOOK = ['.mjs', '.js', '.cjs', '.ts', '.tsx'];

// A CALL, not a mention. The first version matched vendor names, so a COMMENT quoting Rob — "anthropic is about to go public" — was
// reported as an unbounded model call. Both halves are needed: a call shape, and on a line that is not a comment.
const CALL = /(chat\/completions|messages\.create\s*\(|generateContent\s*\(|generateText\s*\(|\/api\/generate|\/api\/chat)/i;
const BUDGET = /(max_tokens|maxTokens|max_completion_tokens|max_output_tokens|num_predict|maxOutputTokens|budgetTokens)/;
const TRUNCATION_REASON = /(finish_reason|finishReason|stop_reason|stopReason|done_reason)/;
const TRUNCATION_BRANCH = /(length|max_tokens|maxTokens|MAX_TOKENS)/;

const problems = [];
let checked = 0;
function walk(dir) {
  let entries = [];
  try { entries = readdirSync(dir); } catch { return; }
  for (const e of entries) {
    if (SKIP.has(e)) continue;
    const p = join(dir, e);
    if (SKIP_PATHS.some((re) => re.test(p))) continue;
    let s = null;
    try { s = statSync(p); } catch { continue; }
    if (s.isDirectory()) { walk(p); continue; }
    if (!LOOK.some((x) => e.endsWith(x)) || /\.min\./.test(e)) continue;
    let src = '';
    try { src = readFileSync(p, 'utf8'); } catch { continue; }
    // Comments are prose about a provider, not a request to one.
    const code = src.split('\n').filter((line) => {
      const t = line.trim();
      return t && !t.startsWith('//') && !t.startsWith('*') && !t.startsWith('/*');
    }).join('\n');
    if (!CALL.test(code)) continue;
    checked++;
    const rel = relative(root, p);
    if (!BUDGET.test(src)) {
      problems.push(`${rel}: calls a model but declares no output budget (max_tokens / max_completion_tokens / num_predict)`);
      continue;
    }
    if (TRUNCATION_REASON.test(src) && !TRUNCATION_BRANCH.test(src)) {
      problems.push(`${rel}: reads a finish/stop reason but never handles the "hit the cap" branch — a cut reply would read as complete`);
    }
  }
}
walk(root);

if (problems.length) {
  console.error('  unbounded model output (a truncated reply must be an error, not a silent cut):');
  for (const p of problems.slice(0, 20)) console.error(`    ${p}`);
  process.exit(1);
}
console.log(`  ok   ${checked} file(s) call a model; every one declares a budget`);
process.exit(0);
