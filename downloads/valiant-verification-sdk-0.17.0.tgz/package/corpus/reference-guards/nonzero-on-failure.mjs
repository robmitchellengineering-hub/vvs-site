#!/usr/bin/env node
// Reference guard — invariant 24: "a tool that cannot do its job exits non-zero."
//
// A check that prints PASS and exits 0 when its input is broken is worse than no check: it is a check that teaches
// people to trust a green. The guard runs a declared check against a deliberately broken fixture and FAILS if the
// check still exits 0.
//
// Configuration (a JSON file, default ./nonzero-on-failure.json):
//   { "checks": [ { "name": "...", "cmd": ["node", "tool.mjs"], "broken": "fixtures/broken.json" } ] }
// The fixture path is appended to the command.
// Usage: node nonzero-on-failure.mjs [dir]   (exit 0 = every check refuses a broken input, 1 = one accepts it)
import { readFileSync, existsSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';

const root = resolve(process.argv[2] || '.');
const cfgPath = process.env.NONZERO_CFG || join(root, 'nonzero-on-failure.json');
if (!existsSync(cfgPath)) {
  console.log('nonzero-on-failure: no nonzero-on-failure.json — nothing declared to check');
  process.exit(0);
}
let cfg;
try { cfg = JSON.parse(readFileSync(cfgPath, 'utf8')); } catch (e) {
  console.log(`  CANNOT-CHECK the configuration is not valid JSON (${e.message})`);
  process.exit(2);
}
const checks = Array.isArray(cfg.checks) ? cfg.checks : [];
if (checks.length === 0) { console.log('  CANNOT-CHECK no checks declared — an empty list is not a pass'); process.exit(2); }

let bad = 0;
for (const c of checks) {
  if (!c.name || !Array.isArray(c.cmd) || !c.cmd.length || !c.broken) {
    console.log(`  CANNOT-CHECK ${c.name ?? '(unnamed)'} — needs "name", "cmd" and "broken"`);
    bad++;
    continue;
  }
  const r = spawnSync(c.cmd[0], [...c.cmd.slice(1), c.broken], { cwd: root, encoding: 'utf8', timeout: 300_000 });
  if (r.error) { console.log(`  CANNOT-CHECK ${c.name} — could not run (${r.error.code})`); bad++; continue; }
  if ((r.status ?? 0) === 0) {
    console.log(`  FAIL ${c.name} — accepted a broken input (exit 0). A check that cannot fail cannot be trusted.`);
    bad++;
  } else {
    console.log(`  ok   ${c.name} — refused the broken input (exit ${r.status})`);
  }
}
process.exit(bad ? 1 : 0);
