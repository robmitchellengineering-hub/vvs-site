#!/usr/bin/env node
// Reference guard — invariant 1: "contract integrity".
//
// Adding an export is safe. REMOVING or renaming one is not: every caller must be updated in the same change, or the import resolves to
// `undefined` and the failure surfaces somewhere unrelated — often in production, often as `TypeError: x is not a function`.
//
// WHAT THIS CHECKS. Every named import in the tree that points at a file in the same tree must name something that file exports. It is a
// static check of the contract between modules, and it needs no build, no install and no type checker — which is why it can run on every
// gate rather than in a job someone remembers.
//
// WHAT IT DOES NOT DO. It does not resolve package imports (those are someone else's contract), and it does not check default exports
// against re-exports through a barrel file more than one hop deep — a limitation stated rather than hidden.
//
// Usage: node contract-integrity.mjs [dir]   (exit 0 = every import names an export, 1 = a broken contract)
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, resolve, relative, dirname } from 'node:path';

const root = resolve(process.argv[2] || '.');
const SKIP = new Set(['node_modules', '.git', 'dist', 'build', 'target', '.venv', '__pycache__', '.vv', '.playwright']);
const EXTS = ['.mjs', '.js', '.cjs', '.ts', '.tsx', '.jsx'];
const files = [];
(function walk(dir) {
  let entries = [];
  try { entries = readdirSync(dir); } catch { return; }
  for (const e of entries) {
    if (SKIP.has(e)) continue;
    const p = join(dir, e);
    let s = null;
    try { s = statSync(p); } catch { continue; }
    if (s.isDirectory()) { walk(p); continue; }
    if (EXTS.some((x) => e.endsWith(x)) && !/\.min\./.test(e)) files.push(p);
  }
})(root);

/** The names a file exports: `export function x`, `export const x`, `export class x`, `export { a, b }`, `export { a as b }`. */
function exportsOf(file) {
  let src = '';
  try { src = readFileSync(file, 'utf8'); } catch { return null; }
  const names = new Set();
  for (const m of src.matchAll(/export\s+(?:async\s+)?(?:function|const|let|var|class)\s+([A-Za-z_$][\w$]*)/g)) names.add(m[1]);
  const groups = new RegExp("export\\s*\\{([^}]+)\\}", "g");
  for (const m of src.matchAll(groups)) {
    for (const part of m[1].split(',')) {
      const t = part.trim();
      if (!t) continue;
      const as = /\bas\s+([A-Za-z_$][\w$]*)$/.exec(t);       // export { a as b }
      names.add(as ? as[1] : t.split(/\s+/)[0]);
    }
  }
  return names;
}

/** Named imports with their specifier, so a missing name can be compared against the target's exports. */
function namedImports(src) {
  const out = [];
  const named = new RegExp("import\\s*\\{([^}]+)\\}\\s*from\\s*['\"]([^'\"]+)['\"]", "g");
  for (const m of src.matchAll(named)) {
    const names = m[1].split(',').map((s) => s.trim()).filter(Boolean)
      .map((s) => (/\bas\s+([A-Za-z_$][\w$]*)$/.exec(s) ? /\bas\s+([A-Za-z_$][\w$]*)$/.exec(s)[1] : s.split(/\s+/)[0]));
    out.push({ names, from: m[2] });
  }
  return out;
}

const problems = [];
const cache = new Map();
let checked = 0;
for (const f of files) {
  let src = '';
  try { src = readFileSync(f, 'utf8'); } catch { continue; }
  for (const imp of namedImports(src)) {
    if (!imp.from.startsWith('.')) continue;                       // a package: not our contract
    const base = resolve(dirname(f), imp.from);
    const target = [base, ...EXTS.map((e) => base + e), ...EXTS.map((e) => join(base, 'index' + e))].find((p) => existsSync(p) && statSync(p).isFile());
    if (!target) continue;                                          // unresolved import: not this guard's rule
    let names = cache.get(target);
    if (names === undefined) { names = exportsOf(target); cache.set(target, names); }
    if (!names) continue;
    checked++;
    for (const n of imp.names) {
      if (!names.has(n)) problems.push(`${relative(root, f)} imports "${n}" from ${imp.from}, but ${relative(root, target)} does not export it`);
    }
  }
}

if (problems.length) {
  console.error('  broken contracts (an export was removed or renamed without updating its callers):');
  for (const p of problems.slice(0, 25)) console.error(`    ${p}`);
  if (problems.length > 25) console.error(`    …and ${problems.length - 25} more`);
  process.exit(1);
}
console.log(`  ok   ${checked} named import(s) across ${files.length} file(s) all name a real export`);
process.exit(0);
