#!/usr/bin/env node
// Reference guard — invariant 22: "the loop survives its own queue".
//
// A worker that dies because an item vanished mid-iteration stops processing everything behind it. The rule: one item's error must not kill the
// loop. It is not a style preference — it is the difference between a queue that drains and a queue that wedges at the first race.
//
// THE CONTRACT. `conventions.loop.entry` names a runnable worker that consumes a directory of items (one file per item). The guard runs it twice
// against a copy of the repo's own fixture: once with every item, and once with an item deleted BETWEEN the two runs, which is what a racing
// producer does. Both runs must exit 0. A worker that only survives a static queue is the bug this rule names.
//
// WHAT IT DOES NOT DO. It does not inspect the worker's logic and cannot see a race it does not trigger; deleting the item between runs reproduces
// the observable half.
import { readFileSync, existsSync, cpSync, rmSync, mkdtempSync, readdirSync } from "node:fs";
import { join, resolve } from "node:path";
import { spawnSync } from "node:child_process";
import { tmpdir } from "node:os";
import { readConventions, CONVENTIONS, unenforced } from "../../src/conventions.mjs";

const root = resolve(process.argv[2] || ".");
const cfgPath = join(root, "valiant.json");
if (!existsSync(cfgPath)) { console.log("  ok   no valiant.json: nothing is adopted here"); process.exit(0); }
const cfg = JSON.parse(readFileSync(cfgPath, "utf8"));
const c = CONVENTIONS.find((x) => x.key === "loop");
const { declared, problems } = readConventions(cfg, root);
const mine = problems.filter((p) => p.key === "loop");
if (mine.length) { console.error(`  ${mine.map((m) => m.why).join("; ")}`); process.exit(1); }
if (declared.loop === undefined) { console.log("  " + unenforced(c)); process.exit(0); }

const { entry, queue } = declared.loop;
if (!queue) { console.log("  " + unenforced({ ...c, what: 'needs "queue": the directory of items the worker consumes' })); process.exit(0); }
const queueDir = join(root, queue);
if (!existsSync(queueDir)) { console.error(`  conventions.loop names queue ${queue}, which does not exist`); process.exit(1); }
const items = readdirSync(queueDir).filter((f) => !f.startsWith("."));
if (items.length < 2) { console.error(`  conventions.loop queue ${queue} holds ${items.length} item(s); the guard needs at least two to remove one`); process.exit(1); }

const work = mkdtempSync(join(tmpdir(), "loop-"));
try {
  cpSync(root, work, { recursive: true, filter: (p) => !/[\\/](\.git|node_modules)$/.test(p) });
  const wq = join(work, queue);
  const run = () => spawnSync(process.execPath, [join(work, entry)], { cwd: work, encoding: "utf8", env: { ...process.env, VALIANT_QUEUE: wq } });
  const all = run();
  if ((all.status ?? 1) !== 0) {
    console.error(`  the loop exited ${all.status} on a FULL queue: ${(all.stderr || "").split("\n")[0].slice(0, 120)}`);
    process.exit(1);
  }
  // a producer removes an item that this worker has already read
  const remaining = readdirSync(wq).filter((f) => !f.startsWith("."));
  if (remaining.length) rmSync(join(wq, remaining[0]), { force: true });
  const raced = run();
  if ((raced.status ?? 1) !== 0) {
    console.error(`  the loop exited ${raced.status} after an item vanished mid-run: ${(raced.stderr || "").split("\n")[0].slice(0, 120)}`);
    console.error("  One vanished item must not stop the rest — that is the whole invariant.");
    process.exit(1);
  }
  console.log(`  ok   the loop survived ${items.length} item(s), then a queue item removed between runs`);
  process.exit(0);
} finally { rmSync(work, { recursive: true, force: true }); }
