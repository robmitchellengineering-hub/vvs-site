#!/usr/bin/env node
// timers-that-loop.mjs — invariant 26: a repeated action cannot run faster than its own interval.
//
// THE INCIDENT. A one-shot restart script was installed under a supervisor configured to relaunch it whenever
// it exits. It exits in a fraction of a second, so the service was restarted every 41 seconds, forty minutes of
// log noise and a machine that looked busy and broken at once. The script was correct; the supervision was not.
//
// WHY A GUARD. "Don't put KeepAlive on a one-shot" is invisible at review time: the plist is 20 lines of XML
// and the dangerous key is one line of it. This reads the supervisor files and fails on the combinations that
// produce a loop.
//
// RULES, each with the failure it prevents:
//   launchd  KeepAlive present AND the program is a script that exits (not a daemon)  -> restart storm
//   launchd  StartInterval below the floor                                            -> hammers the machine
//   systemd  Restart=always on Type=oneshot                                           -> restart storm
//   systemd  Restart=always without RestartSec >= the floor                           -> restart storm
//   cron     an every-minute entry                                                    -> hammers the machine
//
//   node timers-that-loop.mjs [repoRoot]     exit 0 clean · 1 a timer can loop
import { readFileSync, existsSync, readdirSync } from "node:fs";
import { join, relative } from "node:path";

const ROOT = process.argv[2] || process.cwd();
const MIN_INTERVAL_SECONDS = 600; // ten minutes: the floor the mesh's own gate settled on, for a good reason
const SKIP_DIRS = new Set([".git", "node_modules", "dist", "build", ".next", "target", ".venv"]);

function* walk(dir) {
  let entries;
  try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of entries) {
    if (e.isDirectory()) {
      if (!SKIP_DIRS.has(e.name)) yield* walk(join(dir, e.name));
      continue;
    }
    if (!e.isFile()) continue;
    const rel = relative(ROOT, join(dir, e.name));
    if (/\.plist$/i.test(e.name) || /\.(service|timer)$/i.test(e.name) || /(^|\/)crontab$/i.test(rel) || /\.cron$/i.test(e.name)) {
      yield { p: join(dir, e.name), rel };
    }
  }
}

const findings = [];
let scanned = 0;

for (const { p, rel } of walk(ROOT)) {
  let text;
  try { text = readFileSync(p, "utf8"); } catch { continue; }
  scanned++;

  if (/\.plist$/i.test(rel)) {
    const keepAlive = /<key>\s*KeepAlive\s*<\/key>/.test(text);
    const interval = Number((text.match(/<key>\s*StartInterval\s*<\/key>\s*<integer>\s*(\d+)/) || [])[1] || 0);
    if (keepAlive) {
      findings.push({ rel, why: "KeepAlive relaunches it the moment it exits — a one-shot becomes a loop" });
    }
    if (interval && interval < MIN_INTERVAL_SECONDS) {
      findings.push({ rel, why: `StartInterval ${interval}s is below the ${MIN_INTERVAL_SECONDS}s floor` });
    }
  }

  if (/\.(service|timer)$/i.test(rel)) {
    const oneshot = /Type\s*=\s*oneshot/i.test(text);
    const restart = (text.match(/Restart\s*=\s*(\w+)/i) || [])[1] || "";
    const restartSec = Number((text.match(/RestartSec\s*=\s*(\d+)/i) || [])[1] || 0);
    if (oneshot && /always/i.test(restart)) {
      findings.push({ rel, why: "Restart=always on a Type=oneshot unit — it restarts the instant the script ends" });
    }
    if (/always/i.test(restart) && restartSec > 0 && restartSec < 60) {
      findings.push({ rel, why: `RestartSec ${restartSec}s is a restart loop, not a recovery` });
    }
  }

  if (/(^|\/)crontab$/i.test(rel) || /\.cron$/i.test(rel)) {
    for (const line of text.split("\n")) {
      const t = line.trim();
      if (!t || t.startsWith("#")) continue;
      if (/^\*[\s/]/.test(t) || t.startsWith("* * * * *")) {
        findings.push({ rel, why: `every-minute cron entry: ${t.slice(0, 60)}` });
      }
    }
  }
}

console.log(`\n  scanned ${scanned} timer file(s) under ${ROOT}, floor ${MIN_INTERVAL_SECONDS}s\n`);
if (findings.length === 0) {
  console.log("  PASS   no timer can restart faster than its own interval\n");
  process.exit(0);
}
for (const f of findings) console.log(`  FAIL   ${f.rel}  ${f.why}`);
console.error(`\ntimers-that-loop: ${findings.length} timer(s) can run faster than their interval.`);
process.exit(1);
