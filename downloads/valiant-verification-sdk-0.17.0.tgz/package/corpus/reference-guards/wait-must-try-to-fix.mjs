#!/usr/bin/env node
// Reference guard — invariant 43: "a wait loop must attempt the repair it is waiting for."
//
// Born from a real failure (2026-10-31): a delivery script polled for two hours for a status flag to
// change by itself, while the command that changes it (`gh pr update-branch`, a merge, a dispatch) was
// available the whole time and had already been used earlier in the same session. The work was finished;
// the delivery waited on a condition only the session could create.
//
// The rule this encodes: polling is for state an OUTSIDE party must change — a person, a machine that is
// off. If the same script can perform the repair, it must do so, and the loop must show it.
//
// Usage: node wait-must-try-to-fix.mjs [dir]   (exit 0 = every wait loop can repair, 1 = one cannot)
import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';

const root = resolve(process.argv[2] || '.');
const FILE = /\.(sh|bash|zsh|mjs|cjs|js)$/;
const LOOP = [/\bwhile\b[^\n]*\b(true|sleep)\b/, /\bfor i in \$\(seq\b/, /\bwhile\s*:\s*;/, /\bsleep\s+\d+/];
const WAITS_ON = /\bgh pr (view|checks|list)\b|\bgh run (view|list|watch)\b|\bgit (fetch|pull)\b|\bkubectl (get|wait)\b|\bcurl\b/;
const REPAIRS = [
  /\bgh pr update-branch\b/, /\bgh pr merge\b/, /\bgh run rerun\b/, /\bgh workflow run\b/,
  /\bgit push\b/, /\bgit rebase\b/, /\breset\b/, /\brestart\b/, /\bdispatch\b/i, /\bretry\b/i,
];

const files = [];
const collect = (p) => {
  if (!existsSync(p)) return;
  let s = null;
  try { s = statSync(p); } catch { return; }
  if (s.isDirectory()) {
    for (const e of readdirSync(p)) {
      if (e === '.git' || e === 'node_modules') continue;
      collect(join(p, e));
    }
    return;
  }
  if (FILE.test(p)) files.push(p);
};
collect(root);

const offenders = [];
for (const f of files) {
  let text = '';
  try { text = readFileSync(f, 'utf8'); } catch { continue; }
  const isLoop = LOOP.some((re) => re.test(text)) && WAITS_ON.test(text);
  if (!isLoop) continue;
  const repairs = REPAIRS.some((re) => re.test(text));
  if (!repairs) offenders.push(relative(root, f));
}

if (offenders.length === 0) {
  console.log(`wait-must-try-to-fix: every wait loop shows a repair attempt (${files.length} files)`);
  process.exit(0);
}
for (const o of offenders) {
  console.log(`FAIL ${o}: polls for state it could change, and never attempts the change`);
}
console.log('wait-must-try-to-fix: waiting on your own status flag is a machine for converting time into excuses (invariant 43)');
process.exit(1);
