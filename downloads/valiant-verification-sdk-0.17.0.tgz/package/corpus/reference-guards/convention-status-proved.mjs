#!/usr/bin/env node
// Reference guard — invariant 25: "liveness is proved, not inferred".
//
// A status that says "up" because a config file lists the host, because a socket was open once, or because a cached check said so is the shape of
// every outage that reads as healthy. The rule: liveness comes from the thing itself — a fresh reply, or an identity match.
//
// WHAT THIS CHECKS. Each module declared as `conventions.status` must obtain its answer from a live probe (a request, a socket round-trip, a
// process check) AND compare an identity (a pid, a hostname, a version, a uid) — and it may not report up from a cached or adjacent signal alone.
import { readFileSync, existsSync } from "node:fs";
import { join, resolve } from "node:path";
import { readConventions, CONVENTIONS, unenforced } from "../../src/conventions.mjs";

const root = resolve(process.argv[2] || ".");
const cfgPath = join(root, "valiant.json");
if (!existsSync(cfgPath)) { console.log("  ok   no valiant.json: nothing is adopted here"); process.exit(0); }
const cfg = JSON.parse(readFileSync(cfgPath, "utf8"));
const c = CONVENTIONS.find((x) => x.key === "status");
const { declared, problems } = readConventions(cfg, root);
const mine = problems.filter((p) => p.key === "status");
if (mine.length) { console.error(`  ${mine.map((m) => m.why).join("; ")}`); process.exit(1); }
if (declared.status === undefined) { console.log("  " + unenforced(c)); process.exit(0); }

const PROBE = /(fetch\(|https?\.request|net\.connect|createConnection|execSync|spawnSync|kill\(|readFileSync)/;
const IDENTITY = /(pid|hostname|version|uid|identity|service|fingerprint)/i;
const CACHED = /(cache|cached|lastKnown|previous|stale)/i;
const bad = [];
for (const rel of declared.status) {
  const f = join(root, rel);
  if (!existsSync(f)) { bad.push(`${rel}: declared but missing`); continue; }
  const src = readFileSync(f, "utf8");
  if (!PROBE.test(src)) bad.push(`${rel}: reports a status without probing the thing (no request, socket, process or file read)`);
  if (!IDENTITY.test(src)) bad.push(`${rel}: never compares an identity — a reply from the wrong process is not liveness`);
  if (CACHED.test(src) && !PROBE.test(src.replace(/^.*cache.*$/gim, ""))) bad.push(`${rel}: reads a cached state and has no other probe — an inferred "up" is not evidence`);
}
if (bad.length) { console.error("  status that is inferred rather than proved:"); for (const b of bad) console.error(`    ${b}`); process.exit(1); }
console.log(`  ok   ${declared.status.length} status module(s) probe live and match an identity`);
process.exit(0);
