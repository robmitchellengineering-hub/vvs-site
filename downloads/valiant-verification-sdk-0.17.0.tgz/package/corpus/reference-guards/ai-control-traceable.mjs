#!/usr/bin/env node
// ai-control-traceable.mjs — reference guard (AI control standard).
//
// A claim an AI makes about the world must trace to a source the HUMAN can re-open and
// re-check — otherwise "the AI says so" is the only evidence, and the human is not in control
// of the verification. Every action line must carry a non-empty `source`.
//
// Convention: ai-actions.jsonl, one NDJSON line per action, with a `source` field.
// Exit 0 = every action traceable (or nothing recorded) · 1 = an untraceable action exists.
import { readFileSync, existsSync } from "node:fs";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

const LEDGER = "ai-actions.jsonl";

export function check(dir) {
  const p = join(resolve(dir), LEDGER);
  if (!existsSync(p)) return { ok: true, detail: "no action ledger — nothing recorded" };
  const lines = readFileSync(p, "utf8").split("\n").filter((l) => l.trim());
  const bad = [];
  lines.forEach((l, i) => {
    let a;
    try { a = JSON.parse(l); } catch { return; } // a non-JSON line is ai-control-approved's finding
    if (typeof a.source !== "string" || !a.source.trim()) bad.push(`line ${i + 1}: "${String(a.action ?? "").slice(0, 40)}" has no source to re-check`);
  });
  return { ok: bad.length === 0, detail: bad.length ? bad.join(" · ") : `${lines.length} action(s), all traceable` };
}

const IS_MAIN = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;
if (IS_MAIN) {
  if (process.argv.includes("--self-test")) {
    const { mkdtempSync, writeFileSync, rmSync } = await import("node:fs");
    const { tmpdir } = await import("node:os");
    let fail = 0;
    const good = mkdtempSync(join(tmpdir(), "atr-")); writeFileSync(join(good, LEDGER), '{"action":"write a","source":"human: do it"}\n');
    if (!check(good).ok) { console.error("FAIL: a fully-sourced ledger should pass"); fail++; }
    const bad = mkdtempSync(join(tmpdir(), "atr-")); writeFileSync(join(bad, LEDGER), '{"action":"write a","source":""}\n');
    if (check(bad).ok) { console.error("FAIL: a missing source must go red"); fail++; }
    rmSync(good, { recursive: true, force: true }); rmSync(bad, { recursive: true, force: true });
    console.log(`ai-control-traceable: ${fail === 0 ? "PASS" : "FAIL"} self-test`);
    process.exit(fail ? 1 : 0);
  }
  const r = check(process.argv[2] || ".");
  if (r.ok) process.exit(0);
  console.error(`ai-control-traceable: ${r.detail}`);
  process.exit(1);
}
