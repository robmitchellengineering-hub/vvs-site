#!/usr/bin/env node
// Reference guard — invariant 41: "no dead ends".
//
// An error with nothing to press is a defect, not a message. Every failure and empty state must name the next step and offer it as an action.
//
// WHAT THIS CHECKS. In the directories declared as `conventions.errors`, every JSX/TSX/Vue/Svelte element that renders an error or empty state
// (a class or text containing "error", "failed", "empty", "no results") must contain a link, a button, or a handler — an action, not just words.
//
// WHAT IT DOES NOT DO. It does not decide whether the action is the RIGHT one; it refuses a dead end, which is the failure people hit most.
import { readFileSync, existsSync, readdirSync, statSync } from "node:fs";
import { join, resolve, relative } from "node:path";
import { readConventions, CONVENTIONS, unenforced } from "../../src/conventions.mjs";

const root = resolve(process.argv[2] || ".");
const cfgPath = join(root, "valiant.json");
if (!existsSync(cfgPath)) { console.log("  ok   no valiant.json: nothing is adopted here"); process.exit(0); }
const cfg = JSON.parse(readFileSync(cfgPath, "utf8"));
const c = CONVENTIONS.find((x) => x.key === "errors");
const { declared, problems } = readConventions(cfg, root);
const mine = problems.filter((p) => p.key === "errors");
if (mine.length) { console.error(`  ${mine.map((m) => m.why).join("; ")}`); process.exit(1); }
if (declared.errors === undefined) { console.log("  " + unenforced(c)); process.exit(0); }

const EXT = /\.(jsx|tsx|vue|svelte)$/i;
const files = [];
const walk = (dir) => {
  let entries = []; try { entries = readdirSync(dir); } catch { return; }
  for (const e of entries) {
    if (e === "node_modules" || e === ".git") continue;
    const p = join(dir, e); let s = null; try { s = statSync(p); } catch { continue; }
    if (s.isDirectory()) walk(p); else if (EXT.test(e)) files.push(p);
  }
};
for (const d of declared.errors) walk(join(root, d));

// A DEAD END IS AN ELEMENT THAT RENDERS A FAILURE AND OFFERS NOTHING. The first version split the source on tags, which consumed the opening tag —
// and `className="error"` lives there, so the guard found no error state and reported "every error/empty state offers an action" for a page with
// exactly that defect (its own test caught it once the counter was moved to the end).
const ELEMENT = /<(div|section|main|li|ul|p|aside|article)\b([^>]*)>([\s\S]*?)<\/\1>/gi;
const FAILING = /\b(error|errors|failed|failure|empty|no-results|nothing-here)\b|\b(No results?|Nothing (here|yet)|Failed|Error)\b/i;
const ACTION = /(<(a|Link|button|Button|NavLink)\b[^>]*(href|to|onClick)|onClick\s*=|onPress\s*=)/i;
const bad = [];
for (const f of files) {
  const src = readFileSync(f, 'utf8');
  for (const m of src.matchAll(ELEMENT)) {
    const attrs = m[2] ?? "";
    const inner = m[3] ?? "";
    if (!FAILING.test(attrs) && !FAILING.test(inner)) continue;
    if (ACTION.test(inner)) continue;
    bad.push(`${relative(root, f)}: renders a failure with no action — ${(attrs + " " + inner).replace(/\s+/g, " ").trim().slice(0, 90)}`);
    break;
  }
}
if (bad.length) {
  console.error("  dead ends (a failure the reader cannot act on):");
  for (const b of bad.slice(0, 10)) console.error(`    ${b}`);
  process.exit(1);
}
console.log(`  ok   ${files.length} UI file(s) checked; every error/empty state offers an action`);
process.exit(0);
