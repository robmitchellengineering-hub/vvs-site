#!/usr/bin/env node
// Reference guard — invariant 42: "evidence must reach the verifier."
//
// A diagnostic that writes its evidence only onto the thing under test is not evidence the verifier can
// use — it is a note left inside the patient. Born from a real failure (2026-10-30): an operating system's
// hardware report wrote sshd's refusal reason to the boot stick, and the stick was inside the machine, so
// five image builds were spent on hypotheses the machine could have answered in one line. The report
// existed; the verifier could not read it.
//
// This guard reads a repository's diagnostic scripts and names every one that writes evidence to a subject
// path with no transmission step and no explicit local-only marker.
//
// Usage: node evidence-reaches-verifier.mjs [dir]   (exit 0 = every report can leave, 1 = one cannot)
import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';

const root = resolve(process.argv[2] || '.');
const SUBJECT_PATHS = [/\/efi\b/, /\/persist\b/, /\/mnt\b/, /\/media\b/, /\/run\/media\b/, /\$ESP\b/, /ESP=/];
const TRANSMITS = [
  /\bcurl\b/, /\bwget\b/, /\bnc\s/, /\bnetcat\b/, /\bssh\b/, /\bscp\b/, /\brsync\b/,
  /\bfetch\s*\(/, /\bhttp\.request\b/, /\bhttps?:\/\//, /\bsendmail\b/, /\bmailx\b/,
];
const DIAGNOSTIC = /report|diagnos|telemetry|hwreport|observe|snapshot/i;
const FILE = /\.(sh|bash|zsh|mjs|cjs|js|py)$/;
const LOCAL_ONLY = /local-only:\s*\S+/i;

const files = [];
const collect = (p) => {
  if (!existsSync(p)) return;
  let s = null;
  try { s = statSync(p); } catch { return; }
  if (s.isDirectory()) {
    for (const e of readdirSync(p)) {
      if (e === '.git' || e === 'node_modules') continue;
      collect(join(p, e));
    }
    return;
  }
  if (FILE.test(p)) files.push(p);
};
collect(root);

const offenders = [];
for (const f of files) {
  let text = '';
  try { text = readFileSync(f, 'utf8'); } catch { continue; }
  const name = relative(root, f);
  if (!DIAGNOSTIC.test(text.slice(0, 4000)) && !DIAGNOSTIC.test(name)) continue;
  const writesToSubject = SUBJECT_PATHS.some((re) => re.test(text));
  if (!writesToSubject) continue;
  const canLeave = TRANSMITS.some((re) => re.test(text));
  if (canLeave || LOCAL_ONLY.test(text)) continue;
  offenders.push(name);
}

if (offenders.length === 0) {
  console.log(`evidence-reaches-verifier: every diagnostic can leave the subject (${files.length} files)`);
  process.exit(0);
}
for (const o of offenders) {
  console.log(`FAIL ${o}: writes its report to a subject path with no transmission step`);
}
console.log('evidence-reaches-verifier: a report the verifier cannot reach is not evidence (invariant 42)');
process.exit(1);
