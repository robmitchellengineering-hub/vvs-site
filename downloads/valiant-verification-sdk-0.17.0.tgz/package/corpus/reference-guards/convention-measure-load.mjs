#!/usr/bin/env node
// Reference guard — invariant 35: "a measurement under load measures the rig".
//
// A number produced on a saturated machine is a finding about the rig, not about the code. The rule: every measurement result carries the load it
// was taken under, so a reader can tell "the build takes 40 s" from "the build takes 40 s while the box was at 97%".
//
// WHAT THIS CHECKS. Each module declared as `conventions.measure` must write a load figure into its result — a `load`, `loadavg`, `cpuPercent`
// or `rig` field — and must obtain it rather than hard-code a zero.
import { readFileSync, existsSync } from "node:fs";
import { join, resolve } from "node:path";
import { readConventions, CONVENTIONS, unenforced } from "../../src/conventions.mjs";

const root = resolve(process.argv[2] || ".");
const cfgPath = join(root, "valiant.json");
if (!existsSync(cfgPath)) { console.log("  ok   no valiant.json: nothing is adopted here"); process.exit(0); }
const cfg = JSON.parse(readFileSync(cfgPath, "utf8"));
const c = CONVENTIONS.find((x) => x.key === "measure");
const { declared, problems } = readConventions(cfg, root);
const mine = problems.filter((p) => p.key === "measure");
if (mine.length) { console.error(`  ${mine.map((m) => m.why).join("; ")}`); process.exit(1); }
if (declared.measure === undefined) { console.log("  " + unenforced(c)); process.exit(0); }

const FIELD = /\b(load|loadavg|loadAvg|cpuPercent|cpu_pct|rig)\b/;
const SOURCE = /(os\.loadavg|os\.cpus|uptime|vmstat|wmic|Get-CimInstance|process\.cpuUsage|performance\.now)/;
const HARDCODED = /\b(load|loadavg|cpuPercent|rig)\s*:\s*(0|"0"|null)\b/;
const bad = [];
for (const rel of declared.measure) {
  const f = join(root, rel);
  if (!existsSync(f)) { bad.push(`${rel}: declared but missing`); continue; }
  const src = readFileSync(f, "utf8");
  if (!FIELD.test(src)) bad.push(`${rel}: writes no load figure — a result without the rig state cannot be interpreted later`);
  else if (!SOURCE.test(src)) bad.push(`${rel}: names a load field but never reads the rig (os.loadavg / uptime / process.cpuUsage)`);
  else if (HARDCODED.test(src)) bad.push(`${rel}: writes a hard-coded zero load — that is the absence of a measurement dressed as one`);
}
if (bad.length) { console.error("  measurement without its rig:"); for (const b of bad) console.error(`    ${b}`); process.exit(1); }
console.log(`  ok   ${declared.measure.length} measurement module(s) record the load they ran under`);
process.exit(0);
