# Install and use Valiant

One tarball, no dependencies, no network at verify time. This page is the whole path from nothing to a gate that means
something. If a step does not work as written, that is a defect — the commands here are run before this page is committed.

---

## 1. What you need

- **Node 18 or newer** (`node --version`).
- **A licence file** from your issuer — a signed token beginning `vvs1.`, a few hundred bytes (it grows only when your issuer includes a revocation list). Without one, `valiant gate` refuses
  by design: it will not tell you a repo is fine unless it is licensed to run.
- That is all. Nothing else is downloaded, at install time or at run time.

## 2. Install

```sh
# download the current build and its checksum, then check what you got
curl -LO https://vvs.morpheus.nz/downloads/valiant-verification-sdk-0.3.0.tgz
curl -LO https://vvs.morpheus.nz/downloads/valiant-verification-sdk-0.3.0.tgz.sha256
shasum -a 256 -c valiant-verification-sdk-0.3.0.tgz.sha256
npm install -g ./valiant-verification-sdk-0.3.0.tgz
valiant --help
```

You should see `valiant — make "done" mean "verified"` followed by the command list. If you see
`command not found`, the global bin directory is not on your `PATH`.

**There is no npm, deliberately** — no third-party registry to depend on, to be unavailable, or to be taken over. Distribution is
ours: a package registry on our own domain, plus a plain download for anyone who would rather have a file.

```sh
# ask what exists and what is current
curl -s -X POST https://api.morpheus.nz/api/functions/listPackages -H 'content-type: application/json' -d '{}'

# install straight from our registry — "latest" or an exact version
npm install -g "https://api.morpheus.nz/api/functions/getPackage?name=valiant-verification-sdk&version=latest"
```

You should see the versions and their `sha256` from the first command, and a working `valiant --help` from the second — the tarball
comes back with its checksum in the `x-checksum-sha256` header, so a mirrored copy can be verified.

A plain file is still published for anyone who wants one, with its checksum:

```sh
curl -LO https://vvs.morpheus.nz/downloads/valiant-verification-sdk-0.3.0.tgz
curl -LO https://vvs.morpheus.nz/downloads/valiant-verification-sdk-0.3.0.tgz.sha256
shasum -a 256 -c valiant-verification-sdk-0.3.0.tgz.sha256
```

Install the licence, once per machine:

```sh
valiant licence --file ./acme.licence      # installs it and shows what it is
valiant licence --status                  # what this machine holds: plan, seats, expiry
```

You should see `licence OK` and a line naming the plan, the seats and the expiry date.

## 3. First run, in five minutes

In the repository you want verified:

```sh
valiant init
```

You should see `wrote …/valiant.json`, one `gate` line per check it found, and then either a guard it proved
and wrote for you, or the line `why I am not suggesting one: …`.

`init` finds the checks you already run — Node scripts, `scripts/run-tests.sh`, or nine other stacks (Python, Maven,
Gradle, .NET, Go, Rust, PHP, Ruby, Make) — and writes **one file**, `valiant.json`. It does not edit your code, and it
refuses to write a config that verifies nothing.

Then add one **guard**: a change to one of your files that one of those checks must catch. **`init` suggests one that it
has already proved is caught** — it picks a module your tests import, makes a concrete edit, and runs it through the real
mutation engine before printing it:

```
  1. add this guard to valiant.json — I have already proved it is caught:
     guard went red 2x under the sabotage and green 2x once it was undone
     breaks  pricing.js: export const TAX = 0.2; → export const TAX = 1.2;
```

You should see those three lines. The "guard went red Nx" line is the proof that this guard can fail — without it,
`init` prints nothing here and tells you why instead.

If no guard can be proved, `init` says so and refuses to invent one (`why I am not suggesting one: … SURVIVED`). Here is
the same shape by hand, for a repository whose `npm test` reads `pricing.js`:

You should see this written into `valiant.json` — the gate, and one guard naming a real line of a real file:

```json
{
  "gates": [{ "name": "test", "cmd": ["npm", "run", "test"] }],
  "ledger": false,
  "guards": [
    {
      "name": "tax-is-a-fifth",
      "file": "pricing.js",
      "find": "export const TAX = 0.2;",
      "replace": "export const TAX = 0.5;",
      "check": ["npm", "run", "test"]
    }
  ]
}
```

**Put the gate in front of the push** — so a red gate cannot reach a branch:

```sh
valiant hooks --install      # writes .git/hooks/pre-push and declares it in valiant.json
```

You should see `hooks: installed …/.git/hooks/pre-push` and `hooks: declared "pre-push:gate"`.

The hook runs `valiant gate` and blocks on **1 (broken) and 2 (could not check)** alike; it records every decision, so
`valiant decisions` shows it ran, and reports it as UNEXERCISED if it ever stops firing. `git push --no-verify` bypasses
it, and leaves no record — deliberately visible.

Now prove it, and ask for the verdict:

```sh
valiant mutate     # proves the guard can fail; writes mutations.json
valiant gate       # the verdict
```

You should see `1/1 mutations caught`, then the four contract lines, then `gate: every contract holds`.

`mutate` should say `1/1 mutations caught`. `gate` should end with **`gate: every contract holds`** and exit `0`.

### What each verdict word means

| word | meaning | what to do |
|---|---|---|
| `CAUGHT` | the check went red when the guard's subject was broken, and green when it was restored | nothing — this guard is real |
| `SURVIVED` | the check **passed** with the subject broken | your check does not test what you think; fix the check or the guard |
| `STALE` | the `find` string does not appear exactly once in the file | fix the string; a sabotage that changed nothing proves nothing |
| `UNSTABLE` | the check stayed red after the breakage was undone | the check depends on state outside the copy |
| `ALWAYS-RED` | the check fails with nothing sabotaged | the check is broken, not the guard |
| `CANNOT-RUN` | the check could not be executed, or answered `2` | fix the environment; this is not a detection |

## 3a. What each command costs

Measured on a repository with **one gate and one guard, where the check itself takes about 50 ms** (macOS, 2026-10-28):

| command | time | what it does |
|---|---|---|
| `valiant verify` | **0.3 s** | runs each declared gate once |
| `valiant mutate` | **1.7 s** | copies the repo and runs your check **5× per guard** — one clean, twice under the sabotage, twice once it is undone; guards are proved **in parallel** |
| `valiant gate` | **2.3–2.9 s** | verify + ledger + the whole proof + the SOP baseline |

Those are for a repository with **one gate and one guard, where the check is `node check.mjs` and takes ~90 ms**.

### The number that decides your speed: what you put in `check`

The same repository with the same check, but written as `npm run test`:

| check | one run | `gate` |
|---|---|---|
| `node check.mjs` | 90 ms | **2.3–2.9 s** |
| `npm run test` (which runs the same command) | 620 ms | **6.3–7.0 s** |

**npm's own startup is most of that.** The engine runs the check five times per guard, so a 0.5 s wrapper costs 2.5 s by
itself. If speed matters, name the command rather than the package-manager script:

```json
"check": ["node", "test/rules.mjs"]
```

You should see `gate` finish in about two seconds on the same repository, because the check no longer pays npm's startup
five times.

The proof cannot be cheaper than *your check × 5*. A three-minute suite makes `gate` about fifteen minutes, and that is
the nature of the guarantee, not the engine: the proof **is** running your check under a sabotage and watching it fail.

The re-execution sample is deliberate. An earlier version trusted a proof file the repository supplies, and a repository
can fabricate one; the SDK re-runs the sample from its own copy. It skips that re-run **only inside a single `gate`
invocation**, where the mutate segment proved every guard seconds earlier — and only via a one-shot marker file that is
written per run, age-limited, repo-matched, and deleted when read. Run `valiant sops check` on its own and it always
re-executes.

## 4. Where the verdict lands

`valiant ci-init` reads the machine and the repo, then picks a lane:

```sh
valiant ci-init                                   # GitHub remote → hosted runners, the account's own minutes
valiant ci-init --self-hosted                     # this machine runs the gate; prints the runner script for this OS
valiant ci-init --existing self-hosted,build-linux,gpu-a100   # enterprise runners already exist — nothing installed
valiant ci-init --mesh ./nodes                    # one matrix job per machine, each pinned to its own runner
valiant ci-init gitlab                            # .gitlab-ci.yml
valiant ci-init jenkins                           # Jenkinsfile
valiant ci-init --check                           # do the labels the workflow names actually exist?
```

You should see the lane it chose, the file it wrote, and — for a self-hosted lane — one registration script per machine.

It keeps three promises a CI step usually does not: a workflow written for one lane is not silently kept while another
lane's runner scripts are installed (`--force` to replace); a self-hosted node's own licence is never overwritten by an
empty secret; and `--check` with no way to look prints `UNVERIFIED` and exits 2, because absent evidence is not a pass.
Hosted runners need one secret, `VALIANT_LICENCE`; a node that already has a licence ignores it.

**Security tab (SARIF)** — a red gate as a code-scanning finding:

```sh
valiant verify --format sarif > valiant.sarif
```

You should see one JSON document and nothing else on stdout; `jq .runs[0].results | length` counts the findings.

Broken contract → `error`; could not check → `warning`. The two are never flattened.

## 5. Agents (MCP)

```sh
valiant mcp     # JSON-RPC over stdio; five tools
```

You should see nothing on stdout until a client sends a request — the server waits on stdin. Send
`{"jsonrpc":"2.0","id":1,"method":"initialize"}` and it answers with `serverInfo`.

Any MCP client can start it. A typical client entry:

```json
{
  "mcpServers": {
    "valiant": { "command": "valiant", "args": ["mcp"] }
  }
}
```

Tell the agent, once:

> Before reporting work as done, call `valiant_gate` and report its exit code: 0 every contract holds, 1 broken,
> 2 could not be checked. Do not describe a gate as passing unless `exitCode` is 0.

The server says the same thing in its `initialize` response, so a client that reads it does not need the prompt.

## 6. Managing the licence

```sh
valiant licence --status          # what this machine has
valiant licence --list            # every licence known here
valiant licence --html            # the same as a page you can open
valiant licence --revoke lic_m3k9x2   # the id shown by --list
```

You should see one row per licence with plan, seats, seats used, expiry and status, then a total.

Licences are **monthly** — 30 days, the billing period — and renew while the subscription is paid. A failed payment mints a **7-day grace licence**, so a declined card does not stop work immediately. When it stops, nothing is renewed, the licence runs out,
and `valiant gate` refuses with `licence expired N day(s) ago` and exit `2`.

## 7. Exit codes — the whole contract

| code | meaning |
|---|---|
| `0` | every contract holds |
| `1` | a contract is broken |
| `2` | a contract **could not be checked** (no licence, no config, a gate that did not run) |

`2` is never a pass. In CI it fails the job exactly like `1`.

## 8. When it does not work

| what you see | what it means |
|---|---|
| `this repo has no valiant.json yet` | run `valiant init` here |
| `init: I found no check to gate on` | no test command was found — the message lists every place it looked; add a gate by hand |
| `gate needs a licence on this machine` | `valiant licence --file <path>` |
| `licence expired …` | the subscription lapsed; renew it |
| `guard PASSED with the sabotage applied` | the check does not read the file you are breaking — see §3 |
| `find matches 2 times (must be exactly once)` | make the `find` string unique |
| `gate: a contract could not be checked` | a gate exited 2 or did not run; the line above names it |

## 9. What this does not do

- It cannot tell whether your check *means* anything. A check that keeps state outside its copy can look like a catch.
- It is not a security boundary: a check that writes outside its copy by absolute path is reported after the fact.
- It is not a hosted service: no account, no server, no network call. Seats are a local honour system.
- Scope today: one repository at a time, macOS and Linux. Windows is untested.
- Not on npm, and no CI service of ours — it produces a verdict, it does not become the queue.
