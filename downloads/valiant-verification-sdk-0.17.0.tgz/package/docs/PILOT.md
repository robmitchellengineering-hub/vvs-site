# Valiant — what this does, and what it does not

A one-page brief for a design partner. If anything here is wrong, that is a defect in the SDK, not in your reading.

## What you do

```sh
npm install -g ./valiant-verification-sdk-0.2.0.tgz
valiant init            # writes valiant.json — the only file it adds to your repo
#   add a guard (init prints a starting point)
valiant mutate          # proves the guard can fail; writes mutations.json
valiant gate            # the verdict: 0 every contract holds · 1 broken · 2 could not check
```

Adoption is one file, `valiant.json`. Our baseline of operating rules ships **inside the SDK**, signed, and is verified
there on every run — there is no copy in your repository to edit, delete or replay. Your own rules go in the same file
under `sopRules`.

## What it actually does

- **Runs your existing checks** — `npm test`, `pytest`, `go test`, anything that exits non-zero on failure. It never
  replaces them, and it never edits your code: every guard is exercised in a throwaway copy.
- **Proves a guard can fail** — it breaks the thing the guard protects, in that copy, and requires the check to go red;
  then it undoes the break and requires green. A guard that passes with the sabotage applied is reported `SURVIVED`,
  which is the useful answer: your check does not test what you think it tests.
- **Re-runs every proof it counts** — `mutations.json` rows carry `file`, `find`, `replace`, `check`, and `sample-proofs`
  re-executes them through the SDK itself. A proof it cannot re-run is refused, not accepted.
- **Enforces six baseline rules** — a gate really ran · evidence names its subject · a check must be able to fail · the
  baseline is unmodified · quality output is defined · nothing is remembered as done that was not checked.

## What it does not do

- **It cannot tell whether your check means anything.** A check that keeps state outside the copy (a counter in `/tmp`, a
  snapshot it compares later) can look like a catch. No tool can decide what arbitrary code does. What the SDK
  establishes is the observation: green, then red while the exact bytes were sabotaged, then green once restored — on a
  randomised number of trials — and it says so in those words rather than claiming your check *knows* why.
- **It is not a security boundary.** It runs your checks; a check that writes outside its copy by absolute path is
  reported after the fact (`no-disruption`), not prevented.
- **It is not a hosted service.** No account, no server, no network calls. The licence is a signed file on your machine;
  seats are a local honour system, per-home — they stop accidents, not intent.
- **Scope today:** one repository at a time, JS/TS first-class, macOS and Linux. Windows is untested.
- **Not on npm.** You get a tarball, not a registry package, and the licence comes from us directly.

## What to expect on day one

`gate` will be red until you have a guard whose proof is red — that is B3 doing its job, not a broken install. Expect to
spend the first hour turning one thing you already trust into one guard you have watched fail.

## If it is wrong

Every verdict is reproducible: the command that produced it is printed, the evidence file is in your repo, and
`valiant sample-proofs` re-runs the proofs. Send us the command and the output; a claim we cannot reproduce is a bug.
