# Licensing — from the payment to a working install

One page, end to end. Every step names the code that implements it, so a sentence here can be checked against the product
rather than believed.

The shape in one line: **a monthly subscription mints a short-lived signed licence; the licence is what the tool checks,
offline; when payments stop, nothing is minted and the tool refuses.**

---

## 0. What a licence covers — one machine and one CI runner, per seat

A **seat is a machine and a runner.** Every seat covers one developer machine *and* one CI runner, so a solo buyer's pipeline
can run `valiant gate` without a second seat, and a team that bought five seats gets five of each. Rob, 2026-11-02: *"a single
licence should allow you to build with vvs qa"* and then *"if you buy 5 seats thats 5 CI runners"*.

| seats bought | machines | CI runners |
|---|---|---|
| 1 | 1 | 1 |
| 5 | 5 | **5** |

The allowance is stated in the licence as a `runners` claim, so a buyer can see what they got without reading code.

A runner is recognised by the environment CI sets (`GITHUB_ACTIONS`, `GITLAB_CI`, `CIRCLECI`, `BUILDKITE`, `JENKINS_URL`,
`TF_BUILD`, and plain `CI=true` last). Anything unclear counts as a machine, because guessing "runner" would hand out free
seats. You should see both counts on one line when a licence is in use:

```sh
valiant licence --list
```

```
account    plan   machines  used  runners  used  expires      status
cus_solo12 solo   1         1     1        1     2026-11-28   valid
```

## 1. You pay

Stripe, per seat. The packages are defined in `PACKAGES` in morpheus `server/src/functions/createCertificationCheckout.js`:

| package | price | per seat | what it is |
|---|---|---|---|
| `sdk` | $25 / developer / month | **yes** | the SDK, standard |
| `sdk_ent` | $49 / developer / month | **yes** | same software; SSO, priority support, an SLA |
| `corpus` | $500 / month | no (flat) | the guard + hazard + method feed |
| `corpus_ent` | $1,500 / month | no (flat) | adds regulatory mappings, priority ingestion, badge audit |

**Per seat means per seat.** One licence covers the number of seats bought, and a seat is a **machine**: a laptop, a
desktop, and a CI runner are three seats. That is the rule, not a nuance — plan for it before a team installs.

## 2. The licence is minted

```
invoice.paid / invoice.payment_succeeded
   → morpheus /api/functions/stripeWebhook   (Stripe signature verified against the raw body)
   → mints a 30-day licence (the billing period), seats taken from the Stripe quantity
   → mails it to the Stripe customer as lic_abc123.licence
```

You should see the email arrive within a minute of the payment, with a `.licence` attachment whose filename starts `lic_`.

The signing is identical to this repo's own tool (`src/stripe-renew.mjs`), and morpheus runs
`scripts/verify-valiant-licence.mjs`, which asserts that **the SDK's own verifier accepts what morpheus signs** — so the two
implementations cannot drift apart silently.

## 3. You install

You need two things: the **tarball** and the **licence file**.

```sh
npm install -g ./valiant-verification-sdk-0.2.0.tgz
valiant licence --file ./lic_abc123.licence
valiant licence --status
```

You should see the plan, the seat count and the expiry date. The licence is stored at `~/.valiant/licence` (mode 600) and
is checked **offline** — no account, no network call, nothing to log in to.

Then, in the repository you want verified:

```sh
valiant setup
```

You should see four numbered steps ending in `gate: every contract holds`.

## 4. It renews while you pay

Every monthly payment mints a **new 30-day licence** and mails it — the licence lasts exactly as long as the period that was paid for. Replacing it is one command:

```sh
valiant licence --file ./lic_9f2c4a.licence
```

You should see the new expiry date, thirty days later than the last one.

Nothing else changes: your config, your proofs and your guards are untouched by a renewal.

## 5. When a payment fails — 7 days of grace, then it stops

A **failed payment is not an instant cut-off**. `invoice.payment_failed` mints a **7-day grace licence**, labelled
`grace: true` in its claims, so support can tell "we granted you a week" from "you paid". A declined card has that week to
be fixed; when the grace runs out, nothing more is minted:

You should see that grace licence arrive by email within a minute of the failure; `valiant licence --status` shows an
expiry seven days out:

```
invoice.payment_failed  → mints a 7-day grace licence (grace: true)
                       → after that: nothing
```

`customer.subscription.paused` and `customer.subscription.deleted` mint **nothing at all** — the last licence runs out when
it expires, and then:

```sh
valiant gate
```

You should see `valiant: this machine's licence is not valid: licence expired 2 day(s) ago` and exit **2** — a contract
that could not be checked.

That is the whole enforcement: **time, not a phone-home.** A machine that has gone quiet still stops, because its licence
has an expiry date in it. Exit 2 is red: a build that cannot check is not a build that passed.

## 5a. Verified online, with a 24-hour cache

Rob, 2026-11-02: *"licence verification needs to be done online"*, then *"24 hr cache"*. A licence that verified locally can still
have been revoked since, so the issuer is asked — and the four rules are opposites of each other on purpose:

| situation | what happens |
|---|---|
| the issuer says valid | allowed, and that verdict is believed for **24 hours** |
| the issuer says revoked | **refused now** — a revocation never waits for a cache to expire |
| the server cannot be reached, last verdict < 24 h | allowed, and the run **says** it is using a cached verdict |
| the server cannot be reached, no verdict in 24 h | **cannot check** — red, because an unreachable server is not a licence |

The cache is keyed by licence id, so a re-issued licence never inherits the previous one's health.

You should see the verdict and how old the cached answer is:

```sh
valiant licence --online            # ask now, print the verdict and the cache age
valiant licence --online --enable   # use it on every gate run
valiant licence --online --disable  # stop asking (the local check still applies)
```

It prints `online: OK (server)` or `online: OK (cache, 6h old)`, and on a refusal prints `online: REFUSED — …` with exit 2.

It is **opt-in** because turning every gate run into a network call would change what an existing install does the day it updates.

## 6. Revocation — loud first, then blocked

Rob, 2026-10-30: *"Block after grace."* A `jti` listed in `~/.valiant/revoked.txt` is not refused the instant it appears:

| | |
|---|---|
| **first 48 hours** | the gate **runs**, and every run prints one warning naming the hours left and the deadline |
| **after 48 hours** | `gate` exits **2** — *"was REVOKED on <date> and the grace has run out"* |

The reason for the middle phase is asymmetric risk: a revocation can be **wrong** — the wrong account, a key rotation, a
licence copied to an old laptop — and cutting a paying customer off instantly turns our mistake into their outage. A leaked
licence surviving two days is the smaller harm.

The clock starts when this machine **first sees** the id (recorded in `~/.valiant/revocations-seen.json`), not when the
licence was issued: otherwise grace would be either eternal or already used up.

You should see, on the first run after the list arrives:

```
valiant: WARNING — this licence (lic_9f2c41) has been REVOKED. It keeps working for 48 more hour(s), until
2026-11-01T09:00:00.000Z, so a wrong revocation is not an outage — after that every gate stops.
```

### How the list reaches a machine

Two carriers, both offline-safe — neither needs the SDK to call a server on every run:

1. **It travels with the licence.** A renewal can carry `revocations: [jti…]` as a signed claim. When a licence verifies,
   the gate absorbs that list into `~/.valiant/revoked.txt`. So the email a customer already receives is also the
   revocation update, and no endpoint has to exist.
2. **`--sync` for immediate action.**

```sh
valiant licence --sync https://example.com/revocations.vvs
valiant licence --sync /path/to/revocations.vvs
```

You should see the count and the list's date, and the command exits 0:

```
licence --sync: +2 new, 2 revoked id(s) held · list issued 2026-10-29 (file)
```

A list is the **second token type** in the same signed envelope (`kind: "revocations"`), so it is checked as strictly as a
licence — version, expiry, signature, a real array — and a licence cannot be passed off as one. Two refusals are
deliberate: an **edited** list fails its signature, and an **older** list is refused rather than merged, because a rollback
would resurrect a revoked licence. A list more than 30 days old prints a warning instead of pretending to be current.

### Publishing the list

The issuer mints one file and puts it anywhere a customer can fetch it. It is **public** — it names withdrawn ids and
nothing else — and it is signed, because an unsigned list is a wish: anyone could hand a customer a list bearing the
customer's own id.

```sh
node tools/mint-revocations.mjs --out revocations.vvs --from ~/.valiant/revoked.txt  # on the Mac, the issuing machine
node tools/mint-revocations.mjs --out revocations.vvs --jti lic_a --jti lic_b --days 90  # on the Mac
```

You should see the count, the key that signed it, and its expiry:

```
mint-revocations: 2 id(s), signed with vvs-2026-10, valid until 2027-01-27
```

It is published, and this is the URL to hand a customer:

https://vvs.morpheus.nz/revocations.vvs

Measured end to end on 2026-10-30: a machine with an empty list ran
`valiant licence --sync https://vvs.morpheus.nz/revocations.vvs` and held the revoked id afterwards. Nothing at the
customer's end needs updating — it verifies with the SDK they already installed.

**A revocation is recorded in the admin page and published from this Mac, so the two are kept in step by pulling.** The server
is remote and cannot write here, so the Mac reads what the database records:

```sh
tools/pull-revocations.sh   # on the Mac: merge the ids the database marks revoked
```

You should see the count of new ids and the total held:

```
pull-revocations: +2 new, 3 id(s) held — 2 of them new to this machine
```

It only ever **adds**: a list that can shrink is a list that can resurrect a revoked licence. If the database cannot be read
it exits 2 and changes nothing, because an empty list looks exactly like "nothing is revoked". The scheduled run does
pull-then-publish, so revoking someone in the admin page reaches the published list without anything being copied by hand.

**The cadence is the control, because the list expires.** One command re-mints and publishes it:

You should see the count, the term, and the live URL at the end:

```sh
tools/publish-revocations.sh            # on the Mac: mint, commit to the public site, merge
tools/publish-revocations.sh --dry-run  # mint and stop; publish nothing
```

Run it **whenever something is revoked** and **on a schedule** (weekly is enough for a 90-day term) — a list that is never
re-minted is a list that silently goes stale. On this Mac it is scheduled: a launchd agent
(`nz.morpheus.valiant.revocations`) runs it Mondays at 09:15, because the issuer key never leaves this machine and a node
cannot sign a list without it.

**It refuses to publish anything but the issuer's own list.** `~/.valiant/revoked.txt` is the only source it accepts; any
other file — including a symlink planted at that path — stops it with exit 2, because a publish script pointed at a test file
is pointed at production. When you do mean another source, say so explicitly and it prints the override:

```sh
tools/publish-revocations.sh --allow-other-source --from /path/to/other-list.txt
```

**The limit, stated plainly:** the list is **per machine**. A revocation reaches only machines that have been given the
file, and the grace above is per machine too. For a customer on the other side of the planet, **expiry is the control you
can rely on** — a monthly licence that stops being renewed stops working within a month, with no network call and no list to
deliver.

## 7. Operator runbook — "my licence expired"

1. Is the subscription `active` and paid in Stripe? If yes → the next `invoice.paid` re-mints; or mint by hand:
   `node tools/mint-licence.mjs --account <id> --plan team --seats 3 --days 7 --out acme.licence`.
2. If it is not paid, the answer is payment, not a licence. Saying otherwise is how a support relationship starts badly.
3. If the licence is present and current but refused: `valiant licence --status` names the reason — expired, revoked, seat
   count exceeded, or a `kid` this build does not carry (that last one means the tool is older than the signing key).

## 8. Customer runbook — "it stopped working"

| what you see | what it is | what to do |
|---|---|---|
| `licence expired N day(s) ago`, exit 2 | payment lapsed a week ago | renew, then `valiant licence --file <new>` |
| `licence … has been revoked` | the issuer revoked that `jti` | ask for a new licence; do not edit the file |
| `already used on N machine(s)` | seats are per machine and you are over | buy a seat, or release one by removing its entry from `~/.valiant/seats.json` |
| `this build has several signing keys but the licence names no key id` | the licence predates a key rotation | update the tool, or ask for a re-minted licence |
| exit 0, `gate: every contract holds` | working | nothing |

## 8a. Enforcement — where the gate actually stops something

A tool an agent may ignore is documentation. `valiant enforce --status` prints this table, and the installs make each row
true:

| where | what stops | command |
|---|---|---|
| `git push` | a red gate cannot leave the machine | `valiant hooks --install` |
| CI (GitHub, Jenkins, GitLab) | a red gate fails the job | `valiant ci-init` (hosted, self-hosted, existing labels, or a fleet) |
| **Claude Code** | the agent cannot finish a turn while the gate is red — a `Stop` hook exits 2 and hands it the reason | `valiant enforce --install claude` |
| **DSH** | the harness runs the gate before a completion-shaped command | `valiant enforce --install dsh` |

`valiant mcp` is the consultative half: it lets an agent *ask* for the verdict. The hook is the enforcement half: it runs
when the agent tries to finish. Both are needed — the tool for an agent that cooperates, the hook for one that does not.

## 9. What this deliberately is not

- **No phone-home.** Verification never contacts us. A licence is a signed file with an expiry date.
- **No seat telemetry.** Seat counting is local (`~/.valiant/seats.json`) — it stops accidents, not intent. A customer who
  edits the file is not detected; that is a decision, not an oversight, and it is why the price is per developer rather
  than per installation.
- **No account to log into** for the SDK itself. The licence page on the web is for issuing and revoking, not for running
  the tool.
