// licenceview.mjs — every licence this machine knows, verified, as a table or a standalone HTML page.
//
// Rob, 2026-10-27: "can you give me the link to the licence management i havent seen any of it yet". There was no view
// at all — only `--status` for the one active licence. There is no server and no account to log into: a verification
// tool that needs the internet to answer "is this still valid" is unusable on exactly the machines it exists for.
import { readFileSync, existsSync, readdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { homedir } from "node:os";
import { verifyLicence } from "./licence.mjs";
import { loadKeyring } from "./keyring.mjs";

export async function licenceView({ html = false } = {}) {
  const dir = join(process.env.HOME || homedir(), ".valiant");
  const store = join(dir, "licence");
  const kept = join(dir, "licenses.d");
  const seatsPath = join(dir, "seats.json");
  const revokedPath = join(dir, "revoked.txt");
  const here = dirname(fileURLToPath(import.meta.url));
  const pub = join(here, "..", "licence-public.pem");
  // THE KEYRING, NOT ONE KEY. A licence names the key that signed it (`kid`), and the issuer key was
  // rotated to vvs-2026-11 — so a build that trusted only `licence-public.pem` (the pre-rotation key)
  // rejected every licence minted after the rotation, with "the signature does not match this licence".
  // `src/keyring.mjs` was written for exactly this and then never imported; this is the import.
  // AN EXPLICIT KEY STILL WINS: setting VALIANT_LICENCE_KEY is a deliberate act.
  const ring = loadKeyring(join(here, "..", "licence-keys"));
  if (existsSync(pub)) ring["vvs-2026-10"] = readFileSync(pub, "utf8");
  const publicKeyPem = process.env.VALIANT_LICENCE_KEY
    || (Object.keys(ring).length ? ring : undefined);
  const revoked = (() => {
    try { return new Set(readFileSync(revokedPath, "utf8").split("\n").map((l) => l.trim()).filter(Boolean)); }
    catch { return new Set(); }
  })();
  const { revocationNotice } = await import("./revocation.mjs");
  let seats = { licences: {} };
  try { seats = JSON.parse(readFileSync(seatsPath, "utf8")); } catch { /* first use */ }

  const files = [];
  if (existsSync(store)) files.push({ where: store, text: readFileSync(store, "utf8").trim() });
  if (existsSync(kept)) {
    for (const f of readdirSync(kept)) {
      if (f.endsWith(".licence")) files.push({ where: join(kept, f), text: readFileSync(join(kept, f), "utf8").trim() });
    }
  }
  if (!files.length) {
    return { ok: false, code: 2, message: "no licence on this machine — `valiant licence --file <path>` installs one" };
  }

  const rows = [];
  for (const f of files) {
    const v = (() => { try { return verifyLicence(f.text, { publicKeyPem, revoked }); } catch (e) { return { ok: false, reason: e.message }; } })();
    if (!v.ok) { rows.push({ ok: false, where: f.where, reason: v.reason }); continue; }
    const c = v.claims;
    const used = seats.licences?.[c.jti] ?? [];
    // ONE LICENCE = ONE MACHINE + ONE CI RUNNER (Rob, 2026-11-02). `--status` must show BOTH counts, or a customer cannot tell
    // why a runner was accepted or refused — and "1 of 1 used" on a licence that also allows a runner reads like a full house.
    const kinds = Array.isArray(used)
      ? used.map((u) => (typeof u === "string" ? "machine" : u.kind ?? "machine"))
      : [];
    const usedMachines = kinds.filter((k) => k === "machine").length;
    const usedRunners = kinds.filter((k) => k === "runner").length;
    const allowance = {
      machines: c.plan === "enterprise" && !(c.seats > 0) ? "unlimited" : String(c.seats ?? 1),
      runners: String(Number.isInteger(c.runners) ? c.runners : 1),
    };
    rows.push({
      ok: true,
      account: `${String(c.sub ?? "").slice(0, 8)}…`,
      plan: c.plan,
      seats: allowance.machines,
      runners: allowance.runners,
      used: usedMachines,
      usedRunners,
      exp: new Date(c.exp * 1000).toISOString().slice(0, 10),
      revoked: revoked.has(c.jti),
      jti: c.jti,
    });
  }

  if (!html) {
    // One licence covers one machine per seat AND one CI runner, so both counts are shown. A single "used 1/1" column hid the
    // runner allowance entirely and made a licence look full when it could still build in CI.
    const lines = ["account    plan         machines     used  runners  used  expires      status"];
    for (const r of rows) {
      if (!r.ok) { lines.push(`  ${r.where} — ${r.reason}`); continue; }
      lines.push(`${r.account.padEnd(10)} ${String(r.plan).padEnd(12)} ${String(r.seats).padEnd(12)} ${String(r.used).padEnd(5)} ${String(r.runners).padEnd(8)} ${String(r.usedRunners).padEnd(5)} ${r.exp.padEnd(12)} ${r.revoked ? "REVOKED" : "valid"}`);
    }
    const valid = rows.filter((r) => r.ok && !r.revoked).length;
    lines.push("", `${valid} valid · ${rows.length - valid} not usable`);
    lines.push("one licence covers one machine per seat plus one CI runner; seats are a local honour system (docs/OPERATING.md §3)");
    return { ok: true, code: 0, text: lines.join("\n") };
  }

  const esc = (x) => String(x).replace(/[&<>]/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[m]));
  const tr = rows.map((r) => r.ok
    ? `<tr><td>${esc(r.account)}</td><td>${esc(r.plan)}</td><td>${esc(r.seats)}</td><td>${r.used}</td><td>${esc(r.exp)}</td><td class="${r.revoked ? "bad" : "ok"}">${r.revoked ? "revoked" : "valid"}</td><td><code>${esc(r.jti)}</code></td></tr>`
    : `<tr><td colspan="7" class="bad">${esc(r.where)} — ${esc(r.reason)}</td></tr>`).join("\n");
  return {
    ok: true, code: 0,
    text: `<!doctype html><meta charset="utf-8"><title>Valiant licences</title>
<style>
 body{font:15px/1.5 -apple-system,system-ui,sans-serif;margin:2.5rem auto;max-width:56rem;color:#111;padding:0 1rem}
 h1{font-size:1.15rem;margin:0 0 .25rem} .sub{color:#555;margin:0 0 1.5rem;font-size:.9rem}
 table{border-collapse:collapse;width:100%} th,td{text-align:left;padding:.55rem .5rem;border-bottom:1px solid #e5e5e5;font-size:.92rem}
 th{font-size:.72rem;text-transform:uppercase;letter-spacing:.05em;color:#666;font-weight:600}
 .ok{color:#0a6b2d;font-weight:600} .bad{color:#b00020;font-weight:600}
 code{font-size:.8rem;color:#555} .note{margin-top:1.75rem;color:#444;font-size:.85rem;border-top:1px solid #e5e5e5;padding-top:1rem}
</style>
<h1>Valiant licences on this machine</h1>
<p class="sub">${rows.filter((r) => r.ok && !r.revoked).length} valid · ${rows.length - rows.filter((r) => r.ok && !r.revoked).length} not usable · generated ${new Date().toISOString().slice(0, 16).replace("T", " ")}Z</p>
<table><tr><th>Account</th><th>Plan</th><th>Seats</th><th>Used here</th><th>Expires</th><th>Status</th><th>Licence id</th></tr>
${tr}
</table>
<p class="note"><strong>Seats are a local honour system.</strong> The tool records the machines a licence has been used on
(<code>~/.valiant/seats.json</code>) and refuses past its count, but the registry is per-home: copying a licence to a
machine with a fresh home starts a new count. The enforcement that matters is the signature, not the seat number.</p>`,
  };
}
