// guard-suggest.mjs — propose a FIRST guard, and only propose one that has been shown to be caught.
//
// The trap this closes: `init` used to suggest a placeholder against `package.json`, which `npm run test` does not read, so
// a customer's first attempt was `SURVIVED` — the tool telling them their check is worthless when the suggestion was the
// thing that was wrong.
//
// So the rule here is the product's own: a suggestion is not a suggestion until it has gone red. This module picks a file
// the check plausibly reads (a module the test files IMPORT, or a source file their text mentions), builds a concrete
// edit, and `init` then runs it through the real mutation engine. If it is not caught, it is not offered.
import { readdirSync, readFileSync, statSync, existsSync } from "node:fs";
import { join, extname, basename, dirname } from "node:path";

const SKIP_DIRS = new Set(["node_modules", ".git", "dist", "build", ".next", "coverage", ".venv", "target", "__pycache__", "vendor"]);
const CODE = new Set([".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".py", ".go", ".rs", ".java", ".cs", ".php", ".rb"]);
const TESTY = /(^|[._-])(test|spec)([._-]|$)|(^|\/)(tests?|spec)\//i;

const walk = (dir, root, out = []) => {
  let entries = [];
  try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of entries) {
    if (e.isDirectory()) { if (!SKIP_DIRS.has(e.name)) walk(join(dir, e.name), root, out); continue; }
    if (e.isFile() && CODE.has(extname(e.name).toLowerCase())) out.push(join(dir, e.name).slice(root.length + 1));
  }
  return out;
};

/** Relative imports/references from the test files — the strongest signal that a check READS a file. */
function importedModules(root, files) {
  const targets = new Set();
  for (const f of files) {
    let text = "";
    try { text = readFileSync(join(root, f), "utf8"); } catch { continue; }
    const specs = [
      ...text.matchAll(/(?:import|export)[^'"]*from\s*["'](\.[^"']+)["']/g),
      ...text.matchAll(/require\(\s*["'](\.[^"']+)["']\s*\)/g),
      ...text.matchAll(/from\s+["'](\.[^"']+)["']/g),
    ].map((m) => m[1]);
    for (const spec of specs) {
      const base = join(dirname(f), spec);
      for (const cand of [base, `${base}.js`, `${base}.mjs`, `${base}.ts`, `${base}.tsx`, `${base}.py`, `${base}.go`, join(base, "index.js")]) {
        if (existsSync(join(root, cand)) && !TESTY.test(cand)) { targets.add(cand); break; }
      }
    }
  }
  return [...targets];
}

/** A line worth breaking: prefers something with a literal in it (a number, a string, a boolean). */
function pickEdit(root, file) {
  let lines = [];
  try { lines = readFileSync(join(root, file), "utf8").split("\n"); } catch { return null; }
  const score = (l) => {
    if (l.trim().length < 8 || l.trim().startsWith("//") || l.trim().startsWith("#") || l.trim().startsWith("*")) return -1;
    if (/(=\s*[-0-9.]+;?|=\s*["'][^"']+["']|return\s+[-0-9."'])/.test(l)) return 3;
    if (/[=:]/.test(l)) return 2;
    return 1;
  };
  let best = null;
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    const s = score(l);
    if (s < 1) continue;
    if (lines.filter((x) => x === l).length !== 1) continue;   // must be unique in the file
    if (!best || s > best.s) best = { line: l, s, index: i };
    if (s === 3) break;
  }
  if (!best) return null;
  const find = best.line.trim();
  // A concrete, behaviour-changing edit. A numeric or string literal is flipped; otherwise the statement is disabled.
  let replace = null;
  const num = /(\b\d+(?:\.\d+)?\b)/.exec(find);
  const str = /(["'])([^"']{2,})\1/.exec(find);
  if (num) replace = find.replace(num[0], String(Number(num[0]) + 1));
  else if (str) replace = find.replace(str[0], `${str[1]}${str[2]}_broken${str[1]}`);
  else replace = `${find} /* valiant: sabotage */`;
  if (replace === find) return null;
  return { find, replace };
}

/**
 * The candidate guard: a real file, a real edit, and the gate's own command. The caller MUST prove it before offering it —
 * this function cannot know whether the check actually reads that file.
 */
export function candidateGuard(root, gateCmd) {
  const files = walk(root, root);
  const tests = files.filter((f) => TESTY.test(f));
  const targets = importedModules(root, tests);
  const ordered = [...targets, ...files.filter((f) => !TESTY.test(f))];
  for (const file of ordered.slice(0, 40)) {
    const edit = pickEdit(root, file);
    if (!edit) continue;
    return { name: "first-guard", file, find: edit.find, replace: edit.replace, check: gateCmd };
  }
  return null;
}
