// agents.mjs — enforcement where an AGENT works, not only where a human pushes.
//
// THE HOLE THIS FILLS. `valiant mcp` lets an agent ASK for the verdict; nothing makes it ask. An agent that never calls the
// tool reports "done" with the gate untouched, and the product's whole claim is that done means something. A tool an agent
// may ignore is documentation, not enforcement.
//
// Two hosts matter:
//   Claude Code  — `.claude/settings.json` hooks. A `Stop` hook runs when the agent tries to finish; a non-zero exit stops
//                  it and feeds the reason back. That is the moment "done" is attempted, so it is where the gate belongs.
//   DSH          — `~/.dsh/hooks/hooks.json`, `PreToolUse` on the shell, so a command that would claim completion is run
//                  through the gate first.
//
// Both files are edited surgically: existing entries are kept, entries that are already ours are not duplicated, and a
// malformed file is refused rather than overwritten.
import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { homedir } from "node:os";

export const MARKER = "installed by valiant enforce";

// THE HOOK MUST SCOPE ITSELF. A PreToolUse hook that runs `valiant gate` on EVERY tool call blocks everything: most calls
// happen in directories with no valiant.json, where the gate correctly exits 2 ("could not check"). So the hook asks the
// tool to decide: `enforce --hook` reads the event on stdin, and only a command that would CLAIM COMPLETION (a commit or a
// push) is gated. Everything else is allowed instantly.
// NO `|| exit 2`, AND NO BAKED-IN PATH. The first version ended with `|| exit 2`, which meant a missing checkout turned EVERY tool
// call in every session into a failure — a way-in risk, not enforcement — and it also masked the engine's own exit code, so "gate
// red" and "hook broken" looked identical. The command now resolves the CLI the same way the pre-push hook does and lets the engine
// decide: 0 allow, 2 block, and a clear sentence if the CLI cannot be found.
const hookCommand = (cliPath, event) => {
  // The Stop hook runs the gate, so it TELLS the gate that it is a hook — otherwise its blocks record nothing and a block without a
  // reason is the thing this project refuses.
  // THE ASSIGNMENT MUST PRECEDE THE COMMAND. `$V VALIANT_HOOK=… gate` passes the assignment as an ARGUMENT to the CLI, which then sees a
  // command word it does not know — measured: the Stop hook blocked but recorded nothing, which is exactly the gap this was meant to close.
  // THE STOP HOOK RUNS THE FAST VERDICT, NOT THE WHOLE GATE. Running all 36 gates on every turn took ten minutes on this repo, and a check that
  // slow is switched off — which is worse than a narrower one that says what it covers. `valiant check` is the turn-end verdict; `valiant gate`
  // stays where it is already paid for: pre-push and CI.
  const runner = event === "Stop" ? "check" : "enforce --hook";
  const prefix = event === "Stop" ? "VALIANT_HOOK=claude:stop " : "";
  return [
    'V="${VALIANT_BIN:-}"; ',
    `if [ -z "$V" ]; then if [ -f "${cliPath}" ]; then V="${process.execPath} ${cliPath}"; elif command -v valiant >/dev/null 2>&1; then V="$(command -v valiant)"; fi; fi; `,
    'if [ -z "$V" ]; then echo "valiant: the hook cannot find the CLI (checkout moved, and no valiant on PATH)" >&2; exit 2; fi; ',
    // THE HOST BLOCKS ON EXIT 2, NOT ON "NON-ZERO". Claude Code treats 2 as "block and hand the agent the reason"; a 1 is an error
    // it may not act on. So any failure is mapped to 2 — but the gate's OWN exit code is printed by the engine first, so "broken" and
    // "could not check" stay distinguishable to a human. (A test caught this: removing the mapping made a broken repo exit 1, which
    // is not a block.)
    `${prefix}$V ${runner}; code=$?; if [ $code -ne 0 ]; then exit 2; fi; exit 0`,
  ].join("");
};

/** The hook entry, in the shape both hosts use. */
const entry = (cliPath, event) => ({
  matcher: event === "Stop" ? "*" : "*",
  hooks: [{ type: "command", command: `${hookCommand(cliPath, event)}   # ${MARKER}` }],
  _valiant: MARKER,
});

const isOurs = (e) => JSON.stringify(e).includes(MARKER);

/** Read a JSON file, or return a fresh object. A malformed file is an error, never silently replaced. */
function readJson(path) {
  if (!existsSync(path)) return { ok: true, data: {} };
  const raw = readFileSync(path, "utf8");
  if (!raw.trim()) return { ok: true, data: {} };
  try { return { ok: true, data: JSON.parse(raw) }; }
  catch (e) { return { ok: false, why: `${path} is not valid JSON (${e.message}) — fix it before installing` }; }
}

export function installClaude(repoRoot, cliPath) {
  const path = join(repoRoot, ".claude", "settings.json");
  const r = readJson(path);
  if (!r.ok) return { ok: false, why: r.why };
  const cfg = r.data;
  cfg.hooks = cfg.hooks ?? {};
  const stop = Array.isArray(cfg.hooks.Stop) ? cfg.hooks.Stop : [];
  // UPGRADE, NOT SKIP. `stop.some(isOurs)` ended the install whenever our marker existed, so a hook written by an older build was never
  // replaced — the machine kept running the bug the new build fixed. Same fault as the DSH installer next door.
  const at = stop.findIndex(isOurs);
  if (at !== -1) {
    const want = entry(cliPath, "Stop");
    const have = stop[at]?.hooks?.[0]?.command ?? "";
    // AN INSTALL FROM AN OLDER BUILD LACKS THE PRE-TOOL HOOK, so "already installed" must also check for it — otherwise the new guard is never
    // added to a machine that has the old one (the same upgrade-vs-skip fault this installer already fixed for the hook text).
    const preHave = (Array.isArray(cfg.hooks.PreToolUse) ? cfg.hooks.PreToolUse : []).findIndex(isOurs);
    if (have === want.hooks[0].command && preHave !== -1) return { ok: true, path, already: true };
    stop[at] = want;
    cfg.hooks.Stop = stop;
    const pre = Array.isArray(cfg.hooks.PreToolUse) ? cfg.hooks.PreToolUse : [];
    if (preHave !== -1) pre[preHave] = entry(cliPath, "PreToolUse"); else pre.push(entry(cliPath, "PreToolUse"));
    cfg.hooks.PreToolUse = pre;
    try { writeFileSync(path, `${JSON.stringify(cfg, null, 2)}\n`); } catch (e) { return { ok: false, why: `could not rewrite ${path}: ${e.message}` }; }
    return { ok: true, path, upgraded: true };
  }
  cfg.hooks.Stop = [...stop, entry(cliPath, "Stop")];
  // AND A PRE-TOOL-USE HOOK. A Stop hook only fires when the agent FINISHES, so a commit it makes on the way is already in history by the time
  // anything objects. The pre-tool hook refuses the committing command itself — and passes every read-only call instantly, because `enforce --hook`
  // only gates what would CLAIM COMPLETION.
  const pre = Array.isArray(cfg.hooks.PreToolUse) ? cfg.hooks.PreToolUse : [];
  const preAt = pre.findIndex(isOurs);
  if (preAt !== -1) pre[preAt] = entry(cliPath, "PreToolUse"); else pre.push(entry(cliPath, "PreToolUse"));
  cfg.hooks.PreToolUse = pre;
  try {
    mkdirSync(dirname(path), { recursive: true });
    writeFileSync(path, `${JSON.stringify(cfg, null, 2)}\n`);
  } catch (e) { return { ok: false, why: `could not write ${path}: ${e.message}` }; }
  return { ok: true, path, already: false };
}

export function installDsh(cliPath, home = homedir()) {
  const path = join(home, ".dsh", "hooks", "hooks.json");
  const r = readJson(path);
  if (!r.ok) return { ok: false, why: r.why };
  const cfg = r.data;
  cfg.hooks = cfg.hooks ?? {};
  const pre = Array.isArray(cfg.hooks.PreToolUse) ? cfg.hooks.PreToolUse : [];
  // AN UPGRADE IS NOT A DUPLICATE. Seeing our marker used to end the install, so a hook written by an older build was never
  // replaced — the fix already shipped and the machine kept running the version with the bug. If ours is present but its command
  // differs, rewrite it in place.
  const ours = pre.findIndex(isOurs);
  if (ours !== -1) {
    const want = entry(cliPath, "PreToolUse");
    const have = pre[ours]?.hooks?.[0]?.command ?? "";
    if (have === want.hooks[0].command) return { ok: true, path, already: true };
    pre[ours] = want;
    cfg.hooks.PreToolUse = pre;
    try {
      mkdirSync(dirname(path), { recursive: true });
      writeFileSync(path, `${JSON.stringify(cfg, null, 2)}\n`);
    } catch (e) { return { ok: false, why: `could not rewrite ${path}: ${e.message}` }; }
    return { ok: true, path, upgraded: true };
  }
  cfg.hooks.PreToolUse = [...pre, entry(cliPath, "PreToolUse")];
  try {
    mkdirSync(dirname(path), { recursive: true });
    writeFileSync(path, `${JSON.stringify(cfg, null, 2)}\n`);
  } catch (e) { return { ok: false, why: `could not write ${path}: ${e.message}` }; }
  return { ok: true, path, already: false };
}

/** What is enforced where. Used by the docs and by `valiant enforce --status`. */
export function status(repoRoot, home = homedir()) {
  // The stance is shown FIRST, because "installed" and "enforcing" are different facts and a hook that is installed in advisory
  // mode blocks nothing.
  const claudePath = join(repoRoot, ".claude", "settings.json");
  const dshPath = join(home, ".dsh", "hooks", "hooks.json");
  const has = (p) => { const r = readJson(p); return r.ok && JSON.stringify(r.data).includes(MARKER); };
  const push = existsSync(join(repoRoot, ".git", "hooks", "pre-push")) &&
    readFileSync(join(repoRoot, ".git", "hooks", "pre-push"), "utf8").includes("installed by valiant hooks");
  return {
    push,
    claude: has(claudePath),
    dsh: has(dshPath),
    rows: [
      ["git push", push ? "enforced" : "not installed", "valiant hooks --install"],
      ["CI (GitHub/Jenkins/GitLab)", "enforced where the file is committed", "valiant ci-init <platform>"],
      ["Claude Code", has(claudePath) ? "enforced" : "advisory only — the agent may ignore it", "valiant enforce --install claude"],
      ["DSH harness", has(dshPath) ? "installed" : "not installed", "valiant enforce --install dsh"],
    ],
  };
}
