// selfcheck.mjs — the running tool proves it is the tool that was released.
//
// THE GAP. Every other check in this SDK trusts the code running it. A verifier whose own `src/` has been edited can report anything: one line in
// gates.mjs and a red contract reads green, and no gate would notice because the gate IS the edited code. `valiant pack` can sign a bundle, but
// nothing compared the running engine to that bundle.
//
// THE MECHANISM. `tools/release.mjs` writes `SELF.json` beside the engine — a sha256 per file over the files that DECIDE verdicts (`bin/`,
// `src/`, `corpus/reference-guards/`). `valiant selfcheck` recomputes and compares: a changed, added or removed engine file is named. It ships in
// the tarball, so an installed copy can be checked as well as a checkout.
//
// WHAT IT IS NOT. It is not a signature: `SELF.json` and the engine are in the same tree, so someone who edits both gets a consistent answer.
// Proving the engine was not tampered with needs the signed bundle (`valiant pack --verify` against the issuer key) — and this command says so in
// its output rather than implying more than a hash comparison can do.
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, relative } from 'node:path';
import { createHash } from 'node:crypto';

export const SELF = 'SELF.json';
/** The files that decide a verdict. A docs file changing is not an engine change; a gate's comparison changing is. */
// THESE DECIDE VERDICTS, so they are hashed. `tools/` holds every gate command and `valiant.json` holds the sabotage definitions: without them the
// release could prove "the tool is the tool" while the checks it runs, and the proofs that those checks can fail, were free to change
// (independent review, 2026-11-02).
const ENGINE_DIRS = ['bin', 'src', join('corpus', 'reference-guards'), 'tools'];
const ENGINE_FILES = ['valiant.json'];

const sha = (buf) => createHash('sha256').update(buf).digest('hex');

export function engineFiles(root) {
  const out = [];
  const walk = (dir) => {
    let entries = [];
    try { entries = readdirSync(dir); } catch { return; }
    for (const e of entries) {
      if (e === 'node_modules' || e === '.git') continue;
      const p = join(dir, e);
      let s = null;
      try { s = statSync(p); } catch { continue; }
      if (s.isDirectory()) walk(p);
      else if (e.endsWith('.mjs') || e.endsWith('.js')) out.push(relative(root, p));
    }
  };
  for (const d of ENGINE_DIRS) walk(join(root, d));
  for (const f of ENGINE_FILES) { try { if (statSync(join(root, f)).isFile()) out.push(f); } catch { /* absent */ } }
  return out.sort();
}

export function compute(root) {
  const files = {};
  for (const rel of engineFiles(root)) {
    try { files[rel] = sha(readFileSync(join(root, rel))); } catch { /* a file that vanished between listing and reading is reported by verify */ }
  }
  const engine = sha(Object.entries(files).map(([k, v]) => `${k}:${v}`).join('\n'));
  return { engine, files };
}

export function write(root, version) {
  const { engine, files } = compute(root);
  // WRITTENAT IS PRESERVED WHEN NOTHING ELSE CHANGED. A rewrite that only moves the timestamp is a diff that says "the engine changed" when it did
  // not — it made every `mutate` run look like it had altered the tree (found 2026-11-02, reported as "a file in this repo changed during mutate").
  let writtenAt = new Date().toISOString();
  try {
    const prev = JSON.parse(readFileSync(join(root, SELF), "utf8"));
    if (prev.engine === engine && prev.version === version) writtenAt = prev.writtenAt ?? writtenAt;
  } catch { /* no previous record */ }
  const body = {
    note: 'sha256 of the files that decide verdicts. Written by tools/release.mjs at pack time; `valiant selfcheck` compares the running engine to it. This is a change-detector, not a signature — use `valiant pack --verify` for provenance.',
    version,
    writtenAt,
    engine,
    files,
  };
  return body;
}

/** @returns {{ok:boolean, detail:string, changed:string[], added:string[], removed:string[], unrecorded:boolean}} */
export function verify(root) {
  const p = join(root, SELF);
  if (!existsSync(p)) {
    return { ok: true, unrecorded: true, changed: [], added: [], removed: [],
      detail: `no ${SELF} in this build — a development checkout cannot self-check. Released tarballs carry one (tools/release.mjs writes it).` };
  }
  let recorded;
  try { recorded = JSON.parse(readFileSync(p, 'utf8')); } catch (e) {
    return { ok: false, unrecorded: false, changed: [], added: [], removed: [], detail: `${SELF} is not valid JSON (${e.message})` };
  }
  const now = compute(root);
  const was = recorded.files ?? {};
  const changed = Object.keys(was).filter((f) => now.files[f] !== undefined && now.files[f] !== was[f]);
  const removed = Object.keys(was).filter((f) => now.files[f] === undefined);
  const added = Object.keys(now.files).filter((f) => was[f] === undefined);
  const ok = changed.length === 0 && removed.length === 0;
  const parts = [];
  if (changed.length) parts.push(`${changed.length} engine file(s) CHANGED: ${changed.slice(0, 4).join(", ")}`);
  if (removed.length) parts.push(`${removed.length} engine file(s) REMOVED: ${removed.slice(0, 4).join(", ")}`);
  if (added.length) parts.push(`${added.length} file(s) added (a new check is not a tamper)`);
  return { ok, unrecorded: false, changed, added, removed,
    detail: parts.length ? parts.join("; ") : `the running engine matches ${SELF} (${Object.keys(was).length} files, engine ${String(recorded.engine).slice(0, 12)})` };
}
