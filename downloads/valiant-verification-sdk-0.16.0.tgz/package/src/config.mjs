import { readFileSync } from "node:fs";
import { basename } from "node:path";

// Load and validate a config file. A config that does not name its gates and guards
// is refused, never guessed at. The config path is independent of the repo root so
// the SDK can drive a repo's checks without writing anything into that repo.
export function loadConfig(configPath, opts = {}) {
  let raw;
  try {
    raw = readFileSync(configPath, "utf8");
  } catch (e) {
    // The most common first-run failure in the whole tool. A bare ENOENT teaches nothing, so say what
    // this file is and the one command that writes it.
    const missing = e.code === "ENOENT";
    throw new Error(missing
      ? `this repo has no ${basename(configPath)} yet, so there is nothing to verify.\n` +
        `  To start:      valiant init            (writes one from the checks this repo already has)\n` +
        `  To copy one:   valiant init --print    (writes nothing, prints the config it would write)`
      : `cannot read config ${configPath} (${e.message})`);
  }
  let cfg;
  try {
    cfg = JSON.parse(raw);
  } catch (e) {
    throw new Error(`config ${configPath} is not valid JSON: ${e.message}`);
  }

  if (cfg === null || typeof cfg !== "object" || Array.isArray(cfg)) {
    throw new Error(`config ${configPath} must be a JSON object with "gates"`);
  }
  const gates = Array.isArray(cfg.gates) ? cfg.gates : [];
  const guards = Array.isArray(cfg.guards) ? cfg.guards : [];
  if (cfg.sops !== undefined && cfg.sops !== true) {
    throw new Error(`"sops" must be true or absent — the installed SOP baseline is not optional`);
  }
  const guardNames = new Set();
  for (const [i, g] of guards.entries()) {
    if (!g.name) throw new Error(`guards[${i}] needs a name`);
    if (guardNames.has(g.name)) throw new Error(`two guards are named "${g.name}" — a proof row names one guard, so a duplicate makes the evidence ambiguous`);
    // A GUARD MUST SAY WHICH RULE IT BACKS. A guard with no invariant is an assertion nobody can place: it can go red, be merged, and no reader can
    // tell which promise of the product it defends. `invariant` names a corpus id; `backs` is the sentence, because a number alone is a filing
    // cabinet. `"local": true` is the honest escape for a repo-specific rule that no corpus invariant covers.
    if (g.invariant === undefined && g.local !== true) {
      throw new Error(`guards[${i}] ("${g.name}") names no invariant. Add "invariant": <corpus id> and "backs": "<the rule in one sentence>", or "local": true if this guard is repo-specific and no corpus invariant covers it`);
    }
    if (g.invariant !== undefined && !Number.isInteger(g.invariant)) {
      throw new Error(`guards[${i}] ("${g.name}") has invariant ${JSON.stringify(g.invariant)} — it must be a corpus invariant id (a number)`);
    }
    guardNames.add(g.name);
  }

  // A CONFIG THAT NAMES NO GATE CANNOT BE SATISFIED, ONLY IGNORED. This used to load fine and report
  // "0/0 gates passed" then "every contract holds" — the exact sentence `valiant init` refuses to create.
  // Found by an independent review, 2026-10-26.
  // `allowEmpty` exists for one caller: `valiant verify --corpus`, where the gate set comes from the shipped
  // reference guards rather than the config. Without it the six guards are unreachable on the day someone
  // installs the tool and has not written any gates yet — the moment they most want to see it do something.
  if (gates.length === 0 && !opts?.allowEmpty) {
    throw new Error(`this config has no gates, so there is nothing to verify — "every contract holds" would be a lie.\n` +
      `  Write at least one:  "gates": [{ "name": "test", "cmd": ["npm", "run", "test"] }]`);
  }

  const gateNames = new Set();
  for (const [i, g] of gates.entries()) {
    if (!g.name || !Array.isArray(g.cmd) || g.cmd.length === 0) {
      throw new Error(`gates[${i}] needs a string "name" and a non-empty "cmd" array`);
    }
    if (g.type === "policy-tests") {
      // Validated at load, so a policy gate that cannot reject anything never reaches a run looking fine.
      if (!Array.isArray(g.cases) || g.cases.length === 0) throw new Error(`gates[${i}] ("${g.name}") is a policy-tests gate with no cases`);
      for (const [j, c] of g.cases.entries()) {
        if (!c || typeof c.input !== "string" || !c.input) throw new Error(`gates[${i}].cases[${j}] needs a string "input" (a path, appended to the command)`);
        if (c.expect !== "pass" && c.expect !== "fail") throw new Error(`gates[${i}].cases[${j}] needs "expect": "pass" or "fail"`);
      }
      if (!g.cases.some((c) => c.expect === "fail")) throw new Error(`gates[${i}] ("${g.name}") has no case that expects failure — a policy never shown to reject anything is not a policy`);
    } else if (g.type !== undefined) {
      throw new Error(`gates[${i}] ("${g.name}") has unknown type "${g.type}" (known: policy-tests)`);
    }
    if (gateNames.has(g.name)) throw new Error(`two gates are named "${g.name}" — a name has to identify one gate, or a verdict cannot say which one it came from`);
    gateNames.add(g.name);
  }
  for (const [i, g] of guards.entries()) {
    if (!g.name || !g.file || typeof g.find !== "string") {
      throw new Error(`guards[${i}] needs "name", "file", and "find"`);
    }
    if (typeof g.replace !== "string") {
      throw new Error(`guards[${i}] needs a "replace" string`);
    }
    const hasCheck = Array.isArray(g.check) && g.check.length > 0;
    const hasFixture = Array.isArray(g.fixture) && g.fixture.length > 0;
    if (hasCheck === hasFixture) {
      throw new Error(`guards[${i}] needs exactly one of "check" (subject flavour) or "fixture" (guard-logic flavour)`);
    }
    if (g.kind !== undefined && g.kind !== "check" && g.kind !== "claim") {
      throw new Error(`guards[${i}] has an unknown "kind" "${g.kind}" — use "check" or "claim"`);
    }
  }

  const ledger = (cfg.ledger === false || cfg.ledger === null) ? null : (cfg.ledger ?? "KNOWN-HAZARDS.md");
  const unprovenBaseline = cfg.unprovenBaseline ?? 0;
  if (!Number.isInteger(unprovenBaseline) || unprovenBaseline < 0) {
    throw new Error(`config "unprovenBaseline" must be a non-negative integer, got ${JSON.stringify(cfg.unprovenBaseline)}`);
  }
  // `prover: "external"` declares that this repo's guards are proved by its OWN runner and the proofs are
  // published in mutations.json. Without it, an empty guard list is refused rather than reported as 0/0 —
  // a run that proves nothing must not pass.
  const prover = cfg.prover === "external" ? "external" : null;
  // `proverCmd` names the command that produces this repo's proofs. Stripping it made the sample fall back to
  // a default prover that most repos do not have, so the re-run failed and the evidence looked fabricated.
  const proverCmd = typeof cfg.proverCmd === "string" && cfg.proverCmd.trim() ? cfg.proverCmd.trim() : null;
  // `hooks` were silently dropped here: `valiant decisions` declares the hooks it expects to see, and a config loader
  // that discards the list makes the UNEXERCISED check always pass. Optional, additive, validated.
  const hooks = cfg.hooks === undefined ? [] : (Array.isArray(cfg.hooks) ? cfg.hooks : null);
  if (hooks === null || hooks.some((h) => typeof h !== "string" || !h)) {
    throw new Error('config "hooks" must be an array of hook names (for example ["pre-commit", "route-to-mesh"])');
  }
  // `conventions` MUST SURVIVE THE LOADER. The loader returns an explicit object (so an unknown key never leaks into the engine), and the
  // artefact conventions were added after it was written — so every declaration was silently dropped and `valiant conventions` reported
  // "8 absent" for a repo that had declared two. Measured 2026-11-01: a config with conventions.context set still reported absent.
  return { gates, guards, ledger, strict: cfg.strict === true, unprovenBaseline, prover, proverCmd, hooks, decisionMaxAgeDays: cfg.decisionMaxAgeDays,
    conventions: cfg.conventions && typeof cfg.conventions === "object" && !Array.isArray(cfg.conventions) ? cfg.conventions : undefined,
    // THE GATE DEBT. How many gates may declare no sabotage. Recorded explicitly so the number is a decision a reader can see, not a silence:
    // a gate nobody has broken is a claim, and this is the count of claims the repo is carrying.
    // ABSENT IS NOT ZERO. Defaulting to 0 here made every repo with a gate fail on upgrade, because the ceiling is applied where the gate list is
    // known; the loader's job is to carry the value, not to decide the policy. `undefined` means "no ceiling recorded".
    unprovenGates: Number.isInteger(cfg.unprovenGates) && cfg.unprovenGates >= 0 ? cfg.unprovenGates : undefined };
}
