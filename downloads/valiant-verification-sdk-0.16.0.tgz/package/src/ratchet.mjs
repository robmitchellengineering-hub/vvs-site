// ratchet.mjs — the gate list and the proof set may GROW, never shrink quietly.
//
// THE GAP. Nothing recorded what a repo's checks were. A gate could be deleted, or swapped for a decorative one with the count unchanged, and the
// verdict stayed green — the SDK counted gates, never remembered them. The same hole sat under the proofs: `unprovenBaseline` absorbs "stale" and
// "not-run", so a guard that WAS proven could lose its proof and the run stayed green, calling it maintenance.
//
// THE MECHANISM. `valiant ratchet --write` records, in `valiant.lock.json`:
//   gates      — name → a hash of its command (so a renamed gate or a changed command is a different gate)
//   guards     — the guards that have a recorded red proof
//   baseline   — the unproven ceiling it was written under
//
// The gate then compares. REMOVALS are red and name what went. ADDITIONS are free — a repo must be able to add a check without a ceremony, or people
// stop adding checks. A proof that disappears from the set is red: a guard that was shown to fail and now cannot be shown is a regression.
//
// WHAT IT IS NOT. A header hash proves nothing against someone who edits both files. The lock is a RECORD of intent that makes drift visible in a
// diff — the same job the ledger's chain does, and with the same honest limit: it detects change, it does not stop a determined editor.
import { readFileSync, writeFileSync, existsSync, readdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { createHash, sign as signBytes, verify as verifyBytes } from 'node:crypto';

export const LOCK = 'valiant.lock.json';

const sha = (s) => createHash('sha256').update(s).digest('hex').slice(0, 16);

/** A gate's identity is its name AND its command: renaming or re-pointing a gate is a different check. */
export const gateKey = (g) => `${g.name} ${sha(JSON.stringify(g.cmd ?? null))}`;

/** The set of guards that carry a recorded red proof, from mutations.json. */
export function provenGuards(proofs) {
  // GATE ROWS ARE NOT GUARDS. Both live in mutations.json, so this set held 39 names for a repo with 4 guards — and when a GATE's row went stale the
  // ratchet reported "a guard that LOST its proof", which is what pushed a re-cut anchor instead of a restore (independent review, 2026-11-02).
  return [...new Set((proofs ?? []).filter((p) => (p.result === 'red' || p.verdict === 'caught') && p.kind !== 'gate').map((p) => p.guard).filter(Boolean))].sort();
}

export function readLock(repoRoot) {
  const p = join(repoRoot, LOCK);
  if (!existsSync(p)) return null;
  try { return JSON.parse(readFileSync(p, 'utf8')); } catch { return { broken: true }; }
}

/**
 * Sign the record with the issuer key when this machine has one, exactly as `pack` signs its manifest. An UNSIGNED record still catches drift in a
 * diff; a SIGNED one cannot be edited without the signature failing, which is the difference between "we noticed" and "it cannot be changed quietly".
 * A machine without a key produces an unsigned record rather than failing: adoption must not require an issuer key.
 */
export function signLock(repoRoot, lockBody) {
  const sigPath = join(repoRoot, `${LOCK}.sig`);
  try {
    const keyPath = join(process.env.HOME ?? "", ".valiant", "issuer-key.pem");
    if (!existsSync(keyPath)) return { signed: false, why: "no issuer key on this machine, so the record is a change-detector only" };
    const sig = signBytes(null, Buffer.from(lockBody), readFileSync(keyPath, "utf8"));
    writeFileSync(sigPath, `${sig.toString("base64")}\n`);
    return { signed: true, file: sigPath };
  } catch (e) { return { signed: false, why: `the record could not be signed (${e.message})` }; }
}

/** The public keys this build trusts, in the same order `pack --verify` tries them. */
function trustedKeys() {
  const here = dirname(new URL(import.meta.url).pathname);
  const out = [];
  const legacy = join(here, "..", "licence-public.pem");
  if (existsSync(legacy)) out.push(readFileSync(legacy, "utf8"));
  try {
    for (const f of readdirSync(join(here, "..", "licence-keys"))) {
      if (f.endsWith(".pem")) out.push(readFileSync(join(here, "..", "licence-keys", f), "utf8"));
    }
  } catch { /* no keyring: the legacy key is still tried */ }
  return out;
}

export function writeLock(repoRoot, cfg, proofs) {
  const lock = {
    note: 'Recorded by `valiant ratchet --write`. Gates and proofs may be ADDED freely; removing one, renaming one, or losing a proof is a regression the gate names.',
    writtenAt: new Date().toISOString(),
    gates: (cfg.gates ?? []).map(gateKey).sort(),
    proven: provenGuards(proofs),
    unprovenBaseline: Number.isInteger(cfg.unprovenBaseline) ? cfg.unprovenBaseline : 0,
  };
  writeFileSync(join(repoRoot, LOCK), `${JSON.stringify(lock, null, 2)}\n`);
  return lock;
}

/**
 * Compare reality to the lock.
 * @returns {{ok: boolean, added: string[], removed: string[], lostProofs: string[], detail: string}}
 */
export function compare(repoRoot, cfg, proofs) {
  const lock = readLock(repoRoot);
  // ABSENT IS NOT A VIOLATION. Adoption is one file by promise, so a repo that has never recorded its checks is not failing — it is told, in
  // every gate run, that removals would be invisible until it does. Turning that into a red would break the promise to protect a rule.
  if (!lock) return { ok: true, unrecorded: true, added: [], removed: [], lostProofs: [], detail: `no ${LOCK} yet — nothing has recorded this repo's checks, so a removed gate would be invisible. Record once with: valiant ratchet --write` };
  if (lock.broken) return { ok: false, added: [], removed: [], lostProofs: [], detail: `${LOCK} is not valid JSON, so it cannot be trusted as a record` };

  // A SIGNED RECORD MUST VERIFY. If a .sig exists and does not match the body against any key this build trusts, the record itself was edited —
  // which is the one thing a record cannot detect on its own.
  let sigNote = "";
  const sigPath = join(repoRoot, `${LOCK}.sig`);
  if (existsSync(sigPath)) {
    const body = Buffer.from(readFileSync(join(repoRoot, LOCK), "utf8"));
    let ok = false;
    for (const pem of trustedKeys()) {
      try { if (verifyBytes(null, body, pem, Buffer.from(readFileSync(sigPath, "utf8").trim(), "base64"))) { ok = true; break; } } catch { /* next key */ }
    }
    if (!ok) return { ok: false, added: [], removed: [], lostProofs: [], detail: `${LOCK}.sig does not verify against any key this build trusts — the record was edited after it was signed` };
    sigNote = ", signature valid";
  } else {
    sigNote = ", unsigned (a change-detector only)";
  }

  const now = new Set((cfg.gates ?? []).map(gateKey));
  const was = new Set(lock.gates ?? []);
  const removed = [...was].filter((k) => !now.has(k));
  const added = [...now].filter((k) => !was.has(k));

  const provenNow = new Set(provenGuards(proofs));
  const lostProofs = (lock.proven ?? []).filter((g) => !provenNow.has(g));

  const ok = removed.length === 0 && lostProofs.length === 0;
  const parts = [];
  if (removed.length) parts.push(`${removed.length} gate(s) REMOVED or re-pointed: ${removed.slice(0, 5).join(" · ")}`);
  if (lostProofs.length) parts.push(`${lostProofs.length} guard(s) LOST their proof: ${lostProofs.slice(0, 5).join(", ")} — a guard that was shown to fail and cannot be shown now is a regression, not maintenance`);
  if (added.length) parts.push(`${added.length} gate(s) added (allowed)`);
  return { ok, added, removed, lostProofs, detail: (parts.length ? parts.join("; ") : `all ${now.size} gate(s) and ${provenNow.size} proof(s) match the record`) + sigNote };
}
