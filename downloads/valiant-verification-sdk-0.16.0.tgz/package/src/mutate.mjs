import { spawnSync, spawn } from "node:child_process";
import { runCheck } from "./spawn.mjs";
import { readFileSync, writeFileSync, cpSync, rmSync, mkdtempSync, lstatSync, realpathSync, symlinkSync, existsSync, readdirSync, statSync } from "node:fs";
import { isAbsolute, relative, sep, join } from "node:path";
import { tmpdir, cpus } from "node:os";
// ONE TEMP ROOT PER COPY. Two copies under one root let a check list its sibling and compare the trees — a state-free way to fake a catch that defeats random names, red-twice and green-twice (review #10, F3.1).
const tmpdirRoot = (tag) => mkdtempSync(join(tmpdir(), `vvs-${tag}-`));

/**
 * Sweep this tool's own abandoned working roots. A run killed with Ctrl-C leaves a complete copy of the repo behind,
 * and a check that enumerates tmpdir can then compare itself against it and be graded CAUGHT without reading the
 * sabotage (independent review #13, F1). Only roots older than this process are removed, so a concurrent run is safe.
 */
// Roots this process is using, so an interrupt can remove them instead of leaving an oracle behind.
const ACTIVE_ROOTS = new Set();
let signalsInstalled = false;
function trackRoots() {
  if (signalsInstalled) return;
  signalsInstalled = true;
  for (const sig of ["SIGINT", "SIGTERM", "SIGHUP"]) {
    process.once(sig, () => {
      for (const r of ACTIVE_ROOTS) { try { rmSync(r, { recursive: true, force: true }); } catch { /* best effort */ } }
      process.exit(130);
    });
  }
}

export function sweepStaleCopies() {
  // A GRACE PERIOD WAS NOT ENOUGH, and deleting by name prefix alone was worse: it removed `$TMPDIR/valiant-notes-backup`
  // and the live working copy of a concurrent `sops check` (independent reviews #13 F1, #14 F2). A root is ours to
  // remove only when (a) it carries our ownership marker and that owner is dead, or (b) it is markerless but has
  // exactly mkdtemp's shape for this tool AND holds a `repo/` — which is what every version of this tool creates.
  let entries = [];
  try { entries = readdirSync(tmpdir()); } catch { return 0; }
  const MKD = /^(valiant|sops-rule|vvs-(clean|dirty))-[A-Za-z0-9]{6}$/;
  let removed = 0;
  for (const e of entries) {
    if (!/^(valiant-|sops-rule-|vvs-)/.test(e)) continue;
    const full = join(tmpdir(), e);
    let owner = null;
    let markerStat = null;
    try { owner = Number(readFileSync(join(full, ".valiant-owner"), "utf8").trim()); } catch { /* no marker */ }
    if (owner && Number.isFinite(owner)) {
      try { markerStat = statSync(join(full, ".valiant-owner")); } catch { continue; }
      if (typeof process.getuid === "function" && markerStat.uid !== process.getuid()) continue;   // someone else's
      let alive = true;
      try { process.kill(owner, 0); } catch (err) { alive = err.code === "EPERM"; }
      if (alive) continue;                                                                        // a live run
    } else {
      if (!MKD.test(e)) continue;                                                                 // not provably ours
      try { if (!statSync(join(full, "repo")).isDirectory()) continue; } catch { continue; }
    }
    try { rmSync(full, { recursive: true, force: true }); removed++; } catch { /* in use or gone */ }
  }
  return removed;
}


// The mutation-test contract (Valiant principle 2): a guard is proven only by a
// recorded run where a seeded fault was injected and the guard went RED. The real
// repo is never touched — the sabotage is applied to a throwaway copy, so a SIGKILL
// cannot leave a mutated guard behind. A find that matches 0 or >1 times is STALE,
// reported, never skipped silently (H19).
/**
 * Bring dependencies into the copy WITHOUT letting a check write the real tree. On APFS `cp -c` clones the tree
 * copy-on-write (cheap, and a write lands in the clone), so this is a real copy in everything but space. Where cloning is
 * unavailable we fall back to a symlink — and the caller hashes the real tree, so an escape is at least reported.
 */
function cloneDepsInto(repoRoot, copy) {
  for (const d of ["node_modules", ".venv"]) {
    const src = join(repoRoot, d);
    if (!existsSync(src) || existsSync(join(copy, d))) continue;
    const cloned = spawnSync("cp", ["-c", "-R", src, join(copy, d)], { encoding: "utf8" });
    if (cloned.status !== 0) {
      // NEVER A SYMLINK. `cp -c` is Darwin-only; on Linux this used to link the real dependency tree, so a check's write
      // landed in the customer's repo and was only reported afterwards (independent review #13, F4).
      const plain = spawnSync("cp", ["-R", src, join(copy, d)], { encoding: "utf8" });
      if (plain.status !== 0) return false;
    }
  }
}

const EXCLUDE = /(^|\/)(\.git|node_modules|\.venv|target|dist|build|__pycache__)(\/|$)/;
// Excluded from the COPY but linked into it: a test that imports a dependency must still run, or every check in a
// real JS repo reads as "always-red" and the SDK blames the customer's check (independent review #6, F3).
// ONLY READ-ONLY DEPENDENCY TREES ARE LINKED. `dist`, `build`, `target` and `__pycache__` are WRITTEN BY CHECKS, so
// linking them let a build write the real tree while "no-disruption" only noticed afterwards (review #8, C). They are
// copied instead, which costs space and buys the claim the README makes: the SDK never edits the repo.
const LINK_INTO_COPY = ["node_modules", ".venv"];

/**
 * Prove every guard, several at a time, by running this same CLI once per guard.
 *
 * MEASURED 2026-10-28: four guards cost 3.9s serially — and the cost is the customer's own check, run five times per
 * guard, which no optimisation of ours can remove. Each guard already works inside its own throwaway copy and touches
 * nothing shared, so proving them concurrently is free of ordering hazards: the wall clock becomes roughly the slowest
 * guard instead of the sum.
 *
 * A child process rather than threads, deliberately: the engine is proven synchronous (spawnSync, in-place file writes),
 * and re-entering it concurrently inside one process would put every one of those assumptions up for review at once.
 * the risk of a scheduling bug in the mutation engine is not worth the milliseconds saved.
 */
export function runAllMutationsParallel(guards, repoRoot, cliPath, concurrency = 0) {
  const n = concurrency > 0 ? concurrency : Math.max(1, Math.min(guards.length, Number(process.env.VALIANT_CONCURRENCY) || cpus().length));
  if (guards.length < 2 || n < 2) return guards.map((g) => runMutation(g, repoRoot));
  const results = new Array(guards.length);
  let next = 0;
  const worker = () => new Promise((resolve) => {
    const step = () => {
      const i = next++;
      if (i >= guards.length) return resolve();
      const g = guards[i];
      const child = spawn(process.execPath, [cliPath, "mutate", "--only", g.name], { cwd: repoRoot, stdio: ["ignore", "pipe", "pipe"] });
      let out = "";
      child.stdout.on("data", (c) => { out += c; });
      child.stderr.on("data", () => { /* the child reports through its JSON line */ });
      child.on("close", () => {
        const line = out.split("\n").reverse().find((l) => l.trim().startsWith("{"));
        try { results[i] = JSON.parse(line); } catch { results[i] = { name: g.name, result: "error", detail: "the child process returned no verdict" }; }
        step();
      });
    };
    step();
  });
  return new Promise((resolve) => {
    Promise.all(Array.from({ length: Math.min(n, guards.length) }, worker)).then(() => resolve(results));
  });
}

export function runMutation(guard, repoRoot) {
  const { name, file, find, replace, check, fixture } = guard;
  // Subject flavour: `file` is the thing being guarded, `check` is the guard.
  // Guard-logic flavour: `file` is the guard's own logic, `fixture` is a synthetic
  // exerciser that must go red once that logic is weakened.
  const verifyCmd = fixture ?? check;

  // THE SABOTAGE MUST NOT ESCAPE. `file` came straight from the config and was joined to the repo root, so a guard
  // could name `../../../../tmp/victim` or a symlink and the write went through to a real file outside the copy —
  // including the repo's own source, which was then left sabotaged while "no-disruption" reported failure
  // (independent review #6, F1). Absolute paths, `..`, symlinks and non-files are all refused here.
  if (typeof file !== "string" || !file || isAbsolute(file)) return { name, result: "error", detail: `guard file must be a relative path inside the repo (got ${JSON.stringify(file)})` };
  const subjectPath = join(repoRoot, file);
  const rel = relative(repoRoot, subjectPath);
  if (rel.startsWith("..") || isAbsolute(rel)) return { name, result: "error", detail: `guard file resolves outside the repo: ${file}` };
  try {
    if (lstatSync(subjectPath).isSymbolicLink()) return { name, result: "error", detail: `guard file is a symlink (${file}) — a symlink can point anywhere, so it is refused` };
    if (!lstatSync(subjectPath).isFile()) return { name, result: "error", detail: `guard file is not a regular file (${file})` };
    const realRepo = realpathSync(repoRoot);
    if (!realpathSync(subjectPath).startsWith(realRepo + sep)) return { name, result: "error", detail: `guard file resolves outside the repo: ${file}` };
  } catch (e) {
    return { name, result: "error", detail: `cannot inspect ${file}: ${e.message}` };
  }

  let src;
  try {
    src = readFileSync(subjectPath, "utf8");
  } catch (e) {
    return { name, result: "error", detail: `cannot read ${file}: ${e.message}` };
  }

  const count = src.split(find).length - 1;
  if (count === 0) return { name, result: "stale", detail: `find not present in ${file} (0 matches)` };
  if (count > 1) return { name, result: "stale", detail: `find matches ${count} times (must be exactly once)` };

  // ONE COPY, MUTATED IN PLACE. Two copies anywhere on disk can be compared by the check — separate mkdtemp roots
  // still share a parent, so `readdirSync(tmpdir())` found the sibling and a check that only compares the two trees was
  // graded CAUGHT (independent review #11, F2). Nothing here creates a second copy of the repo.
  sweepStaleCopies();
  trackRoots();
  const tmp = mkdtempSync(join(tmpdir(), "valiant-"));
  ACTIVE_ROOTS.add(tmp);
  try { writeFileSync(join(tmp, ".valiant-owner"), String(process.pid)); } catch { /* best effort */ }
  const copy = join(tmp, "repo");
  try {
    // TEST THE PATH RELATIVE TO THE REPO. The filter used to see the absolute path, so a repo whose own location
    // contained "dist" (or build/target/.git) had EVERY file excluded, proved nothing, and overwrote a good
    // mutations.json with red=0 (independent review #14, F1).
    cpSync(repoRoot, copy, { recursive: true, filter: (s2) => !EXCLUDE.test(relative(repoRoot, s2)) });
    if (cloneDepsInto(repoRoot, copy) === false) {
      return { name, result: "cannot-run", detail: "the project's dependencies could not be copied into a throwaway tree — running the check would risk the real ones" };
    }

    // The subject must exist in the copy — a file inside an excluded directory is not there, and that used to throw a
    // raw ENOENT instead of a verdict (independent review #9, F2.2).
    let targetReal = null;
    try { targetReal = realpathSync(join(copy, file)); }
    catch { return { name, result: "error", detail: `guard file is not in the throwaway copy (${file}) — it lives in a directory the copy excludes (dist, build, .git, …)` }; }
    const realCopy = realpathSync(copy);
    if (!targetReal.startsWith(realCopy + sep)) {
      return { name, result: "error", detail: `guard file resolves outside the throwaway copy (${file}) — it is inside a directory linked back to the repo` };
    }

    // A CHECK THAT NEVER RETURNS MUST NOT HANG THE GATE, and a check answering 2 (the tool's own "cannot check") is
    // not evidence of a fault. Reviews #14 F13/F14; the timeout is generous and overridable.
    const CHECK_TIMEOUT = Number(process.env.VALIANT_CHECK_TIMEOUT_MS ?? 600_000);
    const run = () => runCheck(verifyCmd, verifyCmd.slice(1), { cwd: copy, timeout: CHECK_TIMEOUT });
    const src = readFileSync(join(copy, file));   // the exact bytes, so the sabotage and the undo are exact
    const first = run();
    if (first.error) return { name, result: "cannot-run", detail: `the check could not be run at all (${first.error.code ?? first.error.message})` };
    if (first.signal || first.error?.code === "ETIMEDOUT") {
      return { name, result: "cannot-run", detail: `the check did not finish within ${CHECK_TIMEOUT}ms — that is not a verdict` };
    }
    if (first.status === 2) {
      return { name, result: "cannot-run", detail: "the check answered 2 (\"cannot check\"), which is not a detection of a fault" };
    }
    if ((first.status ?? 0) !== 0) {
      return { name, result: "always-red", detail: `the check is red with NOTHING sabotaged (exit ${first.status}) — it cannot distinguish a fault from its own brokenness` };
    }

    // A RANDOM PROTOCOL, so a run index cannot be mapped to a state. Then: red with the sabotage applied (twice, in
    // either order), and green once it is restored (twice). A check keyed on an invocation counter used to pass with
    // exit sequence 0,1,1,0,0 (review #11, F3).
    const trials = 2 + Math.floor(Math.random() * 2);
    const spliced = (() => {
      // BUFFER, NOT TEXT, and a replacement FUNCTION, not a string: `String.replace` expands `$&`/`$$` (so the declared
      // sabotage was not the one applied — review #14 F3), and a utf8 round trip corrupts a binary subject so the undo
      // could never restore it (F4).
      const i = src.indexOf(find);
      if (i < 0) return src;   // reported as stale by the caller
      return Buffer.concat([src.subarray(0, i), Buffer.from(replace, "utf8"), src.subarray(i + find.length)]);
    })();
    writeFileSync(join(copy, file), spliced);
    for (let t = 0; t < trials; t++) {
      const r = run();
      if (r.error) return { name, result: "cannot-run", detail: `the check could not be run under the sabotage (${r.error.code ?? r.error.message})` };
      if ((r.status ?? 0) === 0) {
        return { name, result: "survived", detail: "guard PASSED with the sabotage applied — it does not catch what it claims" };
      }
    }
    writeFileSync(join(copy, file), src);
    for (let t = 0; t < trials; t++) {
      const r = run();
      if (r.error) return { name, result: "cannot-run", detail: `the check could not be run after the undo (${r.error.code ?? r.error.message})` };
      if ((r.status ?? 0) !== 0) {
        return { name, result: "unstable", detail: "the check stayed red after the sabotage was undone — it is not detecting the sabotage" };
      }
    }
    return { name, result: "caught", trials, detail: `guard went red ${trials}x under the sabotage and green ${trials}x once it was undone` };
    } catch (e) {
      // A PROGRAMMING ERROR IS NOT A VERDICT. `runCheck` was once used here without being imported; the ReferenceError was
      // swallowed by this catch and reported as "cannot-run", so two suites went red and the cause looked like the
      // customer's check. Anything that is not an expected filesystem error is re-thrown, loudly.
      if (e instanceof ReferenceError || e instanceof TypeError) throw e;
      // AN UNREADABLE OR UNWRITABLE FILESYSTEM IS "CANNOT CHECK", not a crash (independent review #14, F6).
      return { name, result: "cannot-run", detail: `the check could not be set up (${e.code ?? e.message})` };
    } finally {
      try { rmSync(tmp, { recursive: true, force: true }); ACTIVE_ROOTS.delete(tmp); } catch { /* best effort */ }
    }
  }

export function runAllMutations(guards, repoRoot) {
  return guards.map((g) => runMutation(g, repoRoot));
}
